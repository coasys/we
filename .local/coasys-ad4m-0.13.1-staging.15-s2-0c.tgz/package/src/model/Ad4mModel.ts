import { Literal } from "../Literal";
import { Link } from "../links/Links";
import { LinkQuery } from "../perspectives/LinkQuery";
import { PerspectiveProxy } from "../perspectives/PerspectiveProxy";
import { CallOptions } from "../apiClient";
import { makeRandomId } from "./util";
import { getPropertiesMetadata, getRelationsMetadata, setPropertyRegistryEntry, setRelationRegistryEntry, Model } from "./decorators";
import type { PropertyOptions, PropertyMetadataEntry, RelationMetadataEntry } from "./decorators";
import { formatQueryValue, compileWhereClause } from "./query-utils";
import { requireSingleParent, requireTotalCount, resolveParentPredicate } from "./query-common";
import { isArrayType, determinePredicate, determineNamespace, buildModelFromJSONSchema } from "./json-schema";
import type { SHACLShape } from "../shacl/SHACLShape";
import type { RegisterResult } from "../generated/api/RegisterResult";
import type { JSONSchemaProperty, JSONSchema, JSONSchemaToModelOptions } from "./json-schema";

import { buildSPARQLQuery, valueToLiteralIri, effectiveLiteralStorage } from "./query-sparql";
import { ModelQueryBuilder } from "./ModelQueryBuilder";
import {
  normalizeValue,
} from "./hydration";
import type {
  Scope, TraverseScope, IncludeMap, Query,
  GetOptions, AllInstancesResult, Page, ResultsWithTotalCount,
  PaginationResult, PropertyMetadata, RelationMetadata, ModelMetadata,
  IncludeProjection,
  TypedQuery, IncludeExtras, IncludeOf, LinksMap,
} from "./types";
import { isContainedScope, isContainmentTraversal, isTraverseScope } from "./types";



// ---------------------------------------------------------------------------
// Helpers for Rust-side include resolution
// ---------------------------------------------------------------------------

/**
 * Construct a model class instance from a plain JSON object returned by the
 * Rust endpoint.  Recursively converts included relation values (which come
 * back as plain JSON objects) into proper model class instances.
 */
/**
 * Key under which the executor returns a polymorphically-hydrated instance's
 * concrete class.
 *
 * Half of a wire contract: the writer is `SUBJECT_CLASS_KEY` in
 * `rust-executor/src/perspectives/model_query/relations.rs`, and the two are
 * separate literals in separate languages. Renaming one alone does not fail to
 * compile — it degrades to every instance staying plain JSON, which looks
 * identical to a relation that declared no classes to build.
 * `tests/js/tests/model/model-polymorphic.test.ts` drives both ends against one
 * executor, so the drift fails a test rather than a user's query.
 *
 * The value is the class's target class IRI (two classes may share a name):
 * {@link classKey} of the class it was read as. The executor also returns
 * `__subjectClasses`, the whole set this one names the head of, by target
 * class IRI. Nothing here reads it — it rides onto the instance with every
 * other JSON key, for a caller that wants to know a choice was made.
 */
const SUBJECT_CLASS_KEY = '__subjectClass';

/** {@link Ad4mModel.hasCallActions} per class: a class's shape is fixed once
 *  it is declared. */
const callActionsCache = new WeakMap<Function, boolean>();

/**
 * The IRI the executor names `cls` by (`queriedAs`: its target class), or
 * `undefined` for something that is not a declared model class.
 */
function classKey(cls: unknown): string | undefined {
  try {
    const key = (cls as any)?.queriedAs?.();
    return typeof key === 'string' ? key : undefined;
  } catch {
    return undefined;
  }
}

/**
 * The namespace of a target class IRI: everything up to and including its
 * last `#`, `:` or `/`, the split the executor's `class_name_of` makes
 * (`urn:isbn:Book` → `urn:isbn:`, `a://b/c/Thing` → `a://b/c/`). `undefined`
 * when there is no local name after it.
 */
function namespaceOf(targetClass: string | undefined): string | undefined {
  if (!targetClass) return undefined;
  const split = Math.max(targetClass.lastIndexOf('#'), targetClass.lastIndexOf(':'), targetClass.lastIndexOf('/'));
  if (split < 0 || split === targetClass.length - 1) return undefined;
  return targetClass.slice(0, split + 1);
}

/**
 * Turn on `polymorphic` for every relation that declares it, at every depth of
 * an include map.
 *
 * A relation being heterogeneous is a fact about the data, not about one query,
 * so the declaration lives on the model and the call site writes
 * `include: { children: true }`. That has to hold just as much one level down:
 * in `include: { posts: { include: { children: true } } }`, `children` is a
 * relation on `Post`, so the walk carries the class it is reading against down
 * with it. Without that, a nested include of an untyped polymorphic relation
 * reaches the executor with no shape to resolve and fails the query outright.
 *
 * An explicit `polymorphic: false` at any level still wins — `undefined` is the
 * only state the default fills in.
 *
 * The walk stops descending *through* a polymorphic relation, because there is
 * nothing to descend into: its targets are of several classes by definition, so
 * no single class's metadata could say what a deeper include means. The
 * executor applies each concrete class's declared default from its shape
 * (`ad4m://polymorphic`) to those nested includes instead.
 */
function applyPolymorphicIncludeDefaults(includes: IncludeMap, ctor: Function): void {
  const relMeta = getRelationsMetadata(ctor);
  for (const [relName, val] of Object.entries(includes)) {
    // `$`-prefixed keys are projections, not relations.
    if (relName.startsWith('$')) continue;
    const meta = relMeta[relName];
    if (!meta) continue;

    let subQuery = val as any;
    if (meta.polymorphic) {
      if (val === true) {
        subQuery = { polymorphic: true };
        includes[relName] = subQuery;
      } else if (typeof val === 'object' && val !== null && subQuery.polymorphic === undefined) {
        subQuery.polymorphic = true;
      }
      // The classes this call site can build are also the classes it wants its
      // targets read as, so the declaration answers both questions and the call
      // site repeats neither. Sent as part of the query rather than applied to
      // the results: a preference in the request is reproducible by anyone who
      // sends it, where one applied afterwards would make the same data read
      // differently depending on which classes the caller happened to import.
      //
      // It ranks and does not narrow — a target matching none of them still
      // arrives — so declaring what you can construct never costs you a member
      // of a relation that is heterogeneous by definition.
      if (
        typeof subQuery === 'object' &&
        subQuery !== null &&
        subQuery.polymorphic &&
        subQuery.preferClasses === undefined &&
        meta.instantiateAs
      ) {
        const classes = (meta.instantiateAs() ?? [])
          .map(classKey)
          .filter((key): key is string => typeof key === 'string');
        if (classes.length) subQuery.preferClasses = classes;
      }
    }

    if (typeof subQuery !== 'object' || subQuery === null) continue;
    const nested = subQuery.include as IncludeMap | undefined;
    if (!nested || subQuery.polymorphic) continue;

    // The thunk is only evaluated here, at query time, so a self-referential or
    // circularly-imported target that is not yet defined costs the nested
    // default rather than the whole query.
    let TargetClass: any;
    try {
      TargetClass = meta.target?.();
    } catch (e) {
      // A class not yet initialised throws `ReferenceError` from the temporal
      // dead zone, which is the expected cost of an import cycle and not worth
      // saying anything about. Anything else — a thunk closing over nothing,
      // typically — is a broken declaration that would otherwise cost the nested
      // default in silence, so it gets said out loud.
      const circularImport = e instanceof ReferenceError;
      const say = circularImport ? console.debug : console.warn;
      say(`prepareModelQueryParams: target class unavailable for include '${relName}':`, e);
      continue;
    }
    if (TargetClass) applyPolymorphicIncludeDefaults(nested, TargetClass);
  }
}

/**
 * Split an include map into its relations and its `$`-prefixed projections.
 *
 * The two travel in different fields: a relation is hydrated, a projection is
 * computed over one. Both halves are new objects, so the caller's query is left
 * as it was written and can be sent again.
 */
function splitIncludeProjections(include: IncludeMap): {
  includes: IncludeMap;
  projections: Record<string, IncludeProjection>;
} {
  const includes: IncludeMap = {};
  const projections: Record<string, IncludeProjection> = {};
  for (const [key, val] of Object.entries(include)) {
    if (key.startsWith('$')) {
      projections[key] = { ...(val as IncludeProjection) };
    } else {
      includes[key] = val;
    }
  }
  return { includes, projections };
}

/**
 * Tag each projection with its target class IRI, so the executor can resolve
 * the target shape through its in-memory cache when applying a projection's
 * where-clause. `ctor` is the class the projections are read against; without
 * one (the members of a polymorphic relation) nothing is tagged, and the
 * executor resolves each projection against each member's own class.
 */
function tagProjectionTargets(projections: Record<string, IncludeProjection>, ctor: Function | undefined): void {
  if (!ctor) return;
  const allRelMeta = getRelationsMetadata(ctor);
  for (const proj of Object.values(projections)) {
    const relMeta = allRelMeta[proj.from];
    if (!proj.targetClassName && relMeta?.target) {
      try {
        const TargetClass = relMeta.target() as any;
        if (typeof TargetClass?.queriedAs === 'function') {
          proj.targetClassName = TargetClass.queriedAs();
        }
      } catch (e) { console.debug(`prepareModelQueryParams: target class unavailable for projection:`, e); }
    }
  }
}

/**
 * Move the `$`-prefixed keys of every nested include into that sub-query's own
 * `projections`, at every depth.
 *
 * The executor reads a sub-query exactly as it reads a top-level query, so a
 * projection on related records belongs in the sub-query's `projections` field,
 * as it does at the top. Left inside `include` it named a relation that does not
 * exist and was skipped: the query succeeded and the field was simply absent, so
 * `include: { posts: { include: { $likeCount: … } } }` came back without counts
 * and said nothing.
 *
 * Copies every sub-query it changes rather than editing it, so a query object
 * the caller keeps (a subscription re-preparing its query, say) still says what
 * it said.
 */
function liftNestedProjections(includes: IncludeMap, ctor: Function | undefined): IncludeMap {
  const relMeta = ctor ? getRelationsMetadata(ctor) : {};
  const out: IncludeMap = {};
  for (const [relName, val] of Object.entries(includes)) {
    if (typeof val !== 'object' || val === null || relName.startsWith('$')) {
      out[relName] = val;
      continue;
    }
    const subQuery: any = { ...val };
    // The class the nested keys are read against. A polymorphic relation's
    // members are of several classes, so there is none to name: its nested
    // projections go untagged and the executor resolves them per member class.
    let TargetClass: Function | undefined;
    if (!subQuery.polymorphic) {
      try {
        TargetClass = relMeta[relName]?.target?.();
      } catch (e) {
        console.debug(`prepareModelQueryParams: target class unavailable for include '${relName}':`, e);
      }
    }
    if (subQuery.include && typeof subQuery.include === 'object') {
      const { includes: nestedIncludes, projections } = splitIncludeProjections(subQuery.include);
      if (Object.keys(nestedIncludes).length > 0) {
        subQuery.include = liftNestedProjections(nestedIncludes, TargetClass);
      } else {
        delete subQuery.include;
      }
      if (Object.keys(projections).length > 0) {
        tagProjectionTargets(projections, TargetClass);
        subQuery.projections = { ...(subQuery.projections ?? {}), ...projections };
      }
    }
    out[relName] = subQuery;
  }
  return out;
}

function jsonToModelInstance<T extends Ad4mModel>(
  ModelClass: typeof Ad4mModel & (new (...args: any[]) => T),
  perspective: PerspectiveProxy,
  json: any,
  include?: IncludeMap,
  properties?: string[],
): T {
  const instance = new ModelClass(perspective, json.id || json.baseExpression) as any;

  // When a properties projection is active, remove own properties set by the
  // constructor that are not in the projected JSON.  This ensures assertions
  // like `expect(r).to.not.have.own.property("body")` pass.
  if (properties) {
    const jsonKeys = new Set(Object.keys(json));
    for (const key of Object.getOwnPropertyNames(instance)) {
      // Keep internal fields (backing store for getters), id, baseExpression, perspective
      if (key === 'id' || key === 'baseExpression' || key === 'perspective' || key.startsWith('_')) continue;
      if (!jsonKeys.has(key)) {
        delete instance[key];
      }
    }
  }

  for (const [key, value] of Object.entries(json)) {
    if (key === 'baseExpression' || key === 'id') continue;

    // Skip getter-only properties anywhere in the prototype chain
    let isReadonly = false;
    let proto = Object.getPrototypeOf(instance);
    while (proto) {
      const desc = Object.getOwnPropertyDescriptor(proto, key);
      if (desc) { isReadonly = !!(desc.get && !desc.set); break; }
      proto = Object.getPrototypeOf(proto);
    }
    if (isReadonly) continue;

    // Parse ISO timestamps to epoch milliseconds (matches hydrateFromLinks behaviour)
    if ((key === 'createdAt' || key === 'updatedAt') && typeof value === 'string' && value.includes('T')) {
      instance[key] = new Date(value).getTime();
      continue;
    }

    instance[key] = value;
  }


  // Recursively convert included relation values to class instances
  if (include) {
    const relMeta = getRelationsMetadata(ModelClass as any);
    for (const [relName, includeVal] of Object.entries(include)) {
      if (!includeVal) continue;
      const meta = relMeta[relName];
      // A polymorphic relation may legitimately declare no target at all —
      // that is the case it exists for — so it must not be gated on one.
      if (!meta) continue;
      if (!meta.target && !meta.polymorphic) continue;
      const TargetClass = meta.target?.() as any;
      // For a polymorphic relation the executor sends each child's concrete
      // class back on the instance, because it had to know it in order to
      // hydrate against the right shape at all. What it cannot send is the
      // constructor, so `instantiateAs` names the classes this side can build
      // and the target class → class map is derived from them: each class
      // knows its own target class IRI, which the executor names it by (two
      // classes may share a name).
      //
      // Built on first use rather than at decoration time, because the thunk
      // exists to be called late: a class defined further round a circular
      // import graph is not there yet when the decorator runs.
      let byTargetClass: Map<string, any> | undefined;
      // May resolve to nothing: a polymorphic relation is allowed to declare no
      // target at all, and the list may not name the class that arrived — it
      // says what this call site can construct, not what the relation may hold.
      // The item then stays plain JSON — correct data, carrying its target
      // class for a caller that wants to dispatch on it — rather than being
      // forced through a constructor that does not exist.
      const resolveChildClass = (item: any): any => {
        if (!meta.polymorphic) return TargetClass;
        const concrete = item?.[SUBJECT_CLASS_KEY];
        // No concrete class means this was not read polymorphically after all —
        // an explicit `polymorphic: false` at the call site — so the relation's
        // own declared target is the right shape.
        if (typeof concrete !== 'string') return TargetClass;
        if (meta.instantiateAs) {
          if (!byTargetClass) {
            byTargetClass = new Map();
            for (const cls of meta.instantiateAs() ?? []) {
              const key = classKey(cls);
              if (key) byTargetClass.set(key, cls);
            }
          }
          const cls = byTargetClass.get(concrete);
          if (cls) return cls;
        }
        // The declared target is not a fallback, and having named no classes to
        // build does not make it one. Where a relation both declares a target
        // and reads polymorphically, a child of some third class was hydrated
        // against *its own* shape, so constructing the declared class over that
        // JSON produces an instance that answers `instanceof` for a class it is
        // not, carrying fields that class never declared — the exact
        // mislabelling polymorphic reads exist to prevent. It fits only when it
        // is the class the executor named.
        return TargetClass && classKey(TargetClass) === concrete ? TargetClass : undefined;
      };
      const nestedInclude =
        typeof includeVal === 'object' && includeVal !== null
          ? (includeVal as any).include
          : undefined;
      const nestedProperties =
        typeof includeVal === 'object' && includeVal !== null
          ? (includeVal as any).properties
          : undefined;

      const raw = instance[relName];
      if (Array.isArray(raw)) {
        instance[relName] = raw.map((item: any) => {
          const ChildClass = resolveChildClass(item);
          if (ChildClass && typeof item === 'object' && item !== null && item.id) {
            return jsonToModelInstance(ChildClass, perspective, item, nestedInclude, nestedProperties);
          }
          return item;
        });
      } else if (typeof raw === 'object' && raw !== null && raw.id) {
        const ChildClass = resolveChildClass(raw);
        if (ChildClass) {
          instance[relName] = jsonToModelInstance(
            ChildClass, perspective, raw, nestedInclude, nestedProperties,
          );
        }
      }
    }
  }

  return instance;
}

/** One field write: the commands and parameters of one `executeAction`. */
interface FieldWrite {
  commands: any[];
  parameters: { name: string; value: any }[];
}

/** The most writes `sendWrites` joins into one `executeAction` call. */
const MAX_WRITES_PER_CALL = 200;

/**
 * Put `childId` under `parent`. A containment scope `{ id }` writes through the
 * built-in `Container` (#1446): the executor runs the adder of the parent's own
 * `children` relation when its class has one (a block's `we://child`), else
 * writes `ad4m://has_child`. The other forms write their one predicate.
 */
async function linkToParent(
  perspective: PerspectiveProxy,
  parent: Exclude<Scope, TraverseScope>,
  childCtor: Function,
  childId: string,
  batchId?: string,
): Promise<void> {
  if (isContainedScope(parent)) {
    await perspective.updateSubject(
      "ad4m://Container",
      parent.id,
      { children: { action: "adder", value: [childId] } },
      batchId,
    );
    return;
  }
  const link = new Link({
    source: parent.id,
    predicate: resolveParentPredicate(parent, childCtor),
    target: childId,
  });
  await perspective.add(link, 'shared', batchId);
}

/**
 * Base class for defining data models in AD4M.
 * 
 * @description
 * Ad4mModel provides the foundation for creating data models that are stored in AD4M perspectives.
 * Each model instance is represented as a subgraph in the perspective, with properties and relations
 * mapped to links in that graph. The class uses Prolog-based queries to efficiently search and filter
 * instances based on their properties and relationships.
 * 
 * Key concepts:
 * - Each model instance has a unique base expression that serves as its identifier
 * - Properties are stored as links with predicates defined by the `through` option
 * - Relations represent one-to-many relationships as sets of links
 * - Queries are translated to Prolog for efficient graph pattern matching
 * - Changes are tracked through the perspective's subscription system
 * 
 * @example
 * ```typescript
 * // Define a recipe model
 * @Model({ name: "Recipe" })
 * class Recipe extends Ad4mModel {
 *   // Plain property — no `resolveLanguage` → deterministic typed literal
 *   // storage (fast POS-index path). This is the perf default.
 *   @Property({ through: "recipe://name" })
 *   name: string = "";
 *
 *   // Property that needs per-value provenance (e.g. a signed message body):
 *   // `resolveLanguage: "literal"` routes values through expression_create on
 *   // the built-in literal language, producing a signed envelope URI
 *   // (author/timestamp/proof) instead of a bare typed literal.
 *   @Property({
 *     through: "recipe://signed_note",
 *     resolveLanguage: "literal"
 *   })
 *   signedNote: string = "";
 *
 *   // Property resolved through a custom language: values are routed through
 *   // expression_create on that language (signed expression URIs).
 *   @Optional({
 *     through: "recipe://photo",
 *     resolveLanguage: "QmFileStorageLanguageAddress..."
 *   })
 *   photo: string = "";
 *
 *   // Optional property with custom initial value
 *   @Optional({
 *     through: "recipe://status",
 *     initial: "recipe://draft"
 *   })
 *   status: string = "";
 * 
 *   // Read-only computed property
 *   @ReadOnly({
 *     through: "recipe://rating",
 *     getter: `
 *       findall(Rating, triple(Base, "recipe://user_rating", Rating), Ratings),
 *       sum_list(Ratings, Sum),
 *       length(Ratings, Count),
 *       Value is Sum / Count
 *     `
 *   })
 *   averageRating: number = 0;
 * 
 *   // Relation of ingredients
   *   @HasMany({ through: "recipe://ingredient" })
   *   ingredients: string[] = [];
 * 
 *   // Relation of comments linked to another model
 *   @HasMany(() => Comment, { through: "recipe://comment" })
 *   comments: Comment[] = [];
 * }
 * 
 * // Create and save a new recipe
 * const recipe = new Recipe(perspective);
 * recipe.name = "Chocolate Cake";
 * recipe.ingredients = ["flour", "sugar", "cocoa"];
 * await recipe.save();
 * 
 * // Query recipes in different ways
 * // Get all recipes
 * const allRecipes = await Recipe.findAll(perspective);
 * 
 * // Find recipes with specific criteria
 * const desserts = await Recipe.findAll(perspective, {
 *   where: { 
 *     status: "recipe://published",
 *     averageRating: { gt: 4 }
 *   },
 *   order: { name: "ASC" },
 *   limit: 10
 * });
 * 
 * // Use the fluent query builder
 * const popularRecipes = await Recipe.query(perspective)
 *   .where({ averageRating: { gt: 4.5 } })
 *   .order({ averageRating: "DESC" })
 *   .limit(5)
 *   .get();
 * 
 * // Subscribe to real-time updates
 * await Recipe.query(perspective)
 *   .where({ status: "recipe://cooking" })
 *   .subscribe(recipes => {
 *     console.log("Currently being cooked:", recipes);
 *   });
 * 
 * // Paginate results
 * const { results, totalCount, pageNumber } = await Recipe.query(perspective)
 *   .where({ status: "recipe://published" })
 *   .paginate(10, 1);
 * ```
 */
export class Ad4mModel {
  private _baseExpression: string;
  private _perspective: PerspectiveProxy;
  private _snapshot: Record<string, any> | null = null;
  /** Fields a static {@link Ad4mModel.update} was given on a call-backed
   *  class: dirty whatever the snapshot says ({@link changedFields}). */
  private _given: Set<string> | null = null;
  /** True when the constructor minted the id: no record can hold links yet. */
  private _idMinted: boolean = false;
  /** Predicates this instance has already written relation links under (`add*`/`set*`), so they may hold links. */
  private _relationsWritten = new Set<string>();
  author: string;
  createdAt: any;
  updatedAt: any;
  /**
   * Per-link rows for the entries asked for with `Query.links`, keyed as they
   * were asked. Absent when the query did not ask for any.
   */
  declare __links?: LinksMap;

  /**
   * Backwards compatibility alias for createdAt.
   * @deprecated Use createdAt instead. This will be removed in a future version.
   */
  get timestamp(): any {
    return (this as any).createdAt;
  }

  /**
   * Generates the SDNA (Subject DNA) Prolog rules for this model class.
   * Injected at class-definition time by the `@Model` decorator.
   * Returns a default value on un-decorated base classes.
   */
  static generateSDNA(): { sdna: string; name: string } {
    return { sdna: '', name: '' };
  }

  /**
   * Generates the SHACL shape graph for this model class.
   * Injected at class-definition time by the `@Model` decorator.
   * Returns `{ shape: null, name: '' }` on un-decorated base classes —
   * the decorator's `parentSHACL?.shape?.nodeShapeUri` check handles this.
   */
  static generateSHACL(): { shape: any; name: string } {
    return { shape: null, name: '' };
  }

  /** The `@Model` name of this class: its human-facing name. Two classes
   *  may share one; the executor addresses each by {@link getTargetClass}. */
  static getClassName(): string {
    const className = (this as any).className;
    if (!className) throw new Error(`Class ${this.name} has no class name: declare it with @Model.`);
    return className;
  }

  /** The target class IRI of this class (`sh:targetClass` of its shape),
   *  which the executor addresses it by. */
  static getTargetClass(): string {
    // A class from `fromSHACL` keeps the shape's own target class: its name
    // need not be the IRI's local name (a mount's `MountThing` for
    // `mounttest://Thing`), so the generated `namespace + name` is not it.
    const targetClass = this.importedShape()?.targetClass ?? this.generateSHACL().shape?.targetClass;
    if (!targetClass) throw new Error(`Class ${this.name} has no target class: declare it with @Model.`);
    return targetClass;
  }

  /**
   * Extracts metadata from decorators for query building.
   * 
   * @description
   * This method reads the metadata stored by decorators (@Property, @HasMany, etc.)
   * and returns it in a structured format that's easier to work with for query builders
   * and other systems that need to introspect model structure.
   * 
   * The metadata includes:
   * - Class name from @Model
   * - Property metadata (predicates, types, constraints, etc.)
   * - Relation metadata (predicates, filters, etc.)
   * 
   * For models created via `fromJSONSchema()`, this method will derive metadata from
   * the WeakMap registries that were populated during the dynamic class creation.
   * If these structures are empty but a JSON schema was attached to the class,
   * it can fall back to deriving metadata from that schema.
   * 
   * @returns Structured metadata object containing className, properties, and relations
   * @throws Error if the class doesn't have @Model decorator
   * 
   * @example
   * ```typescript
   * @Model({ name: "Recipe" })
   * class Recipe extends Ad4mModel {
   *   @Property({ through: "recipe://name" })
   *   name: string = "";
   *
   *   @HasMany({ through: "recipe://ingredient" })
   *   ingredients: string[] = [];
   * }
   * 
   * const metadata = Recipe.getModelMetadata();
   * console.log(metadata.className); // "Recipe"
   * console.log(metadata.properties.name.predicate); // "recipe://name"
   * console.log(metadata.relations.ingredients.predicate); // "recipe://ingredient"
   * ```
   */
  public static getModelMetadata(): ModelMetadata {
    // Access the prototype with any type to access decorator-added properties
    const prototype = this.prototype as any;
    
    // Validate that the class has @Model decorator
    // The decorator sets prototype.className, so we check for its existence
    if (!prototype.className || prototype.className === 'Ad4mModel') {
      throw new Error("Model class must be decorated with @Model");
    }
    
    // Extract className
    const className = prototype.className;
    
    // Extract properties from WeakMap registry
    const propertiesMetadata: Record<string, PropertyMetadata> = {};
    const prototypeProperties = getPropertiesMetadata(this);
    
    for (const [propertyName, opts] of Object.entries(prototypeProperties)) {
      const options = opts as PropertyOptions & { required?: boolean; flag?: boolean; writable?: boolean };
      propertiesMetadata[propertyName] = {
        name: propertyName,
        predicate: options.through || "",
        required: options.required || false,
        readOnly: !(options.writable ?? false),
        ...(options.initial !== undefined && { initial: options.initial }),
        ...(options.resolveLanguage !== undefined && { resolveLanguage: options.resolveLanguage }),
        ...(options.prologGetter !== undefined && { prologGetter: options.prologGetter }),
        ...(options.getter !== undefined && { getter: options.getter }),
        ...(options.prologSetter !== undefined && { prologSetter: options.prologSetter }),
        ...(options.local !== undefined && { local: options.local }),
        ...(options.flag !== undefined && { flag: options.flag }),
        ...(options.transform !== undefined && { transform: options.transform })
      };
    }
    
    // Extract relations (relations) from WeakMap registry
    const relationsMetadata: Record<string, RelationMetadata> = {};
    const allRelationsMeta = getRelationsMetadata(this as any);
    const prototypeRelations = allRelationsMeta;
    
    for (const [relationName, opts] of Object.entries(prototypeRelations)) {
      const options = opts as RelationMetadataEntry;
      relationsMetadata[relationName] = {
        name: relationName,
        predicate: options.predicate || "",
        ...(options.local !== undefined && { local: options.local }),
        ...(options.getter !== undefined && { getter: options.getter }),
        ...(options.readOnly && { readOnly: true }),
        direction: (options.kind === 'belongsToMany' || options.kind === 'belongsToOne') ? 'reverse' : 'forward',
        ...(options.kind !== undefined && { kind: options.kind }),
        ...(options.maxCount !== undefined && { maxCount: options.maxCount }),
        ...(options.target !== undefined && { target: options.target }),
        ...(options.filter !== undefined && { filter: options.filter }),
        ...(options.where !== undefined && { where: options.where }),
        ...(options.ordering !== undefined && { ordering: options.ordering }),
      };
    }
    
    // Fallback: If both structures are empty but a JSON schema is attached, derive from it
    // This handles edge cases where fromJSONSchema() was called but metadata wasn't properly populated
    const hasProperties = Object.keys(propertiesMetadata).length > 0;
    const hasRelations = Object.keys(relationsMetadata).length > 0;
    const hasMetadata = hasProperties || hasRelations;
    
    if (!hasMetadata && prototype.__jsonSchema) {
      // Derive metadata from the attached JSON schema
      const schema = prototype.__jsonSchema;
      const options = prototype.__jsonSchemaOptions || {};
      
      if (schema.properties) {
        for (const [propertyName, propertySchema] of Object.entries(schema.properties)) {
          const isArray = isArrayType(propertySchema as JSONSchemaProperty);
          const predicate = determinePredicate(
            schema, 
            propertyName, 
            propertySchema as JSONSchemaProperty, 
            determineNamespace(schema, options),
            options
          );
          
          if (isArray) {
            relationsMetadata[propertyName] = {
              name: propertyName,
              predicate: predicate,
              ...(propertySchema["x-ad4m"]?.local !== undefined && { local: propertySchema["x-ad4m"].local })
            };
          } else {
            const isRequired = schema.required?.includes(propertyName) || false;
            propertiesMetadata[propertyName] = {
              name: propertyName,
              predicate: predicate,
              required: isRequired,
              readOnly: propertySchema["x-ad4m"]?.writable === false,
              ...(propertySchema["x-ad4m"]?.resolveLanguage !== undefined && { resolveLanguage: propertySchema["x-ad4m"].resolveLanguage }),
              ...(propertySchema["x-ad4m"]?.initial && { initial: propertySchema["x-ad4m"].initial }),
              ...(propertySchema["x-ad4m"]?.local !== undefined && { local: propertySchema["x-ad4m"].local })
            };
          }
        }
      }
    }
    
    return {
      className,
      properties: propertiesMetadata,
      relations: relationsMetadata,
    };
  }

  /**
   * Constructs a new model instance.
   * 
   * @param perspective - The perspective where this model will be stored
   * @param baseExpression - Optional expression URI for this instance.
   *             If omitted, a random `ad4m://obj/<id>` IRI is generated,
   *             independent of any property content — this is what keeps
   *             two instances with identical property values distinct.
   * @param source - Optional source expression this instance is linked to
   *
   * @example
   * ```typescript
   * // Create a new recipe with auto-generated base expression
   * const recipe = new Recipe(perspective);
   *
   * // Create with specific base expression
   * const recipe = new Recipe(perspective, "ad4m://obj/existing-id");
   * ```
   */
  constructor(perspective: PerspectiveProxy, baseExpression?: string) {
    // Use a dedicated `ad4m://obj/<id>` scheme for auto-generated
    // baseExpressions instead of `Literal.from(...).toUrl()`'s
    // `literal:string:<id>`. After typed-literal storage lands, the storage
    // layer translates any `literal:string:X` target into a typed
    // `"X"^^xsd:string` literal — which is correct for property values but
    // wrong for relation targets (which must remain NamedNode IRIs). Using
    // a distinct scheme keeps auto-generated instance IDs unambiguously
    // IRIs, so relation links like `<post> --has_comment--> <comment-id>`
    // round-trip correctly through the SPARQL store.
    this._baseExpression = baseExpression ? baseExpression : `ad4m://obj/${makeRandomId(24)}`;
    this._idMinted = !baseExpression;
    this._perspective = perspective;
  }

  /**
   * The unique identifier (expression URI) of this model instance.
   */
  get id(): string {
    return this._baseExpression;
  }

  /**
   * Protected getter for the perspective.
   * Allows subclasses to access the perspective while keeping it private from external code.
   */
  protected get perspective(): PerspectiveProxy {
    return this._perspective;
  }

  /**
   * Get property metadata from decorator.
   * @private
   */
  private getPropertyMetadata(key: string): PropertyMetadataEntry | undefined {
    const ctor = this.constructor;
    const props = getPropertiesMetadata(ctor);
    return props[key];
  }

  /**
   * Get relation options from decorator
   * @private
   */
  private getRelationOptions(key: string): RelationMetadataEntry | undefined {
    const ctor = this.constructor;
    const rels = getRelationsMetadata(ctor);
    return rels[key];
  }

  /**
   * Generate property setter action from metadata.
   * @private
   */
  private generatePropertySetterAction(key: string, metadata: PropertyMetadataEntry): any[] {
    // Flags are always immutable — throw a clear error
    if (metadata.flag) {
      throw new Error(
        `Property "${key}" is a @Flag and cannot be written. ` +
        `Flags are immutable type markers set at creation time.`
      );
    }

    // Check if property is read-only
    if (metadata.readOnly) {
      throw new Error(`Property "${key}" is read-only and cannot be written`);
    }

    if (metadata.prologSetter) {
      // Custom Prolog setter - throw error for now (Phase 2)
      throw new Error(
        `Custom Prolog setter for property "${key}" not yet supported without Prolog. ` +
        `Use standard @Property decorator or enable Prolog for custom setters.`
      );
    }

    if (!metadata.through) {
      throw new Error(`Property "${key}" has no 'through' predicate defined`);
    }

    return [{
      action: "setSingleTarget",
      source: "this",
      predicate: metadata.through,
      target: "value",
      ...(metadata.local && { local: true })
    }];
  }

  /**
   * Generate relation action from metadata.
   * @private
   */
  private generateRelationAction(key: string, actionType: 'adder' | 'remover' | 'setter'): any[] {
    const metadata = this.getRelationOptions(key);
    if (!metadata) {
      throw new Error(`Relation "${key}" has no metadata defined`);
    }

    if (!metadata.predicate) {
      throw new Error(`Relation "${key}" has no predicate defined`);
    }

    const actionMap = {
      adder: "addLink",
      remover: "removeLink",
      setter: "collectionSetter"
    };

    return [{
      action: actionMap[actionType],
      source: "this",
      predicate: metadata.predicate,
      target: "value",
      ...(metadata.local && { local: true })
    }];
  }

  // ──────────────────────────────────────────────────────────
  //  Snapshot / dirty tracking
  // ──────────────────────────────────────────────────────────

  /**
   * @param includedRelations  Controls which relation fields are recorded
   *   in the snapshot for dirty-tracking:
   *     • `undefined` (default) — snapshot ALL relations (used by `.get()`,
   *       `.create()`, `.save()` etc. where full hydration has occurred).
   *     • `IncludeMap` object (e.g. `{ views: true }`) — only snapshot the
   *       relations named in the map.  Fields not listed are omitted from
   *       the snapshot so that `changedFields()` ignores them.
   *     • `null` / empty object — skip ALL relations (used by bare
   *       subscriptions that don't eagerly load relations).
   */
  /** @internal */
  protected takeSnapshot(includedRelations?: Record<string, any> | null): void {
    const ctor = this.constructor as typeof Ad4mModel;
    const metadata = ctor.getModelMetadata();
    const snap: Record<string, any> = {};

    // Always snapshot properties
    for (const propName of Object.keys(metadata.properties)) {
      const val = (this as any)[propName];
      snap[propName] = normalizeValue(
        Array.isArray(val) ? [...val] : val,
      );
    }

    // Snapshot relations only when appropriate:
    //   undefined → all relations (backward compat)
    //   IncludeMap → only the keys present in the map
    //   null / {} → none
    if (includedRelations === undefined) {
      // Full snapshot — e.g. after getData() / create()
      for (const relName of Object.keys(metadata.relations)) {
        const val = (this as any)[relName];
        snap[relName] = normalizeValue(
          Array.isArray(val) ? [...val] : val,
        );
      }
    } else if (includedRelations && Object.keys(includedRelations).length > 0) {
      // Partial snapshot — only the explicitly included relations
      for (const relName of Object.keys(includedRelations)) {
        if (relName in metadata.relations) {
          const val = (this as any)[relName];
          snap[relName] = normalizeValue(
            Array.isArray(val) ? [...val] : val,
          );
        }
      }
    }
    // else: null or empty object → skip all relations

    this._snapshot = snap;
  }

  /**
   * Returns `true` if any tracked property or relation has changed
   * since the last hydration (or since `takeSnapshot()` was last called).
   *
   * Always returns `true` if no snapshot exists (e.g. a freshly
   * constructed instance that hasn't been fetched yet).
   *
   * @example
   * ```typescript
   * const recipe = await Recipe.create(perspective, { name: "Pasta" });
   * recipe.isDirty();        // false — just hydrated
   * recipe.name = "Risotto";
   * recipe.isDirty();        // true
   * ```
   */
  isDirty(): boolean {
    if (!this._snapshot) return true;
    return this.changedFields().length > 0;
  }

  /**
   * Returns the names of properties/relations that differ from the
   * snapshot taken at the last hydration.
   *
   * Returns **all** field names if no snapshot exists.
   *
   * @example
   * ```typescript
   * recipe.name = "New Name";
   * recipe.changedFields(); // ["name"]
   * ```
   */
  changedFields(): string[] {
    const ctor = this.constructor as typeof Ad4mModel;
    const metadata = ctor.getModelMetadata();

    if (!this._snapshot) {
      return [
        ...Object.keys(metadata.properties),
        ...Object.keys(metadata.relations),
      ];
    }

    const changed: string[] = [];
    const allFields = [
      ...Object.keys(metadata.properties),
      ...Object.keys(metadata.relations),
    ];

    for (const field of allFields) {
      if (this._given?.has(field)) {
        changed.push(field);
        continue;
      }
      // Skip fields that were not recorded in the snapshot (e.g. relation
      // fields omitted because the originating query had no `include`).
      // Without this guard, a relation populated by hydrateFromLinks with
      // raw string IDs would appear "dirty" against a missing snapshot
      // entry and trigger an unnecessary (and potentially destructive)
      // setRelationValues call during innerUpdate.
      if (!(field in this._snapshot)) continue;

      const current = normalizeValue((this as any)[field]);
      const original = this._snapshot[field];

      if (Array.isArray(current) || Array.isArray(original)) {
        // For an ordered relation the sequence *is* the state, so a reorder is
        // the whole change and must mark the field dirty — sorting first would
        // make `save()` a no-op for the one edit the ordering feature exists to
        // support.
        //
        // Everything else compares order-insensitively, because an unordered
        // relation is a set: the executor returns its members by link timestamp,
        // and a caller who assigned the same members in another order has not
        // changed anything.
        const ordered = !!(metadata.relations as any)[field]?.ordering;
        const a = Array.isArray(current) ? [...current] : [];
        const b = Array.isArray(original) ? [...original] : [];
        if (!ordered) {
          a.sort();
          b.sort();
        }
        if (a.length !== b.length || a.some((v: any, i: number) => v !== b[i])) {
          changed.push(field);
        }
      } else if (current !== original) {
        changed.push(field);
      }
    }
    return changed;
  }

  private async getData(opts?: GetOptions) {
    // Route through the Rust model query endpoint — same pipeline as executeModelQuery
    // but for a single instance by ID.
    try {
      const ctor = this.constructor as typeof Ad4mModel;
      const query: Query = {
        where: { id: this._baseExpression },
        limit: 1,
        deepQuery: true,  // Single-instance get() always evaluates property getters
      };
      if (opts?.properties) query.properties = opts.properties;
      if (opts?.include) query.include = opts.include;

      const { results } = await (ctor as any).executeModelQuery(
        this._perspective, query, null
      );

      if (results.length > 0) {
        const hydrated = results[0];
        // Copy all hydrated values from the Rust-side result onto this instance
        for (const [key, value] of Object.entries(hydrated as any)) {
          if (key === '_baseExpression' || key === '_perspective' || key === '_snapshot') continue;
          if (key.startsWith('_')) continue;
          // Check for readonly getters
          let isReadonly = false;
          let proto = Object.getPrototypeOf(this);
          while (proto) {
            const desc = Object.getOwnPropertyDescriptor(proto, key);
            if (desc) { isReadonly = !!(desc.get && !desc.set); break; }
            proto = Object.getPrototypeOf(proto);
          }
          if (isReadonly) continue;
          (this as any)[key] = value;
        }
      }

      // Property getters and relation conformance getters are now evaluated
      // Rust-side via evaluate_getters() in model_query.rs.
    } catch (e) {
      console.error(`getData via Rust model query failed for ${this._baseExpression}:`, e);
    }

    this.takeSnapshot(opts?.include);
    return this;
  }

  /**
   * Generates a SPARQL query from a Query object.
   * 
   * @description
   * This method translates high-level query parameters into a SPARQL query string
   * that can be executed against the SPARQL backend. Unlike Prolog queries which
   * operate on SDNA-aware predicates, SPARQL queries operate directly on raw links
   * stored in SPARQL.
   * 
   * The generated query uses a CTE (Common Table Expression) pattern:
   * 1. First, identify candidate base expressions by filtering links based on where conditions
   * 2. Then, for each candidate base, resolve properties and relations via subqueries
   * 3. Finally, apply ordering, pagination (LIMIT/START) at the SQL level
   * 
   * Key architectural notes:
   * - SPARQL stores only raw links (source, predicate, target, author, timestamp)
   * - No SDNA knowledge at the database level
   * - Properties are resolved via subqueries that look for links with specific predicates
   * - Relations are similar but return multiple values instead of one
   * - Special fields (base, author, timestamp) are accessed directly, not via subqueries
   * 
   * @param perspective - The perspective to query (used for metadata extraction)
   * @param query - Query parameters (where, order, limit, offset, properties, relations)
   * @returns Complete SPARQL query string ready for execution
   * 
   * @example
   * ```typescript
   * const query = Recipe.queryToSPARQL(perspective, {
   *   where: { name: "Pasta", rating: { gt: 4 } },
   *   order: { timestamp: "DESC" },
   *   limit: 10
   * });
   * // Returns: SELECT source AS base, array::first(target[WHERE predicate = ...]) AS name, ...
   * //          FROM link WHERE ... GROUP BY source ORDER BY timestamp DESC LIMIT 10
   * ```
   */
  public static async queryToSPARQL(perspective: PerspectiveProxy, query: Query): Promise<string> {
    const metadata = this.getModelMetadata();
    const allRelMeta = getRelationsMetadata(this as any);
    return buildSPARQLQuery(metadata, allRelMeta, query, this);
  }

  /**
   * Build the JSON parameters needed for a model query/subscription endpoint.
   * Returns the className and queryJson that the Rust executor expects.
   * Shape resolution happens server-side from the perspective's SHACL triples.
   * @internal
   */
  /**
   * Whether this class's shape declares a language `call` action: a
   * constructor, destructor, or a property's setter, adder or remover (a
   * mounted class, whose records live in a language). Such a class writes
   * through the validated `perspective.instance*` RPCs, which run the
   * declared actions; every other class keeps its `executeAction` / subject
   * writes. A class from {@link fromSHACL} answers from the shape it was
   * made from.
   */
  static hasCallActions(): boolean {
    if (!callActionsCache.has(this)) {
      const shape = this.ownShape();
      const calls = (actions?: any[]) => (actions ?? []).some((a) => a?.action === 'call');
      callActionsCache.set(this, !!shape && (
        calls(shape.constructor_actions) ||
        calls(shape.destructor_actions) ||
        (shape.properties ?? []).some((p: any) => calls(p.setter) || calls(p.adder) || calls(p.remover))
      ));
    }
    return callActionsCache.get(this)!;
  }

  /** The shape this class's writes follow, actions included: the shape
   *  {@link fromSHACL} made it from ({@link importedShape}), else its
   *  generated one. {@link getTargetClass} reads the same.
   *  @internal */
  static ownShape(): any {
    return this.importedShape() ?? this.generateSHACL().shape;
  }

  /** The shape {@link fromSHACL} made this class from: its own, or the
   *  nearest ancestor's when no class in between was decorated with
   *  `@Model`. A decorated subclass has a generated shape of its own, and
   *  is addressed and written by that shape, not its parent's.
   *  @internal */
  static importedShape(): any {
    for (let c: any = this; c && c !== Ad4mModel; c = Object.getPrototypeOf(c)) {
      if (Object.prototype.hasOwnProperty.call(c, 'sourceShape')) return c.sourceShape;
      if (Object.prototype.hasOwnProperty.call(c, 'generateSHACL')) return undefined;
    }
    return undefined;
  }

  /**
   * The IRI the executor addresses this class by: its target class, or a
   * built-in abstract class's URI (`ad4m://TextContent`, #1446). The URI is
   * the class's own static only: a subclass is a class of its own.
   * @internal
   */
  static queriedAs(): string {
    const builtinUri = Object.prototype.hasOwnProperty.call(this, 'builtinUri') ? (this as any).builtinUri : undefined;
    return builtinUri || this.getTargetClass();
  }

  static prepareModelQueryParams(
    query: Query = {},
    classNameOverride?: string | null,
  ): { className: string; queryJson: string; metadata: ModelMetadata } {
    const metadata = this.getModelMetadata();
    const className = classNameOverride || this.queriedAs();

    // Expand includeAll: true to a full IncludeMap covering every forward relation.
    if (query.includeAll) {
      const allRelMeta = getRelationsMetadata(this as any);
      const expanded: IncludeMap = {};
      for (const [relName, relMeta] of Object.entries(allRelMeta)) {
        if ((relMeta as any).direction !== 'reverse') {
          expanded[relName] = true;
        }
      }
      query = { ...query, include: { ...expanded, ...query.include } };
    }

    const queryInput: any = {};
    if (query.parent && isContainedScope(query.parent)) {
      // Containment: the executor resolves the predicates from the installed
      // classes, so only the id travels.
      queryInput.parent = { id: query.parent.id };
    } else if (query.parent && isContainmentTraversal(query.parent)) {
      // A traversal over containment: no predicate travels either.
      const t = query.parent;
      const traverse: Record<string, unknown> = { ids: t.ids };
      if (t.transitive !== undefined) traverse.transitive = t.transitive;
      if (t.direction !== undefined) traverse.direction = t.direction;
      if (t.limitPerAnchor !== undefined) traverse.limitPerAnchor = t.limitPerAnchor;
      if (t.levels !== undefined) traverse.levels = t.levels;
      if (t.maxDepth !== undefined) traverse.maxDepth = t.maxDepth;
      queryInput.parent = traverse;
    } else if (query.parent) {
      const parentPredicate = resolveParentPredicate(query.parent, this);
      // A traversal keeps its own shape on the wire: the executor reads `ids`,
      // and flattening it to one `id` here is how a request for a whole level
      // would quietly become a request for one parent's children.
      //
      // Its fields are named rather than spread, because `model` — the class
      // itself — is how the scope may name its predicate, and that is a
      // constructor, not something to put in a query variable. The predicate is
      // resolved above; what travels is the result.
      if (isTraverseScope(query.parent)) {
        const t = query.parent;
        const traverse: Record<string, unknown> = {
          ids: t.ids,
          predicate: parentPredicate,
        };
        if (t.transitive !== undefined) traverse.transitive = t.transitive;
        if (t.direction !== undefined) traverse.direction = t.direction;
        if (t.limitPerAnchor !== undefined) traverse.limitPerAnchor = t.limitPerAnchor;
        if (t.levels !== undefined) traverse.levels = t.levels;
        if (t.maxDepth !== undefined) traverse.maxDepth = t.maxDepth;
        queryInput.parent = traverse;
      } else {
        queryInput.parent = { id: query.parent.id, predicate: parentPredicate };
      }
    }
    if (query.properties) queryInput.properties = query.properties;
    if (query.include) {
      // $-prefixed keys → queryInput.projections; all other keys (boolean |
      // RelationSubQuery) → queryInput.include.
      const { includes: normalIncludes, projections } = splitIncludeProjections(query.include);
      // A relation declared `polymorphic` reads that way by default, so the
      // caller writes `include: { children: true }` and still gets each child
      // hydrated as the class it actually is. Declaring it on the model rather
      // than repeating it at every call site is the point — the relation being
      // heterogeneous is a fact about the data, not about one query — but an
      // explicit `polymorphic: false` at the call site still wins. Applied at
      // every depth, since a nested include is a fact about the data too.
      if (Object.keys(normalIncludes).length > 0) {
        applyPolymorphicIncludeDefaults(normalIncludes, this as any);
        queryInput.include = liftNestedProjections(normalIncludes, this as any);
      }
      if (Object.keys(projections).length > 0) {
        tagProjectionTargets(projections, this as any);
        queryInput.projections = projections;
      }
    }
    if (query.where) queryInput.where = query.where;
    if (query.order) {
      queryInput.order = Object.entries(query.order).map(([k, v]) => [k, v]);
    }
    if (query.offset !== undefined) queryInput.offset = query.offset;
    if (query.limit !== undefined) queryInput.limit = query.limit;
    if (query.count !== undefined) queryInput.count = query.count;
    if (query.links) queryInput.links = query.links;
    queryInput.deepQuery = query.deepQuery ?? true;
    if (query.linkStatus != null) queryInput.linkStatus = query.linkStatus;
    if (query.includeUnverified !== undefined) queryInput.includeUnverified = query.includeUnverified;

    // Conformance getters, where filters, and target shapes for includes
    // are all resolved by the executor from the perspective's SHACL triples
    // — no client-side pre-computation is needed any more.

    return {
      className,
      queryJson: JSON.stringify(queryInput),
      metadata,
    };
  }

  /**
   * Parse raw model query/subscription result JSON into typed model instances.
   * Used by ModelQueryBuilder to convert subscription updates without circular imports.
   * @internal
   */
  static parseModelResult<T extends Ad4mModel>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    raw: any,
    include?: IncludeMap,
    properties?: string[],
  ): T[] {
    const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
    const arr = data.instances || data;
    if (!Array.isArray(arr)) return [];
    return arr.map((json: any) => jsonToModelInstance(this, perspective, json, include, properties));
  }

  /**
   * Snapshot freshly built instances for dirty tracking, with the relations
   * `include` loaded (its `$`-prefixed projection keys are not relations).
   * Used by every query path, and by ModelQueryBuilder for pushed results.
   * @internal
   */
  static takeSnapshots(instances: Ad4mModel[], include?: IncludeMap): void {
    const relations = include
      ? Object.fromEntries(Object.entries(include).filter(([k]) => !k.startsWith('$')))
      : undefined;
    const snapshot = relations && Object.keys(relations).length > 0 ? relations : undefined;
    for (const inst of instances) inst.takeSnapshot?.(snapshot);
  }


  // ── One query over several classes (#1238) ────────────────────────────────

  /**
   * Build the wire parameters for one query over several classes.
   *
   * Each class normalises the query as it would for itself — its polymorphic
   * include defaults, its `$` projections, its parent predicate — and the
   * results are merged: includes and projections by key (the first class that
   * declares a key decides its form; a projection two classes tag with
   * different target classes is refused), the parent scope only when every
   * class that can resolve it resolves it to the same predicate.
   * @internal
   */
  static prepareUnionQueryParams(
    classes: (typeof Ad4mModel)[],
    query: Query = {},
  ): { classNames: string[]; queryJson: string } {
    if (!classes.length) throw new Error('A query over several classes needs at least one class');
    const { parent, preferClasses, ...rest } = query;
    const inputs = classes.map((c) => JSON.parse(c.prepareModelQueryParams(rest).queryJson));
    // A projection is tagged with its relation's target class, at every depth,
    // and the executor hydrates a list projection (and resolves its `where`)
    // as that class. Two classes that tag the same key differently cannot share
    // one form of it, so the key is refused rather than read as the first's.
    const tags = new Map<string, string>();
    const collectTags = (node: any, path: string) => {
      if (!node || typeof node !== 'object') return;
      for (const [k, v] of Object.entries(node)) {
        if (k === 'targetClassName' && typeof v === 'string') {
          const seen = tags.get(path);
          if (seen !== undefined && seen !== v) {
            throw new Error(
              `projection '${path}': the classes resolve it to different target classes ` +
              `(${seen}, ${v}); query those classes separately`,
            );
          }
          tags.set(path, v);
        } else {
          collectTags(v, path ? `${path}.${k}` : k);
        }
      }
    };
    for (const input of inputs) {
      collectTags(input.include, 'include');
      collectTags(input.projections, 'projections');
    }
    const merged: any = { ...inputs[0] };
    if (preferClasses) merged.preferClasses = preferClasses;
    for (const key of ['include', 'projections'] as const) {
      const combined = Object.assign({}, ...inputs.map((i) => i[key] ?? {}).reverse());
      if (Object.keys(combined).length) merged[key] = combined;
      else delete merged[key];
    }
    if (parent) {
      // A model-form scope names its predicate through the relation that
      // targets the queried class, so each class may resolve it differently
      // or not at all. One query has one scope.
      const scopes: string[] = [];
      let firstError: unknown;
      for (const c of classes) {
        try {
          scopes.push(JSON.stringify(JSON.parse(c.prepareModelQueryParams({ parent }).queryJson).parent));
        } catch (e) {
          firstError ??= e;
        }
      }
      if (!scopes.length) throw firstError;
      if (new Set(scopes).size > 1) {
        throw new Error(
          'parent(): the classes resolve the parent scope to different predicates; ' +
          'pass the predicate itself (or a `field`) so they share one scope',
        );
      }
      merged.parent = JSON.parse(scopes[0]);
    }
    return {
      classNames: classes.map((c) => c.queriedAs()),
      queryJson: JSON.stringify(merged),
    };
  }

  /**
   * Build each row of a union result as the class the executor hydrated it as
   * (`__subjectClass`, the key it was asked for: {@link queriedAs}). A row of
   * a class not in `classes` stays plain JSON.
   * @internal
   */
  static parseUnionResult(
    classes: (typeof Ad4mModel)[],
    perspective: PerspectiveProxy,
    raw: any,
    include?: IncludeMap,
    properties?: string[],
  ): Ad4mModel[] {
    const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
    const arr = data.instances || data;
    if (!Array.isArray(arr)) return [];
    const byKey = new Map(classes.map((c) => [c.queriedAs(), c]));
    return arr.map((json: any) => {
      const cls = byKey.get(json?.[SUBJECT_CLASS_KEY]);
      return cls ? jsonToModelInstance(cls as any, perspective, json, include, properties) : json;
    });
  }

  /** @internal */
  static async executeUnionQuery(
    perspective: PerspectiveProxy,
    classes: (typeof Ad4mModel)[],
    query: Query = {},
    options?: CallOptions,
  ): Promise<Page<Ad4mModel>> {
    const { classNames, queryJson } = Ad4mModel.prepareUnionQueryParams(classes, query);
    const result = await perspective.modelQuery(classNames, queryJson, options);
    const results = Ad4mModel.parseUnionResult(classes, perspective, result, query.include, query.properties);
    Ad4mModel.takeSnapshots(results, query.include);
    return { results, totalCount: result.totalCount };
  }

  /**
   * One query over several model classes (#1238).
   *
   * `where`, `order`, `limit` and `offset` apply once, over the union. Each
   * result is an instance of the class the executor hydrated it as: the first
   * `preferClasses` entry it conforms to, otherwise the most specific of
   * `classes` it conforms to. A record that is several of them is returned
   * once; `__subjectClasses` on it names every class it conforms to.
   *
   * - `where` on a property a class does not declare excludes that class's rows.
   * - `order` on such a property sorts those rows last, in both directions,
   *   then by id.
   *
   * @example
   * ```typescript
   * const items = await Ad4mModel.findAllOf(perspective, [Placement, EdgeRoute], {
   *   parent: { id: canvas.id, predicate: "canvas://item" },
   *   order: { zIndex: "ASC" },
   *   limit: 50,
   * });
   * for (const item of items) {
   *   if (item instanceof Placement) { ... }
   * }
   * ```
   */
  static async findAllOf<C extends (typeof Ad4mModel)[]>(
    perspective: PerspectiveProxy,
    classes: [...C],
    query?: Query,
    options?: CallOptions,
  ): Promise<InstanceType<C[number]>[]> {
    const { results } = await Ad4mModel.executeUnionQuery(perspective, classes, query ?? {}, options);
    return results as InstanceType<C[number]>[];
  }

  /**
   * A {@link ModelQueryBuilder} over several model classes: the builder form of
   * {@link findAllOf}. `subscribe()` registers one subscription, which re-runs
   * when any of the classes changes.
   *
   * @example
   * ```typescript
   * const builder = Ad4mModel.queryOf(perspective, [Placement, EdgeRoute])
   *   .parent(canvas.id, "canvas://item");
   * await builder.subscribe((items) => render(items));
   * ```
   */
  static queryOf<C extends (typeof Ad4mModel)[]>(
    perspective: PerspectiveProxy,
    classes: [...C],
    query?: Query,
  ): ModelQueryBuilder<InstanceType<C[number]>> {
    return new ModelQueryBuilder<InstanceType<C[number]>>(perspective, Ad4mModel, query, classes);
  }

  // instancesFromQueryResult — removed (superseded by Rust executeModelQuery pipeline)

  /**
   * Execute a model query via the executor-side endpoint.
   * 
   * This replaces the old SPARQL-build → hydrate → JS-filter → JS-sort → JS-paginate pipeline
   * with a single RPC to the executor that handles everything in Rust.
   * 
   * @internal
   */
  private static async executeModelQuery<T extends Ad4mModel>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    query: Query = {},
    classNameOverride?: string | null,
    options?: CallOptions,
  ): Promise<Page<T>> {
    // Delegate query input building to the shared prepareModelQueryParams
    // helper.  The executor resolves the shape from SHACL server-side.
    const { className, queryJson } = this.prepareModelQueryParams(
      query, classNameOverride,
    );

    const result = await perspective.modelQuery(className, queryJson, options);

    // Convert JSON instances to model class instances, recursively constructing
    // class instances for any included relations resolved by Rust.
    const instances: T[] = result.instances.map((json: any) => {
      return jsonToModelInstance(this, perspective, json, query.include, query.properties);
    });

    Ad4mModel.takeSnapshots(instances, query.include);

    return {
      results: instances,
      totalCount: result.totalCount,
    };
  }

  /**
   * Gets all instances of the model in the perspective that match the query params.
   * 
   * @param perspective - The perspective to search in
   * @param query - Optional query parameters to filter results
   * @param _engine - **Deprecated.** Accepted for backward compatibility but ignored.
   *   All queries now use the Rust SPARQL pipeline.
   * @returns Array of matching models
   *
   * @example
   * ```typescript
   * const allRecipes = await Recipe.findAll(perspective);
   *
   * const recipes = await Recipe.findAll(perspective, {
   *   where: {
   *     name: "Pasta",
   *     rating: { gt: 4 }
   *   },
   *   order: { createdAt: "DESC" },
   *   limit: 10
   * });
   * ```
   */
  static async findAll<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    query?: Q,
    options?: CallOptions,
  ): Promise<(T & IncludeExtras<T, IncludeOf<Q>>)[]> {
    const q = (query ?? {}) as Query;
    if (q.properties && q.properties.length === 0) {
      throw new Error("properties[] must not be empty — omit the field to return all properties, or specify at least one field name");
    }

    const { results } = await this.executeModelQuery(perspective, q, undefined, options);
    return results as (T & IncludeExtras<T, IncludeOf<Q>>)[];
  }

  /**
   * Finds the first instance matching the query, or `null` if none exists.
   *
   * Equivalent to `findAll` with `limit: 1` — only one instance is hydrated.
   *
   * @param perspective - The perspective to search in
   * @param query - Optional query parameters to filter results
   * @param _engine - **Deprecated.** Accepted for backward compatibility but ignored.
   * @returns The first matching instance, or `null`
   *
   * @example
   * ```typescript
   * const recipe = await Recipe.findOne(perspective, {
   *   where: { name: "Pasta" }
   * });
   * if (recipe) {
   *   console.log(recipe.name);
   * }
   * ```
   */
  static async findOne<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    query?: Q,
    options?: CallOptions,
  ): Promise<(T & IncludeExtras<T, IncludeOf<Q>>) | null> {
    const limitedQuery = { ...((query ?? {}) as Query), limit: 1 } as Q;
    const results = await this.findAll<T, Q>(perspective, limitedQuery, options);
    return results[0] ?? null;
  }

  /**
   * Gets all instances with count of total matches without offset & limit applied.
   * 
   * @param perspective - The perspective to search in
   * @param query - Optional query parameters to filter results
   * @param _engine - **Deprecated.** Accepted for backward compatibility but ignored.
   * @returns Object containing results array and total count
   *
   * @example
   * ```typescript
   * const { results, totalCount } = await Recipe.findAllAndCount(perspective, {
   *   where: { category: "Dessert" },
   *   limit: 10
   * });
   * console.log(`Showing 10 of ${totalCount} dessert recipes`);
   * ```
   */
  static async findAllAndCount<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    query?: Q,
    options?: CallOptions,
  ): Promise<ResultsWithTotalCount<T & IncludeExtras<T, IncludeOf<Q>>>> {
    const answer = await this.executeModelQuery(perspective, { ...((query ?? {}) as Query), count: true }, undefined, options);
    return { results: answer.results as (T & IncludeExtras<T, IncludeOf<Q>>)[], totalCount: requireTotalCount(answer) };
  }

  /**
   * Helper function for pagination with explicit page size and number.
   * 
   * @param perspective - The perspective to search in
   * @param pageSize - Number of items per page
   * @param pageNumber - Which page to retrieve (1-based)
   * @param query - Optional additional query parameters
   * @returns Paginated results with metadata
   * 
   * @example
   * ```typescript
   * const page = await Recipe.paginate(perspective, 10, 1, {
   *   where: { category: "Main Course" }
   * });
   * console.log(`Page ${page.pageNumber} of recipes, ${page.results.length} items`);
   * ```
   */
  static async paginate<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    pageSize: number,
    pageNumber: number,
    query?: Q,
    options?: CallOptions,
  ): Promise<PaginationResult<T & IncludeExtras<T, IncludeOf<Q>>>> {
    const paginationQuery = { ...((query ?? {}) as Query), limit: pageSize, offset: pageSize * (pageNumber - 1), count: true };
    const answer = await this.executeModelQuery(perspective, paginationQuery, undefined, options);
    return { results: answer.results as (T & IncludeExtras<T, IncludeOf<Q>>)[], totalCount: requireTotalCount(answer), pageSize, pageNumber };
  }

  /**
   * Generates a SPARQL COUNT query for the model.
   * 
   * @param perspective - The perspective context
   * @param query - Query parameters to filter the count
   * @returns SPARQL COUNT query string
   * 
   * @private
   */
  // countQueryToSPARQL — removed (zero callers; Rust COUNT fast-path supersedes)

  /**
   * Gets a count of all matching instances.
   * 
   * @param perspective - The perspective to search in
   * @param query - Optional query parameters to filter results
   * @returns Total count of matching entities
   * 
   * @example
   * ```typescript
   * const totalRecipes = await Recipe.count(perspective);
   * const activeRecipes = await Recipe.count(perspective, {
   *   where: { status: "active" }
   * });
   * ```
   */
  static async count<T extends Ad4mModel>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    query?: TypedQuery<T>,
    options?: CallOptions,
  ): Promise<number> {
    return requireTotalCount(await this.executeModelQuery(perspective, { ...((query ?? {}) as Query), limit: 0, count: true }, undefined, options));
  }

  /** The `executeAction` write that sets property `key` to `value`; none for an empty value. */
  private async planProperty(key: string, value: any): Promise<FieldWrite[]> {
    const metadata = this.getPropertyMetadata(key);
    if (!metadata) {
      console.warn(`Property "${key}" has no metadata, skipping`);
      return [];
    }

    // Generate actions from metadata (replaces Prolog query)
    const actions = this.generatePropertySetterAction(key, metadata);

    // Skip storing empty/null/undefined values to avoid invalid empty literals (e.g. literal:string:)
    if (value === undefined || value === null || value === "") {
      return [];
    }

    const mode = effectiveLiteralStorage(metadata);
    if (mode.kind === "custom") {
      // Custom language: route through expression_create on that language.
      value = await this._perspective.createExpression(value, mode.language);
    } else if (mode.kind === "envelope") {
      // Built-in literal language: signed-envelope expression (provenance).
      value = await this._perspective.createExpression(value, "literal");
    } else {
      // Deterministic literal: IRI (POS-index friendly).
      value = valueToLiteralIri(value);
    }

    return [{ commands: actions, parameters: [{ name: "value", value }] }];
  }

  /**
   * The `executeAction` writes of a relation change: one for a set (its
   * `collectionSetter` takes every value), one per value for an add or remove.
   */
  private planRelation(key: string, kind: 'setter' | 'adder' | 'remover', value: any): FieldWrite[] {
    const metadata = this.getRelationOptions(key);
    if (!metadata) {
      console.warn(`Relation "${key}" has no metadata, skipping`);
      return [];
    }

    // Generate actions from metadata (replaces Prolog query)
    const actions = this.generateRelationAction(key, kind);

    if (value == null) return [];
    const values = Array.isArray(value) ? value : [value];
    const param = (v: any) => ({ name: "value", value: this.resolveRelationId(v) });
    if (kind === 'setter') return [{ commands: actions, parameters: values.map(param) }];
    return values.map(v => ({ commands: actions, parameters: [param(v)] }));
  }

  /**
   * Sends writes in as few `executeAction` calls as keep their links: the
   * executor runs a call's commands in order, so consecutive writes share one
   * call, each with its own parameter names. A `collectionSetter` takes every
   * parameter of its call as a member, so it goes in a call of its own. A
   * command's `local` flag is per command, so Local and Shared links mix. The
   * executor tries every parameter name at each position of each command, so
   * a call holds at most `MAX_WRITES_PER_CALL` writes.
   */
  private async sendWrites(writes: FieldWrite[], batchId?: string): Promise<void> {
    let group: FieldWrite[] = [];
    const flush = async () => {
      if (group.length === 1) {
        await this._perspective.executeAction(group[0].commands, this._baseExpression, group[0].parameters, batchId);
      } else if (group.length > 1) {
        const commands: any[] = [];
        const parameters: { name: string; value: any }[] = [];
        group.forEach((write, i) => {
          // The executor substitutes a parameter name wherever it occurs in a
          // command's source, predicate or target; rename `value` the same way.
          const name = `ad4m-model-write-${i}-value`;
          const rename = (s: any) => (typeof s === "string" && write.parameters.length ? s.split("value").join(name) : s);
          for (const c of write.commands) {
            commands.push({ ...c, source: rename(c.source), predicate: rename(c.predicate), target: rename(c.target) });
          }
          for (const p of write.parameters) parameters.push({ name, value: p.value });
        });
        await this._perspective.executeAction(commands, this._baseExpression, parameters, batchId);
      }
      group = [];
    };
    for (const write of writes) {
      if (write.commands.some((c: any) => c.action === "collectionSetter")) {
        await flush();
        group = [write];
        await flush();
      } else {
        group.push(write);
        if (group.length >= MAX_WRITES_PER_CALL) await flush();
      }
    }
    await flush();
  }

  private async setProperty(key: string, value: any, batchId?: string) {
    if (this.callBacked()) {
      await this.instanceUpdate({ [key]: value }, batchId);
      return;
    }
    await this.sendWrites(await this.planProperty(key, value), batchId);
  }

  /** Whether this row writes through the validated `instance*` RPCs: its
   *  class declares `call` actions ({@link Ad4mModel.hasCallActions}) and it
   *  is not read through an abstract class (those dispatch per record). */
  private callBacked(): boolean {
    return !this.abstractName() && (this.constructor as typeof Ad4mModel).hasCallActions();
  }

  /** `perspective.instanceUpdate` on this row, under the class's target
   *  class IRI (two classes may share a name, #1666). The executor runs each
   *  property's declared setter; a collection is its full member list (`[]`
   *  clears). A caller's batch is passed on: the executor refuses it when a
   *  setter calls a language, since the batch cannot roll the call back. */
  private async instanceUpdate(properties: Record<string, any>, batchId?: string) {
    await this._perspective.instanceUpdate({
      className: (this.constructor as typeof Ad4mModel).queriedAs(),
      baseUri: this._baseExpression,
      properties,
      ...(batchId && { batchId }),
    });
  }

  /** An add or remove on a call-backed row whose shape declares an adder
   *  (remover) for `key`: `instanceAddToCollection`
   *  (`instanceRemoveFromCollection`) per member, which runs the declared
   *  action (a `call` adder reaches the language). Answers false, writing
   *  nothing, for a setter write or an op the shape does not declare: those
   *  are a full-list replace through the setter, which the executor
   *  refuses when there is none. */
  private async declaredMemberWrite(
    key: string,
    kind: 'setter' | 'adder' | 'remover',
    ids: string[],
    batchId?: string
  ): Promise<boolean> {
    if (kind === 'setter') return false;
    const ctor = this.constructor as typeof Ad4mModel;
    const shape = ctor.ownShape();
    const prop = (shape?.properties ?? []).find((p: any) => p?.name === key);
    if (!((prop?.[kind] ?? []).length > 0)) return false;
    for (const itemUri of ids) {
      const body = {
        className: ctor.queriedAs(),
        baseUri: this._baseExpression,
        collection: key,
        itemUri,
        ...(batchId && { batchId }),
      };
      if (kind === 'adder') await this._perspective.instanceAddToCollection(body);
      else await this._perspective.instanceRemoveFromCollection(body);
    }
    return true;
  }

  /** The members `key` holds now, as IDs, read fresh from the perspective:
   *  an add or remove on a call-backed class is a full-list replace through
   *  the declared setter, the only collection write its shape declares. */
  private async currentMembers(key: string): Promise<string[]> {
    const fresh = new (this.constructor as any)(this._perspective, this._baseExpression);
    await fresh.get();
    const members = fresh[key];
    return Array.isArray(members) ? members.map((m: any) => this.resolveRelationId(m)) : [];
  }

  /** The member list `key` should hold after a relation write of `kind`
   *  with `ids`: a setter's ids as given, an adder's or remover's applied
   *  to the current members. */
  private async membersAfter(key: string, kind: 'setter' | 'adder' | 'remover', ids: string[]): Promise<string[]> {
    if (kind === 'setter') return ids;
    const current = await this.currentMembers(key);
    if (kind === 'adder') return [...current, ...ids.filter((id) => !current.includes(id))];
    return current.filter((id) => !ids.includes(id));
  }

  /** A relation write on a call-backed row (see {@link callBacked}): a
   *  forward collection is replaced through `instanceUpdate` with its full
   *  member list, so a declared `call` setter reaches the language (an add or
   *  remove included; `[]` clears). A `hasOne` goes as its scalar member. A
   *  reverse relation, or a `hasOne` being cleared, keeps the legacy write. */
  private async callRelation(key: string, kind: 'setter' | 'adder' | 'remover', value: any, batchId?: string) {
    const relMeta = this.getRelationOptions(key);
    const ids = (value == null ? [] : Array.isArray(value) ? value : [value]).map((v) => this.resolveRelationId(v));
    const reverse = relMeta?.kind === "belongsToOne" || relMeta?.kind === "belongsToMany";
    if (!reverse && relMeta?.kind !== "hasOne") {
      if (await this.declaredMemberWrite(key, kind, ids, batchId)) return;
      await this.instanceUpdate({ [key]: await this.membersAfter(key, kind, ids) }, batchId);
      return;
    }
    if (!reverse && kind !== 'remover' && ids.length > 0) {
      await this.instanceUpdate({ [key]: ids[0] }, batchId);
      return;
    }
    await this.sendWrites(this.planRelation(key, kind, value), batchId);
  }

  /** Resolve a relation argument to a plain string ID. Accepts either a raw
   * string ID or an Ad4mModel instance (in which case `.id` is used). */
  private resolveRelationId(value: any): string {
    if (typeof value === 'string') return value;
    if (value && typeof value === 'object' && typeof value.id === 'string') return value.id;
    return String(value);
  }

  /** A relation write on a row read through an abstract class (#1435). The
   *  relation's predicate is the abstract class's, which no record's class
   *  reads: the executor runs the adder, remover or setter of each of the
   *  record's classes for the relation answering to `key`. */
  private async relationThroughAbstract(
    abstractName: string,
    key: string,
    action: 'adder' | 'remover' | 'setter',
    value: any,
    batchId?: string
  ) {
    const ids = (Array.isArray(value) ? value : [value]).map((v) => this.resolveRelationId(v));
    await this._perspective.updateSubject(abstractName, this._baseExpression, { [key]: { action, value: ids } }, batchId);
  }

  private async setRelationValues(key: string, value: any, batchId?: string) {
    await this.writeRelation(key, 'setter', value, batchId);
  }

  private async addRelationValue(key: string, value: any, batchId?: string) {
    await this.writeRelation(key, 'adder', value, batchId);
  }

  private async removeRelationValue(key: string, value: any, batchId?: string) {
    await this.writeRelation(key, 'remover', value, batchId);
  }

  /** A relation setter, adder or remover call: on a row read through an
   *  abstract class it dispatches through the executor (see
   *  {@link relationThroughAbstract}); on a call-backed class through
   *  `instanceUpdate` ({@link callRelation}); otherwise its writes go out in
   *  as few `executeAction` calls as {@link sendWrites} allows. */
  private async writeRelation(key: string, kind: 'setter' | 'adder' | 'remover', value: any, batchId?: string) {
    const predicate = this.getRelationOptions(key)?.predicate;
    if (predicate && kind !== 'remover') this._relationsWritten.add(predicate);
    if (this.callBacked()) {
      await this.callRelation(key, kind, value, batchId);
      return;
    }
    const abstractName = this.abstractName();
    if (!abstractName) {
      await this.sendWrites(this.planRelation(key, kind, value), batchId);
      return;
    }
    if (!this.getRelationOptions(key)) {
      console.warn(`Relation "${key}" has no metadata, skipping`);
      return;
    }
    if (value != null) await this.relationThroughAbstract(abstractName, key, kind, value, batchId);
  }

  /**
   * Saves the model instance to the perspective.
   *
   * **New instances** (no snapshot yet): creates the subject via
   * `createSubject` with initial scalar values, then sets relations
   * via `innerUpdate`.
   *
   * **Existing instances** (snapshot present, i.e. fetched via `get()`
   * or a query): updates only dirty fields via `innerUpdate`, then
   * refreshes from the perspective.
   * 
   * @param batchId - Optional batch ID for batch operations
   * @throws Will throw if instance creation, linking, or updating fails
   * 
   * @example
   * ```typescript
   * // Create
   * const recipe = new Recipe(perspective);
   * recipe.name = "Spaghetti";
   * await recipe.save();
   * 
   * // Update
   * recipe.rating = 10;
   * await recipe.save();
   * ```
   */
  async save(batchId?: string) {
    // Existing instance → update path (has been fetched / hydrated before)
    if (this._snapshot) {
      const abstractName = this.abstractName();
      if (abstractName) {
        await this.perspective.updateSubject(abstractName, this._baseExpression, this.changedValuesForDispatch(), batchId);
      } else if (this.callBacked()) {
        await this.callUpdate(batchId);
      } else {
        await this.innerUpdate(true, batchId);
      }
      if (batchId) {
        // Batch hasn't been committed yet — getData() would fetch stale data
        // and overwrite in-memory values. Just refresh the snapshot so further
        // saves within the same batch diff correctly.
        this.takeSnapshot();
      } else {
        await this.getData();
      }
      return;
    }

    // New instance → create path. The executor refuses an abstract class
    // too; refusing here keeps the error ahead of the batch.
    if (this.abstractName()) {
      const name = (this.constructor as typeof Ad4mModel).getClassName();
      throw new Error(
        `'${name}' is an abstract class and cannot be created. Create an instance of ` +
        `a class that has its properties; querying '${name}' reads it.`
      );
    }
    if (this.callBacked()) {
      await this.callCreate(batchId);
      return;
    }
    let batchCreatedHere = false;
    if(!batchId) {
      batchId = await this.perspective.createBatch()
      batchCreatedHere = true;
    }

    const metadata = (this.constructor as typeof Ad4mModel).getModelMetadata();

    // Track properties resolved through expression_create — a signed literal
    // envelope or a custom (non-"literal") resolveLanguage. These may fail
    // inside a batch context, so defer them to setProperty after createSubject.
    const deferredExpressionProps: string[] = [];

    const initialValues = {};
    for (const [key, value] of Object.entries(this)) {
      if (value !== undefined && value !== null && !(Array.isArray(value) && value.length > 0) && !value?.action) {
        const propMeta = metadata.properties[key];
        // Only offer keys with a declared, settable model property. This
        // excludes ORM bookkeeping fields (_baseExpression, _perspective —
        // enumerable instance fields, not model properties), relations
        // (@HasOne also registers a property, but innerUpdate writes it as a
        // relation), and read-only properties/flags (readOnly: true). None of
        // these have an `ad4m://setter` on the Rust side, which otherwise logs
        // a "declares no setter" warning per key on every save().
        if (!propMeta || propMeta.readOnly || metadata.relations[key]) {
          continue;
        }
        if (effectiveLiteralStorage(propMeta).kind !== "deterministic") {
          deferredExpressionProps.push(key);
          continue;
        }
        initialValues[key] = value;
      }
    }

    const created = await this.perspective.createSubject(
      this,
      this._baseExpression,
      initialValues,
      batchId
    );

    // A `call` constructor mints the record inside its language and the RPC
    // answers the minted URL — that URL, not `_baseExpression`, is the
    // instance's id. Adopt it before writing relations, or they land on an
    // address the language never created.
    if (typeof created === "string") {
      this._baseExpression = created;
    }

    // Relations via innerUpdate; createSubject wrote the scalar properties.
    const writes = await this.updateWrites(false);

    for (const key of deferredExpressionProps) {
      const value = (this as any)[key];
      if (value !== undefined && value !== null) {
        writes.push(...await this.planProperty(key, value));
      }
    }
    await this.sendWrites(writes, batchId);

    // If we got a batchId passed in, we let the caller decide when to commit.
    // We can't call getData() since the instance won't exist in the perspective
    // until the batch is committed.
    if (batchCreatedHere) {
      await this.perspective.commitBatch(batchId)
      await this.getData();
    } else {
      // Take a snapshot so that a subsequent save() within the same batch
      // routes through the UPDATE path instead of CREATE, avoiding duplicate
      // links (e.g. two competing "title" values).
      this.takeSnapshot();
    }
  }

  /** Create on a call-backed class (see {@link callBacked}): one validated
   *  `instanceCreate` under the class's target class IRI. The executor runs
   *  the declared constructor — a `call` mints the record in its language
   *  and answers the minted URL, which becomes this instance's id — and the
   *  setters the shape declares. A reverse relation and an action envelope
   *  are written after, through {@link writeRelation}. */
  private async callCreate(batchId?: string) {
    const ctor = this.constructor as typeof Ad4mModel;
    const metadata = ctor.getModelMetadata();
    const properties: Record<string, any> = {};
    const deferred: [string, 'setter' | 'adder' | 'remover', any][] = [];
    for (const [key, value] of Object.entries(this)) {
      if (value === undefined || value === null) continue;
      const relMeta = metadata.relations[key];
      if (relMeta) {
        if (relMeta.getter || relMeta.readOnly) continue;
        if (value?.action) {
          const kind = value.action === "adder" || value.action === "remover" ? value.action : "setter";
          deferred.push([key, kind, value.value]);
          continue;
        }
        if (relMeta.direction === "reverse") {
          deferred.push([key, 'setter', value]);
          continue;
        }
        const ids = (Array.isArray(value) ? value : [value]).map((v) => this.resolveRelationId(v));
        if (ids.length === 0) continue;
        properties[key] = this.getRelationOptions(key)?.kind === "hasOne" ? ids[0] : ids;
        continue;
      }
      const propMeta = metadata.properties[key];
      if (!propMeta || propMeta.readOnly) continue;
      properties[key] = value;
    }
    const created = await this._perspective.instanceCreate({
      className: ctor.queriedAs(),
      baseUri: this._baseExpression,
      properties,
      ...(batchId && { batchId }),
    });
    this._baseExpression = created.baseUri;
    for (const [key, kind, value] of deferred) {
      await this.writeRelation(key, kind, value, batchId);
    }
    if (batchId) this.takeSnapshot();
    else await this.getData();
  }

  /** Update on a call-backed class (see {@link callBacked}): the changed
   *  fields as one `instanceUpdate` patch, so the declared setters run in one
   *  grouped call. A forward collection is its full member list — `[]`
   *  included, which clears it in the language; an adder or remover envelope
   *  is applied to the current members first. A getter or readOnly relation
   *  is not written; a reverse relation and a `hasOne` clear keep the legacy
   *  write. A save with no change sends nothing. */
  private async callUpdate(batchId?: string) {
    const relations = (this.constructor as typeof Ad4mModel).getModelMetadata().relations;
    const patch: Record<string, any> = {};
    for (const [key, value] of Object.entries(this.changedValues())) {
      const relMeta = relations[key];
      if (!relMeta) {
        patch[key] = value;
        continue;
      }
      if (relMeta.getter || relMeta.readOnly) continue;
      const kind = value?.action === "adder" || value?.action === "remover" ? value.action : "setter";
      const members = value?.action ? value.value : value;
      const ids = (members == null ? [] : Array.isArray(members) ? members : [members]).map((v) => this.resolveRelationId(v));
      const scalar = this.getRelationOptions(key)?.kind === "hasOne";
      if (relMeta.direction === "reverse" || (scalar && (kind === "remover" || ids.length === 0))) {
        await this.sendWrites(this.planRelation(key, kind, members), batchId);
        continue;
      }
      if (!scalar && (await this.declaredMemberWrite(key, kind, ids, batchId))) continue;
      patch[key] = scalar ? ids[0] : await this.membersAfter(key, kind, ids);
    }
    if (Object.keys(patch).length > 0) await this.instanceUpdate(patch, batchId);
  }

  /** The name the executor knows the class by when it is abstract (#1435):
   *  a built-in's URI (#1446). Through an abstract class, the executor
   *  writes to the record's own classes. */
  private abstractName(): string | undefined {
    const ctor = this.constructor as typeof Ad4mModel & { isAbstract?: boolean };
    return ctor.isAbstract ? ctor.queriedAs() : undefined;
  }

  private changedValues(): Record<string, any> {
    return Object.fromEntries(this.changedFields().map((key) => [key, (this as any)[key]]));
  }

  /** `changedValues()` with each relation's members as IDs, as the relation
   *  helpers send them: a member may be a model instance. An action envelope
   *  (`{ action: "adder", value }`) keeps its action, as `innerUpdate()` runs
   *  it; an action it does not know is a setter there, so it is one here. */
  private changedValuesForDispatch(): Record<string, any> {
    const relations = (this.constructor as typeof Ad4mModel).getModelMetadata().relations;
    const ids = (value: any) =>
      Array.isArray(value) ? value.map((v) => this.resolveRelationId(v)) : this.resolveRelationId(value);
    return Object.fromEntries(
      Object.entries(this.changedValues()).map(([key, value]) => {
        if (!relations[key] || value == null) return [key, value];
        if (value.action) {
          const action = ["adder", "remover", "setter"].includes(value.action) ? value.action : "setter";
          return [key, { action, value: ids(value.value) }];
        }
        return [key, ids(value)];
      })
    );
  }

  private cleanCopy() {
    const ctor = this.constructor as typeof Ad4mModel;
    const metadata = ctor.getModelMetadata();
    const cleanCopy: Record<string, any> = {};

    // Only include schema-declared fields (properties + relations),
    // preserving internal ORM machinery (_id, _perspective, generated
    // addX/removeX/setX methods, _snapshot, etc.)
    const schemaFields = new Set([
      ...Object.keys(metadata.properties),
      ...Object.keys(metadata.relations),
    ]);

    for (const key of schemaFields) {
      const value = (this as any)[key];
      if (value !== undefined && value !== null && key !== "author" && key !== "timestamp") {
        cleanCopy[key] = value;
      }
    }
    return cleanCopy;
  }

  private async innerUpdate(setProperties: boolean = true, batchId?: string) {
    await this.sendWrites(await this.updateWrites(setProperties), batchId);
  }

  /** The writes of the changed fields, in field order (see {@link sendWrites}). */
  private async updateWrites(setProperties: boolean = true): Promise<FieldWrite[]> {
    const writes: FieldWrite[] = [];
    const ctor = this.constructor as typeof Ad4mModel;

    // Determine which fields actually changed (skip unchanged when snapshot exists)
    const dirty = this._snapshot ? new Set(this.changedFields()) : null;

    // Only iterate schema-declared fields, not internal ORM properties
    const metadata = ctor.getModelMetadata();
    const schemaFields = new Set([
      ...Object.keys(metadata.properties),
      ...Object.keys(metadata.relations),
    ]);

    const entries = Object.entries(this);
    for (const [key, value] of entries) {
      // Only process schema-declared fields
      if (!schemaFields.has(key)) continue;
      // Skip unchanged fields when a snapshot is available
      if (dirty && !dirty.has(key)) continue;

      // Skip read-only relations — explicit getters never write links, and
      // neither does a relation declared `readOnly`.
      // For target+filter relations, skip only when another relation on this
      // model claims the same predicate (i.e., this is a filtered *view* of a
      // base relation and writing would collide).
      const relMeta = metadata.relations[key];
      if (relMeta) {
        if (relMeta.getter || relMeta.readOnly) continue;
        if (relMeta.target && relMeta.filter !== false) {
          // Check for predicate collision with a sibling relation
          const hasCollision = Object.entries(metadata.relations).some(
            ([otherName, otherMeta]) =>
              otherName !== key &&
              (otherMeta as RelationMetadata).predicate === relMeta.predicate
          );
          if (hasCollision) continue;
        }
      }

      if (value !== undefined && value !== null) {
        if (value?.action) {
          const envelopePredicate = this.getRelationOptions(key)?.predicate;
          if (envelopePredicate && value.action !== "remover") this._relationsWritten.add(envelopePredicate);
          switch (value.action) {
            case "setter":
              writes.push(...this.planRelation(key, 'setter', value.value));
              break;
            case "adder":
              writes.push(...this.planRelation(key, 'adder', value.value));
              break;
            case "remover":
              writes.push(...this.planRelation(key, 'remover', value.value));
              break;
            default:
              writes.push(...this.planRelation(key, 'setter', value.value));
              break;
          }
        } else if (Array.isArray(value)) {
          // Handle all arrays as relations, including empty ones (which clears the relation).
          // A record being created under an id minted here has no links to
          // clear, so an empty relation there costs a round trip and writes nothing.
          const predicate = this.getRelationOptions(key)?.predicate ?? key;
          if (value.length === 0 && !this._snapshot && this._idMinted && !this._relationsWritten.has(predicate)) continue;
          this._relationsWritten.add(predicate);
          writes.push(...this.planRelation(key, 'setter', value));
        } else if (value !== undefined && value !== null && value !== "") {
          // A scalar handed to a relation field is a single-member relation.
          //
          // This used to `continue` — "Skip, it's a relation, not a regular
          // property" — so `Model.create(p, { source: 'uri://x' })` typechecked,
          // ran, resolved, and wrote no link. The record was created with the
          // relation empty and nothing anywhere said so, which surfaces later as
          // a *reader* complaining about a malformed instance: a Relationship
          // with no endpoints, a Placement pointing at nothing. Both look like
          // rendering bugs from the outside, because the record exists and the
          // thing that should reference it does not.
          //
          // The array form is the documented path and stays correct; the problem
          // is that the scalar form is plausible, typechecks against a field
          // declared `string`, and fails silently. Coercing matches what a caller
          // reaching for it meant. A value `setRelationValues` cannot use now
          // fails there, loudly, instead of vanishing here.
          //
          // Deliberately outside the `setProperties` gate, mirroring the array
          // branch above. `create` passes `setProperties: false` when the class
          // has a constructor, because `create_subject` writes the values map —
          // but a relation carries `ad4m://adder`, not `ad4m://setter`, so
          // `create_subject` drops it (see the warning added in 3ee2b5bc6).
          // Relations have to be written here in both cases or they are lost by
          // both paths at once.
          const relationMeta = this.getRelationOptions(key);
          if (relationMeta) {
            this._relationsWritten.add(relationMeta.predicate);
            writes.push(...this.planRelation(key, 'setter', [value]));
            continue;
          }

          if (setProperties) {
            // Skip flag properties — they are immutable after creation
            const propMeta = this.getPropertyMetadata(key);
            if (propMeta?.flag) {
              continue;
            }

            writes.push(...await this.planProperty(key, value));
          }
        }
      }
    }
    return writes;
  }

  /**
   * Evaluate SPARQL getters for a batch of instances on demand.
   *
   * Since deepQuery defaults to true, property getters are evaluated
   * automatically during collection queries.  Use this method when
   * deepQuery was explicitly set to false and you want to lazily
   * resolve getter-backed properties for a subset of instances.
   *
   * @param instances - Array of model instances to evaluate getters on
   * @param perspective - The perspective to query against
   * @param propertyNames - Optional list of getter-backed property names to evaluate.
   *                        If omitted, all getters are evaluated.
   *
   * @example
   * ```typescript
   * const messages = await Message.query(perspective).deepQuery(false).limit(30).get();
   * // messages[i].replyingTo is undefined (getter skipped)
   *
   * // Evaluate getters for the visible subset
   * await Message.evaluateGetters(messages.slice(0, 10), perspective, ['replyingTo']);
   * // messages[0..9].replyingTo is now populated
   * ```
   */
  static async evaluateGetters<T extends Ad4mModel>(
    instances: T[],
    perspective: PerspectiveProxy,
    propertyNames?: string[],
  ): Promise<void> {
    if (instances.length === 0) return;
    const metadata = this.getModelMetadata();

    const instanceIds = instances.map(inst => inst.id || (inst as any)._baseExpression);

    // The executor reads getter SPARQL from the registered shape, so no
    // shape JSON is shipped with the call.
    const result = await perspective.evaluateGetters(
      this.queriedAs(),
      instanceIds,
      propertyNames,
    );

    // Determine which property names were evaluated for snapshot sync
    const evaluatedPropertyNames: string[] = [];
    for (const [propName, propMeta] of Object.entries(metadata.properties)) {
      if ((propMeta as any).getter) {
        if (!propertyNames || propertyNames.length === 0 || propertyNames.includes(propName)) {
          evaluatedPropertyNames.push(propName);
        }
      }
    }
    // Also include relation getters
    for (const [relName, relMeta] of Object.entries(metadata.relations)) {
      if ((relMeta as any).getter) {
        if (!propertyNames || propertyNames.length === 0 || propertyNames.includes(relName)) {
          evaluatedPropertyNames.push(relName);
        }
      }
    }

    // Apply results to instances and sync snapshots
    for (const instance of instances) {
      const id = (instance as any).id || (instance as any)._baseExpression;
      const props = result[id];
      if (props) {
        for (const [key, value] of Object.entries(props)) {
          (instance as any)[key] = value;
        }
      }
      // Sync snapshot so isDirty() doesn't flag getter-only changes
      const modelInstance = instance as Ad4mModel;
      if (modelInstance._snapshot) {
        for (const propName of evaluatedPropertyNames) {
          const val = (instance as any)[propName];
          modelInstance._snapshot[propName] = normalizeValue(Array.isArray(val) ? [...val] : val);
        }
      }
    }
  }

  /**
   * Gets the model instance with all properties and relations populated.
   *
   * @param optsOrInclude - Optional hydration options. Accepts two forms:
   *   - `GetOptions` wrapper: `{ include: { comments: true }, properties: ['title'] }`
   *   - `IncludeMap` shorthand: `{ comments: true }` (equivalent to `{ include: { comments: true } }`)
   * @returns The populated model instance
   * @throws Will throw if data retrieval fails
   *
   * @example
   * ```typescript
   * const recipe = new Recipe(perspective, existingId);
   * await recipe.get();
   * console.log(recipe.name, recipe.ingredients);
   *
   * // Shorthand — pass IncludeMap directly:
   * await recipe.get({ ingredients: true });
   *
   * // Full options — includes sparse fieldset:
   * await recipe.get({ include: { ingredients: true }, properties: ['name'] });
   * ```
   */
  async get(optsOrInclude?: GetOptions | IncludeMap) {
    // Normalise: if the caller passed a plain IncludeMap shorthand (no `include`
    // or `properties` key at the top level) wrap it in GetOptions automatically.
    let opts: GetOptions | undefined;
    if (!optsOrInclude) {
      opts = undefined;
    } else if ('include' in optsOrInclude || 'properties' in optsOrInclude) {
      opts = optsOrInclude as GetOptions;
    } else {
      opts = { include: optsOrInclude as IncludeMap };
    }

    return await this.getData(opts);
  }

  /**
   * Deletes the model instance from the perspective.
   * 
   * @param batchId - Optional batch ID for batch operations
   * @throws Will throw if removal fails
   * 
   * @example
   * ```typescript
   * const recipe = await Recipe.findAll(perspective)[0];
   * await recipe.delete();
   * 
   * // Or with batch operations:
   * const batchId = await perspective.createBatch();
   * await recipe.delete(batchId);
   * await perspective.commitBatch(batchId);
   * ```
   */
  async delete(batchId?: string) {
    if (this.callBacked()) {
      // The executor runs the declared destructor (a `call` reaches the
      // language), then removes the links left on the node. A caller's
      // batch is refused there when the destructor calls.
      await this._perspective.instanceRemove({
        className: (this.constructor as typeof Ad4mModel).queriedAs(),
        baseUri: this._baseExpression,
        ...(batchId && { batchId }),
      });
      return;
    }
    const metadata = (this.constructor as typeof Ad4mModel).getModelMetadata();
    // Through an abstract class (#1435), `removeSubject` runs the destructors
    // of the record's own classes.
    const hasDestructor = !!this.abstractName() || Object.values(metadata.properties).some(
      (p) => p.required || p.flag || p.initial !== undefined
    );

    if (hasDestructor) {
      // Remove the subject itself (destructor actions)
      await this._perspective.removeSubject(this, this._baseExpression, batchId);
    } else {
      // No destructor (all-optional model).
      // SAFETY: We must NOT remove all outgoing links because another model
      // class may be instantiated on the same base expression.  Removing
      // everything would silently destroy that other instance's data — and
      // if that instance has a destructor, it can no longer be called
      // cleanly, leaving link debris.
      //
      // Instead we only remove outgoing links whose predicate is declared
      // by THIS model's schema (properties + relations).
      try {
        const knownPredicates = new Set<string>();
        for (const p of Object.values(metadata.properties)) {
          if (p.predicate) knownPredicates.add(p.predicate);
        }
        for (const r of Object.values(metadata.relations)) {
          if (r.predicate) knownPredicates.add(r.predicate);
        }

        const outgoingLinks = await this._perspective.get(new LinkQuery({ source: this._baseExpression }));
        const ownLinks = outgoingLinks.filter(
          (link) => link.data.predicate && knownPredicates.has(link.data.predicate)
        );
        if (ownLinks.length > 0) {
          await this._perspective.removeLinks(ownLinks, batchId);
        }
      } catch (e) {
        console.warn(`delete(): failed to remove outgoing links for ${this._baseExpression}:`, e);
      }
    }

    // Clean up incoming links — remove any links that point **to** this instance.
    // Unlike outgoing links (scoped above), incoming links originate from OTHER
    // nodes.  Removing them doesn't damage sibling models on this node; it
    // prevents dangling references elsewhere (e.g. a parent's has_child link).
    try {
      const incomingLinks = await this._perspective.get(new LinkQuery({ target: this._baseExpression }));
      if (incomingLinks.length > 0) {
        await this._perspective.removeLinks(incomingLinks, batchId);
      }
    } catch (e) {
      // Non-fatal: the subject was already deleted; incoming link cleanup is best-effort
      console.warn(`delete(): failed to clean up incoming links for ${this._baseExpression}:`, e);
    }
  }

  // ──────────────────────────────────────────────────────────
  //  Static convenience methods
  // ──────────────────────────────────────────────────────────

  /**
   * Creates and saves a new model instance in one step.
   *
   * @param perspective - The perspective to create the instance in
   * @param data - Property values to assign before saving
   * @param options - Optional settings:
   *   - `parent` — a `Scope` (model form or raw form) whose `id` will
   *     be used to create an incoming link from the parent to the new instance.
   *   - `batchId` — an existing batch id; when provided the link write and
   *     `save()` are added to the batch instead of committed immediately.
   * @returns The saved model instance
   *
   * @example
   * ```typescript
   * // Simple create
   * const recipe = await Recipe.create(perspective, {
   *   name: "Spaghetti",
   *   rating: 5,
   * });
   *
   * // Create under a parent (link auto-created)
   * const comment = await Comment.create(perspective, { text: "Great!" }, {
   *   parent: { model: Post, id: postId },
   * });
   *
   * // Create inside a transaction
   * await Ad4mModel.transaction(perspective, async (tx) => {
   *   await Recipe.create(perspective, { name: "Pasta" }, { batchId: tx.batchId });
   * });
   * ```
   */
  static async create<T extends Ad4mModel>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    data: Record<string, any> = {},
    options?: { parent?: Scope; batchId?: string },
  ): Promise<T> {
    const instance = new this(perspective) as T;
    Object.assign(instance, data);

    // When a parent scope is provided without a caller-supplied batch, open a
    // new batch ourselves so that the instance creation and the parent→child
    // link are committed atomically.  If either step throws, commitBatch is
    // never reached and the batch is implicitly abandoned (rollback).
    if (options?.parent && !options?.batchId) {
      const batchId = await perspective.createBatch();
      await instance.save(batchId);
      await linkToParent(perspective, requireSingleParent(options.parent), this, instance.id, batchId);
      await perspective.commitBatch(batchId);
      // Hydrate the instance now that the batch has been committed (mirrors the
      // behaviour of save() when it manages its own batch).
      await instance.get();
      return instance;
    }

    await instance.save(options?.batchId);

    // Create parent → child link if a parent scope was provided
    if (options?.parent) {
      await linkToParent(perspective, requireSingleParent(options.parent), this, instance.id, options?.batchId);
    }

    return instance;
  }

  /**
   * Updates an existing model instance identified by `id`.
   *
   * Fetches the instance, applies the provided changes, calls `save()`,
   * and returns the refreshed instance.
   *
   * @param perspective - The perspective containing the instance
   * @param id - The expression URI of the instance to update
   * @param data - Property values to merge before saving
   * @returns The updated model instance
   *
   * @example
   * ```typescript
   * const recipe = await Recipe.update(perspective, recipeId, {
   *   rating: 10,
   * });
   * ```
   */
  static async update<T extends Ad4mModel>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    id: string,
    data: Record<string, any>,
  ): Promise<T> {
    const instance = new this(perspective, id) as T;
    await instance.get();
    Object.assign(instance, data);
    // A call-backed record lives in its language and the perspective only
    // mirrors it, from each call's delta: just after a write the read above
    // can still show the old value. The fields given are the write, so they
    // go out even when that read already shows them (an Untag `tags: []`
    // racing the Tag before it). An ordinary class reads the store it writes.
    if (this.hasCallActions()) (instance as any)._given = new Set(Object.keys(data));
    try {
      await instance.save();
    } finally {
      (instance as any)._given = null;
    }
    return instance;
  }

  /**
   * Deletes an existing model instance identified by `id`.
   *
   * Also cleans up any incoming links that point to this instance.
   *
   * @param perspective - The perspective containing the instance
   * @param id - The expression URI of the instance to delete
   *
   * @example
   * ```typescript
   * await Recipe.delete(perspective, recipeId);
   * ```
   *
   * @deprecated Use the name `delete` — `remove` is preserved as an alias.
   */
  static async remove(
    this: typeof Ad4mModel & (new (...args: any[]) => Ad4mModel),
    perspective: PerspectiveProxy,
    id: string,
  ): Promise<void> {
    return this.delete(perspective, id);
  }

  /**
   * Deletes an existing model instance identified by `id`.
   *
   * Also cleans up any incoming links that point to this instance.
   *
   * @param perspective - The perspective containing the instance
   * @param id - The expression URI of the instance to delete
   *
   * @example
   * ```typescript
   * await Recipe.delete(perspective, recipeId);
   * ```
   */
  static async delete(
    this: typeof Ad4mModel & (new (...args: any[]) => Ad4mModel),
    perspective: PerspectiveProxy,
    id: string,
  ): Promise<void> {
    const instance = new this(perspective, id);
    await instance.delete();
  }

  /**
   * Registers this model's SHACL schema on the given perspective.
   *
   * This ensures the perspective knows about the model's shape
   * (properties, relations, constraints) so instances can be
   * created, queried, and validated.
   *
   * @param perspective - The perspective to register the model on
   *
   * @example
   * ```typescript
   * await Recipe.register(perspective);
   * // Now you can create / query Recipe instances on this perspective
   * ```
   */
  static async register(
    this: typeof Ad4mModel,
    perspective: PerspectiveProxy,
  ): Promise<RegisterResult> {
    return Ad4mModel.registerAll(perspective, [this]);
  }

  /**
   * Registers model classes on a perspective in one call. A class whose
   * stored shape already is its shape is `unchanged` and nothing is written,
   * so registering on every start is cheap; built-in classes (`TextContent`)
   * live in the executor and are skipped.
   *
   * @param perspective - The perspective to register the models on
   * @param models - Array of Ad4mModel subclasses to register
   *
   * @example
   * ```typescript
   * await Ad4mModel.registerAll(perspective, [Community, Channel, Message, Task]);
   * ```
   */
  static async registerAll(
    perspective: PerspectiveProxy,
    models: (typeof Ad4mModel)[],
  ): Promise<RegisterResult> {
    const shapes = models
      .filter(model => !Object.prototype.hasOwnProperty.call(model, 'builtinUri'))
      .map(model => {
        const { shape } = model.generateSHACL();
        if (!shape) throw new Error(`Class ${model.name} has no shape: declare it with @Model.`);
        return shape as SHACLShape;
      });
    return perspective.registerShapes(shapes);
  }

  /**
   * Executes a set of model operations inside a single batch (transaction).
   *
   * All `save`, `update`, and `delete` calls made via the provided `batchId`
   * are buffered and flushed atomically when the callback completes.
   * If the callback throws, the batch is **not** committed, preventing
   * partial writes.
   *
   * @param perspective - The perspective to operate on
   * @param fn - Async callback that receives a `TransactionContext` object.
   *             Pass `tx.batchId` to `save(tx.batchId)`, `update(tx.batchId)`,
   *             `delete(tx.batchId)`, etc.
   * @returns The value returned by `fn`
   *
   * @example
   * ```typescript
   * await Ad4mModel.transaction(perspective, async (tx) => {
   *   const recipe = new Recipe(perspective);
   *   recipe.name = "Spaghetti";
   *   await recipe.save(tx.batchId);
   *
   *   const old = await Recipe.query(perspective).where({ name: "Stale" }).run();
   *   for (const r of old) await r.delete(tx.batchId);
   * });
   * // All changes committed atomically here
   * ```
   */
  static async transaction<R = void>(
    perspective: PerspectiveProxy,
    fn: (tx: { batchId: string }) => Promise<R>,
  ): Promise<R> {
    const batchId = await perspective.createBatch();
    const result = await fn({ batchId });
    await perspective.commitBatch(batchId);
    return result;
  }

  /**
   * Creates a query builder for fluent query construction.
   * 
   * @param perspective - The perspective to query
   * @param query - Optional initial query parameters
   * @returns A new query builder instance
   * 
   * @example
   * ```typescript
   * const recipes = await Recipe.query(perspective)
   *   .where({ category: "Dessert" })
   *   .order({ rating: "DESC" })
   *   .limit(5)
   *   .run();
   * 
   * // With real-time updates
   * await Recipe.query(perspective)
   *   .where({ status: "cooking" })
   *   .subscribe(recipes => {
   *     console.log("Currently cooking:", recipes);
   *   });
   * ```
   */
  static query<T extends Ad4mModel>(
    this: typeof Ad4mModel & (new (...args: any[]) => T),
    perspective: PerspectiveProxy,
    query?: TypedQuery<T>,
  ): ModelQueryBuilder<T> {
    return new ModelQueryBuilder<T>(perspective, this as any, (query ?? {}) as Query);
  }

  /**
   * Creates an Ad4mModel class from a JSON Schema definition.
   * 
   * @description
   * This method dynamically generates an Ad4mModel subclass from a JSON Schema,
   * enabling integration with systems that use JSON Schema for type definitions.
   * 
   * The method follows a cascading approach for determining predicates:
   * 1. Explicit configuration in options parameter (highest precedence)
   * 2. x-ad4m metadata in the JSON Schema
   * 3. Inference from schema title and property names
   * 4. Error if no namespace can be determined
   * 
   * @example
   * ```typescript
   * // With explicit configuration
   * const PersonClass = Ad4mModel.fromJSONSchema(schema, {
   *   name: "Person",
   *   namespace: "person://"
   * });
   * 
   * // With property mapping
   * const ContactClass = Ad4mModel.fromJSONSchema(schema, {
   *   name: "Contact",
   *   namespace: "contact://",
   *   propertyMapping: {
   *     "name": "foaf://name",
   *     "email": "foaf://mbox"
   *   }
   * });
   * 
   * // With x-ad4m metadata in schema
   * const schema = {
   *   "title": "Product",
   *   "x-ad4m": { "namespace": "product://" },
   *   "properties": {
   *     "name": { 
   *       "type": "string",
   *       "x-ad4m": { "through": "product://title" }
   *     }
   *   }
   * };
   * const ProductClass = Ad4mModel.fromJSONSchema(schema, { name: "Product" });
   * ```
   * 
   * @param schema - JSON Schema definition
   * @param options - Configuration options
   * @returns Generated Ad4mModel subclass
   * @throws Error when namespace cannot be inferred
   */
  static fromJSONSchema(
    schema: JSONSchema,
    options: JSONSchemaToModelOptions
  ): typeof Ad4mModel {
    return buildModelFromJSONSchema(this, schema, options);
  }

  /**
   * Creates a fully functional Ad4mModel subclass from a SHACL shape.
   *
   * Unlike `fromJSONSchema()`, no predicate inference is required —
   * `SHACLShape` already contains the exact predicate URI in `path` for
   * every property. The method reads each property's `path`, `maxCount`,
   * `writable`, and `resolveLanguage` directly and writes them to the
   * WeakMap metadata registries.
   *
   * Properties with `hasValue` (flag / type-discrimination markers) are
   * registered as hidden flag entries so that the SPARQL query builder emits
   * the fixed triple `?source <predicate> <value>` needed for type discrimination.
   * Properties without a `name` field are skipped.
   *
   * **Backward-compat:** Old Flux SHACL shapes (created before `sh:hasValue`
   * was persisted on property shapes) carry the flag value only in
   * `shape.constructor_actions` as the `target` of an `addLink` action.
   * This method recovers those values so that old perspectives are queried
   * with the correct type-discriminator triple.
   *
   * @param shape - SHACL node shape (as returned by `PerspectiveProxy.shapes()`)
   * @param name  - Class name to assign (e.g. "Channel")
   * @returns Generated Ad4mModel subclass, ready for querying
   */
  /**
   * Synthesise an `Ad4mModel` subclass from a SHACL shape.
   *
   * @param shape           - The SHACL shape to synthesise from.
   * @param name            - The model name (e.g. "Channel").
   * @param classResolver   - Optional thunk factory.  When provided, any collection
   *   property that carries a `sh:class` URI will have its `target` wired up lazily:
   *   `target: () => classResolver(localName)`.  Because `target` is only called at
   *   query time (inside `enrichShapeForIncludes` / `jsonToModelInstance`), the
   *   resolver just needs to return the correct class by the time a query runs —
   *   making it safe to pass a closure over a registry object that is still being
   *   populated (e.g. the `result` record inside `getModelClasses`).
   */
  static fromSHACL(
    shape: SHACLShape,
    name: string,
    classResolver?: (localName: string) => typeof Ad4mModel | undefined,
  ): typeof Ad4mModel {
    const DynamicModelClass = class extends (this as any) {} as unknown as typeof Ad4mModel;
    (DynamicModelClass as any).className = name;
    // The shape as registered, actions included: the class's generated shape
    // carries link actions only, but a `call` constructor, setter or
    // destructor decides how its writes go ({@link hasCallActions}).
    (DynamicModelClass as any).sourceShape = shape;
    (DynamicModelClass.prototype as any).className = name;

    // Build a backward-compat fallback map: predicate → fixed-IRI-value from
    // constructor actions. Old SHACL stores (created before sh:hasValue was
    // persisted on the property shape) don't carry sh:hasValue on properties,
    // but the shape-level constructor_actions always contain an addLink action
    // with the fixed flag value as the target.
    const flagValueFromConstructor = new Map<string, string>();
    for (const action of shape.constructor_actions ?? []) {
      if (
        action.action === 'addLink' &&
        typeof action.predicate === 'string' &&
        typeof action.target === 'string' &&
        action.target !== 'value' &&
        !action.target.startsWith('literal:')
      ) {
        flagValueFromConstructor.set(action.predicate, action.target);
      }
    }

    for (const prop of shape.properties) {
      const resolvedHasValue = prop.hasValue ?? flagValueFromConstructor.get(prop.path);

      if (resolvedHasValue !== undefined) {
        const flagKey = prop.name ?? `_flag_${prop.path.replace(/[^a-zA-Z0-9_]/g, '_')}`;
        setPropertyRegistryEntry(DynamicModelClass, flagKey, {
          through: prop.path,
          required: true,
          initial: resolvedHasValue,
          flag: true,
          writable: false,
          readOnly: true,
        });
        continue;
      }

      // Skip properties without a declared name
      if (!prop.name) continue;

      const isCollection = prop.maxCount === undefined || prop.maxCount > 1;

      if (isCollection) {
        // Derive a lazy `target` thunk when a sh:class URI is present and a
        // classResolver was supplied.  The thunk is evaluated at query time so
        // it is safe even if the target class hasn't been registered yet.
        let targetThunk: (() => typeof Ad4mModel) | undefined;
        if (prop.class && classResolver) {
          const sep = Math.max(prop.class.lastIndexOf('#'), prop.class.lastIndexOf('/'));
          const localName = sep >= 0 ? prop.class.slice(sep + 1) : prop.class;
          targetThunk = () => classResolver(localName) as typeof Ad4mModel;
        }

        setRelationRegistryEntry(DynamicModelClass, prop.name, {
          predicate: prop.path,
          kind: 'hasMany',
          ...(targetThunk !== undefined && { target: targetThunk }),
          ...(prop.local !== undefined && { local: prop.local }),
          ...(prop.getter !== undefined && { getter: prop.getter }),
        });
      } else {
        setPropertyRegistryEntry(DynamicModelClass, prop.name, {
          through: prop.path,
          writable: prop.writable ?? true,
          ...(prop.resolveLanguage !== undefined && { resolveLanguage: prop.resolveLanguage }),
          ...(prop.local !== undefined && { local: prop.local }),
        });
      }
    }

    // The class keeps the shape's target class, which the executor
    // addresses it by: its namespace is everything before the local name.
    const namespace = namespaceOf(shape.targetClass);
    const ModelDecorator = Model({ name, ...(namespace && { namespace }) });
    ModelDecorator(DynamicModelClass);

    return DynamicModelClass as typeof Ad4mModel;
  }
}

