import { Ad4mClient } from './Ad4mClient';
import { ApiClient, RpcError } from './apiClient';
import { Perspective } from './perspectives/Perspective';
import { LinkQuery } from './perspectives/LinkQuery';
import type { EventMap, EventName } from './generated/api/Events';
import type { DecoratedLinkExpression } from './generated/api/DecoratedLinkExpression';
import type { PerspectiveHandle } from './generated/api/PerspectiveHandle';

// Save original WebSocket so we can restore it after the suite
const originalWebSocket = (global as any).WebSocket;

/**
 * Test architecture:
 *
 * The AD4M server exposes NO REST endpoints for authenticated operations.
 * Everything goes through WebSocket RPC at /api/v1/ws.
 *
 * MockWebSocket intercepts all WS RPC messages and resolves them directly
 * from a response map — no HTTP server, no Express, no REST translation.
 *
 * Server-side unauthenticated WS RPC types (empty token allowed):
 *   user.create, user.login, user.verifyEmail, user.requestVerification,
 *   user.multiUserEnabled, runtime.info, runtime.tlsDomain
 *
 * The only real HTTP endpoints on the server are:
 *   GET  /           — server info
 *   GET  /health     — health check
 *   POST /api/v1/ai/transcription/feed — binary PCM audio (not JSON)
 */

// ===================== WS RPC MOCK RESPONSES =====================
// Each key is a WS RPC message type. The value is either a static response
// or a function (params) => response for dynamic behaviour.

type RpcHandler = unknown | ((params: Record<string, unknown>) => unknown);

/** A handler result under this key is sent as the reply's `error` member instead of `result`. */
const RPC_ERROR = '__rpcError';

const MOCK_RESPONSES: Record<string, RpcHandler> = {
    // ── Agent ──
    'agent.get': { did: 'did:test:123', perspective: new Perspective(), directMessageLanguage: 'lang://dm', identity: 'did:scid:coasys:1:QmTest' },
    'agent.status': { did: 'did:test:123', didDocument: 'doc', isInitialized: true, isUnlocked: true, identity: 'did:scid:coasys:1:QmTest' },
    // ── Identity ──
    'identity.status': { did: 'did:scid:coasys:1:QmTest', deviceKey: 'z6MkTest', deviceEnc: 'z6LSTest', keyId: 'd1', revoked: null, head: null, fork: null, storeBehind: null, store: { url: 'https://store.ad4m.dev', trusted: true } },
    'identity.claimOffer': (p: Record<string, unknown>) => ({ did: 'did:scid:coasys:1:QmTest', offerId: 'offer', matchCode: 'R7K Q2M', kind: 'node', expires: 1, echo: p }),
    'identity.log': (p: Record<string, unknown>) => ({ did: p.did, events: [], head: null, fork: null }),
    'identity.devices': [],
    'identity.rekey': { sign: 'did:key:z6MkNew', enc: 'z6LSNew' },
    'identity.custodyStatus': { sign: 'did:key:z6MkTest', enc: 'z6LSTest' },
    'identity.resolve': (p: Record<string, unknown>) => ({
        didDocument: { '@context': ['https://www.w3.org/ns/did/v1'], id: p.didUrl, controller: p.didUrl, verificationMethod: [], authentication: [], assertionMethod: [], keyAgreement: [], capabilityInvocation: [] },
        didDocumentMetadata: { versionId: '2', deactivated: false },
        didResolutionMetadata: { contentType: 'application/did+ld+json', 'coasys:source': 'cache', 'coasys:headTrusted': true },
    }),
    'agent.generate': { did: 'did:test:generated', didDocument: 'doc', isInitialized: true, isUnlocked: true },
    'agent.lock': { did: 'did:test:123', isInitialized: true, isUnlocked: false },
    'agent.unlock': { did: 'did:test:123', isInitialized: true, isUnlocked: true },
    'agent.import': { did: 'did:test:imported', isInitialized: true, isUnlocked: true },
    'agent.byDIDs': (p: Record<string, unknown>) => (p.dids as string[]).map(did => ({ did, perspective: new Perspective() })),
    'agent.updateProfile': { did: 'did:test:123', perspective: new Perspective(), directMessageLanguage: 'lang://dm' },
    'agent.sign': 'signed-message-data',
    'agent.isLocked': false,
    'agent.requestCapability': (p: Record<string, unknown>) =>
        'agent' in p ? `request-for-${p.agent}` : 'request-id-123',
    'agent.permitCapability': 'permitted-token',
    'agent.generateJwt': 'jwt-token-abc',
    'agent.getApps': [{ requestId: 'app1', auth: {}, token: 'tok', revoked: false }],
    'agent.removeApp': [],
    'agent.revokeToken': [],
    'agent.getTrustedAgents': ['did:trusted:1'],
    'agent.addTrustedAgents': ['did:trusted:1', 'did:trusted:2'],
    'agent.deleteTrustedAgents': ['did:trusted:1'],
    'agent.getEntanglementProofs': ['proof1', 'proof2'],
    'agent.addEntanglementProofs': [{ did: 'did:test:123', deviceKey: 'key1', deviceKeyType: 'type1' }],
    'agent.deleteEntanglementProofs': [],
    'agent.entanglementProofPreflight': { did: 'did:test:123', deviceKey: 'key1', deviceKeyType: 'type1' },

    // ── Perspectives ──
    'perspective.all': [{ uuid: 'uuid-1', name: 'test-perspective', sharedUrl: null, neighbourhood: null, state: 'Synced' }],
    'perspective.get': (p: Record<string, unknown>) => ({
        uuid: p.uuid, name: 'test-perspective', sharedUrl: null, neighbourhood: null, state: 'Synced',
    }),
    'perspective.create': (p: Record<string, unknown>) => ({
        uuid: 'uuid-new', name: p.name, sharedUrl: null, neighbourhood: null, state: 'Synced',
    }),
    'perspective.update': (p: Record<string, unknown>) => ({
        uuid: p.uuid, name: p.name, sharedUrl: null, neighbourhood: null, state: 'Synced',
    }),
    'perspective.remove': true,
    'perspective.snapshot': {
        links: [{ author: 'did:test:123', timestamp: '2024-01-01', data: { source: 's', predicate: 'p', target: 't' }, proof: { valid: true } }],
    },
    'perspective.publishSnapshot': 'Qm123',
    'perspective.queryLinks': [
        { author: 'did:test:123', timestamp: '2024-01-01', data: { source: 's', predicate: 'p', target: 't' }, proof: { valid: true } },
    ],
    'perspective.addLink': {
        author: 'did:test:123', timestamp: '2024-01-01',
        data: { source: 's', predicate: 'p', target: 't' }, proof: { valid: true },
    },
    'perspective.addLinkExpression': {
        author: 'did:test:123', timestamp: '2024-01-01',
        data: { source: 's', predicate: 'p', target: 't' }, proof: { valid: true },
    },
    'perspective.addLinks': [
        { author: 'did:test:123', timestamp: '2024-01-01', data: { source: 's', predicate: 'p', target: 't' }, proof: { valid: true } },
    ],
    'perspective.removeLinks': [],
    'perspective.linkMutations': {
        additions: [{ author: 'did:test:123', timestamp: '2024-01-01', data: { source: 'a', predicate: 'p', target: 't' }, proof: { valid: true } }],
        removals: [],
    },
    'perspective.updateLink': {
        author: 'did:test:123', timestamp: '2024-01-01',
        data: { source: 'new-s', predicate: 'p', target: 't' }, proof: { valid: true },
    },
    'perspective.removeLink': true,
    'perspective.queryProlog': JSON.stringify([{ X: 'test' }]),
    'perspective.querySparql': JSON.stringify([{ id: '1' }]),
    'perspective.registerShapes': { unchanged: [], written: ['test://TestClass'], generation: 1 },
    'perspective.executeCommands': true,
    'perspective.createSubject': true,
    // A `colour` property is refused as the executor refuses an unknown property: 422 with the
    // InstanceError as data.
    'perspective.instanceCreate': (p: Record<string, unknown>) =>
        (p.properties as Record<string, unknown> | undefined)?.colour !== undefined
            ? { [RPC_ERROR]: {
                code: 422,
                message: "Validation failed for class 'Task': colour (unknownProperty)",
                data: { kind: 'validation', className: 'Task', errors: [{
                    property: 'colour', problem: { kind: 'unknownProperty', class: 'Task', available: ['title'] },
                    expectedType: null, cardinality: null, allowedValues: null, received: 'red', item: null,
                }] },
            } }
            : { className: p.className, baseUri: 'ad4m://obj/new', propertiesSet: Object.keys(p.properties as object), collectionsSet: [], parent: null },
    'perspective.instanceUpdate': (p: Record<string, unknown>) =>
        ({ className: p.className, baseUri: p.baseUri, updatedProperties: Object.keys(p.properties as object) }),
    'perspective.instanceRemove': (p: Record<string, unknown>) =>
        ({ className: p.className, baseUri: p.baseUri, linksRemoved: 3 }),
    'perspective.instanceAddToCollection': (p: Record<string, unknown>) =>
        ({ className: p.className, baseUri: p.baseUri, collection: p.collection, itemUri: p.itemUri, linksAdded: 1, alreadyMember: false, languageCall: false }),
    'perspective.instanceRemoveFromCollection': (p: Record<string, unknown>) =>
        ({ className: p.className, baseUri: p.baseUri, collection: p.collection, itemUri: p.itemUri, linksRemoved: 1, languageCall: false }),
    'perspective.getSubjectData': '{"name":"test"}',
    'perspective.createBatch': 'batch-id-1',
    'perspective.commitBatch': { additions: [], removals: [] },
    'perspective.subscribeQuery': { subscriptionId: 'sub-1', result: [{ s: 'a' }], revision: 0 },
    'perspective.resyncSubscription': { revision: 3, result: [{ s: 'c' }] },
    'events.watch': true,
    'perspective.disposeQuery': true,

    // ── Languages ──
    'language.all': [{ name: 'test-lang', address: 'lang://test', settings: '{}', icon: null, constructorIcon: null }],
    'language.get': (p: Record<string, unknown>) => ({
        name: 'test-lang', address: p.address, settings: '{}', icon: null, constructorIcon: null,
    }),
    'language.meta': {
        name: 'test-lang', address: 'lang://test', description: 'A test language',
        author: 'did:test:123', templated: false, templateSourceLanguageAddress: null,
        templateAppliedParams: null, possibleTemplateParams: null, sourceCodeLink: null,
    },
    'language.source': 'source-code-here',
    'language.writeSettings': true,
    'language.applyTemplate': { name: 'applied-lang', address: 'lang://applied' },
    'language.publish': {
        name: 'published-lang', address: 'lang://published', description: 'Published',
        author: 'did:test:123', templated: false,
    },
    'language.remove': true,

    // ── Neighbourhoods ──
    'neighbourhood.publish': 'neighbourhood://published',
    'neighbourhood.join': {
        uuid: 'uuid-joined', name: 'joined-neighbourhood', sharedUrl: 'neighbourhood://url',
        neighbourhood: {
            author: 'did:test:123', timestamp: '2024-01-01',
            data: { linkLanguage: 'lang://link', meta: { links: [] } },
            proof: { key: 'key', signature: 'sig', valid: true, invalid: false },
        },
        state: 'SYNCED',
    },
    'neighbourhood.otherAgents': ['did:other:1', 'did:other:2'],
    'neighbourhood.hasTelepresence': true,
    'neighbourhood.onlineAgents': [{ did: 'did:test:1', status: new Perspective() }],
    'sfu.status': { reachability: 'nat', isPublic: false, bindAddress: '127.0.0.1:9000', detail: 'nat' },
    'sfu.servesAllMembers': true,
    'neighbourhood.ownOnlineStatus': null,
    'neighbourhood.setOnlineStatus': true,
    'neighbourhood.sendSignal': true,
    'neighbourhood.sendBroadcast': true,

    // ── Expressions ──
    'expression.getRaw': 'raw-expression-data',
    'expression.get': () => {
        return {
            author: 'did:test:123', timestamp: '2024-01-01', data: '{"content":"hello"}',
            language: { address: 'lang://test' }, proof: { valid: true },
        };
    },
    'expression.getMany': (p: Record<string, unknown>) => {
        // One entry per URL, in order: what `expression.get` answers for it.
        const urls = (p.urls || []) as string[];
        return urls.map(() => ({
            author: 'did:test:123', timestamp: '2024-01-01', data: '{"content":"hello"}',
            language: { address: 'lang://test' }, proof: { valid: true },
        }));
    },
    'expression.create': 'Qm-expression-hash',
    'expression.interactions': [{ label: 'interact1', name: 'doSomething', parameters: [] }],
    'expression.interact': 'interaction-result',

    // ── Runtime ──
    'runtime.info': { ad4mExecutorVersion: '0.1.0', ad4mExecutorCommit: null, isUnlocked: true, isInitialized: true },
    'runtime.tlsDomain': 'test.domain.com',
    'runtime.quit': true,
    'runtime.openLink': true,
    'runtime.friends': ['did:friend:1', 'did:friend:2'],
    'runtime.addFriends': ['did:friend:1', 'did:friend:2', 'did:friend:3'],
    'runtime.removeFriends': ['did:friend:1'],
    'runtime.friendStatus': (p: Record<string, unknown>) => ({
        author: p.did, timestamp: '2023-01-01', data: JSON.stringify({ recipe_name: 'test' }), proof: { valid: true },
    }),
    'runtime.sendFriendMessage': true,
    'runtime.inbox': [{ author: 'did:friend:1', timestamp: '2024-01-01', data: new Perspective() }],
    'runtime.outbox': [],
    'runtime.notifications': [],
    'runtime.createNotification': true,
    'runtime.updateNotification': true,
    'runtime.grantNotification': true,
    'runtime.deleteNotification': true,
    'runtime.setStatus': true,
    'runtime.linkLanguageTemplates': [{ address: 'template1', name: 'Template 1', possibleTemplateParams: ['uid', 'name'] }],
    'runtime.addLinkLanguageTemplates': ['lang://template1', 'lang://template2'],
    'runtime.removeLinkLanguageTemplates': ['lang://template1'],
    'runtime.hcAgentInfos': ['hc-agent-info-1', 'hc-agent-info-2'],
    'runtime.addHcAgentInfos': true,
    'runtime.networkMetrics': 'metrics-data',
    'runtime.restartHolochain': true,
    'runtime.restart': true,
    'runtime.logTail': (p: Record<string, unknown>) => ({ lines: [`asked ${p.lines}`] }),
    'runtime.config': { values: { mcp_port: 3001 }, keys: [{ key: 'mcp_port', class: 'restart' }, { key: 'port', class: 'machine', pinned: 'config' }], restartPending: false, file: '/data/adam/config.json' },
    'runtime.setConfig': (p: Record<string, unknown>) => ({ restartPending: true, refused: p.unset ? [{ key: 'port', reason: 'local-only' }] : [] }),
    'runtime.verifySignature': true,
    'runtime.exportData': true,
    'runtime.importData': { success: true, count: 5 },
    'runtime.freeHostingEnabled': false,
    'runtime.setFreeHostingEnabled': true,
    'runtime.computeLog': [],

    // ── AI ──
    'ai.models': [{ id: 'model-1', name: 'GPT-Test', modelType: 'LLM', endpointId: 'e1', remoteModel: 'gpt-5', status: { state: 'READY' } }],
    'ai.addModel': 'model-new-id',
    'ai.updateModel': true,
    'ai.removeModel': true,
    'ai.setDefaultModel': true,
    'ai.getDefaultModel': { id: 'model-1', name: 'GPT-Test', modelType: 'LLM' },
    'ai.tasks': [{ taskId: 'task-1', name: 'summarize', modelId: 'model-1', systemPrompt: 'Summarize', promptExamples: [] }],
    'ai.addTask': { taskId: 'task-new', name: 'new-task', modelId: 'model-1', systemPrompt: 'Do stuff', promptExamples: [] },
    'ai.updateTask': { taskId: 'task-1', name: 'updated', modelId: 'model-1', systemPrompt: 'Updated', promptExamples: [] },
    'ai.removeTask': true,
    'ai.prompt': 'This is the AI response',
    'ai.modelStatus': { state: 'READY' },
    'ai.discoverModels': [{ id: 'qwen3:8b', capabilities: ['chat'] }],

    // ── Users (unauthenticated on server — empty token allowed) ──
    'user.create': { success: true, did: 'did:test:new-user' },
    'user.login': 'login-jwt-token',
    'user.verifyEmail': 'verified-token',
    'user.logout': true,
    'user.revokeAllSessions': true,
    'user.requestVerification': { success: true, message: 'Verification email sent', requiresPassword: false, isExistingUser: true },
    'user.list': [{ email: 'user@test.com', credits: 100, freeAccess: false }],
    'user.multiUserEnabled': false,
    'user.setMultiUserEnabled': true,
    'user.credits': true,
    'user.freeAccess': true,
    'user.wallet': '0x1234567890abcdef',
    'user.emailTest': (p: Record<string, unknown>) => {
        if (p.action === 'get-code') return '123456';
        return true;
    },

    // ── Hosting ──
    'hosting.info': {
        userInfo: { email: 'test@test.com', credits: 5, hotWalletAddress: null, freeAccess: false },
        rates: null,
        version: { dnaHash: null, buildVersion: 'test' },
    },
    'hosting.setHotWallet': true,
    'hosting.requestPayment': { paymentUrl: 'https://pay.test' },

    // ── Runtime: host rates & Unyt ──
    'runtime.hostRates': [{ description: 'Link write', priceInHOT: 0.001 }],
    'runtime.setHostRates': true,
    'runtime.unytAgentKey': 'unyt-agent-key-123',
    'runtime.unytHotAgentPubkey': 'unyt-hot-pubkey-456',
    'runtime.unytWalletBalance': '1000.50',
    'runtime.unytWalletHistory': '[]',
    'runtime.unytVersionInfo': { installed: null, bundled: '0.61.0', installError: 'install failed' },
    'runtime.setUnytMembraneProof': true,
    'runtime.unytReinstallDna': { success: true, message: 'reinstalled' },
    'runtime.unytSendHot': { success: true, message: 'sent' },
};

// ===================== MOCK WEBSOCKET =====================

/** Tracks the last RPC call for test assertions. */
let lastRpcCall: { type: string; params: Record<string, unknown> } | null = null;

class MockWebSocket {
    static instances: MockWebSocket[] = [];
    static CONNECTING = 0;
    static OPEN = 1;
    static CLOSING = 2;
    static CLOSED = 3;

    onopen: ((event: any) => void) | null = null;
    onmessage: ((event: { data: string }) => void) | null = null;
    onerror: ((event: any) => void) | null = null;
    onclose: ((event: any) => void) | null = null;
    readyState: number = MockWebSocket.CONNECTING;
    closed = false;
    url: string;
    /** RPC calls sent on this socket. */
    rpc: { type: string; params: Record<string, unknown> }[] = [];

    close() {
        this.closed = true;
        this.readyState = MockWebSocket.CLOSED;
        this.onclose?.({});
    }

    send(data: string) {
        try {
            const parsed = JSON.parse(data);

            // Ping/pong keepalive
            if (parsed.type === 'ping') {
                setTimeout(() => {
                    this.onmessage?.({ data: JSON.stringify({ type: 'pong' }) });
                }, 0);
                return;
            }

            // RPC call — resolve directly from MOCK_RESPONSES
            const { id, type: msgType, params: rpcParams } = parsed;
            const params = (rpcParams && typeof rpcParams === 'object')
                ? rpcParams as Record<string, unknown>
                : {} as Record<string, unknown>;

            // Track for assertions
            lastRpcCall = { type: msgType, params };
            this.rpc.push(lastRpcCall);

            const handler = MOCK_RESPONSES[msgType];
            if (handler === undefined) {
                setTimeout(() => {
                    this.onmessage?.({ data: JSON.stringify({ id, error: { code: 404, message: `Unknown RPC type: ${msgType}` } }) });
                }, 0);
                return;
            }

            const result = typeof handler === 'function'
                ? (handler as (p: Record<string, unknown>) => unknown)(params)
                : handler;

            const reply = (value: unknown) => setTimeout(() => {
                const error = (value as Record<string, unknown> | null)?.[RPC_ERROR];
                this.onmessage?.({ data: JSON.stringify(error ? { id, error } : { id, result: value }) });
            }, 0);
            if (result instanceof Promise) result.then(reply);
            else reply(result);
        } catch { /* malformed JSON — ignore */ }
    }

    /** Simulate server pushing an event to the client. */
    emit(payload: unknown) {
        this.onmessage?.({ data: JSON.stringify(payload) });
    }

    constructor(url: string) {
        this.url = url;
        MockWebSocket.instances.push(this);
        // Simulate async connection open
        setTimeout(() => {
            if (this.readyState === MockWebSocket.CONNECTING) {
                this.readyState = MockWebSocket.OPEN;
                this.onopen?.({});
            }
        }, 0);
    }
}

// Copy static constants to prototype (matches real WebSocket)
Object.defineProperty(MockWebSocket.prototype, 'CONNECTING', { value: 0 });
Object.defineProperty(MockWebSocket.prototype, 'OPEN', { value: 1 });
Object.defineProperty(MockWebSocket.prototype, 'CLOSING', { value: 2 });
Object.defineProperty(MockWebSocket.prototype, 'CLOSED', { value: 3 });

/** Return the last element of an array (avoids Array.prototype.at which needs ES2022 lib). */
function lastOf<T>(arr: T[]): T {
    return arr[arr.length - 1];
}

// ===================== WIRE EVENTS =====================
// Events exactly as the executor sends them; the payload type is checked against the event table.

function event<K extends EventName>(type: K, payload: EventMap[K]): { type: K } & EventMap[K] {
    return { type, ...payload };
}

function wireLink(source: string, target = 'test://value'): DecoratedLinkExpression {
    return {
        author: 'did:test:123', timestamp: '2024-01-01T00:00:00.000Z',
        data: { source, predicate: 'test://has', target },
        proof: { key: 'key', signature: 'sig', valid: true, invalid: false },
        status: 'SHARED',
    };
}

function wireHandle(uuid: string): PerspectiveHandle {
    return { uuid, name: 'test-perspective', neighbourhood: null, sharedUrl: null, state: 'SYNCED', owners: null };
}

const linkAdded = (perspectiveUuid: string, source: string) => event('link-added', { perspectiveUuid, link: wireLink(source) });
const linkRemoved = (perspectiveUuid: string, source: string) => event('link-removed', { perspectiveUuid, link: wireLink(source) });
const linkUpdated = (perspectiveUuid: string, oldSource: string, newSource: string) =>
    event('link-updated', { perspectiveUuid, oldLink: wireLink(oldSource), newLink: wireLink(newSource) });
const perspectiveAdded = (uuid: string) => event('perspective-added', { perspectiveUuid: uuid, perspective: wireHandle(uuid) });

// ===================== TEST SETUP =====================

let ad4m: Ad4mClient;

/** Clients a test creates; closed after each test so no socket or timer outlives it. */
let clients: { close(): void }[] = [];

function newClient(token = 'test-token'): Ad4mClient {
    const client = new Ad4mClient('http://127.0.0.1:12000', token);
    clients.push(client);
    return client;
}

function closeClients() {
    for (const client of clients) client.close();
    clients = [];
}

beforeAll(() => {
    (global as any).WebSocket = MockWebSocket as any;
    // Ad4mClient takes an HTTP base URL; apiClient converts to ws:// internally
    ad4m = new Ad4mClient('http://127.0.0.1:12000', 'test-token');
});

afterAll(() => {
    ad4m.close();
    (global as any).WebSocket = originalWebSocket;
});

afterEach(closeClients);

beforeEach(() => {
    lastRpcCall = null;
    MockWebSocket.instances = [];
    // Clear caches to prevent cross-test interference
    ad4m.agent.clearByDidCache();
    ad4m.expression.clearCache();
});

// ===================== AGENT TESTS =====================
describe('AgentClient', () => {
    test('me() returns agent with DID', async () => {
        const agent = await ad4m.agent.me();
        expect(agent.did).toBe('did:test:123');
        expect(agent.directMessageLanguage).toBe('lang://dm');
        // agent.get's identity reaches the Agent, as IdentityClient documents.
        expect(agent.identity).toBe('did:scid:coasys:1:QmTest');
    });

    test('status() returns agent status', async () => {
        const status = await ad4m.agent.status();
        expect(status.isInitialized).toBe(true);
        expect(status.isUnlocked).toBe(true);
    });

    test('generate() sends passphrase and returns status', async () => {
        const status = await ad4m.agent.generate('secret123');
        expect(lastRpcCall!.params.passphrase).toBe('secret123');
        expect(status.did).toBe('did:test:generated');
    });

    test('lock() locks the agent', async () => {
        const status = await ad4m.agent.lock('secret123');
        expect(lastRpcCall!.params.passphrase).toBe('secret123');
        expect(status.isUnlocked).toBe(false);
    });

    test('unlock() unlocks the agent', async () => {
        const status = await ad4m.agent.unlock('secret123');
        expect(lastRpcCall!.params.passphrase).toBe('secret123');
        expect(lastRpcCall!.params.holochain).toBe(true);
        expect(status.isUnlocked).toBe(true);
    });

    test('import() imports a DID keystore', async () => {
        const status = await ad4m.agent.import({
            did: 'did:test:import', didDocument: 'doc', keystore: 'ks', passphrase: 'pass',
        });
        expect(lastRpcCall!.params.did).toBe('did:test:import');
        expect(status.did).toBe('did:test:imported');
    });

    test('byDID() fetches agent by DID', async () => {
        const agent = await ad4m.agent.byDID('did:test:other');
        expect(lastRpcCall!.params.dids).toEqual(['did:test:other']);
        expect(agent.did).toBe('did:test:other');
    });

    test('signMessage() signs a message', async () => {
        const signed = await ad4m.agent.signMessage('hello');
        expect(lastRpcCall!.params.message).toBe('hello');
        expect(signed).toBe('signed-message-data');
    });

    test('isLocked() returns lock status', async () => {
        const locked = await ad4m.agent.isLocked();
        expect(locked).toBe(false);
    });

    test('getEntanglementProofs() returns proofs', async () => {
        const proofs = await ad4m.agent.getEntanglementProofs();
        expect(proofs).toEqual(['proof1', 'proof2']);
    });

    test('addEntanglementProofs() sends proofs', async () => {
        const result = await ad4m.agent.addEntanglementProofs([{ did: 'd', deviceKey: 'k', deviceKeyType: 't', didSigningKeyId: 'sk', deviceKeySignedByDid: 'sig1', didSignedByDeviceKey: 'sig2' }]);
        expect(result).toHaveLength(1);
    });

    test('deleteEntanglementProofs() deletes proofs', async () => {
        const result = await ad4m.agent.deleteEntanglementProofs([{ did: 'd', deviceKey: 'k', deviceKeyType: 't', didSigningKeyId: 'sk', deviceKeySignedByDid: 'sig1', didSignedByDeviceKey: 'sig2' }]);
        expect(result).toEqual([]);
    });

    test('requestCapability() returns request ID', async () => {
        const id = await ad4m.agent.requestCapability({ appName: 'test', appDesc: 'test', appDomain: 'test', appUrl: 'test', capabilities: [] } as any);
        expect(id).toBe('request-id-123');
    });

    // #1399: the request names the agent the app asks to act as; without one, no `agent`
    // param goes out (the executor's main agent).
    test('requestCapability() passes the requested agent', async () => {
        const id = await ad4m.agent.requestCapability({ appName: 'test', appDesc: 'test', appDomain: 'test', appUrl: 'test', capabilities: [] } as any, 'alice@example.org');
        expect(id).toBe('request-for-alice@example.org');
    });

    test('permitCapability() returns token', async () => {
        const token = await ad4m.agent.permitCapability('auth-string');
        expect(token).toBe('permitted-token');
    });

    test('generateJwt() returns JWT', async () => {
        const jwt = await ad4m.agent.generateJwt('req-1', 'rand-1');
        expect(lastRpcCall!.params.requestId).toBe('req-1');
        expect(jwt).toBe('jwt-token-abc');
    });

    test('getApps() returns apps list', async () => {
        const apps = await ad4m.agent.getApps();
        expect(apps).toHaveLength(1);
    });

    test('removeApp() removes an app', async () => {
        const result = await ad4m.agent.removeApp('app1');
        expect(result).toEqual([]);
    });

    test('revokeToken() revokes a token', async () => {
        const result = await ad4m.agent.revokeToken('app1');
        expect(result).toEqual([]);
    });

    test('an agent-updated handler receives the agent under `agent`', async () => {
        const freshClient = newClient();
        const callback = jest.fn();
        freshClient.on('agent-updated', ({ agent }) => callback(agent));

        const agent = { did: 'did:test:updated', directMessageLanguage: 'lang://dm2', perspective: null };
        lastOf(MockWebSocket.instances).emit(event('agent-updated', { agent }));

        expect(callback.mock.calls).toEqual([[agent]]);
    });

    test('an agent-status-changed handler receives the status under `agent`', async () => {
        const freshClient = newClient();
        const callback = jest.fn();
        freshClient.on('agent-status-changed', ({ agent }) => callback(agent));

        const status = { did: 'did:test:status', didDocument: null, error: null, isInitialized: true, isUnlocked: false, identity: null };
        lastOf(MockWebSocket.instances).emit(event('agent-status-changed', { agent: status }));

        expect(callback.mock.calls).toEqual([[status]]);
    });
});

// ===================== PERSPECTIVE TESTS =====================
describe('PerspectiveClient', () => {
    test('all() returns perspective proxies', async () => {
        const perspectives = await ad4m.perspective.all();
        expect(perspectives).toHaveLength(1);
        expect(perspectives[0].uuid).toBe('uuid-1');
    });

    test('byUUID() returns a perspective proxy', async () => {
        const p = await ad4m.perspective.byUUID('uuid-1');
        expect(p).not.toBeNull();
        expect(p!.uuid).toBe('uuid-1');
    });

    test('snapshotByUUID() returns snapshot', async () => {
        const snapshot = await ad4m.perspective.snapshotByUUID('uuid-1');
        expect(snapshot).not.toBeNull();
        expect(snapshot!.links).toHaveLength(1);
    });

    test('add() creates a new perspective', async () => {
        const p = await ad4m.perspective.add('new-perspective');
        expect(p.name).toBe('new-perspective'); // the mock echoes the name sent
        expect(p.uuid).toBe('uuid-new');
    });

    test('update() updates a perspective name', async () => {
        const p = await ad4m.perspective.update('uuid-1', 'renamed');
        expect(lastRpcCall!.params.name).toBe('renamed');
        expect(p.name).toBe('renamed');
    });

    test('remove() deletes a perspective', async () => {
        const result = await ad4m.perspective.remove('uuid-1');
        expect(result.perspectiveRemove).toBe(true);
    });

    test('queryLinks() queries links with parameters', async () => {
        const links = await ad4m.perspective.queryLinks('uuid-1', new LinkQuery({ source: 'src', predicate: 'pred' }));
        expect(links).toHaveLength(1);
        expect(lastRpcCall!.params.source).toBe('src');
        expect(lastRpcCall!.params.predicate).toBe('pred');
    });

    test('addLink() adds a link', async () => {
        const link = await ad4m.perspective.addLink('uuid-1', { source: 's', predicate: 'p', target: 't' });
        expect(link.data.source).toBe('s');
        expect(lastRpcCall!.params.link).toEqual({ source: 's', predicate: 'p', target: 't' });
    });

    test('addLinks() adds multiple links', async () => {
        const links = await ad4m.perspective.addLinks('uuid-1', [
            { source: 's1', predicate: 'p', target: 't1' },
            { source: 's2', predicate: 'p', target: 't2' },
        ]);
        expect(links).toHaveLength(1);
        expect(lastRpcCall!.params.links).toHaveLength(2);
    });

    test('removeLinks() forwards batchId in the bulk remove request', async () => {
        const removed = await ad4m.perspective.removeLinks('uuid-1', [{
            author: 'a', timestamp: 't',
            data: { source: 's', predicate: 'p', target: 't' },
            proof: { valid: true },
        }] as any, 'batch-id-1');
        expect(removed).toHaveLength(0);
        expect(lastRpcCall!.type).toBe('perspective.removeLinks');
        expect(lastRpcCall!.params.links).toHaveLength(1);
        expect(lastRpcCall!.params.batchId).toBe('batch-id-1');
    });

    test('instanceCreate() sends the body next to uuid and returns the created instance', async () => {
        const created = await ad4m.perspective.instanceCreate('uuid-1', {
            className: 'Task', properties: { title: 'Write' }, batchId: 'batch-1',
        });
        expect(lastRpcCall!.type).toBe('perspective.instanceCreate');
        expect(lastRpcCall!.params).toEqual({
            uuid: 'uuid-1', className: 'Task', properties: { title: 'Write' }, batchId: 'batch-1',
        });
        expect(created.baseUri).toBe('ad4m://obj/new');
        expect(created.propertiesSet).toEqual(['title']);
    });

    test('a refused instance write rejects with the validation errors as RpcError.data', async () => {
        const error = await ad4m.perspective
            .instanceCreate('uuid-1', { className: 'Task', properties: { title: 't', colour: 'red' } })
            .then(() => null, (e: unknown) => e);
        expect(error).toBeInstanceOf(RpcError);
        const rpcError = error as RpcError;
        expect(rpcError.status).toBe(422);
        const data = rpcError.data as { kind: string; errors: { property: string; problem: { kind: string } }[] };
        expect(data.kind).toBe('validation');
        expect(data.errors[0].property).toBe('colour');
        expect(data.errors[0].problem.kind).toBe('unknownProperty');
    });

    test('the other instance writes call their methods with the body', async () => {
        const base = { className: 'Task', baseUri: 'ad4m://obj/t' };
        const item = { ...base, collection: 'labels', itemUri: 'ad4m://label/x' };

        const updated = await ad4m.perspective.instanceUpdate('uuid-1', { ...base, properties: { status: 'doing' } });
        expect(lastRpcCall).toEqual({ type: 'perspective.instanceUpdate', params: { uuid: 'uuid-1', ...base, properties: { status: 'doing' } } });
        expect(updated.updatedProperties).toEqual(['status']);

        const removed = await ad4m.perspective.instanceRemove('uuid-1', { ...base, batchId: 'b' });
        expect(lastRpcCall).toEqual({ type: 'perspective.instanceRemove', params: { uuid: 'uuid-1', ...base, batchId: 'b' } });
        expect(removed.linksRemoved).toBe(3);

        const added = await ad4m.perspective.instanceAddToCollection('uuid-1', item);
        expect(lastRpcCall).toEqual({ type: 'perspective.instanceAddToCollection', params: { uuid: 'uuid-1', ...item } });
        expect(added.linksAdded).toBe(1);

        const taken = await ad4m.perspective.instanceRemoveFromCollection('uuid-1', item);
        expect(lastRpcCall).toEqual({ type: 'perspective.instanceRemoveFromCollection', params: { uuid: 'uuid-1', ...item } });
        expect(taken.linksRemoved).toBe(1);
    });

    test('updateLink() updates a link', async () => {
        const link = await ad4m.perspective.updateLink('uuid-1',
            { author: 'a', timestamp: 't', data: { source: 's', predicate: 'p', target: 't' }, proof: { valid: true } } as any,
            { source: 'new-s', predicate: 'p', target: 't' },
        );
        expect(link.data.source).toBe('new-s');
    });

    test('removeLink() removes a link', async () => {
        const result = await ad4m.perspective.removeLink('uuid-1', {
            author: 'a', timestamp: 't',
            data: { source: 's', predicate: 'p', target: 't' },
            proof: { valid: true },
        } as any);
        expect(result).toBe(true);
    });

    test('linkMutations() applies mutations', async () => {
        const result = await ad4m.perspective.linkMutations('uuid-1', {
            additions: [{ source: 'a', predicate: 'p', target: 't' }],
            removals: [],
        });
        expect(result.additions).toHaveLength(1);
    });

    test('registerShapes() registers shapes', async () => {
        const result = await ad4m.perspective.registerShapes('uuid-1', [{ target_class: 'test://TestClass', properties: [] }]);
        expect(result).toEqual({ unchanged: [], written: ['test://TestClass'], generation: 1 });
    });

    test('queryProlog() runs prolog query', async () => {
        const result = await ad4m.perspective.queryProlog('uuid-1', 'test(X)');
        expect(result).toEqual([{ X: 'test' }]);
    });

    test('the last unsubscribe closes the socket', async () => {
        const freshClient = newClient();
        const unsubscribe = freshClient.perspective.onQueryUpdate(jest.fn());
        const ws = lastOf(MockWebSocket.instances);

        unsubscribe();
        expect(ws.closed).toBe(true);
    });

    test('perspective lifecycle subscriptions use the WebSocket endpoint', async () => {
        const freshClient = newClient();
        freshClient.on('perspective-added', jest.fn());

        const ws = lastOf(MockWebSocket.instances);
        expect(ws.url).toBe('ws://127.0.0.1:12000/api/v1/ws?token=test-token');
    });

    test('perspective-scoped link subscriptions ignore events for other perspectives', async () => {
        const freshClient = newClient();
        const linkAddedCallback = jest.fn();
        const linkRemovedCallback = jest.fn();
        const linkUpdatedCallback = jest.fn();

        freshClient.on('link-added', ({ link }) => linkAddedCallback(link), { perspective: 'uuid-1' });
        freshClient.on('link-removed', ({ link }) => linkRemovedCallback(link), { perspective: 'uuid-1' });
        freshClient.on('link-updated', ({ oldLink, newLink }) => linkUpdatedCallback({ oldLink, newLink }), { perspective: 'uuid-1' });

        const ws = lastOf(MockWebSocket.instances);
        expect(ws.url).toBe('ws://127.0.0.1:12000/api/v1/ws?token=test-token');

        // Events for a different perspective should be ignored
        ws.emit(linkAdded('uuid-2', 'test://other-added'));
        ws.emit(linkRemoved('uuid-2', 'test://other-removed'));
        ws.emit(linkUpdated('uuid-2', 'test://other-old', 'test://other-new'));

        expect(linkAddedCallback).not.toHaveBeenCalled();
        expect(linkRemovedCallback).not.toHaveBeenCalled();
        expect(linkUpdatedCallback).not.toHaveBeenCalled();

        // Events for the correct perspective should fire
        ws.emit(linkAdded('uuid-1', 'test://added'));
        ws.emit(linkRemoved('uuid-1', 'test://removed'));
        ws.emit(linkUpdated('uuid-1', 'test://updated-old', 'test://updated-new'));

        expect(linkAddedCallback).toHaveBeenCalledWith(wireLink('test://added'));
        expect(linkRemovedCallback).toHaveBeenCalledWith(wireLink('test://removed'));
        expect(linkUpdatedCallback).toHaveBeenCalledWith({ oldLink: wireLink('test://updated-old'), newLink: wireLink('test://updated-new') });
    });

    test('onQueryUpdate() gets every live query update and lag signal on the socket', async () => {
        const freshClient = newClient();
        const callback = jest.fn();
        const unsubscribe = freshClient.perspective.onQueryUpdate(callback);
        const ws = lastOf(MockWebSocket.instances);
        const update = {
            perspectiveUuid: 'uuid-1', uuid: 'uuid-1', subscriptionId: 'sub-1', revision: 1,
            added: [{ id: 'community://1' }], removed: [],
        };

        ws.emit(perspectiveAdded('uuid-ignored'));
        expect(callback).not.toHaveBeenCalled();

        ws.emit(event('query-subscription-update', update));
        ws.emit(event('query-subscription-update', { lagged: true }));
        expect(callback).toHaveBeenNthCalledWith(1, expect.objectContaining(update));
        expect(callback).toHaveBeenNthCalledWith(2, expect.objectContaining({ lagged: true }));

        unsubscribe();
        ws.emit(event('query-subscription-update', { ...update, revision: 2 }));
        expect(callback).toHaveBeenCalledTimes(2);
    });

    test('a client asks the executor for the events its listeners need', async () => {
        jest.useFakeTimers();
        try {
            const freshClient = newClient();
            const watches = (ws: MockWebSocket) => ws.rpc.filter(c => c.type === 'events.watch').map(c => c.params);
            // Lets each events.watch go out and get its reply.
            const settle = async () => { for (let i = 0; i < 3; i++) await jest.advanceTimersByTimeAsync(10); };

            const releaseAddedA = freshClient.on('link-added', jest.fn(), { perspective: 'A' });
            freshClient.on('link-added', jest.fn(), { perspective: 'B' });
            const releaseRemovedA = freshClient.on('link-removed', jest.fn(), { perspective: 'A' });
            await settle();
            const ws = lastOf(MockWebSocket.instances);
            expect(lastOf(watches(ws))).toEqual(expect.objectContaining({ 'link-added': ['A', 'B'], 'link-removed': ['A'] }));

            releaseAddedA();
            releaseRemovedA();
            await settle();
            expect(lastOf(watches(ws))).toEqual(expect.objectContaining({ 'link-added': ['B'] }));
            expect(lastOf(watches(ws))).not.toHaveProperty('link-removed');

            // A new socket starts with no interest: the client registers again.
            ws.close();
            await jest.advanceTimersByTimeAsync(1_000);
            await settle();
            const reopened = lastOf(MockWebSocket.instances);
            expect(reopened).not.toBe(ws);
            expect(watches(reopened)).toEqual([expect.objectContaining({ 'link-added': ['B'] })]);
            expect(watches(reopened)[0]).not.toHaveProperty('link-removed');
        } finally {
            closeClients();
            jest.useRealTimers();
        }
    });

    test('a call made right after adding a listener is sent after the events.watch it needs', async () => {
        // First use: the listener and the call both wait for the socket.
        const freshClient = newClient();
        freshClient.on('link-added', jest.fn(), { perspective: 'A' });
        await freshClient.perspective.snapshotByUUID('A');
        const ws = lastOf(MockWebSocket.instances);
        expect(ws.rpc.map(c => c.type)).toEqual(['events.watch', 'perspective.snapshot']);

        // Open socket: a listener added in the same tick as the call.
        freshClient.on('link-removed', jest.fn(), { perspective: 'A' });
        await freshClient.perspective.snapshotByUUID('A');
        expect(ws.rpc.slice(2).map(c => c.type)).toEqual(['events.watch', 'perspective.snapshot']);
    });

    test('watchApplied() settles only after the events.watch reply', async () => {
        const watchReply = MOCK_RESPONSES['events.watch'];
        let acceptWatch!: (ok: boolean) => void;
        MOCK_RESPONSES['events.watch'] = () => new Promise<boolean>(r => { acceptWatch = r; });
        const api = new ApiClient('http://127.0.0.1:12000', 'test-token');
        clients.push({ close: () => api.closeAll() });
        try {
            api.on('link-added', () => {}, { perspective: 'A' });
            let settled = false;
            const waiting = api.watchApplied().then(() => { settled = true; });
            await new Promise(r => setTimeout(r, 20));
            expect(lastOf(MockWebSocket.instances).rpc.map(c => c.type)).toEqual(['events.watch']);
            expect(settled).toBe(false);

            acceptWatch(true);
            await waiting;
        } finally {
            MOCK_RESPONSES['events.watch'] = watchReply;
        }
    });

    test('a failed events.watch is sent again, a bounded number of times', async () => {
        jest.useFakeTimers();
        const watchReply = MOCK_RESPONSES['events.watch'];
        const errors = jest.spyOn(console, 'error').mockImplementation(() => {});
        const watchCount = (ws: MockWebSocket) => ws.rpc.filter(c => c.type === 'events.watch').length;
        // Open the socket first, so that only the listener sends a watch.
        const opened = async (client: Ad4mClient) => {
            const snapshot = client.perspective.snapshotByUUID('A');
            await jest.advanceTimersByTimeAsync(10);
            await snapshot;
            return client;
        };
        try {
            // The executor rejects the watch once (404: not a closed socket), then accepts it.
            delete MOCK_RESPONSES['events.watch'];
            const recovering = await opened(newClient());
            recovering.on('link-added', jest.fn(), { perspective: 'A' });
            await jest.advanceTimersByTimeAsync(10);
            const ws = lastOf(MockWebSocket.instances);
            expect(watchCount(ws)).toBe(1);
            MOCK_RESPONSES['events.watch'] = watchReply;
            await jest.advanceTimersByTimeAsync(1_010);
            expect(watchCount(ws)).toBe(2);
            for (let i = 0; i < 10; i++) await jest.advanceTimersByTimeAsync(1_000);
            expect(watchCount(ws)).toBe(2);

            // An executor that keeps rejecting it gets some retries, then no more.
            delete MOCK_RESPONSES['events.watch'];
            const failing = await opened(newClient());
            failing.on('link-added', jest.fn(), { perspective: 'A' });
            for (let i = 0; i < 20; i++) await jest.advanceTimersByTimeAsync(1_000);
            const sent = watchCount(lastOf(MockWebSocket.instances));
            expect(sent).toBeGreaterThan(1);
            for (let i = 0; i < 120; i++) await jest.advanceTimersByTimeAsync(1_000);
            expect(watchCount(lastOf(MockWebSocket.instances))).toBe(sent);
        } finally {
            closeClients();
            MOCK_RESPONSES['events.watch'] = watchReply;
            errors.mockRestore();
            jest.useRealTimers();
        }
    });

    test('sync-state and signal listeners only fire for their perspective', async () => {
        const freshClient = newClient();
        const syncState = jest.fn();
        freshClient.on('sync-state-change', ({ state }) => syncState(state), { perspective: 'A' });
        const signal = jest.fn();
        await freshClient.neighbourhood.addSignalHandler('A', signal);
        const ws = lastOf(MockWebSocket.instances);
        expect(lastOf(ws.rpc.filter(c => c.type === 'events.watch')).params)
            .toEqual({ 'signal': ['A'], 'sync-state-change': ['A'] });

        const syncStateChange = (uuid: string) => event('sync-state-change', { perspectiveUuid: uuid, state: 'SYNCED', perspective: wireHandle(uuid) });
        ws.emit(syncStateChange('B'));
        ws.emit(syncStateChange('A'));
        expect(syncState.mock.calls).toEqual([['SYNCED']]);

        const payload = { author: 'did:x', timestamp: 't', data: { links: [] }, proof: { key: 'k', signature: 's', valid: true, invalid: false } };
        const signalEvent = (uuid: string) => event('signal', { perspectiveUuid: uuid, perspective: wireHandle(uuid), signal: payload, recipient: null });
        ws.emit(signalEvent('B'));
        ws.emit(signalEvent('A'));
        expect(signal).toHaveBeenCalledTimes(1);
    });

    test('a live query applies updates and resyncs on a revision gap', async () => {
        const freshClient = newClient();
        const subscription = await freshClient.perspective.byUUID('uuid-1')
            .then(p => p!.subscribeQuery('SELECT ?s WHERE { ?s ?p ?o }'));
        const results: unknown[] = [];
        subscription.onResult(r => results.push(r));
        const ws = lastOf(MockWebSocket.instances);
        expect(subscription.result).toEqual([{ s: 'a' }]);

        ws.emit({ type: 'perspective-added', perspective: { uuid: 'uuid-ignored' } });
        ws.emit({ type: 'query-subscription-update', subscriptionId: 'sub-2', revision: 1, added: [{ s: 'x' }], removed: [] });
        ws.emit({ type: 'query-subscription-update', subscriptionId: 'sub-1', revision: 1, added: [{ s: 'b' }], removed: [{ s: 'a' }] });
        expect(results).toEqual([[{ s: 'b' }]]);

        // Revision 2 never arrives: the client asks for the current state.
        ws.emit({ type: 'query-subscription-update', subscriptionId: 'sub-1', revision: 3, added: [{ s: 'z' }], removed: [] });
        await new Promise(r => setTimeout(r, 10));
        expect(lastRpcCall).toEqual({ type: 'perspective.resyncSubscription', params: { uuid: 'uuid-1', subscriptionId: 'sub-1' } });
        expect(subscription.result).toEqual([{ s: 'c' }]);

        ws.emit({ type: 'query-subscription-update', subscriptionId: 'sub-1', revision: 4, added: [{ s: 'd' }], removed: [] });
        expect(subscription.result).toEqual([{ s: 'c' }, { s: 'd' }]);

        subscription.dispose();
        await new Promise(r => setTimeout(r, 10));
        expect(lastRpcCall).toEqual({ type: 'perspective.disposeQuery', params: { uuid: 'uuid-1', subscriptionId: 'sub-1' } });
    });

    test('publishSnapshotByUUID() publishes a snapshot', async () => {
        const hash = await ad4m.perspective.publishSnapshotByUUID('uuid-1');
        expect(hash).toBe('Qm123');
    });

    test('createBatch() creates a batch', async () => {
        const batchId = await ad4m.perspective.createBatch('uuid-1');
        expect(batchId).toBe('batch-id-1');
    });

    test('commitBatch() commits a batch', async () => {
        const result = await ad4m.perspective.commitBatch('uuid-1', 'batch-id-1');
        expect(result.additions).toEqual([]);
    });
});

// ===================== LANGUAGE TESTS =====================
describe('LanguageClient', () => {
    test('all() returns all languages', async () => {
        const langs = await ad4m.languages.all();
        expect(langs).toHaveLength(1);
        expect(langs[0].name).toBe('test-lang');
    });

    test('byFilter() filters languages', async () => {
        await ad4m.languages.byFilter('test');
        expect(lastRpcCall!.params.filter).toBe('test');
    });

    test('byAddress() returns a language handle', async () => {
        const lang = await ad4m.languages.byAddress('lang://test');
        expect(lang.name).toBe('test-lang');
    });

    test('meta() returns language meta', async () => {
        const meta = await ad4m.languages.meta('lang://test');
        expect(meta.name).toBe('test-lang');
        expect(meta.author).toBe('did:test:123');
    });

    test('source() returns source code', async () => {
        const source = await ad4m.languages.source('lang://test');
        expect(source).toBe('source-code-here');
    });

    test('writeSettings() writes language settings', async () => {
        const result = await ad4m.languages.writeSettings('lang://test', '{"key":"value"}');
        expect(result).toBe(true);
        expect(lastRpcCall!.params.settings).toBe('{"key":"value"}');
    });

    test('applyTemplateAndPublish() applies a template', async () => {
        const ref = await ad4m.languages.applyTemplateAndPublish('lang://source', '{"param":"value"}');
        expect(ref.name).toBe('applied-lang');
        expect(ref.address).toBe('lang://applied');
    });

    test('publish() publishes a language', async () => {
        const meta = await ad4m.languages.publish('/path/to/lang', { name: 'my-lang', description: 'desc' } as any);
        expect(meta.name).toBe('published-lang');
    });

    test('remove() removes a language', async () => {
        const result = await ad4m.languages.remove('lang://test');
        expect(result).toBe(true);
    });
});

// ===================== NEIGHBOURHOOD TESTS =====================
describe('NeighbourhoodClient', () => {
    test('publishFromPerspective() publishes a neighbourhood', async () => {
        const url = await ad4m.neighbourhood.publishFromPerspective(
            'uuid-1', 'lang://link', new Perspective(),
        );
        expect(url).toBe('neighbourhood://published');
        expect(lastRpcCall!.params.perspectiveUuid).toBe('uuid-1');
    });

    test('joinFromUrl() joins a neighbourhood', async () => {
        const handle = await ad4m.neighbourhood.joinFromUrl('neighbourhood://test');
        expect(handle.uuid).toBe('uuid-joined');
        expect(lastRpcCall!.params.url).toBe('neighbourhood://test');
    });

    test('otherAgents() returns other agents', async () => {
        const agents = await ad4m.neighbourhood.otherAgents('uuid-1');
        expect(agents).toEqual(['did:other:1', 'did:other:2']);
    });

    test('hasTelepresenceAdapter() checks adapter', async () => {
        const has = await ad4m.neighbourhood.hasTelepresenceAdapter('uuid-1');
        expect(has).toBe(true);
    });

    test('onlineAgents() returns online agents', async () => {
        const agents = await ad4m.neighbourhood.onlineAgents('uuid-1');
        expect(agents).toHaveLength(1);
    });

    test('setOnlineStatus() sets status', async () => {
        const result = await ad4m.neighbourhood.setOnlineStatus('uuid-1', new Perspective());
        expect(result).toBe(true);
    });

    test('sendSignal() sends a signal', async () => {
        const result = await ad4m.neighbourhood.sendSignal('uuid-1', 'did:other:1', new Perspective());
        expect(result).toBe(true);
        expect(lastRpcCall!.params.remoteAgentDid).toBe('did:other:1');
    });

    test('sendBroadcast() sends a broadcast', async () => {
        const result = await ad4m.neighbourhood.sendBroadcast('uuid-1', new Perspective(), true);
        expect(result).toBe(true);
        expect(lastRpcCall!.params.loopback).toBe(true);
    });

    test('ownOnlineStatus() returns null when the agent has set none', async () => {
        expect(await ad4m.neighbourhood.ownOnlineStatus('uuid-1')).toBeNull();
        expect(lastRpcCall!.type).toBe('neighbourhood.ownOnlineStatus');
        expect(lastRpcCall!.params).toEqual({ uuid: 'uuid-1' });
    });

    test('sfuServesAllMembers() asks the executor about the perspective', async () => {
        expect(await ad4m.neighbourhood.sfuServesAllMembers('uuid-1')).toBe(true);
        expect(lastRpcCall!.type).toBe('sfu.servesAllMembers');
        expect(lastRpcCall!.params).toEqual({ uuid: 'uuid-1' });
    });

    test('SFU event subscriptions get only their events and are watched before the next call', async () => {
        const freshClient = newClient();
        const offers = jest.fn();
        const migrations = jest.fn();
        const data = jest.fn();
        const releaseOffers = freshClient.neighbourhood.subscribeSfuCallRenegotiationOffer('did:me', offers);
        freshClient.neighbourhood.subscribeSfuMigrateEvent('did:me', migrations);
        freshClient.neighbourhood.subscribeSfuDataChannel(data);
        await freshClient.neighbourhood.sfuStatus();
        const ws = lastOf(MockWebSocket.instances);
        expect(ws.rpc.map(c => c.type)).toEqual(['events.watch', 'sfu.status']);
        expect(ws.rpc[0].params).toEqual({ 'sfu-call-renegotiation-offer': null, 'sfu-data': null, 'sfu-migrate': null });

        const room = { neighbourhoodUrl: 'neighbourhood://n', roomName: 'r' };
        ws.emit(event('sfu-call-renegotiation-offer', { targetDid: 'did:other', participantId: 'P2', ...room, sdpOffer: '{}' }));
        ws.emit(event('sfu-call-renegotiation-offer', { targetDid: 'did:me', participantId: 'P1', ...room, sdpOffer: '{"x":1}' }));
        ws.emit(event('sfu-migrate', { targetDid: 'did:me', ...room, migrateToDid: 'did:node' }));
        const message = { senderDid: 'did:other', senderParticipantId: 'P2', ...room, channelLabel: 'chat', binary: false, data: 'hi' };
        ws.emit(event('sfu-data', message));

        expect(offers).toHaveBeenCalledTimes(1);
        expect(offers).toHaveBeenCalledWith({ targetDid: 'did:me', participantId: 'P1', ...room, sdpOffer: '{"x":1}', trackMapping: undefined });
        expect(migrations).toHaveBeenCalledWith({ targetDid: 'did:me', ...room, migrateToDid: 'did:node' });
        expect(data).toHaveBeenCalledWith(expect.objectContaining(message));

        releaseOffers();
        ws.emit(event('sfu-call-renegotiation-offer', { targetDid: 'did:me', participantId: 'P1', ...room, sdpOffer: '{}' }));
        expect(offers).toHaveBeenCalledTimes(1);
    });
});

// ===================== EXPRESSION TESTS =====================
describe('ExpressionClient', () => {
    test('get() returns an expression', async () => {
        const expr = await ad4m.expression.get('lang://test/Qm123');
        expect(expr.author).toBe('did:test:123');
    });

    test('getMany() returns multiple expressions', async () => {
        const exprs = await ad4m.expression.getMany(['url1', 'url2']);
        expect(exprs).toHaveLength(2);
        expect(exprs[0].author).toBe('did:test:123');
        expect(exprs[1].author).toBe('did:test:123');
    });

    test('getMany() sends at most 200 URLs per expression.getMany call', async () => {
        const freshClient = newClient();
        const urls = Array.from({ length: 201 }, (_, i) => `lang://test/Qm${i}`);
        const exprs = await freshClient.expression.getMany(urls);
        expect(exprs).toHaveLength(201);
        const calls = lastOf(MockWebSocket.instances).rpc.filter(c => c.type === 'expression.getMany');
        expect(calls.map(c => (c.params.urls as string[]).length)).toEqual([200, 1]);
        expect(calls.flatMap(c => c.params.urls as string[])).toEqual(urls);
    });

    test('getRaw() returns raw expression', async () => {
        const raw = await ad4m.expression.getRaw('lang://test/Qm123');
        expect(raw).toBe('raw-expression-data');
    });

    test('create() creates an expression', async () => {
        const hash = await ad4m.expression.create({ content: 'hello' }, 'lang://test');
        expect(hash).toBe('Qm-expression-hash');
        expect(lastRpcCall!.params.languageAddress).toBe('lang://test');
    });

    test('interactions() returns interaction meta', async () => {
        const interactions = await ad4m.expression.interactions('lang://test/Qm123');
        expect(interactions).toHaveLength(1);
        expect(interactions[0].label).toBe('interact1');
    });

    test('interact() calls an interaction', async () => {
        const result = await ad4m.expression.interact('lang://test/Qm123', { name: 'doSomething', parameters: {} } as any);
        expect(result).toBe('interaction-result');
    });
});

// ===================== RUNTIME TESTS =====================
describe('RuntimeClient', () => {
    test('info() returns runtime info', async () => {
        const info = await ad4m.runtime.info();
        expect(info.ad4mExecutorVersion).toBe('0.1.0');
    });

    test('tlsDomain() returns TLS domain', async () => {
        const domain = await ad4m.runtime.tlsDomain();
        expect(domain).toBe('test.domain.com');
    });

    test('quit() quits the runtime', async () => {
        const result = await ad4m.runtime.quit();
        expect(result).toBe(true);
    });

    test('friends() returns friends list', async () => {
        const friends = await ad4m.runtime.friends();
        expect(friends).toEqual(['did:friend:1', 'did:friend:2']);
    });

    test('addFriends() adds friends', async () => {
        const result = await ad4m.runtime.addFriends(['did:friend:3']);
        expect(result).toHaveLength(3);
        expect(lastRpcCall!.params.dids).toEqual(['did:friend:3']);
    });

    test('removeFriends() removes friends', async () => {
        const result = await ad4m.runtime.removeFriends(['did:friend:2']);
        expect(result).toEqual(['did:friend:1']);
    });

    test('getTrustedAgents() returns trusted agents', async () => {
        const agents = await ad4m.runtime.getTrustedAgents();
        expect(agents).toEqual(['did:trusted:1']);
    });

    test('addTrustedAgents() adds trusted agents', async () => {
        const result = await ad4m.runtime.addTrustedAgents(['did:trusted:2']);
        expect(result).toHaveLength(2);
    });

    test('deleteTrustedAgents() removes trusted agents', async () => {
        const result = await ad4m.runtime.deleteTrustedAgents(['did:trusted:2']);
        expect(result).toEqual(['did:trusted:1']);
    });

    test('knownLinkLanguageTemplates() returns each template with its meta', async () => {
        const templates = await ad4m.runtime.knownLinkLanguageTemplates();
        expect(templates.map(t => [t.address, t.possibleTemplateParams])).toEqual([['template1', ['uid', 'name']]]);
    });

    test('hcAgentInfos() returns agent infos list', async () => {
        const infos = await ad4m.runtime.hcAgentInfos();
        expect(infos).toEqual(['hc-agent-info-1', 'hc-agent-info-2']);
    });

    test('hcAddAgentInfos() sends array payload and returns boolean', async () => {
        const result = await ad4m.runtime.hcAddAgentInfos(['hc-agent-info-1', 'hc-agent-info-2']);
        expect(result).toBe(true);
        expect(lastRpcCall!.params.agentInfos).toEqual(['hc-agent-info-1', 'hc-agent-info-2']);
    });

    test('verifyStringSignedByDid() verifies signature', async () => {
        const result = await ad4m.runtime.verifyStringSignedByDid('did:test:1', 'key-1', 'data', 'signed');
        expect(result).toBe(true);
        expect(lastRpcCall!.params.did).toBe('did:test:1');
    });

    test('friendStatus() gets friend status', async () => {
        const status = await ad4m.runtime.friendStatus('did:friend:1');
        expect(status.author).toBe('did:friend:1');
    });

    test('friendSendMessage() sends a message', async () => {
        const result = await ad4m.runtime.friendSendMessage('did:friend:1', new Perspective());
        expect(result).toBe(true);
    });

    test('messageInbox() returns inbox messages', async () => {
        const msgs = await ad4m.runtime.messageInbox();
        expect(msgs).toHaveLength(1);
    });

    test('openLink() opens a link', async () => {
        const result = await ad4m.runtime.openLink('https://example.com');
        expect(result).toBe(true);
        expect(lastRpcCall!.params.url).toBe('https://example.com');
    });

    test('notifications() returns notifications', async () => {
        const notifications = await ad4m.runtime.notifications();
        expect(notifications).toEqual([]);
    });

    test('updateNotification() without webhookAuth sends none, so the stored one stays', async () => {
        const result = await ad4m.runtime.updateNotification('notif-1', {
            description: 'd',
            appName: 'a',
            appUrl: 'https://app.test',
            appIconPath: '',
            trigger: 'SELECT ?s WHERE { ?s ?p ?o }',
            perspectiveIds: ['p1'],
            webhookUrl: 'https://webhook.test',
        });
        expect(result).toBe(true);
        expect(lastRpcCall!.type).toBe('runtime.updateNotification');
        expect(lastRpcCall!.params.id).toBe('notif-1');
        expect('webhookAuth' in lastRpcCall!.params).toBe(false);
    });

    test('grantNotification() grants a notification', async () => {
        const result = await ad4m.runtime.grantNotification('notif-1');
        expect(result).toBe(true);
    });

    test('exportDb() exports the database', async () => {
        const result = await ad4m.runtime.exportDb('/tmp/export');
        expect(result).toBe(true);
    });

    test('multiUserEnabled() checks multi-user status', async () => {
        const enabled = await ad4m.runtime.multiUserEnabled();
        expect(enabled).toBe(false);
    });

    test('setMultiUserEnabled() enables multi-user', async () => {
        const result = await ad4m.runtime.setMultiUserEnabled(true);
        expect(result).toBe(true);
    });

    test('restartHolochain() restarts holochain', async () => {
        const result = await ad4m.runtime.restartHolochain();
        expect(result).toBe(true);
    });

    test('restart() calls runtime.restart', async () => {
        expect(await ad4m.runtime.restart()).toBe(true);
        expect(lastRpcCall!.type).toBe('runtime.restart');
    });

    test('logTail() sends the number of lines', async () => {
        const tail = await ad4m.runtime.logTail(20);
        expect(lastRpcCall!.params).toMatchObject({ lines: 20 });
        expect(tail.lines).toEqual(['asked 20']);
    });

    test('config() returns the keys with their classes', async () => {
        const config = await ad4m.runtime.config();
        expect(lastRpcCall!.type).toBe('runtime.config');
        expect(config.keys.find(k => k.key === 'port')?.class).toBe('machine');
        expect(config.keys.find(k => k.key === 'port')?.pinned).toBe('config');
        expect(config.file).toBe('/data/adam/config.json');
    });

    test('setConfig() sends set and unset and returns the refusals', async () => {
        const result = await ad4m.runtime.setConfig({ mcp_port: 3005 }, ['port']);
        expect(lastRpcCall!.type).toBe('runtime.setConfig');
        expect(lastRpcCall!.params).toMatchObject({ set: { mcp_port: 3005 }, unset: ['port'] });
        expect(result.restartPending).toBe(true);
        expect(result.refused).toEqual([{ key: 'port', reason: 'local-only' }]);
    });
});

// ===================== IDENTITY TESTS =====================
describe('IdentityClient', () => {
    test('status() calls identity.status', async () => {
        const status = await ad4m.identity.status();
        expect(lastRpcCall!.type).toBe('identity.status');
        expect(status.did).toBe('did:scid:coasys:1:QmTest');
        expect(status.keyId).toBe('d1');
        expect(status.store).toEqual({ url: 'https://store.ad4m.dev', trusted: true });
    });

    test('claimOffer() sends the offer and the hint', async () => {
        const claimed = await ad4m.identity.claimOffer('coasys:offer:1:abc', 'server');
        expect(lastRpcCall!.type).toBe('identity.claimOffer');
        expect(lastRpcCall!.params.offer).toBe('coasys:offer:1:abc');
        expect(lastRpcCall!.params.hint).toBe('server');
        expect(claimed.matchCode).toBe('R7K Q2M');
    });

    test('log() sends the did, from and fresh', async () => {
        await ad4m.identity.log('did:scid:coasys:1:QmTest', 2, true);
        expect(lastRpcCall!.params).toMatchObject({ did: 'did:scid:coasys:1:QmTest', from: 2, fresh: true });
    });

    test('resolve() sends the DID URL and fresh, and returns the resolution result', async () => {
        const url = 'did:scid:coasys:1:QmTest?src=store.example&versionId=2';
        const result = await ad4m.identity.resolve(url, { fresh: true });
        expect(lastRpcCall!.type).toBe('identity.resolve');
        expect(lastRpcCall!.params).toMatchObject({ didUrl: url, fresh: true });
        expect(result.didDocument!.id).toBe(url);
        expect(result.didDocumentMetadata.versionId).toBe('2');
        expect(result.didResolutionMetadata['coasys:source']).toBe('cache');
        expect(result.didResolutionMetadata['coasys:headTrusted']).toBe(true);
    });

    test('resolve() without options leaves fresh unset', async () => {
        await ad4m.identity.resolve('did:key:z6MkTest');
        expect(lastRpcCall!.type).toBe('identity.resolve');
        expect(lastRpcCall!.params.didUrl).toBe('did:key:z6MkTest');
        expect(lastRpcCall!.params.fresh).toBeUndefined();
    });

    test('rekey() calls identity.rekey and returns the new device keys', async () => {
        const keys = await ad4m.identity.rekey();
        expect(lastRpcCall!.type).toBe('identity.rekey');
        expect(keys).toEqual({ sign: 'did:key:z6MkNew', enc: 'z6LSNew' });
    });

    test('custodyStatus() calls identity.custodyStatus', async () => {
        const keys = await ad4m.identity.custodyStatus();
        expect(lastRpcCall!.type).toBe('identity.custodyStatus');
        expect(keys.enc).toBe('z6LSTest');
    });

    test('agent.status() carries the identity beside the device did', async () => {
        const status = await ad4m.agent.status();
        expect(status.did).toBe('did:test:123');
        expect(status.identity).toBe('did:scid:coasys:1:QmTest');
    });
});

// ===================== AI TESTS =====================
describe('AIClient', () => {
    test('getModels() returns models', async () => {
        const models = await ad4m.ai.getModels();
        expect(models).toHaveLength(1);
        expect(models[0].name).toBe('GPT-Test');
    });

    test('addModel() adds a model on an endpoint', async () => {
        const model = { name: 'New Model', modelType: 'LLM' as const, endpointId: 'e1', remoteModel: 'qwen3:8b' };
        const id = await ad4m.ai.addModel(model);
        expect(id).toBe('model-new-id');
        expect(lastRpcCall!.params).toEqual({ model });
    });

    test('updateModel() updates a model', async () => {
        const model = { name: 'Updated', modelType: 'EMBEDDING' as const, endpointId: 'e1', remoteModel: 'nomic-embed-text' };
        const result = await ad4m.ai.updateModel('model-1', model);
        expect(result).toBe(true);
        expect(lastRpcCall!.params).toEqual({ id: 'model-1', model });
    });

    test('discoverModels() lists a saved endpoint or a server by its kind and URL', async () => {
        const models = await ad4m.ai.discoverModels({ endpointId: 'e1' });
        expect(models[0].id).toBe('qwen3:8b');
        expect(lastRpcCall!.params).toEqual({ endpointId: 'e1' });
        await ad4m.ai.discoverModels({ kind: 'OLLAMA', baseUrl: 'http://127.0.0.1:11434' });
        expect(lastRpcCall!.params).toEqual({ kind: 'OLLAMA', baseUrl: 'http://127.0.0.1:11434' });
    });

    test('removeModel() removes a model', async () => {
        const result = await ad4m.ai.removeModel('model-1');
        expect(result).toBe(true);
    });

    test('tasks() returns tasks', async () => {
        const tasks = await ad4m.ai.tasks();
        expect(tasks).toHaveLength(1);
    });

    test('addTask() adds a task', async () => {
        const task = await ad4m.ai.addTask('new-task', 'model-1', 'Do stuff', []);
        expect(task.name).toBe('new-task');
    });

    test('removeTask() removes a task', async () => {
        expect(await ad4m.ai.removeTask('task-1')).toBe(true);
        expect(lastRpcCall!.params).toEqual({ id: 'task-1' });
    });

    test('prompt() sends a prompt', async () => {
        const response = await ad4m.ai.prompt('task-1', 'Hello AI');
        expect(response).toBe('This is the AI response');
        expect(lastRpcCall!.params.taskId).toBe('task-1');
        expect(lastRpcCall!.params.prompt).toBe('Hello AI');
    });

    test('modelStatus() returns where the model stands', async () => {
        const status = await ad4m.ai.modelStatus('model-1');
        expect(status.state).toBe('READY');
        expect(lastRpcCall!.params).toEqual({ id: 'model-1' });
    });

    test('setDefaultModel() sets default', async () => {
        const result = await ad4m.ai.setDefaultModel('LLM' as any, 'model-1');
        expect(result).toBe(true);
    });
});

// ===================== USER/AUTH TESTS =====================
describe('User and Auth', () => {
    test('createUser() creates a user', async () => {
        const result = await ad4m.agent.createUser('test@test.com', 'password');
        expect(result.success).toBe(true);
    });

    test('loginUser() returns JWT', async () => {
        const jwt = await ad4m.agent.loginUser('test@test.com', 'password');
        expect(jwt).toBe('login-jwt-token');
    });

    test('verifyEmailCode() returns token', async () => {
        const token = await ad4m.agent.verifyEmailCode('test@test.com', '123456', 'login');
        expect(token).toBe('verified-token');
    });

    test('logout() revokes the session token', async () => {
        expect(await ad4m.agent.logout()).toBe(true);
        expect(lastRpcCall).toEqual({ type: 'user.logout', params: {} });
    });

    test('revokeAllSessions() revokes the caller\'s sessions when no email is given', async () => {
        expect(await ad4m.agent.revokeAllSessions()).toBe(true);
        expect(lastRpcCall).toEqual({ type: 'user.revokeAllSessions', params: {} });
    });

    test('revokeAllSessions(email) names the user', async () => {
        expect(await ad4m.agent.revokeAllSessions('test@test.com')).toBe(true);
        expect(lastRpcCall).toEqual({ type: 'user.revokeAllSessions', params: { email: 'test@test.com' } });
    });

    test('hostingUserInfo() returns user info', async () => {
        const info = await ad4m.agent.hostingUserInfo();
        expect(info.email).toBe('test@test.com');
    });

    test('requestLoginVerification() sends email and returns result', async () => {
        const result = await ad4m.agent.requestLoginVerification('test@test.com');
        expect(result.success).toBe(true);
        expect(result.isExistingUser).toBe(true);
        expect(lastRpcCall!.params.email).toBe('test@test.com');
    });

    test('setHotWalletAddress() sends address', async () => {
        const result = await ad4m.agent.setHotWalletAddress('0xABC');
        expect(result).toBe(true);
        expect(lastRpcCall!.params.address).toBe('0xABC');
    });

    test('requestPayment() sends amount', async () => {
        const result = await ad4m.agent.requestPayment('100');
        expect(lastRpcCall!.params.amountHOT).toBe('100');
    });
});

// ===================== MULTI-USER EXTENDED TESTS =====================
describe('Multi-user and Hosting', () => {
    test('listUsers() returns user statistics', async () => {
        const users = await ad4m.runtime.listUsers();
        expect(users).toHaveLength(1);
        expect(users[0].email).toBe('user@test.com');
    });

    test('setUserCredits() sets credits for a user', async () => {
        const result = await ad4m.runtime.setUserCredits('user@test.com', 500);
        expect(result).toBe(true);
        expect(lastRpcCall!.params.email).toBe('user@test.com');
        expect(lastRpcCall!.params.amount).toBe(500);
    });

    test('setUserFreeAccess() toggles free access', async () => {
        const result = await ad4m.runtime.setUserFreeAccess('user@test.com', true);
        expect(result).toBe(true);
        expect(lastRpcCall!.params.email).toBe('user@test.com');
        expect(lastRpcCall!.params.enabled).toBe(true);
    });

    test('userWalletAddress() returns wallet address', async () => {
        const addr = await ad4m.runtime.userWalletAddress('user@test.com');
        expect(addr).toBe('0x1234567890abcdef');
    });

    test('emailTestModeEnable() enables email test mode', async () => {
        const result = await ad4m.runtime.emailTestModeEnable();
        expect(result).toBe(true);
        expect(lastRpcCall!.params.action).toBe('enable');
    });

    test('emailTestModeDisable() disables email test mode', async () => {
        const result = await ad4m.runtime.emailTestModeDisable();
        expect(result).toBe(true);
        expect(lastRpcCall!.params.action).toBe('disable');
    });

    test('emailTestClearCodes() clears test codes', async () => {
        const result = await ad4m.runtime.emailTestClearCodes();
        expect(result).toBe(true);
        expect(lastRpcCall!.params.action).toBe('clear-codes');
    });

    test('hostRates() returns the rates', async () => {
        const rates = await ad4m.runtime.hostRates();
        expect(lastRpcCall!.type).toBe('runtime.hostRates');
        expect(rates).toHaveLength(1);
        expect(rates[0].description).toBe('Link write');
        expect(rates[0].priceInHOT).toBe(0.001);
    });

    test('setHostRates() sends the rates', async () => {
        const rates = [{ description: 'test', priceInHOT: 1 }];
        const result = await ad4m.runtime.setHostRates(rates);
        expect(result).toBe(true);
        expect(lastRpcCall!.type).toBe('runtime.setHostRates');
        expect(lastRpcCall!.params).toEqual({ rates });
    });
});

// ===================== UNYT / mHOT TESTS =====================
describe('Unyt Integration', () => {
    test('unytAgentKey() returns agent key', async () => {
        const key = await ad4m.runtime.unytAgentKey();
        expect(key).toBe('unyt-agent-key-123');
    });

    test('unytHotAgentPubkey() returns pubkey', async () => {
        const key = await ad4m.runtime.unytHotAgentPubkey();
        expect(key).toBe('unyt-hot-pubkey-456');
    });

    test('unytWalletBalance() returns balance', async () => {
        const balance = await ad4m.runtime.unytWalletBalance();
        expect(balance).toBe('1000.50');
    });

    test('unytWalletHistory() returns history', async () => {
        const history = await ad4m.runtime.unytWalletHistory();
        expect(history).toBe('[]');
    });

    test('unytVersionInfo() returns version info and the install error', async () => {
        const info = await ad4m.runtime.unytVersionInfo();
        expect(lastRpcCall!.type).toBe('runtime.unytVersionInfo');
        expect(info).toEqual({ installed: null, bundled: '0.61.0', installError: 'install failed' });
    });

    test('setUnytMembraneProof() sets proof', async () => {
        const result = await ad4m.runtime.setUnytMembraneProof('proof-data');
        expect(result).toBe(true);
        expect(lastRpcCall!.type).toBe('runtime.setUnytMembraneProof');
        expect(lastRpcCall!.params.proof).toBe('proof-data');
    });

    test('unytReinstallDna() reinstalls DNA', async () => {
        const result = await ad4m.runtime.unytReinstallDna();
        expect(result.success).toBe(true);
    });

    test('unytSendHot() sends HOT tokens', async () => {
        const result = await ad4m.runtime.unytSendHot('recipient-123', '50');
        expect(result.success).toBe(true);
        expect(lastRpcCall!.params.recipient).toBe('recipient-123');
        expect(lastRpcCall!.params.amount).toBe('50');
    });
});

// ===================== AD4M CLIENT INTEGRATION =====================
describe('Ad4mClient', () => {
    test('all sub-clients are accessible', () => {
        expect(ad4m.agent).toBeDefined();
        expect(ad4m.expression).toBeDefined();
        expect(ad4m.languages).toBeDefined();
        expect(ad4m.neighbourhood).toBeDefined();
        expect(ad4m.perspective).toBeDefined();
        expect(ad4m.runtime).toBeDefined();
        expect(ad4m.ai).toBeDefined();
    });

    test('token is passed via WebSocket URL query param', async () => {
        const freshClient = newClient('my-secret-token');
        await freshClient.agent.me();
        const ws = lastOf(MockWebSocket.instances);
        expect(ws.url).toBe('ws://127.0.0.1:12000/api/v1/ws?token=my-secret-token');
    });

    test('calls go through the injected webSocketImpl', async () => {
        class InjectedWebSocket extends MockWebSocket {}
        const freshClient = new Ad4mClient('http://127.0.0.1:12000', 'test-token', { webSocketImpl: InjectedWebSocket as any });

        const agent = await freshClient.agent.me();

        expect(agent.did).toBeDefined();
        expect(MockWebSocket.instances.length).toBeGreaterThan(0);
        for (const ws of MockWebSocket.instances) expect(ws).toBeInstanceOf(InjectedWebSocket);
        freshClient.close();
    });

    test('a handler on a new client receives each client-wide event exactly once', async () => {
        const freshClient = newClient();
        const handlers = {
            agentUpdated: jest.fn(), agentStatus: jest.fn(), apps: jest.fn(),
            hosting: jest.fn(),
            added: jest.fn(), updated: jest.fn(), removed: jest.fn(),
            exception: jest.fn(), notification: jest.fn(),
        };
        freshClient.on('agent-updated', ({ agent }) => handlers.agentUpdated(agent));
        freshClient.on('agent-status-changed', ({ agent }) => handlers.agentStatus(agent));
        freshClient.on('apps-changed', () => handlers.apps());
        freshClient.on('hosting-user-info-changed', (info) => handlers.hosting(info));
        freshClient.on('perspective-added', ({ perspective }) => handlers.added(perspective));
        freshClient.on('perspective-updated', ({ perspective }) => handlers.updated(perspective));
        freshClient.on('perspective-removed', ({ perspectiveUuid }) => handlers.removed(perspectiveUuid));
        freshClient.on('exception-occurred', ({ exception }) => handlers.exception(exception));
        freshClient.on('notification-triggered', ({ notification }) => handlers.notification(notification));
        await freshClient.agent.me(); // wait for the socket to open

        const exception = { addon: null, title: 't', message: 'm', type: 'CAPABILITY_REQUESTED' as const };
        const notification = {
            notification: {
                id: 'n-1', granted: true, description: 'd', appName: 'a', appUrl: 'u', appIconPath: 'i',
                trigger: 'q', perspectiveIds: ['uuid-a'], webhookUrl: '', hasWebhookAuth: false, ownerDid: 'did:key:owner',
            },
            perspectiveId: 'uuid-a', triggerMatch: '[]',
        };
        const ws = lastOf(MockWebSocket.instances);
        ws.emit(event('agent-updated', { agent: { did: 'did:test:upd', directMessageLanguage: null, perspective: null } }));
        ws.emit(event('agent-status-changed', { agent: { did: 'did:test:upd', didDocument: null, error: null, isInitialized: true, isUnlocked: true, identity: 'did:scid:coasys:1:QmTest' } }));
        ws.emit(event('apps-changed', {
            requestId: 'app1', token: 'tok', revoked: null,
            auth: { appName: 'a', appDesc: 'd', appDomain: null, appUrl: null, appIconPath: null, capabilities: null, userEmail: null },
        }));
        ws.emit(event('hosting-user-info-changed', { email: 'a@b.c', remainingCredits: '1', hotWalletAddress: null, freeAccess: false }));
        ws.emit(perspectiveAdded('uuid-a'));
        ws.emit(event('perspective-updated', { perspectiveUuid: 'uuid-a', perspective: wireHandle('uuid-a') }));
        ws.emit(event('perspective-removed', { perspectiveUuid: 'uuid-a', uuid: 'uuid-a' }));
        ws.emit(event('exception-occurred', { exception }));
        ws.emit(event('notification-triggered', { perspectiveUuid: 'uuid-a', notification }));

        for (const handler of Object.values(handlers)) {
            expect(handler).toHaveBeenCalledTimes(1);
        }
        expect(handlers.added).toHaveBeenCalledWith(wireHandle('uuid-a'));
        expect(handlers.removed).toHaveBeenCalledWith('uuid-a');
        expect(handlers.exception).toHaveBeenCalledWith(exception);
        expect(handlers.notification).toHaveBeenCalledWith(notification);
        freshClient.close();
    });

    test('the agent client offers no compute-log listener (the executor sends no such event)', () => {
        const freshClient = newClient();
        // @ts-expect-error removed: compute-log-updated never reaches the socket
        expect(freshClient.agent.addComputeLogUpdatedListener).toBeUndefined();
    });

    test('the function on() returns removes the handler', async () => {
        const freshClient = newClient();
        const hosting = jest.fn();
        const exception = jest.fn();
        freshClient.on('hosting-user-info-changed', hosting)();
        freshClient.on('exception-occurred', exception)();
        await freshClient.agent.me();

        const ws = lastOf(MockWebSocket.instances);
        ws.emit(event('hosting-user-info-changed', { email: 'a@b.c', remainingCredits: '1', hotWalletAddress: null, freeAccess: false }));
        ws.emit(event('exception-occurred', { exception: { addon: null, title: 't', message: 'm', type: 'CAPABILITY_REQUESTED' } }));

        expect(hosting).not.toHaveBeenCalled();
        expect(exception).not.toHaveBeenCalled();
        freshClient.close();
    });

    test('a handler added after close() receives events again', async () => {
        const freshClient = newClient();
        freshClient.on('perspective-added', jest.fn());
        freshClient.close();
        const added = jest.fn();
        freshClient.on('perspective-added', added);
        await freshClient.agent.me();

        lastOf(MockWebSocket.instances).emit(perspectiveAdded('uuid-c'));

        expect(added).toHaveBeenCalledTimes(1);
        freshClient.close();
    });

    test('a client without handlers opens no event subscription', async () => {
        const freshClient = newClient();
        expect(MockWebSocket.instances).toHaveLength(0);
        freshClient.close();
    });

    test('a throwing handler does not stop later handlers for the same event', async () => {
        const freshClient = newClient();
        const errorSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
        const first = jest.fn();
        const third = jest.fn();
        freshClient.on('perspective-added', first);
        freshClient.on('perspective-added', () => { throw new Error('handler bug'); });
        freshClient.on('perspective-added', ({ perspective }) => third(perspective));
        const linkThird = jest.fn();
        freshClient.on('link-added', () => { throw new Error('link handler bug'); }, { perspective: 'uuid-1' });
        freshClient.on('link-added', linkThird, { perspective: 'uuid-1' });
        await freshClient.agent.me();

        const ws = lastOf(MockWebSocket.instances);
        ws.emit(perspectiveAdded('uuid-d'));
        ws.emit(linkAdded('uuid-1', 's'));

        expect(first).toHaveBeenCalledTimes(1);
        expect(third).toHaveBeenCalledTimes(1);
        expect(third).toHaveBeenCalledWith(wireHandle('uuid-d'));
        expect(linkThird).toHaveBeenCalledTimes(1);
        expect(errorSpy).toHaveBeenCalled();
        errorSpy.mockRestore();
        freshClient.close();
    });

    test('WS RPC message contains type and params', async () => {
        await ad4m.agent.generate('pass');
        expect(lastRpcCall!.type).toBe('agent.generate');
        expect(lastRpcCall!.params).toBeDefined();
    });
});
