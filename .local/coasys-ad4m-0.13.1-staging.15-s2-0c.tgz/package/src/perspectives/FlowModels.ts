/**
 * TypeScript @Model classes mirroring the Rust-side hardwired SDNA for the
 * flow runtime. Apps can import these to query the perspective graph for
 * pending flow-transition proposals without knowing the raw link predicates.
 *
 * Do not register them: the classes are hard-wired in the executor, which
 * registers each before writing its first instance and reads one not
 * registered yet as empty.
 *
 * Querying:
 *   const pending = await FlowTransitionProposal.findAll(perspective);
 *
 * Slice 5/7 of the flow-implementation arc (design doc §4.2). The Rust engine
 * mints these as of #987 — see `flow_classes.rs` (`mint_proposal`, URIs at
 * `ad4m://flow/proposal/{id}`) — and reads them back in
 * `flow_instance/atom.rs`. A UI mints or joins them through
 * `FlowInstance.proposeTransition`. This class is the client-side mirror:
 *   - clients build UI over proposals without knowing the raw link predicates;
 *   - the SDNA-parity test locks TS/Rust drift against
 *     `rust-executor/src/perspectives/hardwired_sdna/flow_transition_proposal.json`.
 */

import { Ad4mModel } from "../model/Ad4mModel";
import { HasMany, Optional, Property } from "../model/decorators";
import { Model } from "../model/decorators";

/**
 * The engine's proposer rule (`self_authored_proposer`: a `proposer` link
 * signed by the DID it names) as a getter. Must match the `proposer` getter in
 * `hardwired_sdna/flow_transition_proposal.json` byte for byte, as
 * `ACCEPTED_BY_GETTER` must.
 */
export const PROPOSER_GETTER =
  'SELECT ?target WHERE { ?source <ad4m://flow/proposer> ?target . FILTER EXISTS { ?_claim <http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies> <<( ?source <ad4m://flow/proposer> ?target )>> ; <ad4m://ontology/author> ?_author ; <ad4m://ontology/proofValid> ?_valid . FILTER(STR(?_author) = STR(?target) && STR(?_valid) = "true") } }';

/**
 * The engine's vote rule (`signed_by`: the link's author is the DID it names,
 * and its signature verified) as a getter over the link's reifier. Must match
 * the `acceptedBy` getter in `hardwired_sdna/flow_transition_proposal.json`
 * byte for byte: whichever side registers the class first decides the stored
 * shape.
 */
export const ACCEPTED_BY_GETTER =
  'SELECT ?target WHERE { ?source <ad4m://acceptedBy> ?target . FILTER EXISTS { ?_vote <http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies> <<( ?source <ad4m://acceptedBy> ?target )>> ; <ad4m://ontology/author> ?_author ; <ad4m://ontology/proofValid> ?_valid . FILTER(STR(?_author) = STR(?target) && STR(?_valid) = "true") } }';

// ── FlowTransitionProposal ──────────────────────────────────────────────────
// Mirrors the Rust hardwired `flow_transition_proposal.json` SDNA (once wired
// on the engine side; see file header). One node per proposed transition; the
// URI the engine mints is `ad4m://flow/proposal/<hash>` — the content address
// of the proposer-signed fields under the `nonce` (#1108). The class carries
// no URI-format constraint, but a proposal whose URI is not that content
// address (including any app-chosen URI) is not engine-visible: co-signatures
// name the URI, so the engine only counts proposals whose URI commits to
// their fields.

@Model({ name: "FlowTransitionProposal" })
export class FlowTransitionProposal extends Ad4mModel {
  /**
   * URI of the running `FlowInstance` this proposal targets. First-declared
   * property so `buildSHACL` derives the shape namespace from its `through`
   * prefix — `ad4m://flow/instance` → `ad4m://` → target_class
   * `ad4m://FlowTransitionProposal`. Also the identity predicate: the
   * discriminator `findAll` uses to isolate proposal nodes.
   */
  @Property({ through: "ad4m://flow/instance", required: true, identity: true })
  flowInstance: string = "";

  /** Name of the state the flow instance is currently in. */
  @Property({ through: "ad4m://flow/from_state", required: true })
  fromState: string = "";

  /** Name of the state the proposal wants to transition to. */
  @Property({ through: "ad4m://flow/to_state", required: true })
  toState: string = "";

  /**
   * DID of the agent that issued the proposal, read the way the engine reads
   * it: only from a `proposer` link signed by the DID it names. Any member
   * can write a `proposer` link naming someone else, and an unchecked read
   * would show that DID instead (and drop the real proposer from the voters).
   */
  @Property({ through: "ad4m://flow/proposer", required: true, getter: PROPOSER_GETTER, datatype: "xsd:string" })
  proposer: string = "";

  /**
   * URIs of instances offered as evidence that `toState.requires` is now
   * satisfied. Multiple links, one per cited instance; ordering is not
   * significant.
   */
  @HasMany({ through: "ad4m://flow/evidence", datatype: "xsd:string" })
  evidence: string[] = [];

  /**
   * JSON blob: `{ [uri]: sha256_hex }` — one entry per evidence URI, hashing
   * the canonicalized graph-visible properties (sorted by property URI,
   * multi-values sorted lexicographically) at proposal time. Downstream
   * verifiers use it to detect edits to cited instances after the proposal
   * was written. Stored as an opaque string because SHACL properties carry
   * no rich-object type; the engine parses it back into a map.
   */
  @Property({ through: "ad4m://flow/evidence_hashes", required: true })
  evidenceHashes: string = "";

  /**
   * The instances the proposer names as the run's outputs. Written only on
   * a proposal into a terminal state; one link per output, ordering not
   * significant. Each entry is the canonical JSON text of a
   * `{ className, id }` pair (`FlowOutputRef`); `JSON.parse` it to read one.
   */
  @HasMany({ through: "ad4m://flow/output", datatype: "xsd:string" })
  outputs: string[] = [];

  /**
   * SHA-256 (hex) over the named outputs' content (each instance as
   * `model_query` returns it through its class), signed by the proposer
   * next to the evidence seal. Co-signers load the outputs and recompute it
   * before voting, and a flow receipt's output preimages must hash to it.
   * Empty on a proposal into a non-terminal state.
   */
  @Property({ through: "ad4m://flow/outputs_hash" })
  outputsHash: string = "";

  /**
   * The proposer's uniqueness salt for this proposal's content-addressed
   * URI (`ad4m://flow/proposal/<hash>`; the hash covers the instance, the
   * edge, the seal, the outputs commitment, the proposer DID and this
   * nonce). The engine writes a UUID. A proposal without one — or whose URI
   * does not match its own signed fields — is not engine-visible:
   * co-signatures name the URI, so the URI must commit to what they sign
   * (#1108).
   */
  @Property({ through: "ad4m://flow/nonce" })
  nonce: string = "";

  /**
   * URI of the `InterpretationRun` node that produced this proposal, when
   * the proposal came from an LLM extraction pass. Absent when a human
   * clicked "propose" in the UI or an external tool wrote the proposal
   * directly.
   */
  @Optional({ through: "ad4m://flow/run_uri" })
  runUri?: string;

  /**
   * Free-form human-readable justification. Optional — the LLM includes it
   * when it wants to explain *why* the cited evidence satisfies the state's
   * `requires`; the UI shows it to reviewers.
   */
  @Optional({ through: "ad4m://flow/rationale" })
  rationale?: string;

  /**
   * DIDs that accepted this proposal, as the consensus engine counts them:
   * an `ad4m://acceptedBy` link counts only when it is signed by the DID it
   * names, since anyone can write one naming someone else, and each DID once.
   * The proposer's vote is implicit and the proposer may also accept, so the
   * voters are the *set* `{ proposer } ∪ acceptedBy`, not its sum.
   * Read-only: vote with `acceptProposal`, withdraw with `rejectProposal`.
   */
  @HasMany({ through: "ad4m://acceptedBy", getter: ACCEPTED_BY_GETTER, readOnly: true })
  acceptedBy: string[] = [];

  // Whether this proposal settled an edge is not on the record: the
  // executor keeps that per agent, outside the graph (#1424). Ask
  // `PerspectiveProxy.flowFired(instances)` for the proposals your replica
  // recorded as fired, or listen with `onFlowStateChanged`.

  // "When was this proposal written?" is answered by `Ad4mModel`'s built-in
  // `createdAt`, synthesized on hydration from the earliest link timestamp
  // of the proposal's own links (all written together during create_subject).
}

// ── FlowInstanceRecord ──────────────────────────────────────────────────────
// On-graph node minted by the engine when a flow is started on a specific
// base expression. Its URI is the value that `FlowTransitionProposal.flowInstance`
// references. Mirrors `rust-executor/src/perspectives/hardwired_sdna/flow_instance.json`.
//
// Design authority: `docs/flow-interpretation-hints-design.md` §4.3.
//
// This class is the raw on-graph record (@Model over the SDNA shape). The
// object-oriented handle callers work with is `FlowInstance` in
// `./FlowInstance.ts` — it wraps `FlowInstanceRecord + SHACLFlow definition`
// and exposes `currentState`, `availableTransitions`, `proposals`, etc.
// Renamed from `FlowInstance` → `FlowInstanceRecord` on 2026-08-27 per
// Nico's PR #929 review R2 (the `FlowInstance` name is reserved for the
// wrapper the design has always specified in §4.3).
//
// The SDNA name (`@Model({ name: "FlowInstance" })`) stays unchanged — that
// keys the on-graph class, not the TS export. Renaming the TS class only
// changes the JS import surface; the graph shape is identical, and Rust
// hardwired_sdna/flow_instance.json + all the parity tests still lock down
// the same `ad4m://FlowInstance` target class.

@Model({ name: "FlowInstance" })
export class FlowInstanceRecord extends Ad4mModel {
  /**
   * URI of the `SHACLFlow` this instance runs — the flow's canonical
   * identity, collision-free across social-DNA modules from different
   * communities (bare names WILL collide once shared flows are adopted
   * cross-team — James PR #929 R5). Sourced from `SHACLFlow.flowUri`
   * (which is `${namespace}${name}Flow`, e.g. `coasys://DeliveryFlow`).
   *
   * First-declared property so `buildSHACL` derives the shape namespace
   * from its `through` prefix — `ad4m://flow/flow_uri` → `ad4m://` →
   * target_class `ad4m://FlowInstance`. Also the discriminator predicate
   * `findAll` uses to isolate instance nodes.
   *
   * The human-readable flow name is still available on the paired
   * `SHACLFlow` (via `perspective.getFlow(record.flowUri.split('/').pop()!.replace(/Flow$/,''))`,
   * or more commonly via the `FlowInstance` wrapper's `flowName` getter).
   */
  @Property({ through: "ad4m://flow/flow_uri", required: true, identity: true })
  flowUri: string = "";

  /**
   * URI of the subject expression this flow runs on.
   * Named `subject` (not `baseExpression`) because `Ad4mModel` reserves
   * `baseExpression` as a synthetic hydration field always set to the
   * instance's own URI — a subclass property with that name is shadowed
   * on read.
   */
  @Property({ through: "ad4m://flow/base", required: true })
  subject: string = "";

  // The flow's state is not on the record. It is derived from the signed
  // proposals, and each agent's executor keeps what it last derived outside
  // the graph (#1424): read it with `PerspectiveProxy.flowStates`, or use
  // the `FlowInstance` wrapper, whose `currentStateName` is filled from it.

  // "When was this flow started?" is answered by `Ad4mModel`'s built-in
  // `createdAt`, synthesized on hydration from the earliest link timestamp
  // of the instance's own links (all written together during `mint_flow_instance`).
}
