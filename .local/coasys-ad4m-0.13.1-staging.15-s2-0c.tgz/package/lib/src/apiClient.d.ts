import type { RpcMethod, RpcMethods } from './generated/api/RpcMethods';
import type { EventMap, EventName } from './generated/api/Events';
/** Shape of event data pushed via WebSocket. Callers can narrow via generics. */
export interface WsEvent {
    type: string;
    [key: string]: unknown;
}
/** Error thrown by ApiClient when an RPC call fails. */
export declare class RpcError extends Error {
    /** Error code (maps to HTTP status semantics: 400, 401, 403, 404, 422, 500). */
    readonly status: number;
    /** Raw error message from server. */
    readonly body: string;
    /**
     * Structured detail the executor attached (`error.data`), when it did: e.g. the
     * `InstanceError` of a refused `perspective.instance*` write.
     */
    readonly data?: unknown;
    constructor(status: number, body: string, data?: unknown);
}
/** Options accepted by [`ApiClient.call`]. */
export interface CallOptions {
    /**
     * Aborting sends `request.cancel` and rejects the call with an
     * `AbortError`. The executor drops the reply; it cannot always stop the work.
     */
    signal?: AbortSignal;
    /** Timeout in ms, from the call to the reply. Defaults to 30 s, or
     *  {@link LONG_TIMEOUT_MS} for a method the executor marks long. A call
     *  that opens something on the executor (`OPENS_METHODS`, a live query) is
     *  cancelled there when it times out, as when `signal` aborts it; any other
     *  call that times out still runs to its end. */
    timeoutMs?: number;
}
/** Narrows an {@link ApiClient.on} handler to one perspective's events. */
export interface EventFilter {
    perspective?: string;
}
/** Default timeout for calls that can run for minutes: LLM work, Holochain, publishing. */
export declare const LONG_TIMEOUT_MS: number;
export declare class ApiClient {
    private baseUrl;
    private token?;
    private readonly _webSocketImpl?;
    private readonly _fetchImpl?;
    constructor(baseUrl: string, token?: string, webSocketImpl?: new (url: string) => WebSocket, fetchImpl?: typeof fetch);
    getBaseUrl(): string;
    getToken(): string | undefined;
    /** Perform an HTTP request, using an injected fetch implementation if provided. */
    doFetch(url: string, init: RequestInit): Promise<Response>;
    /** The connecting or open socket; null otherwise. */
    private _ws;
    /** Settles when `_ws` opens (resolve) or closes first (reject). */
    private _wsOpen;
    /** `on()` handlers by event type; a type with none has no entry. */
    private _handlers;
    private _reconnectCallbacks;
    private _authFailedCallbacks;
    /** Set once the executor refused the token: the reason. The client then
     *  never connects again; a new token needs a new client. */
    private _authFailed;
    private _hasConnectedOnce;
    private _pendingCalls;
    private _wsReconnectTimer;
    private _wsReconnectDelay;
    private _wsPingTimer;
    /** When the open socket was first pinged since it last delivered a message; null while none is unanswered. */
    private _wsPingedAt;
    /** When that ping could have reached the executor, which reads it only after what the socket sent before it. */
    private _wsPingArrivesBy;
    /** When everything the open socket sent so far could have crossed a SLOWEST_LINK_BYTES_PER_MS link.
     *  A message from the socket does not move it back: hearing from the executor says nothing
     *  about how much of a large upload has reached it. */
    private _wsSentBy;
    /** A `checkConnection` probe waiting for the open socket to say anything; null when none. */
    private _wsProbeTimer;
    private _watching;
    private _watchScheduled;
    private _watchDone;
    private _watchSent;
    private _watchRetries;
    private _watchRetryTimer;
    private _networkCallbacks;
    /** Removes the network-change listeners; null while not listening. */
    private _unlistenNetwork;
    /** A network change waits for its socket to open, then tells `onNetworkChange`. */
    private _networkChanged;
    /** The socket dialled for the last network change. */
    private _networkDial;
    private _getWsUrl;
    private _ensureWs;
    private _onOpen;
    /**
     * Hear of network changes where the platform says so: `online` on the
     * global object (browsers, Deno) redials at once, and `change` on
     * `navigator.connection` (Chromium) runs `checkConnection`. Elsewhere,
     * e.g. Node, nothing is heard and the ping deadline notices a dead
     * socket on its own.
     */
    private _listenForNetworkChanges;
    /**
     * The network changed: the open socket most likely runs over a path that
     * is gone, and nothing would say so before the ping deadline. Drop it as
     * a silent socket is dropped and dial the next one now, without backoff.
     * `onNetworkChange` callbacks fire once that socket opens.
     */
    private _onNetworkChange;
    private _notifyNetworkChange;
    /** `reason` is set when the executor asked to try again later; calls that fail carry it. */
    private _onClose;
    /** The executor refused the token: fail every call with 401, stop
     *  reconnecting and tell the `onAuthFailed` callbacks, once. */
    private _failAuth;
    private _startPing;
    /** Send on `ws`, counting how long what the open socket sent could take to cross the slowest link. */
    private _send;
    /** The socket answered nothing for a whole ping interval: treat it as
     *  closed now. Its close event can take minutes on a dead connection,
     *  since the close frame gets no answer either; `_onClose` ignores it then. */
    private _dropSilentSocket;
    private _stopPing;
    private _endProbe;
    private _scheduleReconnect;
    /** End the wait for the next dial, if one is pending, without dialling. */
    private _cancelReconnect;
    /**
     * Dial now if the client is waiting out its reconnect backoff (up to 30 s)
     * instead of letting the wait run out. For the moments the host knows the
     * executor may be reachable again: an executor it restarted is up, the
     * device woke. In a browser the client does this itself on `online` and when
     * the page becomes visible. Does nothing while a socket is open or
     * connecting, after `closeAll()` with nothing to reconnect, or once the
     * executor refused the token.
     */
    reconnectNow(): void;
    private _wakeListening;
    /** `online` always; `visibilitychange` only when the page became visible. */
    private readonly _onWake;
    /** Listen for `online` and `visibilitychange` exactly while a reconnect
     *  timer is pending. Outside a browser (no `window`) it registers nothing. */
    private _listenForWake;
    /**
     * Call an executor method over the WebSocket, connecting first if needed.
     * Params and result are typed by the executor's method table
     * (`generated/api/RpcMethods.ts`).
     * @param options - `signal` to cancel, `timeoutMs` to override the
     *   default timeout. The timeout covers connecting and the reply.
     */
    call<M extends RpcMethod>(method: M, params: RpcMethods[M]['params'], options?: CallOptions): Promise<RpcMethods[M]['result']>;
    private _request;
    /**
     * Call `handler` with every `type` event the executor pushes, or only those
     * about `filter.perspective`. The client asks the executor for the events
     * its handlers need (`events.watch`). Returns a function that removes this
     * handler. Like `addEventListener`, registering the same handler for the
     * same type and perspective again changes nothing.
     */
    on<K extends EventName>(type: K, handler: (event: EventMap[K]) => void, filter?: EventFilter): () => void;
    /**
     * Resolves once the socket is open and the executor has applied this
     * client's current `events.watch`. After it, every event the registered
     * handlers need reaches them. Only events other peers cause (signals)
     * need this: a call already sends the watch ahead of itself.
     */
    watchApplied(): Promise<void>;
    /** Event type → perspectives wanted (`null`: all), from every handler. */
    watchedEvents(): Partial<Record<EventName, string[] | null>>;
    /** Flush the watch once per microtask, after a subscriber came or went. */
    private _scheduleWatch;
    /** Send `events.watch` now if the socket is open and the executor lacks
     *  the current interest; a socket still connecting gets it on open.
     *  `_watchSent` settles with its reply. */
    private _flushWatch;
    private _closeWs;
    /** Register a callback that fires after a successful WebSocket reconnect.
     *  Does NOT fire on the initial connection — only on reconnects.
     *  Returns an unsubscribe function. */
    onReconnect(callback: () => void): () => void;
    /** Register a callback that fires after the network changed (`online`,
     *  or a socket that failed `checkConnection`), once the socket dialled for the
     *  new network is open and its event watch sent. Calls made from it go
     *  out on that socket. Returns an unsubscribe function. */
    onNetworkChange(callback: () => void): () => void;
    /**
     * Check the open socket now rather than at the next ping: send a ping,
     * and if nothing at all arrives on that socket within `deadlineMs`,
     * treat it as a network change (drop it, dial the next one at once,
     * `onNetworkChange` callbacks fire when it opens). Any message keeps it.
     * For a caller that has seen its network path break, e.g. ICE going
     * disconnected, where the platform fired no `online` event. Without an
     * open socket, or while a check runs, this does nothing.
     */
    checkConnection(deadlineMs?: number): void;
    /** Register a callback that fires once when the executor refuses this
     *  client's token: a 401 reply, or a socket closed with code 1008. Every
     *  call then fails with a 401 `RpcError` and the client does not reconnect;
     *  build a new client to use another token. Returns an unsubscribe function. */
    onAuthFailed(callback: (reason: string) => void): () => void;
    /** Close the WebSocket and reject pending calls. */
    closeAll(): void;
}
