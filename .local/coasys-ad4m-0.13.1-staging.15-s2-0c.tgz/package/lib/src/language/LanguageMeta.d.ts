export declare class LanguageMeta {
    name: string;
    address: string;
    description: string;
    author: string;
    templated: boolean;
    templateSourceLanguageAddress?: string;
    templateAppliedParams?: string;
    possibleTemplateParams?: string[];
    sourceCodeLink?: string;
}
export declare class LanguageMetaInput {
    name: string;
    description: string;
    possibleTemplateParams?: string[];
    sourceCodeLink?: string;
    constructor(name?: string, description?: string);
}
export declare class LanguageMetaInternal {
    name: string;
    address: string;
    description: string;
    templateSourceLanguageAddress?: string;
    templateAppliedParams?: string;
    possibleTemplateParams?: string[];
    sourceCodeLink?: string;
}
declare const LanguageExpression_base: abstract new (author?: string, timestamp?: string, data?: LanguageMetaInternal, proof?: import("../expression/Expression").ExpressionProof) => import("../expression/Expression").ExpressionShape<LanguageMetaInternal, import("../expression/Expression").ExpressionProof>;
export declare class LanguageExpression extends LanguageExpression_base {
}
export declare class LanguageLanguageInput {
    bundle: string;
    meta: LanguageMetaInternal;
}
export {};
