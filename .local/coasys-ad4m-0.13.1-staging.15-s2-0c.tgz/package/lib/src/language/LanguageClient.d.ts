import { ApiClient, CallOptions } from '../apiClient';
import { LanguageHandle } from "./LanguageHandle";
import { LanguageMeta, LanguageMetaInput } from "./LanguageMeta";
import { LanguageRef } from "./LanguageRef";
export declare class LanguageClient {
    #private;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    byAddress(address: string): Promise<LanguageHandle>;
    byFilter(filter: string): Promise<LanguageHandle[]>;
    all(): Promise<LanguageHandle[]>;
    writeSettings(languageAddress: string, settings: string): Promise<Boolean>;
    applyTemplateAndPublish(sourceLanguageHash: string, templateData: string, options?: CallOptions): Promise<LanguageRef>;
    applyTemplateLocal(sourceLanguageHash: string, templateData: object, options?: CallOptions): Promise<LanguageRef>;
    publish(languagePath: string, languageMeta: LanguageMetaInput, options?: CallOptions): Promise<LanguageMeta>;
    meta(address: string): Promise<LanguageMeta>;
    source(address: string): Promise<string>;
    remove(address: string): Promise<Boolean>;
}
