export type Address = string;
