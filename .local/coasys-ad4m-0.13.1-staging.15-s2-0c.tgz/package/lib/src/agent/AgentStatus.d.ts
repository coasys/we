export declare class AgentStatus {
    isInitialized: Boolean;
    isUnlocked: Boolean;
    did?: string;
    didDocument?: string;
    error?: string;
    /** The `did:scid` the agent's device key speaks for; `did` stays the device `did:key`. */
    identity?: string | null;
    constructor(obj?: object);
}
