import { Perspective } from "../perspectives/Perspective";
import type { Agent as WireAgent } from "../generated/api/Agent";
import type { AgentWithIdentity } from "../generated/api/AgentWithIdentity";
/**  AD4M's representation of an Agent
 *
 * AD4M Agents are build around DIDs, which are used to identify and authenticate the Agent.
 * Conceptually, an Agent is regarded as something that can speak and that can listen.
 *
 * Agents speak by creating Expressions in AD4M Languages which are signed by the Agent's DID key,
 * And they also speak (broadcast) by putting semantic statements into their public "Agent Perspective".
 * They listen (can receive messages) through their "direct message Language".
 *
 * These three aspects are represented by the three fields of this class.
 *
 * This class is used as format for the Expressions in the Agent language.
 * Since AD4M treats DID URIs as addresses for the Agent Language,
 * DIDs are resolved to Expressions that are objects of this class.
 * Thus, this is how agents see (other) agents.
 */
export declare class Agent {
    /** The DID of the Agent
     * All epxressions authored by them are signed with the keys mentioned
     * in the DID document behind this DID URI.
     */
    did: string;
    /** The Perspective that holds the public-facing semantics/statements of the Agent
     * Holds and shares a Perspective that links all information
     * this agent wants to offer as public-facing semantics.
     * This should be used for any kind of user profile information.
     */
    perspective?: Perspective;
    /** Address of the Language by which the Agent will receive DMs */
    directMessageLanguage?: string;
    /** The `did:scid` this agent speaks for (`agent.me()`); absent when it speaks for no one,
     * and on agents read from the agent language. `did` stays the device `did:key`. */
    identity?: string;
    constructor(did: string, perspective?: Perspective);
    /** Build an Agent (with its perspective's query helpers) from the executor's wire shape. */
    static fromWire(wire: WireAgent | AgentWithIdentity): Agent;
}
declare const AgentExpression_base: abstract new (author?: string, timestamp?: string, data?: Agent, proof?: import("../expression/Expression").ExpressionProof) => import("../expression/Expression").ExpressionShape<Agent, import("../expression/Expression").ExpressionProof>;
export declare class AgentExpression extends AgentExpression_base {
}
export declare class EntanglementProof {
    did: string;
    didSigningKeyId: string;
    deviceKeyType: string;
    deviceKey: string;
    deviceKeySignedByDid: string;
    didSignedByDeviceKey?: string;
    constructor(did: string, didSigningKeyId: string, deviceKeyType: string, deviceKey: string, deviceKeySignedByDid: string, didSignedByDeviceKey?: string);
}
export declare class EntanglementProofInput {
    did: string;
    didSigningKeyId: string;
    deviceKeyType: string;
    deviceKey: string;
    deviceKeySignedByDid: string;
    didSignedByDeviceKey: string;
    constructor(did: string, didSigningKeyId: string, deviceKeyType: string, deviceKey: string, deviceKeySignedByDid: string, didSignedByDeviceKey: string);
}
export declare class AgentSignature {
    signature: string;
    publicKey: string;
    constructor(signature: string, publicKey: string);
}
export declare class Resource {
    domain: string;
    pointers: string[];
    constructor(domain: string, pointers: string[]);
}
export declare class Capability {
    with: Resource;
    can: string[];
    constructor(withF: Resource, can: string[]);
}
export declare class AuthInfo {
    appName: string;
    appDesc: string;
    appUrl: string;
    appIconPath?: string;
    capabilities: Capability[];
    constructor(appName: string, appDesc: string, appUrl: string, capabilities: Capability[], appIconPath?: string);
}
export declare class Apps {
    requestId: string;
    token: string;
    revoked?: boolean;
    auth: AuthInfo;
    constructor(requestId: string, auth: AuthInfo, token: string, revoked?: boolean);
}
export declare class ResourceInput {
    domain: string;
    pointers: string[];
    constructor(domain: string, pointers: string[]);
}
export declare class CapabilityInput {
    with: ResourceInput;
    can: string[];
    constructor(withF: ResourceInput, can: string[]);
}
export declare class AuthInfoInput {
    appName: string;
    appDesc: string;
    appDomain: string;
    appUrl?: string;
    appIconPath?: string;
    capabilities?: CapabilityInput[];
    constructor(appName: string, appDesc: string, appDomain: string, appUrl?: string, appIconPath?: string, capabilities?: CapabilityInput[]);
}
export declare class UserCreationResult {
    did: string;
    success: boolean;
    error?: string;
    constructor(did: string, success: boolean, error?: string);
}
export {};
