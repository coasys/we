import { ApiClient, CallOptions } from '../apiClient';
import { PerspectiveInput } from "../perspectives/Perspective";
import { Agent, Apps, AuthInfoInput, EntanglementProof, EntanglementProofInput, UserCreationResult } from "./Agent";
import { HostingUserInfo, PaymentRequestResult, ComputeLogEntry } from "../runtime/RuntimeTypes";
import { AgentStatus } from "./AgentStatus";
import { LinkMutations } from "../links/Links";
import { VerificationRequestResult } from "../runtime/RuntimeTypes";
import type { AgentSignature } from "../generated/api/AgentSignature";
export interface InitializeArgs {
    did: string;
    didDocument: string;
    keystore: string;
    passphrase: string;
}
export declare class AgentClient {
    #private;
    /**
     * TTL of every cached profile, the own one too, in memory and in the
     * persistent cache (ms). `agent-updated` only comes from this executor, so
     * a profile changed through another executor of the same agent shows up
     * when the entry expires.
     */
    static REMOTE_AGENT_TTL_MS: number;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    me(): Promise<Agent>;
    status(): Promise<AgentStatus>;
    /** Creates the agent's keys and DID on first run. The executor refuses (409)
     *  an agent that is already initialised — {@link unlock} it instead; a second
     *  `generate` never replaces the existing keys and DID. */
    generate(passphrase: string, options?: CallOptions): Promise<AgentStatus>;
    import(args: InitializeArgs): Promise<AgentStatus>;
    lock(passphrase: string): Promise<AgentStatus>;
    unlock(passphrase: string, holochain?: boolean, options?: CallOptions): Promise<AgentStatus>;
    /**
     * The agent with this DID, or `null` when it is unknown. Concurrent calls
     * for any DIDs share one `agent.byDIDs` request.
     */
    byDID(did: string): Promise<Agent>;
    /**
     * Invalidate a specific DID's cache entry in both L1 and L2.
     */
    invalidateByDid(did: string): void;
    /**
     * Clear the entire L1 (memory) byDID cache.
     * L2 (IndexedDB) is preserved — agent data remains valid across sessions.
     */
    clearByDidCache(): void;
    updatePublicPerspective(perspective: PerspectiveInput): Promise<Agent>;
    mutatePublicPerspective({ additions, removals }: LinkMutations): Promise<Agent>;
    /**
     * Say what kind of agent this is in its public perspective (`AGENT_KIND`; a bot is
     * `AGENT_KIND_BOT`), replacing any kind it said before, or say none with `null`. Changes
     * nothing when the perspective already says exactly that, so it can be called on every start.
     */
    setKind(kind: string | null): Promise<Agent>;
    updateDirectMessageLanguage(directMessageLanguage: string): Promise<Agent>;
    addEntanglementProofs(proofs: EntanglementProofInput[]): Promise<EntanglementProof[]>;
    deleteEntanglementProofs(proofs: EntanglementProofInput[]): Promise<EntanglementProof[]>;
    getEntanglementProofs(): Promise<EntanglementProof[]>;
    entanglementProofPreFlight(deviceKey: string, deviceKeyType: string): Promise<EntanglementProof>;
    /**
     * Asks the executor for a capability token. `agent` names the agent the token will act
     * as: a managed user's email or an agent's DID; absent, the executor's main agent. That
     * agent's owner approves the request (the operator for the main agent, the user for
     * theirs). Returns the request id that {@link generateJwt} redeems with the approver's
     * six-digit code.
     */
    requestCapability(authInfo: AuthInfoInput, agent?: string): Promise<string>;
    permitCapability(auth: string): Promise<string>;
    generateJwt(requestId: string, rand: string): Promise<string>;
    getApps(): Promise<Apps[]>;
    removeApp(requestId: string): Promise<Apps[]>;
    revokeToken(requestId: string): Promise<Apps[]>;
    isLocked(): Promise<boolean>;
    signMessage(message: string): Promise<AgentSignature>;
    createUser(email: string, password: string): Promise<UserCreationResult>;
    loginUser(email: string, password: string): Promise<string>;
    requestLoginVerification(email: string, appInfo?: AuthInfoInput): Promise<VerificationRequestResult>;
    verifyEmailCode(email: string, code: string, verificationType: string): Promise<string>;
    /** Revokes this client's user token. The executor then closes the client's sockets. */
    logout(): Promise<boolean>;
    /**
     * Revokes every token of a user issued up to now, this client's own included, and closes
     * their sockets. A user leaves out `email` (or names themselves); the operator names the
     * user. Needs AGENT_UPDATE, which a login holds. Tokens from a later login work.
     */
    revokeAllSessions(email?: string): Promise<boolean>;
    hostingUserInfo(): Promise<HostingUserInfo>;
    computeLog(since?: string, limit?: number, userEmail?: string): Promise<ComputeLogEntry[]>;
    setHotWalletAddress(address: string): Promise<boolean>;
    requestPayment(amountHOT: string): Promise<PaymentRequestResult>;
}
