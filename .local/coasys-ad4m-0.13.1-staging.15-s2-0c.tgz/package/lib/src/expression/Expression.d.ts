import { Icon } from "../language/Icon";
import { LanguageRef } from "../language/LanguageRef";
type ClassType<T = any> = new (...args: any[]) => T;
export declare class ExpressionProof {
    signature: string;
    key: string;
    valid?: boolean;
    invalid?: boolean;
    constructor(sig: string, k: string);
}
export declare class ExpressionProofInput {
    signature: string;
    key: string;
    valid?: boolean;
    invalid?: boolean;
}
/** The fields every expression carries, with `DataType` as its data. */
export type ExpressionShape<DataType, Proof = ExpressionProof> = {
    author: string;
    timestamp: string;
    data: DataType;
    proof: Proof;
};
export declare function ExpressionGeneric<DataType>(DataTypeClass: ClassType<DataType>): abstract new (author?: string, timestamp?: string, data?: DataType, proof?: ExpressionProof) => ExpressionShape<DataType>;
export declare function ExpressionGenericInput<DataType>(DataTypeClass: ClassType<DataType>): abstract new () => ExpressionShape<DataType, ExpressionProofInput>;
declare const Expression_base: abstract new (author?: string, timestamp?: string, data?: Object, proof?: ExpressionProof) => ExpressionShape<Object, ExpressionProof>;
export declare class Expression extends Expression_base {
}
declare const ExpressionRendered_base: abstract new (author?: string, timestamp?: string, data?: String, proof?: ExpressionProof) => ExpressionShape<String, ExpressionProof>;
export declare class ExpressionRendered extends ExpressionRendered_base {
    /** The expression's data as a JSON string, as the executor renders it. */
    data: string;
    language: LanguageRef;
    icon: Icon;
}
export declare function isExpression(e: any): boolean;
export {};
