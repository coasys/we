import { ApiClient } from "../apiClient";
import { InteractionCall, InteractionMeta } from "../language/Language";
import { ExpressionRendered } from "./Expression";
export declare class ExpressionClient {
    #private;
    /** Maximum number of expressions kept in memory. */
    static MAX_MEM_ENTRIES: number;
    /** Maximum total size (in bytes of JSON) of the expressions kept in memory. */
    static MAX_MEM_BYTES: number;
    /**
     * TTL of every cached expression, in memory and in the persistent cache
     * (ms). A language may change what a URL returns, and no event tells the
     * client, so a cached expression expires instead of staying stale.
     */
    static EXPRESSION_TTL_MS: number;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    /** The expression at `url`; `alwaysGet` skips the literal fast path and the cache. */
    get(url: string, alwaysGet?: boolean): Promise<ExpressionRendered>;
    /**
     * The expressions at `urls`, in order (`null` when not found); the misses go
     * out in calls of at most 200 URLs. Rejects with the `RpcError` `get` gives when a URL's read fails.
     */
    getMany(urls: string[]): Promise<ExpressionRendered[]>;
    /**
     * Clear both the memory and the persistent expression caches.
     */
    clearCache(): void;
    getRaw(url: string): Promise<string>;
    create(content: unknown, languageAddress: string): Promise<string>;
    interactions(url: string): Promise<InteractionMeta[]>;
    interact(url: string, interactionCall: InteractionCall): Promise<string | null>;
}
