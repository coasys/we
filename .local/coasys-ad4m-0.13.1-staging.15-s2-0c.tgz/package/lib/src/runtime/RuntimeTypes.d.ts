import { PerspectiveExpression } from "../perspectives/Perspective";
import { ExceptionType } from "../Exception";
export declare class SentMessage {
    recipient: string;
    message: PerspectiveExpression;
}
export declare class RuntimeInfo {
    ad4mExecutorVersion: string;
    /** The commit the executor was built from, or null when the build could not tell. */
    ad4mExecutorCommit: string | null;
    isInitialized: Boolean;
    isUnlocked: Boolean;
}
export declare class ExceptionInfo {
    title: string;
    message: string;
    type: ExceptionType;
    addon?: string;
}
export declare class NotificationInput {
    description: string;
    appName: string;
    appUrl: string;
    appIconPath: string;
    trigger: string;
    perspectiveIds: string[];
    webhookUrl: string;
    webhookAuth: string;
}
export type NotificationUpdate = Omit<NotificationInput, 'webhookAuth'> & {
    webhookAuth?: string;
};
export declare class Notification {
    id: string;
    granted: boolean;
    description: string;
    appName: string;
    appUrl: string;
    appIconPath: string;
    trigger: string;
    perspectiveIds: string[];
    webhookUrl: string;
    hasWebhookAuth: boolean;
    ownerDid: string;
}
export declare class TriggeredNotification {
    notification: Notification;
    perspectiveId: string;
    triggerMatch: string;
}
export declare class ImportStats {
    total: number;
    imported: number;
    failed: number;
    omitted: number;
    errors: string[];
}
export declare class ImportResult {
    perspectives: ImportStats;
    links: ImportStats;
    expressions: ImportStats;
    perspectiveDiffs: ImportStats;
    notifications: ImportStats;
    aiEndpoints: ImportStats;
    models: ImportStats;
    defaultModels: ImportStats;
    tasks: ImportStats;
    friends: ImportStats;
    trustedAgents: ImportStats;
    knownLinkLanguages: ImportStats;
}
export declare class UserStatistics {
    email: string;
    did: string;
    lastSeen?: string;
    perspectiveCount: number;
    remainingCredits: string;
    freeAccess: boolean;
    hotWalletAddress?: string;
}
export declare class VerificationRequestResult {
    success: boolean;
    message: string;
    requiresPassword: boolean;
    isExistingUser: boolean;
}
export declare class HostingUserInfo {
    email: string;
    remainingCredits: string;
    hotWalletAddress?: string;
    freeAccess: boolean;
    constructor(email: string, remainingCredits: string, hotWalletAddress?: string, freeAccess?: boolean);
}
export declare class PaymentRequestResult {
    success: boolean;
    amountHOT: string;
    constructor(success: boolean, amountHOT: string);
}
export declare class ComputeLogEntry {
    id: number;
    userEmail: string;
    timestamp: string;
    operation: string;
    summary?: string;
    cost: number;
    creditsAfter: number;
    constructor(id: number, userEmail: string, timestamp: string, operation: string, cost: number, creditsAfter: number, summary?: string);
}
