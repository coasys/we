import { ApiClient, CallOptions } from '../apiClient';
import { Perspective, PerspectiveExpression } from "../perspectives/Perspective";
import { RuntimeInfo, SentMessage, NotificationInput, NotificationUpdate, Notification, ImportResult, UserStatistics } from "./RuntimeTypes";
import type { HostRate, LogTail, RuntimeConfig, SetConfigResult, UnytVersionInfo } from "../generated/api";
import { LanguageMeta } from "../language/LanguageMeta";
export declare class RuntimeClient {
    #private;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    info(): Promise<RuntimeInfo>;
    tlsDomain(): Promise<string | null>;
    /** Stops the executor (exit 0). Only the operator on the executor's machine. */
    quit(): Promise<Boolean>;
    /** Answers, then the executor exits 75 and its supervisor starts it again. */
    restart(): Promise<boolean>;
    /** The newest lines (at most 2000) of the executor's log file (`--log-dir`). */
    logTail(lines: number): Promise<LogTail>;
    /** The executor's config file: its values, every key with its class, and whether a write waits for a restart. */
    config(): Promise<RuntimeConfig>;
    /**
     * Writes keys to the executor's config file (`--config`); they take effect at the next
     * start. A `machine` key from a caller off the executor's machine is refused `local-only`.
     */
    setConfig(set?: Record<string, unknown>, unset?: string[]): Promise<SetConfigResult>;
    openLink(url: string): Promise<Boolean>;
    addTrustedAgents(agents: string[]): Promise<string[]>;
    deleteTrustedAgents(agents: string[]): Promise<string[]>;
    getTrustedAgents(): Promise<string[]>;
    addKnownLinkLanguageTemplates(addresses: string[]): Promise<string[]>;
    removeKnownLinkLanguageTemplates(addresses: string[]): Promise<string[]>;
    /** Every link-language template the executor knows, with its meta (name, description,
     *  `possibleTemplateParams`). A template whose meta cannot be read is left out. */
    knownLinkLanguageTemplates(): Promise<LanguageMeta[]>;
    addFriends(dids: string[]): Promise<string[]>;
    removeFriends(dids: string[]): Promise<string[]>;
    friends(): Promise<string[]>;
    hcAgentInfos(): Promise<string[]>;
    getNetworkMetrics(): Promise<string>;
    restartHolochain(options?: CallOptions): Promise<boolean>;
    hcAddAgentInfos(agentInfos: string[]): Promise<boolean>;
    verifyStringSignedByDid(did: string, didSigningKeyId: string, data: string, signedData: string): Promise<boolean>;
    setStatus(perspective: Perspective): Promise<boolean>;
    friendStatus(did: string): Promise<PerspectiveExpression>;
    friendSendMessage(did: string, message: Perspective): Promise<boolean>;
    messageInbox(): Promise<PerspectiveExpression[]>;
    messageOutbox(): Promise<SentMessage[]>;
    requestInstallNotification(notification: NotificationInput): Promise<string>;
    grantNotification(id: string): Promise<boolean>;
    exportDb(filePath: string): Promise<boolean>;
    importDb(filePath: string): Promise<ImportResult>;
    notifications(): Promise<Notification[]>;
    updateNotification(id: string, notification: NotificationUpdate): Promise<boolean>;
    removeNotification(id: string): Promise<boolean>;
    exportPerspective(uuid: string, filePath: string): Promise<boolean>;
    importPerspective(filePath: string): Promise<boolean>;
    multiUserEnabled(): Promise<boolean>;
    setMultiUserEnabled(enabled: boolean): Promise<boolean>;
    freeHostingEnabled(): Promise<boolean>;
    setFreeHostingEnabled(enabled: boolean): Promise<boolean>;
    listUsers(): Promise<UserStatistics[]>;
    userWalletAddress(email: string): Promise<string | null>;
    emailTestModeEnable(): Promise<boolean>;
    emailTestModeDisable(): Promise<boolean>;
    emailTestGetCode(email: string): Promise<string | null>;
    emailTestClearCodes(): Promise<boolean>;
    emailTestSetExpiry(email: string, verificationType: string, expiresAt: number): Promise<boolean>;
    unytAgentKey(): Promise<string>;
    unytHotAgentPubkey(): Promise<string>;
    unytWalletBalance(): Promise<string>;
    unytWalletHistory(page?: number, perPage?: number): Promise<string>;
    /** Installed and bundled DNA versions, and why the last install failed (`installError`). */
    unytVersionInfo(): Promise<UnytVersionInfo>;
    /** Stores the membrane proof (base64); the executor then installs the Unyt DNA in the
     *  background. Poll {@link unytVersionInfo} for the outcome. */
    setUnytMembraneProof(proof: string): Promise<boolean>;
    unytReinstallDna(): Promise<{
        success: boolean;
        message: string;
    }>;
    unytSendHot(recipient: string, amount: string): Promise<{
        success: boolean;
        message: string;
    }>;
    setUserCredits(email: string, amount: number): Promise<boolean>;
    setUserFreeAccess(email: string, enabled: boolean): Promise<boolean>;
    setHostRates(rates: HostRate[]): Promise<boolean>;
    hostRates(): Promise<HostRate[]>;
}
