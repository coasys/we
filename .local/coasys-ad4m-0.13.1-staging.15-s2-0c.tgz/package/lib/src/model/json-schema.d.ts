/**
 * JSON Schema → Ad4mModel class builder and related utilities.
 *
 * Contains:
 * - JSON Schema type definitions (JSONSchemaProperty, JSONSchema, JSONSchemaToModelOptions)
 * - Schema type helpers (normalizeNamespaceString, isArrayType, etc.)
 * - Predicate / namespace resolution helpers
 * - `buildModelFromJSONSchema()` — core implementation of `Ad4mModel.fromJSONSchema()`
 *
 * @module
 */
import type { Ad4mModel } from "./Ad4mModel";
import type { PropertyOptions } from "./decorators";
export interface JSONSchemaProperty {
    type: string | string[];
    items?: JSONSchemaProperty;
    properties?: {
        [key: string]: JSONSchemaProperty;
    };
    required?: string[];
    "x-ad4m"?: {
        through?: string;
        resolveLanguage?: string;
        local?: boolean;
        writable?: boolean;
        initial?: string;
    };
}
export interface JSONSchema {
    $schema?: string;
    title?: string;
    $id?: string;
    type?: string;
    properties?: {
        [key: string]: JSONSchemaProperty;
    };
    required?: string[];
    "x-ad4m"?: {
        namespace?: string;
        className?: string;
    };
}
export interface JSONSchemaToModelOptions {
    name: string;
    namespace?: string;
    predicateTemplate?: string;
    predicateGenerator?: (title: string, property: string) => string;
    propertyMapping?: Record<string, string>;
    resolveLanguage?: string;
    local?: boolean;
    propertyOptions?: Record<string, Partial<PropertyOptions>>;
}
export declare function normalizeNamespaceString(namespace: string): string;
export declare function normalizeSchemaType(type?: string | string[]): string | undefined;
export declare function isSchemaType(schema: JSONSchemaProperty, expectedType: string): boolean;
export declare function isArrayType(schema: JSONSchemaProperty): boolean;
export declare function isObjectType(schema: JSONSchemaProperty): boolean;
export declare function isNumericType(schema: JSONSchemaProperty): boolean;
/**
 * Determines the namespace for predicates using cascading precedence:
 * 1. Explicit namespace in options
 * 2. x-ad4m metadata in schema
 * 3. Infer from schema title
 * 4. Try to extract from $id
 * 5. Error if nothing works
 */
export declare function determineNamespace(schema: JSONSchema, options: JSONSchemaToModelOptions): string;
/**
 * Determines the predicate for a specific property using cascading precedence:
 * 1. Explicit property mapping
 * 2. x-ad4m metadata in property schema
 * 3. Predicate template
 * 4. Custom predicate generator
 * 5. Default: namespace + property name
 */
export declare function determinePredicate(schema: JSONSchema, propertyName: string, propertySchema: JSONSchemaProperty, namespace: string, options: JSONSchemaToModelOptions): string;
/**
 * Gets property-specific options using cascading precedence:
 * 1. Property-specific options
 * 2. x-ad4m metadata in property
 * 3. Global option
 * 4. Default value
 */
export declare function getPropertyOption(propertyName: string, propertySchema: JSONSchemaProperty, options: JSONSchemaToModelOptions, optionName: keyof PropertyOptions, defaultValue?: any): any;
/**
 * Gets default value for a JSON Schema type.
 */
export declare function getDefaultValueForType(type?: string): any;
/**
 * Core implementation of `Ad4mModel.fromJSONSchema()`.
 *
 * Creates a dynamic Ad4mModel subclass from a JSON Schema definition,
 * wiring up property / relation metadata, setters, and the `@Model` decorator.
 *
 * @param BaseClass - The Ad4mModel class (or subclass) to extend
 * @param schema    - JSON Schema definition
 * @param options   - Configuration options
 * @returns Generated Ad4mModel subclass
 */
export declare function buildModelFromJSONSchema(BaseClass: typeof Ad4mModel, schema: JSONSchema, options: JSONSchemaToModelOptions): typeof Ad4mModel;
