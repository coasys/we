/**
 * hydration.ts — Instance hydration helpers extracted from Ad4mModel.
 *
 * After the Rust model_query pipeline migration, most hydration logic moved
 * to Rust. This file retains:
 *   - normalizeValue() — snapshot dirty-tracking
 */
/**
 * Normalize a value for snapshot storage.
 * Arrays of model instances are reduced to their `.id` strings so that
 * dirty-tracking compares stable identifiers instead of object references.
 */
export declare function normalizeValue(value: any): any;
