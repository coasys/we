/**
 * Shared query helpers used by both the Prolog and SPARQL query pipelines.
 */
import type { Scope, TraverseScope } from "./types";
/**
 * The `totalCount` of a model query sent with `count: true`. The executor
 * answers such a query with a count, so an answer without one is an error,
 * not zero matches.
 */
export declare function requireTotalCount(answer: {
    totalCount?: number;
} | null | undefined): number;
/**
 * Resolves the predicate for a parent query.
 *
 * Uses TS discriminated union narrowing:
 * - Raw form (`{ id, predicate }`) → predicate used as-is
 * - Model form (`{ model, id, field? }`) → lookup from relation metadata
 *   - With `field`: direct key lookup
 *   - Without `field`: scan for a relation whose `target()` matches `childCtor`
 */
/**
 * Narrow a scope to the one-parent forms, for the paths that write a link.
 *
 * A traversal describes a read outward from several anchors. Creating a record
 * "under" one would have to pick which, and nothing in the scope says — so this
 * refuses rather than guessing at the first of the list. The executor's write
 * scopes refuse it for the same reason.
 */
export declare function requireSingleParent(parent: Scope): Exclude<Scope, TraverseScope>;
export declare function resolveParentPredicate(parent: Scope, childCtor: Function): string;
