/**
 * SPARQL query building utilities for Ad4mModel.
 *
 * Uses the RDF 1.2 reifier storage model where each AD4M link is stored as:
 * 1. Direct triple: <source> <predicate> <target> . (default graph)
 * 2. Reifier: <link:HASH> <http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies> <<( source predicate target )>> .
 * 3. Metadata: <link:HASH> ad4m://ontology/* "value" . (default graph)
 *
 * All AD4M URIs (source, predicate, target) become RDF IRIs.
 *
 * @module
 */
import type { RelationMetadataEntry } from "./decorators";
import type { Where, Query, ModelMetadata } from "./types";
/**
 * Check whether a `where` clause contains filters that cannot be pushed down
 * to SPARQL and must be evaluated in JS after hydration.
 *
 * JS-only filters include:
 * - Literal-stored properties (equality, comparison, contains, etc.)
 * - Reverse relations (belongsToOne / belongsToMany)
 * - author / timestamp filters (skipped by buildSPARQLWhereFilters)
 * - OR / AND / NOT combinators (skipped by buildSPARQLWhereFilters — see below)
 *
 * When JS-only filters exist, SPARQL-level LIMIT/OFFSET must NOT be applied
 * because the database would cap the candidate set before JS filters run,
 * potentially discarding matches beyond the LIMIT.
 */
export declare function hasJsOnlyWhereFilters(metadata: ModelMetadata, allRelationsMetadata: Record<string, RelationMetadataEntry>, where?: Where): boolean;
/**
 * Prepare a `where` for this client-side SPARQL builder: unwrap `{ eq: X }`
 * to the bare `X`, and refuse a per-link `author`.
 *
 * A per-link `author` (nested, `{ agent: { eq: X, author: A } }`, or a
 * top-level `author` beside link-backed property or relation conditions) is
 * answered by the executor, which joins each matched link's reifier (#1114). This builder
 * has no such join, and treating the author as instance-level here would
 * answer a different, wider question. `findAll()`/`count()` answer it.
 */
export declare function normalizeWhereForSparql(metadata: ModelMetadata, where?: Where): Where | undefined;
/**
 * Check whether a string value is a well-formed absolute IRI that can be
 * stored verbatim as a link target (raw `NamedNode`) instead of being
 * wrapped in a `literal:string:*` URI.
 *
 * This mirrors the Rust `is_safe_iri_target` /
 * `looks_like_absolute_iri` predicate in
 * `rust-executor/src/perspectives/model_query/utils.rs` and is
 * **load-bearing**: a value that returns `true` here MUST also be safely
 * queryable on the Rust side (`validate_iri` gate on the SPARQL
 * `UNION { ?s <pred> <val> }` IRI arm), otherwise scheme-lookalike prose
 * such as `"Note: buy milk"`, `"Re: standup"`, `"TODO: fix this"` slips
 * through the write regex, is stored as an invalid `NamedNode`, and
 * becomes a silent no-match on read.
 *
 * Fast-path scheme check (`^[a-zA-Z][a-zA-Z0-9+\-._]*:`) followed by the
 * same rejection set the Rust `validate_iri` applies: any Unicode
 * whitespace, C0/C1 control chars, and the SPARQL-breaking characters
 * `< > { } "`.
 */
export declare function looksLikeUri(value: string): boolean;
/**
 * Convert a JS value to its literal: IRI form, matching how the Rust executor
 * stores property values in the default deterministic-literal path
 * (`resolveLanguage` unset). Strings that already look like URIs are returned
 * as-is.
 *
 * Exported so write-side helpers (e.g. `Ad4mModel.setProperty`'s literal
 * resolve path) can keep their on-disk form aligned with what
 * `queryToSPARQL()` filters against — otherwise the same value can be
 * stored as `<literal:string:https%3A...>` from one path while WHERE
 * builders probe `<https://example.com>` from the other.
 *
 * The object/array arm mirrors Rust's `Literal::from_json` in
 * `perspective_instance.rs::resolve_property_value` (which routes
 * `Value::Object | Value::Array` through JSON encoding). Without it, JS
 * would fall through to `String(value)` and turn `{a: 1}` into
 * `"[object Object]"` and `[1, 2, 3]` into `"1,2,3"` before wrapping.
 */
export declare function valueToLiteralIri(value: any): string;
/** How a property's value is stored / resolved. */
export type LiteralStorageMode = {
    kind: "deterministic";
} | {
    kind: "envelope";
} | {
    kind: "custom";
    language: string;
};
/**
 * Derive the effective storage mode from a property's explicit options.
 * `resolveLanguage` is the sole selector and is NOT defaulted at the
 * decorator level:
 *   - unset               → deterministic typed literal (the perf default
 *                            for a plain `@Property()`)
 *   - `"literal"`         → signed envelope on the built-in literal language
 *                            (per-value provenance, e.g. Flux message bodies)
 *   - `<custom address>`  → signed expression on that custom language
 */
export declare function effectiveLiteralStorage(meta: {
    resolveLanguage?: string;
}): LiteralStorageMode;
/**
 * Format a value as a SPARQL string literal (double-quoted).
 */
export declare function formatSPARQLValue(value: any): string;
/**
 * Build a SPARQL query that returns all links belonging to instances of
 * the given model class, optionally filtered by `where` conditions.
 *
 * Uses direct triple patterns: ?source ?predicate ?target
 * with named graph storage and metadata keyed by graph IRI.
 */
export declare function buildSPARQLQuery(metadata: ModelMetadata, allRelationsMetadata: Record<string, RelationMetadataEntry>, query: Query, modelClass: any): string;
/**
 * Build an inner subquery that selects DISTINCT ?source URIs with
 * ORDER BY, LIMIT, and OFFSET applied at the instance level.
 *
 * Because the outer SELECT returns multiple rows per instance (one per link),
 * we cannot apply LIMIT/OFFSET there.  Instead this subquery constrains
 * ?source to only the instances on the requested page.
 *
 * @internal — used by buildSPARQLQuery when SPARQL-level pagination is safe.
 */
export declare function buildPaginationSubquery(joinPatterns: string[], filterExpressions: string[], metadata: ModelMetadata, query: Query): string;
