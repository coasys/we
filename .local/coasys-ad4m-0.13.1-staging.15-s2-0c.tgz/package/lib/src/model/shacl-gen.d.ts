/**
 * SHACL shape generation for AD4M model classes.
 *
 * Builds a W3C SHACL `SHACLShape` (with AD4M-specific action extensions)
 * from a model's property and relation metadata.  The heavy lifting used
 * to live inside the `@Model` decorator closure — it is extracted here so
 * decorators.ts stays focused on decorator registration logic.
 */
import { SHACLShape } from "../shacl/SHACLShape";
import type { ConformanceCondition } from "../shacl/SHACLShape";
import type { PropertyMetadataEntry, RelationMetadataEntry, Ad4mModelLike } from "./decorators";
/** Signature for the conformance-filter builder injected by the caller. */
export type ConformanceFilterFn = (relationPredicate: string, targetClass: Ad4mModelLike) => {
    getter: string;
    conformanceConditions: ConformanceCondition[];
} | undefined;
/**
 * Build a SHACL shape for a model class.
 *
 * @param subjectName          - The model's registered name (from `@Model({ name })`)
 * @param target               - The class constructor (used for prototype access,
 *                               inheritance chain, and relation target resolution)
 * @param properties           - Merged property metadata (from `getPropertiesMetadata`)
 * @param allRelationsMeta     - Merged relation metadata (from `getRelationsMetadata`)
 * @param conformanceFilterFn  - Injected conformance-filter builder
 *                               (avoids circular dependency back into decorators.ts)
 */
export declare function buildSHACL(subjectName: string, target: any, properties: Record<string, PropertyMetadataEntry>, allRelationsMeta: Record<string, RelationMetadataEntry>, conformanceFilterFn: ConformanceFilterFn, 
/**
 * Optional early-cache seeding callback. When invoked with a
 * partial `{ shape, name }`, any re-entrant `generateSHACL()`
 * call on the same target — which happens when a relation's
 * `target: () => SameClass` points at us, directly or
 * transitively — observes the in-progress shape rather than
 * re-entering this function infinitely. Provided by `@Model` via
 * `getMemoizedSHACL`; safe to omit when calling `buildSHACL`
 * directly (e.g. from a one-off SDNA build tool).
 */
seedCache?: (partial: {
    shape: SHACLShape;
    name: string;
}) => void, 
/**
 * Natural-language hint declared on the `@Model` decorator that
 * steers the generic LLM extractor when producing instances of
 * this class.  Attached to the SHACL shape node and re-emitted as
 * an `ad4m://interpretation_hint` link by `SHACLShape.toLinks()`.
 */
interpretationHint?: string, 
/** `@Model({ abstract: true })`: emitted as one `ad4m://abstract` link. */
isAbstract?: boolean, 
/** `@Model({ namespace })`: the namespace of the class and shape URIs. */
namespace?: string): {
    shape: SHACLShape;
    name: string;
};
