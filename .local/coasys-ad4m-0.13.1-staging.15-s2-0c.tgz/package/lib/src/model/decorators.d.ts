import type { Where } from "./types";
import type { ConformanceCondition } from "../shacl/SHACLShape";
/** Metadata stored for each property via @Property / @Optional / @ReadOnly / @Flag */
export interface PropertyMetadataEntry extends PropertyOptions {
    /** Internal computed writable flag (inverse of readOnly) for SDNA/SHACL compatibility */
    writable?: boolean;
    flag?: boolean;
}
/** Metadata stored for each relation via @HasMany / @HasOne / @BelongsToOne / @BelongsToMany */
export interface RelationMetadataEntry {
    predicate: string;
    /** Target model class thunk. Optional for untyped string relations. */
    target?: () => Ad4mModelLike;
    kind: 'hasMany' | 'hasOne' | 'belongsToOne' | 'belongsToMany';
    /**
     * Maximum number of related instances.
     * Set automatically: 1 for `@HasOne`/`@BelongsToOne`, undefined (unlimited) for `*Many`.
     */
    maxCount?: number;
    local?: boolean;
    /**
     * Custom getter to resolve the relation values.
     * The expression can reference 'Base' which will be replaced with the instance's base expression.
     */
    getter?: string;
    /** No writer for this relation; see `RelationOptions.readOnly`. */
    readOnly?: boolean;
    /**
     * Whether to auto-generate a conformance filter when `target` is set.
     * Defaults to `true` — set to `false` to opt out of DB-level type filtering
     * while keeping hydration capability via `include`.
     */
    filter?: boolean;
    /**
     * Filter constraints on linked target nodes using the query DSL.
     * Property names reference the target model's properties.
     * Overrides auto-derived conformance when set.
     */
    where?: Where;
    /**
     * SHACL `sh:datatype` for the relation's target values. Set when the
     * relation holds encoded literal values (e.g. `"xsd:string"` for a
     * `HasMany<string>` that stores plain strings). Emitted into SHACL
     * so the executor knows to decode `literal:<type>:<value>` wire form
     * on hydration. Omit for URI relations that point at other model
     * instances — those pass through byte-for-byte.
     */
    datatype?: string;
    /** Hydrate targets as the class each one actually is — see `RelationOptions.polymorphic`. */
    polymorphic?: boolean;
    /** Model classes this relation's polymorphic results can be constructed as. */
    instantiateAs?: () => Ad4mModelLike[];
    /** CRDT ordering config — see `RelationOptions.ordering`. */
    ordering?: {
        strategy: 'linkedList';
    };
    /**
     * Natural-language hint describing what this relation MEANS semantically.
     * Emitted as an `ad4m://interpretation_hint` link on the SHACL property
     * node; read back by the Rust harness and rendered into the
     * `_propose_link_child` tool's `predicate` field description. Mirror of
     * the same field on `RelationOptions` (the decorator arg); this is the
     * memoized registry copy.
     */
    interpretationHint?: string;
    /** Names for abstract classes — see `RelationOptions.alias`. */
    alias?: Record<string, string>;
}
/**
 * Retrieve property metadata for a given class constructor.
 * Walks the prototype chain so subclass decorators compose with parent decorators.
 * Results are memoised per class constructor.
 */
export declare function getPropertiesMetadata(ctor: Function): Record<string, PropertyMetadataEntry>;
/**
 * Retrieve relation metadata for a given class constructor.
 * Walks the prototype chain so subclass decorators compose with parent decorators.
 * Results are memoised per class constructor.
 */
export declare function getRelationsMetadata(ctor: Function): Record<string, RelationMetadataEntry>;
/**
 * Get or compute memoised SHACL for a class. Used by @Model decorator.
 *
 * The `compute` callback receives a `seed(partial)` function: calling
 * it stores `partial` in the cache *before* `compute` returns, so any
 * re-entrant `getMemoizedSHACL(target, …)` call from inside `compute`
 * observes the in-progress shape instead of re-entering `compute`
 * infinitely.
 *
 * This matters for self-referential models — e.g.
 *
 *     @Model({ name: "Channel" })
 *     class Channel extends Ad4mModel {
 *         @HasMany({ predicate: "…/child", target: () => Channel })
 *         childChannels!: Channel[];
 *     }
 *
 * Without the seed, building the SHACL shape for `Channel` invokes
 * `Channel.generateSHACL()` while walking the `childChannels`
 * relation's target (shacl-gen.ts ~line 327), which re-enters this
 * function with an empty cache, blowing the stack.
 */
export declare function getMemoizedSHACL(target: Function, compute: (seed: (partial: any) => void) => any): any;
/**
 * Programmatically register property metadata for a given constructor.
 * Used by `fromJSONSchema()` and other dynamic model builders.
 */
export declare function setPropertyRegistryEntry(ctor: Function, propName: string, meta: PropertyMetadataEntry & {
    writable?: boolean;
}): void;
/**
 * Programmatically register relation metadata for a given constructor.
 * Used by `fromJSONSchema()` and other dynamic model builders.
 */
export declare function setRelationRegistryEntry(ctor: Function, relName: string, meta: RelationMetadataEntry): void;
/**
 * Interface for any class that looks like an Ad4mModel (used in circular-ref-safe typings).
 */
export interface Ad4mModelLike {
    new (...args: any[]): any;
    className?: string;
    /** Set by `@Model({ abstract: true })`. */
    isAbstract?: boolean;
    generateSDNA?: () => any;
    generateSHACL?: () => any;
}
/**
 * Build a conformance filter for a relation whose target model is known.
 *
 * Inspects the target class's property metadata to derive:
 * - `conformanceConditions`: Structured, DB-agnostic conditions (flag & required checks)
 * - `getter`: Pre-computed graph traversal expression that traverses outgoing links and filters
 *   target nodes to only those conforming to the target shape.
 *
 * @param relationPredicate - The relation's predicate URI (e.g. "flux://entry_type")
 * @param targetClass       - The target model class (resolved from the target() thunk)
 * @returns `{ getter, conformanceConditions }` or `undefined` if no conditions could be derived
 */
export declare function buildConformanceFilter(relationPredicate: string, targetClass: Ad4mModelLike): {
    getter: string;
    conformanceConditions: ConformanceCondition[];
} | undefined;
export interface PropertyOptions {
    /**
     * The predicate of the property. All properties must have this option.
     */
    through?: string;
    /**
     * The initial value of the property. Required if the property is marked as required.
     */
    initial?: string;
    /**
     * Indicates whether the property is required. If true, an initial value must be provided.
     */
    required?: boolean;
    /**
     * Indicates whether the property is read-only. If true, no setter will be generated.
     * Defaults to false (property is writable).
     */
    readOnly?: boolean;
    /**
     * The language used to resolve/store the property value — and the sole
     * selector of storage mode. Not defaulted:
     *   - unset (the default for a plain `@Property()`) → deterministic
     *     typed literal storage (`literal:string:` / `:number:` / `:boolean:` /
     *     `:json:` IRIs stored as XSD-typed RDF literals; POS-index friendly).
     *   - `"literal"` → the built-in literal language: values go through
     *     `expression_create`, producing a signed-envelope URI with
     *     author/timestamp/proof (per-value provenance, e.g. Flux message
     *     bodies).
     *   - a custom language address → `expression_create` on that language.
     */
    resolveLanguage?: string;
    /**
     * Custom Prolog getter to get the value of the property. If not provided, the default getter will be used.
     */
    prologGetter?: string;
    /**
     * Custom Prolog setter to set the value of the property. Only available if the property is writable.
     */
    prologSetter?: string;
    /**
     * Custom getter to resolve the property value. Use this for custom graph traversals.
     * The expression can reference 'Base' which will be replaced with the instance's base expression.
     * Example: "SELECT ?target WHERE { <Base> <flux://has_reply> ?target . } LIMIT 1"
     */
    getter?: string;
    /**
     * Indicates whether the property is stored locally in the perspective and not in the network. Useful for properties that are not meant to be shared with the network.
     */
    local?: boolean;
    /**
     * Optional transform expression to modify the property value.
     * This is a SHACL-AF Node Expression that runs in the Rust model query engine.
     * Examples: `fileToDataUri`, `concat(literal('prefix_'), focus())`, etc.
     * Builders (`focus`, `literal`, `path`, `exists`, `ifExpr`, `concat`,
     * `coalesce`, `fn`) and the `fileToDataUri` built-in are exported from
     * the package root: `import { concat, literal, focus } from '@coasys/ad4m'`.
     */
    transform?: import('../shacl/NodeExpression').NodeExpression;
    /**
     * Allowed values for this property (enum constraint).
     * Maps to SHACL `sh:in`. Each entry has a `value` (the stored RDF term)
     * and an optional `label` (human-readable display name).
     *
     * @example
     * ```typescript
     * @Property({
     *   through: "task://status",
     *   options: [
     *     { value: "task://todo", label: "To Do" },
     *     { value: "task://doing", label: "Doing" },
     *     { value: "task://done", label: "Done" },
     *   ]
     * })
     * status: string = "task://todo";
     * ```
     */
    options?: Array<{
        value: string;
        label?: string;
    }>;
    /**
     * Natural-language hint that steers the generic LLM extractor when
     * turning a transcript into typed subject-class instances.  Emitted as
     * an `ad4m://interpretation_hint` link on the property shape and surfaced
     * on `ShapeProperty.interpretation_hint` by the Rust model query so the
     * extractor prompt can quote it verbatim.
     */
    interpretationHint?: string;
    /**
     * Marks this property as the class's **identity** (dedup key) for the
     * generic LLM interpreter: on re-runs, two proposed instances of the same
     * class with an equal (normalized/semantic) value on the identity property
     * are treated as the same instance rather than duplicated. Emitted as an
     * `ad4m://identity` link on the property shape and read back by the Rust
     * model query (`ShapeProperty.identity`). At most one property per class
     * should set this.
     */
    identity?: boolean;
    /**
     * Explicit SHACL `sh:datatype` for the property value. When set, this
     * overrides auto-inference and — importantly — lets custom `getter`
     * properties opt into typed-literal decoding. Auto-inference is disabled
     * for properties with a `getter` (see `shacl-gen.ts`) because such
     * getters typically return URIs; setting `datatype` explicitly declares
     * that this getter returns literal values of the given XSD type
     * (e.g. `"xsd://string"`) and enables the hydration decode gate.
     */
    datatype?: string;
    /**
     * The name this property answers to through an abstract class, keyed by
     * its name: `alias: { TextContent: "text" }` reads (and writes) `body` as
     * `text` through `TextContent`. Registering fails if the class already
     * uses that name.
     */
    alias?: Record<string, string>;
}
/**
 * Convenience decorator for defining optional (not required) properties.
 *
 * @category Decorators
 *
 * @description
 * Equivalent to `@Property` but defaults `required` to `false` and does not
 * apply any `initial` defaults.  Use this when a property
 * may or may not have a value, and you want full control over its configuration.
 *
 * @example
 * ```typescript
 * class Recipe extends Ad4mModel {
 *   @Optional({ through: "recipe://description" })
 *   description?: string;
 * }
 * ```
 *
 * @param {PropertyOptions} opts - Property configuration (same options as @Property)
 */
export declare function Optional(opts: PropertyOptions): <T>(target: T, key: keyof T) => void;
export interface FlagOptions {
    /**
     * The predicate of the property. All properties must have this option.
     */
    through: string;
    /**
     * The value of the property.
     */
    value: string;
}
/**
 * Decorator for defining flags on model classes.
 *
 * @category Decorators
 *
 * @description
 * A specialized property decorator for defining immutable type flags or markers on model instances.
 * Flags are always required properties with a fixed value that cannot be changed after creation.
 *
 * Common uses for flags:
 * - Type discrimination between different kinds of models
 * - Marking models with specific capabilities or features
 * - Versioning or compatibility markers
 *
 * Note: Use of Flag is discouraged unless you specifically need type-based filtering or
 * discrimination between different kinds of models. For most cases, regular properties
 * with @Property or @Optional are more appropriate.
 *
 * @example
 * ```typescript
 * class Message extends Ad4mModel {
 *   // Type flag to identify message models
 *   @Flag({
 *     through: "ad4m://type",
 *     value: "ad4m://message"
 *   })
 *   type: string = "";
 *
 *   // Version flag for compatibility
 *   @Flag({
 *     through: "ad4m://version",
 *     value: "1.0.0"
 *   })
 *   version: string = "";
 *
 *   // Feature flag
 *   @Flag({
 *     through: "message://feature",
 *     value: "message://encrypted"
 *   })
 *   feature: string = "";
 * }
 *
 * // Later you can query for specific types:
 * const messages = await Message.query(perspective)
 *   .where({ type: "ad4m://message" })
 *   .run();
 * ```
 *
 * @param {FlagOptions} opts - Flag configuration
 * @param {string} opts.through - The predicate URI for the flag
 * @param {string} opts.value - The fixed value for the flag
 */
export declare function Flag(opts: FlagOptions): <T>(target: T, key: keyof T) => void;
export interface ModelConfig {
    /**
     * The name of the entity.
     */
    name: string;
    /**
     * The namespace of the class: its target class is `{namespace}{name}`
     * and its shape `{namespace}{name}Shape` (e.g. `"recipe://"`). Without
     * it the namespace is the scheme of the first property's `through`
     * (else of the first relation's predicate, else `ad4m://`), so moving
     * the first field can move the class.
     */
    namespace?: string;
    /**
     * An abstract class names properties a record has, not what it is.
     * Querying it reads every installed class that has all of its names (or
     * aliases for them), matched by name, never by `through`; rows keep
     * their `__subjectClass`. It cannot be created. `save()` and `delete()`
     * on a row read through it run the setters and destructors of the
     * record's own classes; values are not converted between them.
     */
    abstract?: boolean;
    /**
     * Abstract classes this class is meant to be read through: checked at
     * declaration (every name of each must be a name or alias here). The
     * executor matches by structure, listed or not.
     */
    implements?: Ad4mModelLike[];
    /**
     * Natural-language hint that steers the generic LLM extractor when
     * turning a transcript into instances of this class.  Emitted as an
     * `ad4m://interpretation_hint` link on the SHACL shape node and surfaced
     * on `ModelShape.interpretation_hint` by the Rust model query.
     */
    interpretationHint?: string;
}
/**
 * Decorator for defining model classes in AD4M.
 *
 * @category Decorators
 *
 * @description
 * The root decorator that must be applied to any class that represents a model in AD4M.
 * It registers the class as a Social DNA (SDNA) subject class and provides the infrastructure
 * for storing and retrieving instances.
 *
 * This decorator:
 * - Registers the class with a unique name in the AD4M system
 * - Generates the necessary SDNA code for the model's properties and relations
 * - Enables the use of other model decorators (@Property, @HasMany, etc.)
 * - Provides static query methods through the Ad4mModel base class
 *
 * Schema generation calls the class constructor once, without a perspective, to read
 * field defaults, so keep constructors free of side effects.
 *
 * @example
 * ```typescript
 * @Model({ name: "Recipe" })
 * class Recipe extends Ad4mModel {
 *   @Property({
 *     through: "recipe://name"
 *   })
 *   name: string = "";
 *
 *   @HasMany({ through: "recipe://ingredient" })
 *   ingredients: string[] = [];
 *
 *   // Static query methods from Ad4mModel:
 *   static async findByName(perspective: PerspectiveProxy, name: string) {
 *     return Recipe.query(perspective)
 *       .where({ name })
 *       .run();
 *   }
 * }
 *
 * // Using the model:
 * const recipe = new Recipe(perspective);
 * recipe.name = "Chocolate Cake";
 * await recipe.save();
 *
 * // Querying instances:
 * const recipes = await Recipe.query(perspective)
 *   .where({ name: "Chocolate Cake" })
 *   .run();
 *
 * // Registering the class in a perspective:
 * await Recipe.register(perspective);
 * ```
 *
 * @param {ModelConfig} opts - Model configuration
 * @param {string} opts.name - Unique name for the model class in AD4M
 */
export declare function Model(opts: ModelConfig): (target: any) => void;
/**
 * The primary property decorator for AD4M model classes.
 *
 * @category Decorators
 *
 * @description
 * The core property decorator with smart defaults.  All other property decorators
 * (@Optional, @ReadOnly) are thin wrappers that adjust these defaults.
 *
 * Smart defaults (all overridable):
 * - `required` → `false`
 * - `readOnly` → `false`
 * - `resolveLanguage` → unset → deterministic typed literal storage
 *   (the perf default). Set `resolveLanguage: "literal"` for a signed-envelope
 *   value, or a custom language address to resolve through that language.
 * - `initial` → `undefined` (no link created until a value is explicitly set)
 *
 * Properties are optional by default. When a model instance is created without
 * providing a value for an optional property, no link is added to the graph.
 * Set `required: true` explicitly when a property must always be present (this
 * also adds a `"literal:string:uninitialized"` sentinel as the initial value
 * so that the SDNA constructor creates a placeholder link).
 *
 * @example
 * ```typescript
 * class User extends Ad4mModel {
 *   // Optional property (default) — no link created until a value is set
 *   @Property({
 *     through: "user://name"
 *   })
 *   name: string = "";
 *
 *   // Explicitly required property with sentinel initial value
 *   @Property({
 *     through: "user://status",
 *     required: true
 *   })
 *   status: string = "";
 *
 *   // Required property with custom initial value
 *   @Property({
 *     through: "user://role",
 *     required: true,
 *     initial: "user://member"
 *   })
 *   role: string = "";
 *
 *   // Optional property with signed-envelope literal storage
 *   // (per-value provenance)
 *   @Property({
 *     through: "user://bio",
 *     resolveLanguage: "literal"
 *   })
 *   bio: string = "";
 * }
 * ```
 *
 * @param {PropertyOptions} opts - Property configuration
 * @param {string} opts.through - The predicate URI for the property
 * @param {boolean} [opts.required=false] - Whether the property is required (adds query filters and sentinel initial value)
 * @param {string} [opts.initial] - Initial value (defaults to "literal:string:uninitialized" when required)
 * @param {string} [opts.resolveLanguage] - Value-resolution language: unset (deterministic typed literal, the perf default), "literal" (signed envelope), or a custom language address
 * @param {string} [opts.prologGetter] - Custom Prolog code for getting the property value
 * @param {string} [opts.prologSetter] - Custom Prolog code for setting the property value
 * @param {boolean} [opts.local] - Whether the property should only be stored locally
 */
export declare function Property(opts: PropertyOptions): <T>(target: T, key: keyof T) => void;
/**
 * Decorator for defining read-only properties on model classes.
 *
 * @category Decorators
 *
 * @description
 * A convenience decorator that defines a read-only property.
 * Equivalent to `@Property` with `readOnly: true`.
 *
 * Read-only properties are ideal for:
 * - Computed or derived values
 * - Properties that should never change after creation
 * - Properties that are set by the system
 * - Properties that represent immutable data
 *
 * @example
 * ```typescript
 * class Post extends Ad4mModel {
 *   // Read-only property with custom getter for computed value
 *   @ReadOnly({
 *     through: "post://likes",
 *     getter: `findall(User, triple(Base, "post://liked_by", User), Users), length(Users, Value)`
 *   })
 *   likeCount: number = 0;
 *
 *   // Read-only property for creation timestamp
 *   @ReadOnly({
 *     through: "post://created_at",
 *     initial: new Date().toISOString()
 *   })
 *   createdAt: string = "";
 *
 *   // Read-only property that resolves to a Literal
 *   @ReadOnly({
 *     through: "post://author",
 *     resolveLanguage: "literal"
 *   })
 *   author: string = "";
 *
 *   // Read-only property for system-managed data
 *   @ReadOnly({
 *     through: "post://version",
 *     initial: "1.0.0"
 *   })
 *   version: string = "";
 * }
 * ```
 *
 * @param {PropertyOptions} opts - Property configuration
 * @param {string} opts.through - The predicate URI for the property
 * @param {string} [opts.initial] - Initial value (if property should have one)
 * @param {string} [opts.resolveLanguage] - Value-resolution language: unset (deterministic typed literal, the perf default), "literal" (signed envelope), or a custom language address
 * @param {string} [opts.prologGetter] - Custom Prolog code for getting the property value
 * @param {boolean} [opts.local] - Whether the property should only be stored locally
 */
export declare function ReadOnly(opts: PropertyOptions): <T>(target: T, key: keyof T) => void;
/**
 * Options for relation decorators (@HasMany, @HasOne, @BelongsToOne, @BelongsToMany).
 */
export interface RelationOptions {
    /**
     * The predicate URI used to link the two models.
     * Defaults to `'ad4m://has_child'` when omitted.
     * Cannot be combined with `getter`, except on a `readOnly` relation.
     */
    through?: string;
    /** The target model class (use a thunk to avoid circular-dependency issues). Optional for untyped string relations.
     *  Combines with `getter`, where it names the class the traversal's values hydrate into. */
    target?: () => Ad4mModelLike;
    /**
     * Custom getter to resolve the relation values. Use this for custom graph traversals.
     * The expression can reference 'Base' which will be replaced with the instance's base expression.
     * Example: "SELECT ?target WHERE { ?target <flux://has_reply> <Base> . }"
     *
     * Mutually exclusive with `through` — a getter replaces link-based resolution,
     * so there is no predicate to add to or remove from. When `getter` is provided
     * the relation is read-only (no adder/remover actions are generated). The
     * exception is `readOnly: true`, where `through` names the predicate the
     * getter reads and becomes the shape's path.
     *
     * **Combines with `target`**, which names the class the traversal's values
     * hydrate into — without it `include` has no shape to resolve and the relation
     * can only return bare URIs. Also combines with `where`, applied as a
     * post-getter filter against the target class.
     *
     * @example Traversing a reified edge — a connection stored as a record rather
     * than a predicate, so no `through` can express it:
     * ```typescript
     * @HasMany({
     *   getter: `SELECT ?target WHERE {
     *     ?citation <paper://cites_from> <Base> .
     *     ?citation <paper://cites_to> ?target .
     *   }`,
     *   target: () => Paper,
     * })
     * cited: Paper[] = [];
     * ```
     */
    getter?: string;
    /**
     * A relation read through `through` that this model must not write: no
     * `add*`/`remove*`/`set*` methods and no adder or remover actions. Pair
     * it with `getter` when the stored links need filtering on the way out
     * (only those signed by their target, say) but the predicate should
     * still be the shape's path, so a subscription re-runs when one lands.
     */
    readOnly?: boolean;
    /** Whether the link is stored locally (not shared on the network) */
    local?: boolean;
    /**
     * Whether to auto-generate a DB-level conformance filter when `target` is set.
     * Defaults to `true` when `target` is present — the query will only return linked
     * nodes whose shape matches the target model (required properties, flags, etc.).
     * Set to `false` to opt out of filtering while keeping hydration capability.
     */
    filter?: boolean;
    /**
     * Filter constraints on the linked target nodes, using the same query DSL
     * as `Model.query().where(...)`. Property names reference the **target**
     * model's properties (resolved via target metadata).
     *
     * When `target` is set and `where` is omitted, conformance conditions are
     * auto-derived from the target shape (flags + required properties).
     * Providing `where` overrides this auto-derivation.
     *
     * Mutually exclusive with `filter: false`. Combines with `getter`, where it
     * is applied as a post-getter filter against the target class.
     *
     * @example
     * ```typescript
     * @HasMany(() => Message, {
     *   through: "flux://entry_type",
     *   where: { status: "active", priority: { gte: 3 } }
     * })
     * activeMessages: Message[] = []
     * ```
     */
    where?: Where;
    /**
     * SHACL `sh:datatype` for the relation's target values. Set when the
     * relation holds encoded literal values (e.g. `"xsd:string"` for a
     * `HasMany<string>` that stores plain strings). The executor uses
     * this to decode `literal:<type>:<value>` wire form on hydration.
     * Omit for URI relations that point at other model instances.
     *
     * Mutually exclusive with `target`: a relation holds either literals or
     * model instances. Combines with `through` or `getter`.
     *
     * @example
     * ```typescript
     * @HasMany({ through: "run://source", datatype: "xsd:string" })
     * sources: string[] = [];
     * ```
     */
    datatype?: string;
    /**
     * Hydrate each target as the class it actually **is**, rather than as the
     * class this relation declares.
     *
     * A heterogeneous relation has no single right target. Declaring the base
     * class loses every subclass property — the executor hydrates against the
     * shape it is given, so an `ImagePost` read as a `Post` arrives with its own
     * fields simply absent, not merely mislabelled. Declaring nothing leaves
     * `include` with no shape to resolve at all.
     *
     * With this set, the targets are classified, grouped by concrete class, and
     * hydrated against their own shapes — one query per distinct class present,
     * not per instance.
     *
     * Pair with `instantiateAs` so the results become instances of the right
     * model class rather than plain objects.
     *
     * @example
     * ```typescript
     * @HasMany({
     *   through: "we://children",
     *   polymorphic: true,
     *   instantiateAs: () => [TextBlock, ImageBlock],
     * })
     * children: Post[] = [];
     * ```
     */
    polymorphic?: boolean;
    /**
     * The model classes a `polymorphic` result may be constructed as.
     *
     * Classification happens in the executor, structurally — there is no
     * `rdf:type` triple to read, so a target's class is derived from the flags
     * and required properties it carries. What cannot cross the wire is the
     * TypeScript constructor, so this names the classes this side can build.
     * `@Model` already records each class's name on the class itself, so the
     * name → class mapping is derived from the list rather than restated
     * alongside it.
     *
     * **This is advisory, not a constraint.** It never narrows what the query
     * returns and never excludes a target: a class missing from the list arrives
     * as plain JSON carrying its class name, so partial knowledge degrades
     * instead of failing. Declaring what this call site can *construct* is a
     * different statement from declaring what the relation may *contain* — a
     * heterogeneous relation is open by definition, and a list that silently
     * dropped unrecognised members would defeat the point of reading it
     * polymorphically at all. Constraining a read to particular classes belongs
     * in the query, not here.
     *
     * A thunk rather than an array, for the same reason `target` is one: it is
     * evaluated at query time, so a class defined later in a circular import
     * graph still resolves.
     */
    instantiateAs?: () => Ad4mModelLike[];
    /**
     * Give this collection a user-controlled order that survives concurrent edits.
     *
     * A `@HasMany` is a set of links, and hydration sorts them by link timestamp.
     * That is right for an append-only collection — a transcript, a message
     * thread — where timestamp order *is* the order. It cannot express a sequence
     * somebody chose: a kanban column, a playlist, the blocks of a post.
     *
     * **Declaration only, for now.** Setting this emits `ad4m://ordering` on the
     * property shape, where the executor reads it back — but no read or write
     * path acts on it yet, so a relation declaring it still hydrates by link
     * timestamp exactly as one that does not. Wiring save and hydration to the
     * declaration is the next change; nothing about how you write the relation
     * will change when it lands — assign the array in the order you want and
     * save.
     *
     * Ordering is declared in the type system, rather than passed per query, so
     * that *every* writer gets it once it is wired: the ORM, MCP agents, raw
     * WS-RPC callers, another app sharing the neighbourhood. Implemented
     * client-side it would order only what this client wrote.
     *
     * @example
     * ```typescript
     * @HasMany(() => Task, {
     *   through: "kanban://has_task",
     *   ordering: { strategy: "linkedList" },
     * })
     * tasks: Task[] = [];
     * ```
     */
    ordering?: {
        strategy: 'linkedList';
    };
    /**
     * Natural-language hint describing what this relation MEANS semantically —
     * the sentence-level rationale for when to use it, not just its structural
     * shape. Emitted as an `ad4m://interpretation_hint` link on the SHACL
     * property node; read back by the Rust harness (`ClassProposeShape.
     * relations[N].hint`) and rendered into the `_propose_link_child` tool's
     * `predicate` field description so the LLM knows which relation applies
     * to which situation instead of guessing from the predicate name alone.
     *
     * @example
     * ```typescript
     * @HasMany(() => Belief, {
     *   through: "ns://basedOn",
     *   interpretationHint: "The prior beliefs this intention derives from.",
     * })
     * basedOn: Belief[] = [];
     * ```
     */
    interpretationHint?: string;
    /**
     * The name this relation answers to when its class is read through an
     * abstract class, keyed by the abstract class's name. See
     * `PropertyOptions.alias`.
     */
    alias?: Record<string, string>;
}
/**
 * Utility type that describes the auto-generated helper methods for a HasMany
 * relation. For a property named `comments` on a class `Post`, the following
 * methods will be available on instances:
 *
 *   post.addComment(value)
 *   post.removeComment(value)
 *   post.setComment(values)
 */
export type HasManyMethods<Keys extends string> = {
    [K in Keys as `add${Capitalize<K>}`]: (value: string | {
        id: string;
    }, batchId?: string) => Promise<void>;
} & {
    [K in Keys as `remove${Capitalize<K>}`]: (value: string | {
        id: string;
    }, batchId?: string) => Promise<void>;
} & {
    [K in Keys as `set${Capitalize<K>}`]: (values: (string | {
        id: string;
    })[], batchId?: string) => Promise<void>;
};
/**
 * Decorator for defining a one-to-many relation.
 *
 * @category Decorators
 *
 * @description
 * Declares that the decorated property is an array of related model instances.
 * Under the hood it registers the relation in the relation registry and also
 * creates the corresponding relation entry so that the SDNA / SHACL
 * generators continue to emit the correct subject-class code.
 *
 * Supports two calling conventions:
 * ```typescript
 * // Options-object style
 * @HasMany({ through: "post://comment", target: () => Comment })
 *
 * // Target-first shorthand
 * @HasMany(() => Comment, { through: "post://comment" })
 * ```
 *
 * @example
 * ```typescript
 * @Model({ name: "Post" })
 * class Post extends Ad4mModel {
 *   @HasMany(() => Comment, { through: "post://comment" })
 *   comments: string[] = [];
 * }
 * ```
 */
export declare function HasMany(opts: RelationOptions): PropertyDecorator;
export declare function HasMany(target: () => Ad4mModelLike, opts?: Omit<RelationOptions, 'target'>): PropertyDecorator;
/**
 * Decorator for defining a one-to-one relation (owning side).
 *
 * @category Decorators
 *
 * @description
 * Declares that the decorated property holds a single related model instance.
 * The owning side manages the link.
 *
 * Supports two calling conventions:
 * ```typescript
 * @HasOne({ through: "post://author", target: () => Author })
 * @HasOne(() => Author, { through: "post://author" })
 * ```
 *
 * @example
 * ```typescript
 * @Model({ name: "Post" })
 * class Post extends Ad4mModel {
 *   @HasOne(() => Author, { through: "post://author" })
 *   author: string = "";
 * }
 * ```
 */
export declare function HasOne(opts: RelationOptions): PropertyDecorator;
export declare function HasOne(target: () => Ad4mModelLike, opts?: Omit<RelationOptions, 'target'>): PropertyDecorator;
/**
 * Decorator for defining the inverse side of a one-to-one relation.
 *
 * @category Decorators
 *
 * @description
 * Declares the non-owning (inverse) side of a one-to-one relationship.
 * The property is read-only since the owning side manages the link.
 *
 * Supports two calling conventions:
 * ```typescript
 * @BelongsToOne({ through: "post://author", target: () => Post })
 * @BelongsToOne(() => Post, { through: "post://author" })
 * ```
 *
 * @example
 * ```typescript
 * @Model({ name: "Author" })
 * class Author extends Ad4mModel {
 *   @BelongsToOne(() => Post, { through: "post://author" })
 *   post: string = "";
 * }
 * ```
 */
export declare function BelongsToOne(opts: RelationOptions): PropertyDecorator;
export declare function BelongsToOne(target: () => Ad4mModelLike, opts?: Omit<RelationOptions, 'target'>): PropertyDecorator;
/**
 * Decorator for defining the inverse side of a many-to-many relation.
 *
 * @category Decorators
 *
 * @description
 * Declares the non-owning (inverse) side of a many-to-many relationship.
 * The property is a read-only relation since the owning side manages links.
 *
 * Supports two calling conventions:
 * ```typescript
 * @BelongsToMany({ through: "post://tag", target: () => Post })
 * @BelongsToMany(() => Post, { through: "post://tag" })
 * ```
 *
 * @example
 * ```typescript
 * @Model({ name: "Tag" })
 * class Tag extends Ad4mModel {
 *   @BelongsToMany(() => Post, { through: "post://tag" })
 *   posts: string[] = [];
 * }
 * ```
 */
export declare function BelongsToMany(opts: RelationOptions): PropertyDecorator;
export declare function BelongsToMany(target: () => Ad4mModelLike, opts?: Omit<RelationOptions, 'target'>): PropertyDecorator;
