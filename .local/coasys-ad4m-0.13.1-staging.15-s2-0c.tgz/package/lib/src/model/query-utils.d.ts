/**
 * Shared query compilation utilities.
 *
 * These functions are used by both the runtime query builder (`Ad4mModel`) and
 * the compile-time SHACL generator (`decorators.ts`).
 *
 * All output uses native SPARQL syntax.
 */
import type { WhereCondition, Where, ModelMetadata } from "./types";
/**
 * Format a JavaScript value for embedding in a query expression.
 *
 * - Strings are single-quoted with backslash / quote / newline escaping
 * - Numbers and booleans are passed through as-is
 * - Arrays are recursed
 */
export declare function formatQueryValue(value: any): string;
/**
 * Compile a single Where condition for a property into a SPARQL triple pattern
 * that can be embedded in a getter's WHERE clause.
 *
 * The generated pattern operates on `?target` — e.g.:
 *   `?target <pred> <value> .`
 *   `FILTER EXISTS { ?target <pred> ?_v0 }`
 *
 * @param predicate  - The predicate URI for the property
 * @param condition  - The Where condition value
 * @param opts       - Optional settings. `isDeterministicLiteral` (default
 *                     `true`) selects the direct typed-literal WHERE path.
 *                     Set to `false` when the property stores a signed
 *                     envelope (`resolveLanguage: "literal"`) or a
 *                     custom-language expression — the envelope path unwraps
 *                     with `parse_literal` before comparing.
 * @returns A single SPARQL condition string
 */
export declare function buildWhereCondition(predicate: string, condition: WhereCondition, opts?: {
    isDeterministicLiteral?: boolean;
    varIndex?: number;
}): string;
/**
 * Compile a full `Where` clause to an array of SPARQL condition strings.
 *
 * When `metadata` is provided, property names are resolved to predicates
 * using the model's property metadata.  When `metadata` is `null`, property
 * names are treated as raw predicate URIs.
 *
 * Only handles **regular properties** — special fields (`id`, `author`,
 * `timestamp`) and relation fields are skipped (they are only relevant at
 * runtime query time, not for compile-time getter generation).
 */
export declare function compileWhereClause(where: Where, metadata: ModelMetadata | null): string[];
