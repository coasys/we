/**
 * ModelQueryBuilder — fluent query builder for Ad4mModel.
 *
 * Allows building queries with a chainable interface and either
 * running them once or subscribing to real-time updates.
 */
import type { Ad4mModel } from "./Ad4mModel";
import type { LinkStatus, PerspectiveProxy } from "../perspectives/PerspectiveProxy";
import type { Query, PaginationResult, TypedQueryWhere, TypedOrder, TypedIncludeMap, PropertyKeysOf } from "./types";
/** Query builder for Ad4mModel queries.
 * Allows building queries with a fluent interface and either running them once
 * or subscribing to updates.
 *
 * @example
 * ```typescript
 * const builder = Recipe.query(perspective)
 *   .where({ category: "Dessert" })
 *   .order({ rating: "DESC" })
 *   .limit(10);
 *
 * // Run once
 * const recipes = await builder.run();
 *
 * // Or subscribe to updates
 * await builder.subscribe(recipes => {
 *   console.log("Updated recipes:", recipes);
 * });
 * ```
 */
export declare class ModelQueryBuilder<T extends Ad4mModel> {
    private perspective;
    private queryParams;
    private modelClassName;
    private ctor;
    private currentSubscription?;
    /** Set for a query over several classes (`Ad4mModel.queryOf`, #1238). */
    private unionClasses?;
    constructor(perspective: PerspectiveProxy, ctor: typeof Ad4mModel, query?: Query, unionClasses?: (typeof Ad4mModel)[]);
    /** The wire parameters for `params`: one class, or the union's class list. */
    private prepare;
    /** Run `params` once and build model instances from the rows. */
    private execute;
    /** Build model instances from a raw result pushed by a subscription. */
    private parse;
    /** Snapshot instances for dirty tracking, as `execute` does for its rows. */
    private takeSnapshots;
    /** Ends the current subscription, if any, on the client and the executor. */
    dispose(): void;
    /** Open a live model query for `params` as the current subscription.
     *  Resolves with it and the raw initial result; `onResult` gets every later one.
     *  A failed open ends only its own query: a later call may already own
     *  `currentSubscription`. */
    private live;
    /** End `live` after its call failed. A later call may already own
     *  `currentSubscription`, so only clear it if it is still `live`. */
    private endFailed;
    /**
     * Adds where conditions to the query.
     *
     * @param conditions - The conditions to filter by
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * .where({
     *   category: "Dessert",
     *   rating: { gt: 4 },
     *   tags: ["vegan", "quick"],
     *   published: true
     * })
     * ```
     */
    where(conditions: TypedQueryWhere<T>): ModelQueryBuilder<T>;
    /**
     * Sets the order for the query results.
     *
     * @param orderBy - The ordering criteria
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * .order({ createdAt: "DESC" })
     * ```
     */
    order(orderBy: TypedOrder<T>): ModelQueryBuilder<T>;
    /**
     * Sets the maximum number of results to return.
     *
     * @param limit - Maximum number of results
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * .limit(10)
     * ```
     */
    limit(limit: number): ModelQueryBuilder<T>;
    /**
     * Sets the number of results to skip.
     *
     * @param offset - Number of results to skip
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * .offset(20) // Skip first 20 results
     * ```
     */
    offset(offset: number): ModelQueryBuilder<T>;
    /**
     * Scopes the query to instances linked from a parent.
     *
     * The predicate is resolved in order of precedence:
     * 1. **Instance only** — the parent's constructor is used as the model
     *    class; its relation metadata is scanned for a relation whose
     *    `target()` matches the queried model class.
     * 2. **Instance + options with `field`** — direct field-name lookup on
     *    the parent model's relation metadata (disambiguates when a parent
     *    has multiple relations targeting the same child class).
     * 3. **String id + model class** — same metadata scan (or field lookup if
     *    options include `field`).
     * 4. **String id + string predicate** — raw escape hatch, no metadata lookup.
     * 5. **String id alone** — containment through the built-in `Container`:
     *    the id's `ad4m://has_child` targets, and the targets of the `children`
     *    relation of every class the id is an instance of. The executor
     *    resolves the predicates; nothing is looked up here.
     *
     * @param idOrInstance - The parent's expression URI **or** an Ad4mModel instance
     * @param modelOrPredicate - A model class (predicate auto-resolved) **or** a raw predicate string
     * @param options - Optional settings: `field` for direct relation-name lookup
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * // Instance — predicate auto-resolved from Cookbook's @HasMany(() => Recipe)
     * Recipe.query(perspective).parent(cookbook).get();
     *
     * // Instance + field — disambiguate when parent has multiple relations to same child
     * Recipe.query(perspective).parent(cookbook, { field: "recipes" }).get();
     *
     * // String id + model class
     * Recipe.query(perspective).parent(cookbookId, Cookbook).get();
     *
     * // String id + model class + field
     * Recipe.query(perspective).parent(cookbookId, Cookbook, { field: "recipes" }).get();
     *
     * // String id + raw predicate (escape hatch)
     * Recipe.query(perspective).parent(cookbookId, "cookbook://recipe").get();
     *
     * // String id alone: whatever cookbookId contains
     * Recipe.query(perspective).parent(cookbookId).get();
     * ```
     */
    parent(idOrInstance: string | Ad4mModel, modelOrPredicate?: typeof Ad4mModel | string | {
        field: string;
    }, options?: {
        field?: string;
    }): ModelQueryBuilder<T>;
    /**
     * Specifies which properties to include in the results.
     *
     * @param properties - Array of property names to include
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * .properties(["name", "description", "rating"])
     * ```
     */
    properties(properties: PropertyKeysOf<T>[] | string[]): ModelQueryBuilder<T>;
    /**
     * Asks for the individual links behind each instance — author, timestamp
     * and proof per link — under `instance.__links`. See `Query.links`.
     *
     * @param keys - Property / relation names, or absolute predicate IRIs
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * const [post] = await Post.query(perspective).links(["comments"]).get();
     * post.__links!.comments.map((l) => l.timestamp); // when each comment was attached
     * ```
     */
    links(keys: string[]): ModelQueryBuilder<T>;
    /**
     * Controls whether SPARQL property getters are evaluated during hydration.
     *
     * By default, collection queries evaluate property getters (deepQuery=true).
     * Call `.deepQuery(false)` to skip getter evaluation for performance.
     *
     * @param enabled - Whether to evaluate property getters (default: true)
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * const messages = await Message.query(perspective)
     *   .parent(channel)
     *   .deepQuery(false)  // skip property getters for performance
     *   .limit(30)
     *   .get();
     * ```
     */
    deepQuery(enabled?: boolean): ModelQueryBuilder<T>;
    /**
     * Reads instances as they exist in links of one status only.
     *
     * `'shared'` leaves out every Local link, both from the values returned and
     * from what decides which instances are returned. Use it when the data is
     * shown to another user. `'local'` is the converse: it returns only
     * instances flagged in a Local link, so a Local note on a card flagged only
     * in a Shared link is read without `linkStatus`, not under `'local'`.
     * See {@link Query.linkStatus}.
     *
     * @param status - `'shared'` or `'local'`
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * const cards = await Card.query(perspective).linkStatus('shared').get();
     * ```
     */
    linkStatus(status: LinkStatus): ModelQueryBuilder<T>;
    /**
     * Also hydrate from links whose signature did not verify.
     *
     * Off by default: the executor withholds unverified links. Turn it on only
     * to *display* an unverified claim, never for data you act on. See
     * {@link Query.includeUnverified}.
     *
     * @param enabled - Whether to include unverified links (default: true)
     * @returns The query builder for chaining
     */
    includeUnverified(enabled?: boolean): ModelQueryBuilder<T>;
    /**
     * Specifies which relations to eager-load (hydrate into model instances).
     *
     * Without `include`, relation fields contain raw expression URIs (strings).
     * With `include`, the URIs are resolved into fully-hydrated model instances
     * using the `target` class declared in the relation decorator.
     *
     * Supports nested includes for multi-level eager loading.
     *
     * @param map - An IncludeMap describing which relations to hydrate
     * @returns The query builder for chaining
     *
     * @example
     * ```typescript
     * // Hydrate comments one level deep
     * const recipes = await Recipe.query(perspective)
     *   .include({ comments: true })
     *   .run();
     * // recipe.comments is now Comment[] (model instances), not string[]
     *
     * // Nested: hydrate comments AND each comment's author
     * const recipes = await Recipe.query(perspective)
     *   .include({ comments: { author: true } })
     *   .run();
     * ```
     */
    include(map: TypedIncludeMap<T>): ModelQueryBuilder<T>;
    overrideModelClassName(className: string): ModelQueryBuilder<T>;
    /**
     * Executes the query once and returns the results.
     *
     * @returns Array of matching entities
     *
     * @example
     * ```typescript
     * const recipes = await Recipe.query(perspective)
     *   .where({ category: "Dessert" })
     *   .get();
     * ```
     */
    get(): Promise<T[]>;
    /**
     * Executes the query once using SPARQL and returns the results.
     */
    getSparql(): Promise<T[]>;
    /**
     * Shared query execution logic — routes through the executor-side modelQuery endpoint.
     */
    private executeSparqlQuery;
    /**
     * Returns the first matching instance, or `null` if none match.
     *
     * Internally sets `limit: 1` and delegates to `get()`.
     *
     * @returns The first matching instance, or `null`
     *
     * @example
     * ```typescript
     * const recipe = await Recipe.query(perspective)
     *   .where({ name: "Pasta" })
     *   .first();
     * ```
     */
    first(): Promise<T | null>;
    /**
     * Subscribes to the query and receives updates when results change.
     *
     * This method:
     * 1. Creates and initializes a SPARQL live query subscription (default)
     * 2. Sets up the callback to process future updates
     * 3. Returns the initial results immediately
     *
     * Remember to call dispose() when you're done with the subscription
     * to clean up resources.
     *
     * @param callback - Function to call with updated results
     * @returns Initial results array
     *
     * @example
     * ```typescript
     * const builder = Recipe.query(perspective)
     *   .where({ status: "cooking" });
     *
     * const initialRecipes = await builder.subscribe(recipes => {
     *   console.log("Updated recipes:", recipes);
     * });
     *
     * // When done with subscription:
     * builder.dispose();
     * ```
     *
     */
    subscribe(callback: (results: T[]) => void): Promise<T[]>;
    /**
     * Subscribes to the query and receives updates using SPARQL.
     * @deprecated Use subscribe() instead — now routes through Rust model subscription.
     */
    subscribeSparql(callback: (results: T[]) => void): Promise<T[]>;
    /**
     * Gets the total count of matching entities.
     *
     * @returns Total count
     *
     * @example
     * ```typescript
     * const totalDesserts = await Recipe.query(perspective)
     *   .where({ category: "Dessert" })
     *   .count();
     * ```
     */
    count(): Promise<number>;
    /**
     * Gets the total count of matching entities using SPARQL.
     * Delegates to count().
     */
    countSparql(): Promise<number>;
    /**
     * Subscribes to count updates for matching entities.
     *
     * This method:
     * 1. Creates and initializes a SPARQL live query subscription for the count (default)
     * 2. Sets up the callback to process future count updates
     * 3. Returns the initial count immediately
     *
     * Remember to call dispose() when you're done with the subscription
     * to clean up resources.
     *
     * @param callback - Function to call with updated count
     * @returns Initial count
     *
     * @example
     * ```typescript
     * const builder = Recipe.query(perspective)
     *   .where({ status: "active" });
     *
     * const initialCount = await builder.countSubscribe(count => {
     *   console.log("Active items:", count);
     * });
     *
     * // When done with subscription:
     * builder.dispose();
     * ```
     *
     */
    countSubscribe(callback: (count: number) => void): Promise<number>;
    /**
     * Subscribes to count updates using SPARQL.
     * @deprecated Use countSubscribe() instead — now routes through Rust model subscription.
     */
    countSubscribeSparql(callback: (count: number) => void): Promise<number>;
    /**
     * Gets a page of results with pagination metadata.
     *
     * @param pageSize - Number of items per page
     * @param pageNumber - Which page to retrieve (1-based)
     * @returns Paginated results with metadata
     *
     * @example
     * ```typescript
     * const page = await Recipe.query(perspective)
     *   .where({ category: "Main" })
     *   .paginate(10, 1);
     * console.log(`Page ${page.pageNumber}, ${page.results.length} of ${page.totalCount}`);
     * ```
     */
    paginate(pageSize: number, pageNumber: number): Promise<PaginationResult<T>>;
    /**
     * Gets a page of results using SPARQL.
     * Delegates to paginate().
     */
    paginateSparql(pageSize: number, pageNumber: number): Promise<PaginationResult<T>>;
    /**
     * Subscribes to paginated results updates.
     *
     * This method:
     * 1. Creates and initializes a SPARQL live query subscription for the paginated results (default)
     * 2. Sets up the callback to process future page updates
     * 3. Returns the initial page immediately
     *
     * Remember to call dispose() when you're done with the subscription
     * to clean up resources.
     *
     * @param pageSize - Number of items per page
     * @param pageNumber - Which page to retrieve (1-based)
     * @param callback - Function to call with updated pagination results
     * @returns Initial pagination results
     *
     * @example
     * ```typescript
     * const builder = Recipe.query(perspective)
     *   .where({ category: "Main" });
     *
     * const initialPage = await builder.paginateSubscribe(10, 1, page => {
     *   console.log("Updated page:", page.results);
     * });
     *
     * // When done with subscription:
     * builder.dispose();
     * ```
     *
     */
    paginateSubscribe(pageSize: number, pageNumber: number, callback: (results: PaginationResult<T>) => void): Promise<PaginationResult<T>>;
    /**
     * Subscribes to paginated results updates using SPARQL.
     * Delegates to paginateSubscribe().
     */
    paginateSubscribeSparql(pageSize: number, pageNumber: number, callback: (results: PaginationResult<T>) => void): Promise<PaginationResult<T>>;
}
