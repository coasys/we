import type { PropertyMetadataEntry, RelationMetadataEntry } from "./decorators";
/**
 * Build SDNA (Social DNA) Prolog code for a model class.
 *
 * @param subjectName  - The model's registered name (from `@Model({ name })`)
 * @param obj          - `target.prototype` — used to inspect prototype methods
 *                       (e.g. setter stubs, `subjectConstructor`, `isSubjectInstance`)
 * @param properties   - Merged property metadata (from `getPropertiesMetadata`)
 * @param allRelationsMeta - Merged relation metadata (from `getRelationsMetadata`)
 */
export declare function buildSDNA(subjectName: string, obj: any, properties: Record<string, PropertyMetadataEntry>, allRelationsMeta: Record<string, RelationMetadataEntry>): {
    sdna: string;
    name: string;
};
