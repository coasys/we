import { PerspectiveProxy } from "../perspectives/PerspectiveProxy";
import { CallOptions } from "../apiClient";
import type { SHACLShape } from "../shacl/SHACLShape";
import type { RegisterResult } from "../generated/api/RegisterResult";
import type { JSONSchema, JSONSchemaToModelOptions } from "./json-schema";
import { ModelQueryBuilder } from "./ModelQueryBuilder";
import type { Scope, IncludeMap, Query, GetOptions, Page, ResultsWithTotalCount, PaginationResult, ModelMetadata, TypedQuery, IncludeExtras, IncludeOf, LinksMap } from "./types";
/**
 * Base class for defining data models in AD4M.
 *
 * @description
 * Ad4mModel provides the foundation for creating data models that are stored in AD4M perspectives.
 * Each model instance is represented as a subgraph in the perspective, with properties and relations
 * mapped to links in that graph. The class uses Prolog-based queries to efficiently search and filter
 * instances based on their properties and relationships.
 *
 * Key concepts:
 * - Each model instance has a unique base expression that serves as its identifier
 * - Properties are stored as links with predicates defined by the `through` option
 * - Relations represent one-to-many relationships as sets of links
 * - Queries are translated to Prolog for efficient graph pattern matching
 * - Changes are tracked through the perspective's subscription system
 *
 * @example
 * ```typescript
 * // Define a recipe model
 * @Model({ name: "Recipe" })
 * class Recipe extends Ad4mModel {
 *   // Plain property — no `resolveLanguage` → deterministic typed literal
 *   // storage (fast POS-index path). This is the perf default.
 *   @Property({ through: "recipe://name" })
 *   name: string = "";
 *
 *   // Property that needs per-value provenance (e.g. a signed message body):
 *   // `resolveLanguage: "literal"` routes values through expression_create on
 *   // the built-in literal language, producing a signed envelope URI
 *   // (author/timestamp/proof) instead of a bare typed literal.
 *   @Property({
 *     through: "recipe://signed_note",
 *     resolveLanguage: "literal"
 *   })
 *   signedNote: string = "";
 *
 *   // Property resolved through a custom language: values are routed through
 *   // expression_create on that language (signed expression URIs).
 *   @Optional({
 *     through: "recipe://photo",
 *     resolveLanguage: "QmFileStorageLanguageAddress..."
 *   })
 *   photo: string = "";
 *
 *   // Optional property with custom initial value
 *   @Optional({
 *     through: "recipe://status",
 *     initial: "recipe://draft"
 *   })
 *   status: string = "";
 *
 *   // Read-only computed property
 *   @ReadOnly({
 *     through: "recipe://rating",
 *     getter: `
 *       findall(Rating, triple(Base, "recipe://user_rating", Rating), Ratings),
 *       sum_list(Ratings, Sum),
 *       length(Ratings, Count),
 *       Value is Sum / Count
 *     `
 *   })
 *   averageRating: number = 0;
 *
 *   // Relation of ingredients
   *   @HasMany({ through: "recipe://ingredient" })
   *   ingredients: string[] = [];
 *
 *   // Relation of comments linked to another model
 *   @HasMany(() => Comment, { through: "recipe://comment" })
 *   comments: Comment[] = [];
 * }
 *
 * // Create and save a new recipe
 * const recipe = new Recipe(perspective);
 * recipe.name = "Chocolate Cake";
 * recipe.ingredients = ["flour", "sugar", "cocoa"];
 * await recipe.save();
 *
 * // Query recipes in different ways
 * // Get all recipes
 * const allRecipes = await Recipe.findAll(perspective);
 *
 * // Find recipes with specific criteria
 * const desserts = await Recipe.findAll(perspective, {
 *   where: {
 *     status: "recipe://published",
 *     averageRating: { gt: 4 }
 *   },
 *   order: { name: "ASC" },
 *   limit: 10
 * });
 *
 * // Use the fluent query builder
 * const popularRecipes = await Recipe.query(perspective)
 *   .where({ averageRating: { gt: 4.5 } })
 *   .order({ averageRating: "DESC" })
 *   .limit(5)
 *   .get();
 *
 * // Subscribe to real-time updates
 * await Recipe.query(perspective)
 *   .where({ status: "recipe://cooking" })
 *   .subscribe(recipes => {
 *     console.log("Currently being cooked:", recipes);
 *   });
 *
 * // Paginate results
 * const { results, totalCount, pageNumber } = await Recipe.query(perspective)
 *   .where({ status: "recipe://published" })
 *   .paginate(10, 1);
 * ```
 */
export declare class Ad4mModel {
    private _baseExpression;
    private _perspective;
    private _snapshot;
    /** True when the constructor minted the id: no record can hold links yet. */
    private _idMinted;
    /** Predicates this instance has already written relation links under (`add*`/`set*`), so they may hold links. */
    private _relationsWritten;
    author: string;
    createdAt: any;
    updatedAt: any;
    /**
     * Per-link rows for the entries asked for with `Query.links`, keyed as they
     * were asked. Absent when the query did not ask for any.
     */
    __links?: LinksMap;
    /**
     * Backwards compatibility alias for createdAt.
     * @deprecated Use createdAt instead. This will be removed in a future version.
     */
    get timestamp(): any;
    /**
     * Generates the SDNA (Subject DNA) Prolog rules for this model class.
     * Injected at class-definition time by the `@Model` decorator.
     * Returns a default value on un-decorated base classes.
     */
    static generateSDNA(): {
        sdna: string;
        name: string;
    };
    /**
     * Generates the SHACL shape graph for this model class.
     * Injected at class-definition time by the `@Model` decorator.
     * Returns `{ shape: null, name: '' }` on un-decorated base classes —
     * the decorator's `parentSHACL?.shape?.nodeShapeUri` check handles this.
     */
    static generateSHACL(): {
        shape: any;
        name: string;
    };
    /** The `@Model` name of this class: its human-facing name. Two classes
     *  may share one; the executor addresses each by {@link getTargetClass}. */
    static getClassName(): string;
    /** The target class IRI of this class (`sh:targetClass` of its shape),
     *  which the executor addresses it by. */
    static getTargetClass(): string;
    /**
     * Extracts metadata from decorators for query building.
     *
     * @description
     * This method reads the metadata stored by decorators (@Property, @HasMany, etc.)
     * and returns it in a structured format that's easier to work with for query builders
     * and other systems that need to introspect model structure.
     *
     * The metadata includes:
     * - Class name from @Model
     * - Property metadata (predicates, types, constraints, etc.)
     * - Relation metadata (predicates, filters, etc.)
     *
     * For models created via `fromJSONSchema()`, this method will derive metadata from
     * the WeakMap registries that were populated during the dynamic class creation.
     * If these structures are empty but a JSON schema was attached to the class,
     * it can fall back to deriving metadata from that schema.
     *
     * @returns Structured metadata object containing className, properties, and relations
     * @throws Error if the class doesn't have @Model decorator
     *
     * @example
     * ```typescript
     * @Model({ name: "Recipe" })
     * class Recipe extends Ad4mModel {
     *   @Property({ through: "recipe://name" })
     *   name: string = "";
     *
     *   @HasMany({ through: "recipe://ingredient" })
     *   ingredients: string[] = [];
     * }
     *
     * const metadata = Recipe.getModelMetadata();
     * console.log(metadata.className); // "Recipe"
     * console.log(metadata.properties.name.predicate); // "recipe://name"
     * console.log(metadata.relations.ingredients.predicate); // "recipe://ingredient"
     * ```
     */
    static getModelMetadata(): ModelMetadata;
    /**
     * Constructs a new model instance.
     *
     * @param perspective - The perspective where this model will be stored
     * @param baseExpression - Optional expression URI for this instance.
     *             If omitted, a random `ad4m://obj/<id>` IRI is generated,
     *             independent of any property content — this is what keeps
     *             two instances with identical property values distinct.
     * @param source - Optional source expression this instance is linked to
     *
     * @example
     * ```typescript
     * // Create a new recipe with auto-generated base expression
     * const recipe = new Recipe(perspective);
     *
     * // Create with specific base expression
     * const recipe = new Recipe(perspective, "ad4m://obj/existing-id");
     * ```
     */
    constructor(perspective: PerspectiveProxy, baseExpression?: string);
    /**
     * The unique identifier (expression URI) of this model instance.
     */
    get id(): string;
    /**
     * Protected getter for the perspective.
     * Allows subclasses to access the perspective while keeping it private from external code.
     */
    protected get perspective(): PerspectiveProxy;
    /**
     * Get property metadata from decorator.
     * @private
     */
    private getPropertyMetadata;
    /**
     * Get relation options from decorator
     * @private
     */
    private getRelationOptions;
    /**
     * Generate property setter action from metadata.
     * @private
     */
    private generatePropertySetterAction;
    /**
     * Generate relation action from metadata.
     * @private
     */
    private generateRelationAction;
    /**
     * @param includedRelations  Controls which relation fields are recorded
     *   in the snapshot for dirty-tracking:
     *     • `undefined` (default) — snapshot ALL relations (used by `.get()`,
     *       `.create()`, `.save()` etc. where full hydration has occurred).
     *     • `IncludeMap` object (e.g. `{ views: true }`) — only snapshot the
     *       relations named in the map.  Fields not listed are omitted from
     *       the snapshot so that `changedFields()` ignores them.
     *     • `null` / empty object — skip ALL relations (used by bare
     *       subscriptions that don't eagerly load relations).
     */
    /** @internal */
    protected takeSnapshot(includedRelations?: Record<string, any> | null): void;
    /**
     * Returns `true` if any tracked property or relation has changed
     * since the last hydration (or since `takeSnapshot()` was last called).
     *
     * Always returns `true` if no snapshot exists (e.g. a freshly
     * constructed instance that hasn't been fetched yet).
     *
     * @example
     * ```typescript
     * const recipe = await Recipe.create(perspective, { name: "Pasta" });
     * recipe.isDirty();        // false — just hydrated
     * recipe.name = "Risotto";
     * recipe.isDirty();        // true
     * ```
     */
    isDirty(): boolean;
    /**
     * Returns the names of properties/relations that differ from the
     * snapshot taken at the last hydration.
     *
     * Returns **all** field names if no snapshot exists.
     *
     * @example
     * ```typescript
     * recipe.name = "New Name";
     * recipe.changedFields(); // ["name"]
     * ```
     */
    changedFields(): string[];
    private getData;
    /**
     * Generates a SPARQL query from a Query object.
     *
     * @description
     * This method translates high-level query parameters into a SPARQL query string
     * that can be executed against the SPARQL backend. Unlike Prolog queries which
     * operate on SDNA-aware predicates, SPARQL queries operate directly on raw links
     * stored in SPARQL.
     *
     * The generated query uses a CTE (Common Table Expression) pattern:
     * 1. First, identify candidate base expressions by filtering links based on where conditions
     * 2. Then, for each candidate base, resolve properties and relations via subqueries
     * 3. Finally, apply ordering, pagination (LIMIT/START) at the SQL level
     *
     * Key architectural notes:
     * - SPARQL stores only raw links (source, predicate, target, author, timestamp)
     * - No SDNA knowledge at the database level
     * - Properties are resolved via subqueries that look for links with specific predicates
     * - Relations are similar but return multiple values instead of one
     * - Special fields (base, author, timestamp) are accessed directly, not via subqueries
     *
     * @param perspective - The perspective to query (used for metadata extraction)
     * @param query - Query parameters (where, order, limit, offset, properties, relations)
     * @returns Complete SPARQL query string ready for execution
     *
     * @example
     * ```typescript
     * const query = Recipe.queryToSPARQL(perspective, {
     *   where: { name: "Pasta", rating: { gt: 4 } },
     *   order: { timestamp: "DESC" },
     *   limit: 10
     * });
     * // Returns: SELECT source AS base, array::first(target[WHERE predicate = ...]) AS name, ...
     * //          FROM link WHERE ... GROUP BY source ORDER BY timestamp DESC LIMIT 10
     * ```
     */
    static queryToSPARQL(perspective: PerspectiveProxy, query: Query): Promise<string>;
    /**
     * Build the JSON parameters needed for a model query/subscription endpoint.
     * Returns the className and queryJson that the Rust executor expects.
     * Shape resolution happens server-side from the perspective's SHACL triples.
     * @internal
     */
    /**
     * The IRI the executor addresses this class by: its target class, or a
     * built-in abstract class's URI (`ad4m://TextContent`, #1446). The URI is
     * the class's own static only: a subclass is a class of its own.
     * @internal
     */
    static queriedAs(): string;
    static prepareModelQueryParams(query?: Query, classNameOverride?: string | null): {
        className: string;
        queryJson: string;
        metadata: ModelMetadata;
    };
    /**
     * Parse raw model query/subscription result JSON into typed model instances.
     * Used by ModelQueryBuilder to convert subscription updates without circular imports.
     * @internal
     */
    static parseModelResult<T extends Ad4mModel>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, raw: any, include?: IncludeMap, properties?: string[]): T[];
    /**
     * Snapshot freshly built instances for dirty tracking, with the relations
     * `include` loaded (its `$`-prefixed projection keys are not relations).
     * Used by every query path, and by ModelQueryBuilder for pushed results.
     * @internal
     */
    static takeSnapshots(instances: Ad4mModel[], include?: IncludeMap): void;
    /**
     * Build the wire parameters for one query over several classes.
     *
     * Each class normalises the query as it would for itself — its polymorphic
     * include defaults, its `$` projections, its parent predicate — and the
     * results are merged: includes and projections by key (the first class that
     * declares a key decides its form; a projection two classes tag with
     * different target classes is refused), the parent scope only when every
     * class that can resolve it resolves it to the same predicate.
     * @internal
     */
    static prepareUnionQueryParams(classes: (typeof Ad4mModel)[], query?: Query): {
        classNames: string[];
        queryJson: string;
    };
    /**
     * Build each row of a union result as the class the executor hydrated it as
     * (`__subjectClass`, the key it was asked for: {@link queriedAs}). A row of
     * a class not in `classes` stays plain JSON.
     * @internal
     */
    static parseUnionResult(classes: (typeof Ad4mModel)[], perspective: PerspectiveProxy, raw: any, include?: IncludeMap, properties?: string[]): Ad4mModel[];
    /** @internal */
    static executeUnionQuery(perspective: PerspectiveProxy, classes: (typeof Ad4mModel)[], query?: Query, options?: CallOptions): Promise<Page<Ad4mModel>>;
    /**
     * One query over several model classes (#1238).
     *
     * `where`, `order`, `limit` and `offset` apply once, over the union. Each
     * result is an instance of the class the executor hydrated it as: the first
     * `preferClasses` entry it conforms to, otherwise the most specific of
     * `classes` it conforms to. A record that is several of them is returned
     * once; `__subjectClasses` on it names every class it conforms to.
     *
     * - `where` on a property a class does not declare excludes that class's rows.
     * - `order` on such a property sorts those rows last, in both directions,
     *   then by id.
     *
     * @example
     * ```typescript
     * const items = await Ad4mModel.findAllOf(perspective, [Placement, EdgeRoute], {
     *   parent: { id: canvas.id, predicate: "canvas://item" },
     *   order: { zIndex: "ASC" },
     *   limit: 50,
     * });
     * for (const item of items) {
     *   if (item instanceof Placement) { ... }
     * }
     * ```
     */
    static findAllOf<C extends (typeof Ad4mModel)[]>(perspective: PerspectiveProxy, classes: [...C], query?: Query, options?: CallOptions): Promise<InstanceType<C[number]>[]>;
    /**
     * A {@link ModelQueryBuilder} over several model classes: the builder form of
     * {@link findAllOf}. `subscribe()` registers one subscription, which re-runs
     * when any of the classes changes.
     *
     * @example
     * ```typescript
     * const builder = Ad4mModel.queryOf(perspective, [Placement, EdgeRoute])
     *   .parent(canvas.id, "canvas://item");
     * await builder.subscribe((items) => render(items));
     * ```
     */
    static queryOf<C extends (typeof Ad4mModel)[]>(perspective: PerspectiveProxy, classes: [...C], query?: Query): ModelQueryBuilder<InstanceType<C[number]>>;
    /**
     * Execute a model query via the executor-side endpoint.
     *
     * This replaces the old SPARQL-build → hydrate → JS-filter → JS-sort → JS-paginate pipeline
     * with a single RPC to the executor that handles everything in Rust.
     *
     * @internal
     */
    private static executeModelQuery;
    /**
     * Gets all instances of the model in the perspective that match the query params.
     *
     * @param perspective - The perspective to search in
     * @param query - Optional query parameters to filter results
     * @param _engine - **Deprecated.** Accepted for backward compatibility but ignored.
     *   All queries now use the Rust SPARQL pipeline.
     * @returns Array of matching models
     *
     * @example
     * ```typescript
     * const allRecipes = await Recipe.findAll(perspective);
     *
     * const recipes = await Recipe.findAll(perspective, {
     *   where: {
     *     name: "Pasta",
     *     rating: { gt: 4 }
     *   },
     *   order: { createdAt: "DESC" },
     *   limit: 10
     * });
     * ```
     */
    static findAll<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, query?: Q, options?: CallOptions): Promise<(T & IncludeExtras<T, IncludeOf<Q>>)[]>;
    /**
     * Finds the first instance matching the query, or `null` if none exists.
     *
     * Equivalent to `findAll` with `limit: 1` — only one instance is hydrated.
     *
     * @param perspective - The perspective to search in
     * @param query - Optional query parameters to filter results
     * @param _engine - **Deprecated.** Accepted for backward compatibility but ignored.
     * @returns The first matching instance, or `null`
     *
     * @example
     * ```typescript
     * const recipe = await Recipe.findOne(perspective, {
     *   where: { name: "Pasta" }
     * });
     * if (recipe) {
     *   console.log(recipe.name);
     * }
     * ```
     */
    static findOne<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, query?: Q, options?: CallOptions): Promise<(T & IncludeExtras<T, IncludeOf<Q>>) | null>;
    /**
     * Gets all instances with count of total matches without offset & limit applied.
     *
     * @param perspective - The perspective to search in
     * @param query - Optional query parameters to filter results
     * @param _engine - **Deprecated.** Accepted for backward compatibility but ignored.
     * @returns Object containing results array and total count
     *
     * @example
     * ```typescript
     * const { results, totalCount } = await Recipe.findAllAndCount(perspective, {
     *   where: { category: "Dessert" },
     *   limit: 10
     * });
     * console.log(`Showing 10 of ${totalCount} dessert recipes`);
     * ```
     */
    static findAllAndCount<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, query?: Q, options?: CallOptions): Promise<ResultsWithTotalCount<T & IncludeExtras<T, IncludeOf<Q>>>>;
    /**
     * Helper function for pagination with explicit page size and number.
     *
     * @param perspective - The perspective to search in
     * @param pageSize - Number of items per page
     * @param pageNumber - Which page to retrieve (1-based)
     * @param query - Optional additional query parameters
     * @returns Paginated results with metadata
     *
     * @example
     * ```typescript
     * const page = await Recipe.paginate(perspective, 10, 1, {
     *   where: { category: "Main Course" }
     * });
     * console.log(`Page ${page.pageNumber} of recipes, ${page.results.length} items`);
     * ```
     */
    static paginate<T extends Ad4mModel, Q extends TypedQuery<T> = {}>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, pageSize: number, pageNumber: number, query?: Q, options?: CallOptions): Promise<PaginationResult<T & IncludeExtras<T, IncludeOf<Q>>>>;
    /**
     * Generates a SPARQL COUNT query for the model.
     *
     * @param perspective - The perspective context
     * @param query - Query parameters to filter the count
     * @returns SPARQL COUNT query string
     *
     * @private
     */
    /**
     * Gets a count of all matching instances.
     *
     * @param perspective - The perspective to search in
     * @param query - Optional query parameters to filter results
     * @returns Total count of matching entities
     *
     * @example
     * ```typescript
     * const totalRecipes = await Recipe.count(perspective);
     * const activeRecipes = await Recipe.count(perspective, {
     *   where: { status: "active" }
     * });
     * ```
     */
    static count<T extends Ad4mModel>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, query?: TypedQuery<T>, options?: CallOptions): Promise<number>;
    /** The `executeAction` write that sets property `key` to `value`; none for an empty value. */
    private planProperty;
    /**
     * The `executeAction` writes of a relation change: one for a set (its
     * `collectionSetter` takes every value), one per value for an add or remove.
     */
    private planRelation;
    /**
     * Sends writes in as few `executeAction` calls as keep their links: the
     * executor runs a call's commands in order, so consecutive writes share one
     * call, each with its own parameter names. A `collectionSetter` takes every
     * parameter of its call as a member, so it goes in a call of its own. A
     * command's `local` flag is per command, so Local and Shared links mix. The
     * executor tries every parameter name at each position of each command, so
     * a call holds at most `MAX_WRITES_PER_CALL` writes.
     */
    private sendWrites;
    private setProperty;
    /** Resolve a relation argument to a plain string ID. Accepts either a raw
     * string ID or an Ad4mModel instance (in which case `.id` is used). */
    private resolveRelationId;
    /** A relation write on a row read through an abstract class (#1435). The
     *  relation's predicate is the abstract class's, which no record's class
     *  reads: the executor runs the adder, remover or setter of each of the
     *  record's classes for the relation answering to `key`. */
    private relationThroughAbstract;
    private setRelationValues;
    private addRelationValue;
    private removeRelationValue;
    /** A relation setter, adder or remover call: on a row read through an
     *  abstract class it dispatches through the executor (see
     *  {@link relationThroughAbstract}); unbatched it goes through the
     *  `instance*` RPCs, batched through `executeAction` writes. */
    private writeRelation;
    /**
     * Saves the model instance to the perspective.
     *
     * **New instances** (no snapshot yet): creates the subject via
     * `createSubject` with initial scalar values, then sets relations
     * via `innerUpdate`.
     *
     * **Existing instances** (snapshot present, i.e. fetched via `get()`
     * or a query): updates only dirty fields via `innerUpdate`, then
     * refreshes from the perspective.
     *
     * @param batchId - Optional batch ID for batch operations
     * @throws Will throw if instance creation, linking, or updating fails
     *
     * @example
     * ```typescript
     * // Create
     * const recipe = new Recipe(perspective);
     * recipe.name = "Spaghetti";
     * await recipe.save();
     *
     * // Update
     * recipe.rating = 10;
     * await recipe.save();
     * ```
     */
    save(batchId?: string): Promise<void>;
    /** The name the executor knows the class by when it is abstract (#1435):
     *  a built-in's URI (#1446). Through an abstract class, the executor
     *  writes to the record's own classes. */
    private abstractName;
    private changedValues;
    /** `changedValues()` with each relation's members as IDs, as the relation
     *  helpers send them: a member may be a model instance. An action envelope
     *  (`{ action: "adder", value }`) keeps its action, as `innerUpdate()` runs
     *  it; an action it does not know is a setter there, so it is one here. */
    private changedValuesForDispatch;
    /** The unbatched update writes: the changed fields as one `instanceUpdate`
     *  patch plus the incremental collection calls an adder/remover envelope
     *  asks for. A `hasMany` relation in the patch is the full member list
     *  (`[]` clears); a `hasOne` is its scalar member. A reverse (`belongsTo*`),
     *  getter or readOnly relation — the SHACL marks those read-only — keeps
     *  the legacy `executeAction` write, as does a `hasOne` being cleared
     *  (a scalar patch cannot express "no member"). An envelope keeps its
     *  incremental semantics where the relation is a forward collection.
     *  A no-change save makes no calls at all (`instanceUpdate` refuses an
     *  empty patch, and there is nothing to refuse anyway). */
    private instanceWrites;
    private cleanCopy;
    private innerUpdate;
    /** The writes of the changed fields, in field order (see {@link sendWrites}). */
    private updateWrites;
    /**
     * Evaluate SPARQL getters for a batch of instances on demand.
     *
     * Since deepQuery defaults to true, property getters are evaluated
     * automatically during collection queries.  Use this method when
     * deepQuery was explicitly set to false and you want to lazily
     * resolve getter-backed properties for a subset of instances.
     *
     * @param instances - Array of model instances to evaluate getters on
     * @param perspective - The perspective to query against
     * @param propertyNames - Optional list of getter-backed property names to evaluate.
     *                        If omitted, all getters are evaluated.
     *
     * @example
     * ```typescript
     * const messages = await Message.query(perspective).deepQuery(false).limit(30).get();
     * // messages[i].replyingTo is undefined (getter skipped)
     *
     * // Evaluate getters for the visible subset
     * await Message.evaluateGetters(messages.slice(0, 10), perspective, ['replyingTo']);
     * // messages[0..9].replyingTo is now populated
     * ```
     */
    static evaluateGetters<T extends Ad4mModel>(instances: T[], perspective: PerspectiveProxy, propertyNames?: string[]): Promise<void>;
    /**
     * Gets the model instance with all properties and relations populated.
     *
     * @param optsOrInclude - Optional hydration options. Accepts two forms:
     *   - `GetOptions` wrapper: `{ include: { comments: true }, properties: ['title'] }`
     *   - `IncludeMap` shorthand: `{ comments: true }` (equivalent to `{ include: { comments: true } }`)
     * @returns The populated model instance
     * @throws Will throw if data retrieval fails
     *
     * @example
     * ```typescript
     * const recipe = new Recipe(perspective, existingId);
     * await recipe.get();
     * console.log(recipe.name, recipe.ingredients);
     *
     * // Shorthand — pass IncludeMap directly:
     * await recipe.get({ ingredients: true });
     *
     * // Full options — includes sparse fieldset:
     * await recipe.get({ include: { ingredients: true }, properties: ['name'] });
     * ```
     */
    get(optsOrInclude?: GetOptions | IncludeMap): Promise<this>;
    /**
     * Deletes the model instance from the perspective.
     *
     * @param batchId - Optional batch ID for batch operations
     * @throws Will throw if removal fails
     *
     * @example
     * ```typescript
     * const recipe = await Recipe.findAll(perspective)[0];
     * await recipe.delete();
     *
     * // Or with batch operations:
     * const batchId = await perspective.createBatch();
     * await recipe.delete(batchId);
     * await perspective.commitBatch(batchId);
     * ```
     */
    delete(batchId?: string): Promise<void>;
    /**
     * Creates and saves a new model instance in one step.
     *
     * @param perspective - The perspective to create the instance in
     * @param data - Property values to assign before saving
     * @param options - Optional settings:
     *   - `parent` — a `Scope` (model form or raw form) whose `id` will
     *     be used to create an incoming link from the parent to the new instance.
     *   - `batchId` — an existing batch id; when provided the link write and
     *     `save()` are added to the batch instead of committed immediately.
     * @returns The saved model instance
     *
     * @example
     * ```typescript
     * // Simple create
     * const recipe = await Recipe.create(perspective, {
     *   name: "Spaghetti",
     *   rating: 5,
     * });
     *
     * // Create under a parent (link auto-created)
     * const comment = await Comment.create(perspective, { text: "Great!" }, {
     *   parent: { model: Post, id: postId },
     * });
     *
     * // Create inside a transaction
     * await Ad4mModel.transaction(perspective, async (tx) => {
     *   await Recipe.create(perspective, { name: "Pasta" }, { batchId: tx.batchId });
     * });
     * ```
     */
    static create<T extends Ad4mModel>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, data?: Record<string, any>, options?: {
        parent?: Scope;
        batchId?: string;
    }): Promise<T>;
    /**
     * Updates an existing model instance identified by `id`.
     *
     * Fetches the instance, applies the provided changes, calls `save()`,
     * and returns the refreshed instance.
     *
     * @param perspective - The perspective containing the instance
     * @param id - The expression URI of the instance to update
     * @param data - Property values to merge before saving
     * @returns The updated model instance
     *
     * @example
     * ```typescript
     * const recipe = await Recipe.update(perspective, recipeId, {
     *   rating: 10,
     * });
     * ```
     */
    static update<T extends Ad4mModel>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, id: string, data: Record<string, any>): Promise<T>;
    /**
     * Deletes an existing model instance identified by `id`.
     *
     * Also cleans up any incoming links that point to this instance.
     *
     * @param perspective - The perspective containing the instance
     * @param id - The expression URI of the instance to delete
     *
     * @example
     * ```typescript
     * await Recipe.delete(perspective, recipeId);
     * ```
     *
     * @deprecated Use the name `delete` — `remove` is preserved as an alias.
     */
    static remove(this: typeof Ad4mModel & (new (...args: any[]) => Ad4mModel), perspective: PerspectiveProxy, id: string): Promise<void>;
    /**
     * Deletes an existing model instance identified by `id`.
     *
     * Also cleans up any incoming links that point to this instance.
     *
     * @param perspective - The perspective containing the instance
     * @param id - The expression URI of the instance to delete
     *
     * @example
     * ```typescript
     * await Recipe.delete(perspective, recipeId);
     * ```
     */
    static delete(this: typeof Ad4mModel & (new (...args: any[]) => Ad4mModel), perspective: PerspectiveProxy, id: string): Promise<void>;
    /**
     * Registers this model's SHACL schema on the given perspective.
     *
     * This ensures the perspective knows about the model's shape
     * (properties, relations, constraints) so instances can be
     * created, queried, and validated.
     *
     * @param perspective - The perspective to register the model on
     *
     * @example
     * ```typescript
     * await Recipe.register(perspective);
     * // Now you can create / query Recipe instances on this perspective
     * ```
     */
    static register(this: typeof Ad4mModel, perspective: PerspectiveProxy): Promise<RegisterResult>;
    /**
     * Registers model classes on a perspective in one call. A class whose
     * stored shape already is its shape is `unchanged` and nothing is written,
     * so registering on every start is cheap; built-in classes (`TextContent`)
     * live in the executor and are skipped.
     *
     * @param perspective - The perspective to register the models on
     * @param models - Array of Ad4mModel subclasses to register
     *
     * @example
     * ```typescript
     * await Ad4mModel.registerAll(perspective, [Community, Channel, Message, Task]);
     * ```
     */
    static registerAll(perspective: PerspectiveProxy, models: (typeof Ad4mModel)[]): Promise<RegisterResult>;
    /**
     * Executes a set of model operations inside a single batch (transaction).
     *
     * All `save`, `update`, and `delete` calls made via the provided `batchId`
     * are buffered and flushed atomically when the callback completes.
     * If the callback throws, the batch is **not** committed, preventing
     * partial writes.
     *
     * @param perspective - The perspective to operate on
     * @param fn - Async callback that receives a `TransactionContext` object.
     *             Pass `tx.batchId` to `save(tx.batchId)`, `update(tx.batchId)`,
     *             `delete(tx.batchId)`, etc.
     * @returns The value returned by `fn`
     *
     * @example
     * ```typescript
     * await Ad4mModel.transaction(perspective, async (tx) => {
     *   const recipe = new Recipe(perspective);
     *   recipe.name = "Spaghetti";
     *   await recipe.save(tx.batchId);
     *
     *   const old = await Recipe.query(perspective).where({ name: "Stale" }).run();
     *   for (const r of old) await r.delete(tx.batchId);
     * });
     * // All changes committed atomically here
     * ```
     */
    static transaction<R = void>(perspective: PerspectiveProxy, fn: (tx: {
        batchId: string;
    }) => Promise<R>): Promise<R>;
    /**
     * Creates a query builder for fluent query construction.
     *
     * @param perspective - The perspective to query
     * @param query - Optional initial query parameters
     * @returns A new query builder instance
     *
     * @example
     * ```typescript
     * const recipes = await Recipe.query(perspective)
     *   .where({ category: "Dessert" })
     *   .order({ rating: "DESC" })
     *   .limit(5)
     *   .run();
     *
     * // With real-time updates
     * await Recipe.query(perspective)
     *   .where({ status: "cooking" })
     *   .subscribe(recipes => {
     *     console.log("Currently cooking:", recipes);
     *   });
     * ```
     */
    static query<T extends Ad4mModel>(this: typeof Ad4mModel & (new (...args: any[]) => T), perspective: PerspectiveProxy, query?: TypedQuery<T>): ModelQueryBuilder<T>;
    /**
     * Creates an Ad4mModel class from a JSON Schema definition.
     *
     * @description
     * This method dynamically generates an Ad4mModel subclass from a JSON Schema,
     * enabling integration with systems that use JSON Schema for type definitions.
     *
     * The method follows a cascading approach for determining predicates:
     * 1. Explicit configuration in options parameter (highest precedence)
     * 2. x-ad4m metadata in the JSON Schema
     * 3. Inference from schema title and property names
     * 4. Error if no namespace can be determined
     *
     * @example
     * ```typescript
     * // With explicit configuration
     * const PersonClass = Ad4mModel.fromJSONSchema(schema, {
     *   name: "Person",
     *   namespace: "person://"
     * });
     *
     * // With property mapping
     * const ContactClass = Ad4mModel.fromJSONSchema(schema, {
     *   name: "Contact",
     *   namespace: "contact://",
     *   propertyMapping: {
     *     "name": "foaf://name",
     *     "email": "foaf://mbox"
     *   }
     * });
     *
     * // With x-ad4m metadata in schema
     * const schema = {
     *   "title": "Product",
     *   "x-ad4m": { "namespace": "product://" },
     *   "properties": {
     *     "name": {
     *       "type": "string",
     *       "x-ad4m": { "through": "product://title" }
     *     }
     *   }
     * };
     * const ProductClass = Ad4mModel.fromJSONSchema(schema, { name: "Product" });
     * ```
     *
     * @param schema - JSON Schema definition
     * @param options - Configuration options
     * @returns Generated Ad4mModel subclass
     * @throws Error when namespace cannot be inferred
     */
    static fromJSONSchema(schema: JSONSchema, options: JSONSchemaToModelOptions): typeof Ad4mModel;
    /**
     * Creates a fully functional Ad4mModel subclass from a SHACL shape.
     *
     * Unlike `fromJSONSchema()`, no predicate inference is required —
     * `SHACLShape` already contains the exact predicate URI in `path` for
     * every property. The method reads each property's `path`, `maxCount`,
     * `writable`, and `resolveLanguage` directly and writes them to the
     * WeakMap metadata registries.
     *
     * Properties with `hasValue` (flag / type-discrimination markers) are
     * registered as hidden flag entries so that the SPARQL query builder emits
     * the fixed triple `?source <predicate> <value>` needed for type discrimination.
     * Properties without a `name` field are skipped.
     *
     * **Backward-compat:** Old Flux SHACL shapes (created before `sh:hasValue`
     * was persisted on property shapes) carry the flag value only in
     * `shape.constructor_actions` as the `target` of an `addLink` action.
     * This method recovers those values so that old perspectives are queried
     * with the correct type-discriminator triple.
     *
     * @param shape - SHACL node shape (as returned by `PerspectiveProxy.shapes()`)
     * @param name  - Class name to assign (e.g. "Channel")
     * @returns Generated Ad4mModel subclass, ready for querying
     */
    /**
     * Synthesise an `Ad4mModel` subclass from a SHACL shape.
     *
     * @param shape           - The SHACL shape to synthesise from.
     * @param name            - The model name (e.g. "Channel").
     * @param classResolver   - Optional thunk factory.  When provided, any collection
     *   property that carries a `sh:class` URI will have its `target` wired up lazily:
     *   `target: () => classResolver(localName)`.  Because `target` is only called at
     *   query time (inside `enrichShapeForIncludes` / `jsonToModelInstance`), the
     *   resolver just needs to return the correct class by the time a query runs —
     *   making it safe to pass a closure over a registry object that is still being
     *   populated (e.g. the `result` record inside `getModelClasses`).
     */
    static fromSHACL(shape: SHACLShape, name: string, classResolver?: (localName: string) => typeof Ad4mModel | undefined): typeof Ad4mModel;
}
