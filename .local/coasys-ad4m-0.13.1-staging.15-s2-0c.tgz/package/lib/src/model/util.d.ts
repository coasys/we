export declare function capitalize(str: string): string;
export declare function propertyNameToSetterName(property: string): string;
export declare function pluralToSingular(plural: string): string;
export declare function relationToAdderName(relation: string): string;
export declare function relationToRemoverName(relation: string): string;
export declare function relationToSetterName(relation: string): string;
/**
 * Generate a random identifier string of the given length (lowercase alpha).
 */
export declare function makeRandomId(length: number): string;
export declare function stringifyObjectLiteral(obj: any): any;
