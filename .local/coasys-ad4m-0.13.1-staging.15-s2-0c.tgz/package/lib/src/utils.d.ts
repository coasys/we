export declare function formatList(list: any): any;
export declare function capSentence(cap: any): string;
/**
 * Escapes a string value for safe use in query strings.
 *
 * @description
 * Prevents SQL injection by properly escaping special characters in string values
 * that will be interpolated into query strings. This handles the most common
 * special characters that could break SQL queries or enable injection attacks.
 *
 * Single quotes, backslashes, and other special characters are escaped using
 * backslash notation, which is the standard escaping mechanism for query.
 *
 * @param value - The string value to escape
 * @returns The escaped string safe for query interpolation (without surrounding quotes)
 *
 * @example
 * ```typescript
 * const userInput = "user's input with 'quotes'";
 * const escaped = escapeQueryString(userInput);
 * const query = `SELECT * FROM link WHERE uri = '${escaped}'`;
 * // Results in: SELECT * FROM link WHERE uri = 'user\'s input with \'quotes\''
 * ```
 */
export declare function escapeQueryString(value: string): string;
