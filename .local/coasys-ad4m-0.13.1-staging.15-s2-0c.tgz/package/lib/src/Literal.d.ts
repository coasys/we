export declare class Literal {
    #private;
    static fromUrl(url: string): Literal;
    static from(literal: any): Literal;
    toUrl(): string;
    get(): any;
}
