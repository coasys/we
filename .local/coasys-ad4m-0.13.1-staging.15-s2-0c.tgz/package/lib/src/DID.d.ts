export type DID = string;
