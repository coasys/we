/**
 * Two different events at one seq of a log, as the cache recorded them: `ours` the hash of the
 * cached event at `seq`, `theirs` the hash of the other one, which holds on the log before
 * `seq`. A store that answers a shorter log records none (it is behind, or an unverified
 * conflict).
 */
export type ForkRecord = {
    seq: number;
    ours: string;
    theirs: string;
};
