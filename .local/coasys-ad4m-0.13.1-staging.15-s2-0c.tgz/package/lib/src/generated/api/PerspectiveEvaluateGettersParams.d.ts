/**
 * Wire names stay snake_case, as the handler reads them.
 */
export type PerspectiveEvaluateGettersParams = {
    uuid: string;
    class_name: string;
    instance_ids?: Array<string>;
    property_names?: Array<string>;
};
