import type { SfuRosterParticipant } from "./SfuRosterParticipant";
/**
 * Who is in a call room now. Published whenever the room's participants
 * change, and delivered to each of them, so a client knows who joined and
 * who left without waiting on media.
 */
export type SfuRoomRoster = {
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * The room's sessions, sorted by DID, then participant id: this node's,
     * and those the other cascade nodes in the room announced, whose ids
     * name their node (`P3@did:key:...`). An agent in the call from two
     * devices is listed twice.
     */
    participants: Array<SfuRosterParticipant>;
};
