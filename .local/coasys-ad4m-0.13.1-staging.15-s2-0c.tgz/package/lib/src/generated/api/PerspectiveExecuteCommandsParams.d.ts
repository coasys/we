export type PerspectiveExecuteCommandsParams = {
    uuid: string;
    commands: string;
    expression: string;
    parameters?: string;
    batchId?: string;
};
