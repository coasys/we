import type { Capability } from "./Capability";
export type AuthInfo = {
    appName: string;
    appDesc: string;
    appDomain: string | null;
    appUrl: string | null;
    appIconPath: string | null;
    capabilities: Array<Capability> | null;
    /**
     * The user a multi-user token is minted for: the login name of a managed agent's
     * account. The token's `sub` carries the agent's DID; this stays as the account's name.
     */
    userEmail: string | null;
};
