/**
 * `perspective.modelSubscribe`: [`PerspectiveModelQueryParams`] and the client's
 * subscription id (see [`PerspectiveSubscribeQueryParams`]).
 */
export type PerspectiveModelSubscribeParams = {
    uuid: string;
    class_name?: string;
    class_names?: Array<string>;
    query_json: string;
    subscriptionId: string;
};
