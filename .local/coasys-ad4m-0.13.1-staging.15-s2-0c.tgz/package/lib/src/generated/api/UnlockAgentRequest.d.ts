export type UnlockAgentRequest = {
    passphrase: string;
    holochain?: boolean;
};
