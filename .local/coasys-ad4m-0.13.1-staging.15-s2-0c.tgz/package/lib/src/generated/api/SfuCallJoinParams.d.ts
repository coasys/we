export type SfuCallJoinParams = {
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * JSON-encoded `RTCSessionDescriptionInit`.
     */
    sdpOffer: string;
    /**
     * The device the caller joins from (an opaque id, 1 to 128 characters).
     * The caller's session from the same device is replaced; one from
     * another device stays beside it.
     */
    deviceId: string;
    /**
     * The client's random key for this call session (1 to 128 characters,
     * never published). A rebuild of the session sends it again and
     * replaces its own dead session; a join whose key a later join from the
     * same device replaced is refused with 409: that session must stop.
     */
    sessionKey: string;
    /**
     * The caller can reach other cascade nodes, so a busy room may answer
     * with `redirectTo` instead of a session. Off by default: an SDK client
     * reaches only this executor.
     */
    acceptRedirect?: boolean;
};
