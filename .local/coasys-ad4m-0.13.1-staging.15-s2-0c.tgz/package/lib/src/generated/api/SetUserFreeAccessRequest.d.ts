export type SetUserFreeAccessRequest = {
    email: string;
    enabled: boolean;
};
