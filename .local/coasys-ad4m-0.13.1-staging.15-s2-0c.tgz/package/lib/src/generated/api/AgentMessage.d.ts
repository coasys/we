/**
 * One turn of the conversation, as the caller holds it.
 */
export type AgentMessage = {
    /**
     * `user` or `assistant`.
     */
    role: string;
    content: string;
};
