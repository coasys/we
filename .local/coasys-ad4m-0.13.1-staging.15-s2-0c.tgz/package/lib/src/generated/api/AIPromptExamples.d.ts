export type AIPromptExamples = {
    input: string;
    output: string;
};
