/**
 * One step in an auto-processor pass. Ordered roughly by lifecycle; a single
 * pass emits a subset (e.g. `BatchReady → BackedOff` when a peer already holds
 * the claim, or `BatchReady → Claimed → GatheringTranscript →
 * RunningInterpretation → Processed` for the peer that wins).
 */
export type AutoProcessorStep = "batchReady" | "claimed" | "backedOff" | "awaitingAuthor" | "notCandidate" | "gatheringTranscript" | "runningInterpretation" | "llmRequestSent" | "llmResponseReceived" | "toolCall" | "toolResult" | "processed" | "shapesMissing" | "emptyTranscript" | "failed";
