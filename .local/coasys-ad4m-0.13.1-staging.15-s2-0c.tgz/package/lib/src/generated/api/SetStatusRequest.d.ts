export type SetStatusRequest = {
    status: any;
};
