export type HostingUserInfo = {
    email: string;
    remainingCredits: string;
    hotWalletAddress: string | null;
    freeAccess: boolean;
};
