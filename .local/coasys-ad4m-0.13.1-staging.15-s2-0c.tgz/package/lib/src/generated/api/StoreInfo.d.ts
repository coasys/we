/**
 * The identity store an executor uses (`identity.status`).
 */
export type StoreInfo = {
    /**
     * The store's base URL, as the agent language reaches it.
     */
    url: string;
    /**
     * Whether the executor trusts a key for the store (`identity.storeKeys`, or the seed's
     * keys). Without one it accepts no head from it, so no `did:scid` record verifies, and
     * `identity.publish` and `identity.claimOffer` refuse `no-store-keys`.
     */
    trusted: boolean;
};
