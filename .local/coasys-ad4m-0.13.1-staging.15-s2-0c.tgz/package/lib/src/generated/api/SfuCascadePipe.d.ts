export type SfuCascadePipe = {
    roomId: string;
    remoteDid: string;
};
