export type ExpressionProofInput = {
    invalid?: boolean;
    key?: string;
    signature?: string;
    valid?: boolean;
};
