import type { NeighbourhoodPerspectivePayload } from "./NeighbourhoodPerspectivePayload";
export type NeighbourhoodSignalParams = {
    uuid: string;
    remoteAgentDid: string;
    payload: NeighbourhoodPerspectivePayload;
    signed?: boolean;
};
