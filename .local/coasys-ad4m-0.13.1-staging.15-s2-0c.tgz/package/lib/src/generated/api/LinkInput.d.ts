export type LinkInput = {
    predicate?: string;
    source: string;
    target: string;
};
