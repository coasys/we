export type ImportAgentRequest = {
    did: string;
    didDocument: string;
    keystore: string;
    passphrase: string;
};
