export type ExpressionManyRequest = {
    urls: Array<string>;
};
