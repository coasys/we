export type LanguageRef = {
    address: string;
    name: string;
};
