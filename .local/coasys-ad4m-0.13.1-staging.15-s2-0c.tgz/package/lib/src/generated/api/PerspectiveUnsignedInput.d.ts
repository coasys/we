import type { LinkInput } from "./LinkInput";
export type PerspectiveUnsignedInput = {
    links: Array<LinkInput>;
};
