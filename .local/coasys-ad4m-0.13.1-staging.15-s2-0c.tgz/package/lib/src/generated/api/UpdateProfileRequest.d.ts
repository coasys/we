import type { PublicPerspectiveInput } from "./PublicPerspectiveInput";
export type UpdateProfileRequest = {
    dmLanguage?: string;
    publicPerspective?: PublicPerspectiveInput;
};
