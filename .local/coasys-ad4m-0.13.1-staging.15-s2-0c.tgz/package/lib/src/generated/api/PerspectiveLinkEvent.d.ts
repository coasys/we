import type { DecoratedLinkExpression } from "./DecoratedLinkExpression";
/**
 * `link-added` / `link-removed`: one event to all of the perspective's owners.
 */
export type PerspectiveLinkEvent = {
    perspectiveUuid: string;
    link: DecoratedLinkExpression;
};
