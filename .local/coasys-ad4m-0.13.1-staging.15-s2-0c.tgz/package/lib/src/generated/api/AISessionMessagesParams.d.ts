export type AISessionMessagesParams = {
    /**
     * The session to read.
     */
    sessionId: string;
    /**
     * How many entries at most (200 default).
     */
    limit: number | null;
    /**
     * Only entries older than this `seq`.
     */
    before: number | null;
};
