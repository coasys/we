export type PermitCapabilityRequest = {
    auth: string;
};
