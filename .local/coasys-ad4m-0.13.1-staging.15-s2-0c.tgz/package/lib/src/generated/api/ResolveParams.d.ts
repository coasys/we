/**
 * `identity.resolve` params.
 */
export type ResolveParams = {
    /**
     * A `did:scid:coasys:1:<scid>` DID URL (`?src=`, `?versionId=`, `#d1`), or a bare device
     * `did:key:z6Mk…`.
     */
    didUrl: string;
    /**
     * Read the log from its sources even when the cache holds it.
     */
    fresh?: boolean;
    /**
     * The representation asked for; only `application/did+ld+json` (the default).
     */
    accept?: string;
};
