export type RuntimeSetFreeHostingEnabledParams = {
    enabled: boolean;
};
