export type InteractionParameter = {
    name: string;
    type: string;
};
