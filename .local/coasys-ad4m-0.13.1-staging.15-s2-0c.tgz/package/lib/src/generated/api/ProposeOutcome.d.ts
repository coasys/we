import type { FireOutcome } from "./FireOutcome";
/**
 * What one `propose_flow_transition` call did, and where the flow stands
 * after it.
 *
 * A bare `Vec<FireOutcome>` could not say: an empty vec meant "queued for
 * other voters", "you already proposed this", and "the instance is stuck"
 * alike. Each field below separates one of those.
 */
export type ProposeOutcome = {
    /**
     * The live proposal this call minted or joined. A client needs it to
     * render "pending — withdraw?", or to hand to another agent's
     * `acceptProposal`; it exists at mint time either way.
     */
    proposalUri: string;
    /**
     * `true` when this call wrote the proposal; `false` when it found an
     * equivalent one already open and joined that.
     */
    minted: boolean;
    /**
     * `true` when this call recorded a vote for the acting DID — the
     * proposer's own vote on a mint, an `acceptedBy` on a join. `false`
     * means the acting DID had already voted: the call changed nothing.
     */
    recordedVote: boolean;
    /**
     * Consensus events this call's pass recorded for the first time. Empty
     * while the edge is still short of quorum — read with `recorded_vote`
     * to tell "your vote landed, waiting for others" from "nothing to do".
     */
    outcomes: Array<FireOutcome>;
    /**
     * The instance's derived state after the call.
     */
    derivedState: string;
    /**
     * `true` when two edges out of `derived_state` both carry quorum. The
     * flow is irreversibly stalled; a caller must not present this as
     * "awaiting votes". A contested instance is refused up front, so this
     * can only be contention that arrived *during* the call.
     */
    contested: boolean;
};
