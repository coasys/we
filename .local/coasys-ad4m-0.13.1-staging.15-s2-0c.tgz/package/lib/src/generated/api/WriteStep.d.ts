/**
 * What a write was doing when the store failed.
 */
export type WriteStep = {
    "step": "readShape";
} | {
    "step": "readInstance";
} | {
    "step": "checkExisting";
    baseUri: string;
} | {
    "step": "resolveCollection";
    collection: string;
} | {
    "step": "readCollection";
    collection: string;
} | {
    "step": "createSubject";
} | {
    "step": "updateSubject";
} | {
    "step": "removeSubject";
} | {
    "step": "addCollectionItem";
    collection: string;
    item: string;
} | {
    "step": "removeCollectionItem";
    collection: string;
    item: string;
    removed: number;
} | {
    "step": "addToParent";
    parent: string;
} | {
    "step": "commit";
};
