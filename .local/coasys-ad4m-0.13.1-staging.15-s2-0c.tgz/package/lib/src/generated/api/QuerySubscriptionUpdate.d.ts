/**
 * The change from revision `revision - 1` to `revision` (see
 * `perspective_instance::subscriptions::result_delta`): model results
 * carry `ids`, `upsert` and `totalCount`; query results carry `added` and
 * `removed` rows; a result that could not be diffed comes whole as
 * `result`.
 */
export type QuerySubscriptionUpdate = {
    perspectiveUuid: string;
    uuid: string;
    subscriptionId: string;
    revision: number;
    ids?: Array<string>;
    upsert?: Array<any>;
    totalCount?: number;
    added?: Array<any>;
    removed?: Array<any>;
    result?: any;
};
