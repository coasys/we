export type VerificationRequestResult = {
    success: boolean;
    message: string;
    requiresPassword: boolean;
    isExistingUser: boolean;
};
