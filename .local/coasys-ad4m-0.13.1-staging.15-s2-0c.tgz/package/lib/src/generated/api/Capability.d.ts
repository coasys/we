import type { Resource } from "./Resource";
export type Capability = {
    with: Resource;
    can: Array<string>;
};
