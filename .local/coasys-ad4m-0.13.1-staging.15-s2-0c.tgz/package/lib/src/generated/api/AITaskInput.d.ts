import type { AIPromptExamplesInput } from "./AIPromptExamplesInput";
export type AITaskInput = {
    name: string;
    modelId: string;
    systemPrompt: string;
    promptExamples: Array<AIPromptExamplesInput>;
    metaData?: string;
};
