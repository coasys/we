/**
 * Server-pushed event telling a participant to leave their current
 * SFU node and rejoin on `target_did`.  The cascade rebalancer
 * publishes this when it detects a significant load imbalance across
 * the cluster.  The client should call `leave()`, set the connected
 * node DID to `target_did`, then call `join()` — the same flow as
 * cascade failover.
 */
export type SfuMigrateEvent = {
    /**
     * DID of the participant being migrated.  Used by the events_ws
     * fanout to filter per-user.
     */
    targetDid: string;
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * DID of the SFU node the participant should reconnect to.
     */
    migrateToDid: string;
};
