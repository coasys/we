export type ImportRequest = {
    type: string;
    filePath: string;
};
