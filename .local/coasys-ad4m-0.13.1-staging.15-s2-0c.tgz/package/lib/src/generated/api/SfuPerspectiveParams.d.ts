/**
 * A neighbourhood by its perspective's UUID.
 */
export type SfuPerspectiveParams = {
    uuid: string;
};
