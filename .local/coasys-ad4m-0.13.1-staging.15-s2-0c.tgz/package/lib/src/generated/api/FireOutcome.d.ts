/**
 * One consensus event this replica recorded for the first time: the atoms
 * that settled an edge, now marked, with the cache advanced to match.
 */
export type FireOutcome = {
    instanceUri: string;
    fromState: string;
    toState: string;
    /**
     * The distinct DIDs whose votes made up the quorum.
     */
    voters: Array<string>;
    contributingProposalUris: Array<string>;
};
