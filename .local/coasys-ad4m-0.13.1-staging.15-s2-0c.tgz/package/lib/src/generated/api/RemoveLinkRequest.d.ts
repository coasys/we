import type { LinkExpressionInput } from "./LinkExpressionInput";
export type RemoveLinkRequest = {
    link: LinkExpressionInput;
    batchId?: string;
};
