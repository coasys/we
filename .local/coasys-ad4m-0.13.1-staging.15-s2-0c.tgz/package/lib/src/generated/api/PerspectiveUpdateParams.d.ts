export type PerspectiveUpdateParams = {
    uuid: string;
    name: string;
};
