/**
 * The error `expression.get` fails with, reported per URL by `expression.getMany`.
 */
export type ExpressionLookupError = {
    code: number;
    message: string;
};
