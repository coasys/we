export type TranscriptionTextFilter = {
    streamId: string;
    text: string;
    userDid: string | null;
};
