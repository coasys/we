export type HostingVersionInfo = {
    /**
     * The installed Unyt DNA version; `null` before installation.
     */
    dnaHash: string | null;
    buildVersion: string;
};
