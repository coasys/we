/**
 * Reply to `perspective.subscribeQuery` / `perspective.modelSubscribe`:
 * the first result, as JSON, at its revision (0 unless a change was
 * published while it was computed).
 */
export type PerspectiveSubscribed = {
    subscriptionId: string;
    result: any;
    revision: number;
};
