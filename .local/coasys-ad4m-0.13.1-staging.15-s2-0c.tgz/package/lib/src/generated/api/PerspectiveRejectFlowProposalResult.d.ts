export type PerspectiveRejectFlowProposalResult = {
    retractedLinks: number;
};
