import type { LinkExpression } from "./LinkExpression";
export type Perspective = {
    links: Array<LinkExpression>;
};
