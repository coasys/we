export type ResourceInput = {
    domain: string;
    pointers: Array<string>;
};
