export type UserCreationResult = {
    did: string;
    success: boolean;
    error: string | null;
};
