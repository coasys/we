import type { ModelInput } from "./ModelInput";
export type AiAddModelParams = {
    model: ModelInput;
};
