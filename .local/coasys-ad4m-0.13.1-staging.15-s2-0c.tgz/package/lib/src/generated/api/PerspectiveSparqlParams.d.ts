export type PerspectiveSparqlParams = {
    uuid: string;
    query: string;
    /**
     * Only `"sparql"` (the default) is accepted.
     */
    engine?: string;
};
