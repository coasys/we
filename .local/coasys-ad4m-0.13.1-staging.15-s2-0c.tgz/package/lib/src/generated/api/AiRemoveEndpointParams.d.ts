export type AiRemoveEndpointParams = {
    id: string;
    /**
     * Remove the models that run on the endpoint too. Without it, a removal is refused
     * while any does.
     */
    cascade?: boolean;
};
