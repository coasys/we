export type Link = {
    predicate: string | null;
    source: string;
    target: string;
};
