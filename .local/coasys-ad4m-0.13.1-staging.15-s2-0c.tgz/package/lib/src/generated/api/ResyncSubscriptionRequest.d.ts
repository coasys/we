export type ResyncSubscriptionRequest = {
    subscriptionId: string;
};
