import type { AutoProcessorStep } from "./AutoProcessorStep";
/**
 * A single step-signal from one auto-processor pass on one perspective.
 */
export type AutoProcessorEvent = {
    /**
     * UUID of the perspective the processor runs on.
     */
    perspectiveUuid: string;
    /**
     * The processor's id (`AutoProcessorConfig::processor_id`).
     */
    processorId: string;
    /**
     * DID of the agent this executor ran the pass as — lets a multi-user /
     * multi-executor observer see *which* peer claimed/processed vs backed off.
     */
    agentDid: string | null;
    /**
     * Which step this event marks.
     */
    step: AutoProcessorStep;
    /**
     * The batch's source item ids (present from `BatchReady` onward).
     */
    itemIds: Array<string>;
    /**
     * Content hash of the batch — the same
     * [`super::claim::batch_key`] value the perspective-scoped
     * [`AutoProcessorNeighbourhoodState`] carries.
     *
     * Present from `BatchReady` onward, and it is what makes the two
     * streams joinable. Without it a consumer holding both has no way to
     * say "this `LlmRequestSent` belongs to the row I opened on that
     * `Claimed`" — the fine-grained stream carries `item_ids` and the
     * neighbourhood stream carries only the hash of them, so correlating
     * meant re-implementing this hash client-side and matching the Rust
     * serialization exactly. A consumer that merges a peer's coarse
     * phases with its own fine ones needs one shared key, and this is it.
     */
    batchKey: string | null;
    /**
     * Instance base URIs written by the pass (present on `Processed`).
     */
    bases: Array<string>;
    /**
     * Free-form context for the step (a holder/elected DID, an error, …).
     */
    detail: string | null;
    /**
     * Live-debug raw LLM prompt for this pass. Present ONLY on
     * [`AutoProcessorStep::LlmRequestSent`] events, and only when the
     * processor was configured with
     * `AutoProcessorConfig.emit_debug_events = true`. Never carried on
     * `Processed` (which carries `bases` only). Absent (`None`) in the
     * normal path — LLM prompts are 10s of KB and would otherwise
     * inflate every event.
     */
    llmInput: string | null;
    /**
     * Live-debug raw LLM response for this pass. Present ONLY on
     * [`AutoProcessorStep::LlmResponseReceived`] events, and only when
     * the processor was configured with
     * `AutoProcessorConfig.emit_debug_events = true`. Never carried on
     * `Processed`. Same size / privacy rules as `llm_input`.
     */
    llmOutput: string | null;
    /**
     * Name of the tool the harness LLM invoked (or that just returned).
     * Present on [`AutoProcessorStep::ToolCall`] +
     * [`AutoProcessorStep::ToolResult`] events; absent on every other
     * step. Present only when the processor has `emit_debug_events: true`.
     */
    toolName: string | null;
    /**
     * JSON-encoded arguments the LLM sent to the tool. Present ONLY on
     * [`AutoProcessorStep::ToolCall`]; absent on `ToolResult` (where
     * `tool_result` carries the return text instead). Same size / gating
     * rules as `llm_input` / `llm_output`.
     */
    toolArgsJson: string | null;
    /**
     * The tool's return text. Present ONLY on
     * [`AutoProcessorStep::ToolResult`]; may be truncated by the emitter
     * when the tool returns a large payload (e.g. a `_query` result).
     * Same size / gating rules as `llm_input` / `llm_output`.
     */
    toolResult: string | null;
};
