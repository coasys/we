export type FriendsListRequest = {
    dids: Array<string>;
};
