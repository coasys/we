export type JoinNeighbourhoodRequest = {
    url: string;
};
