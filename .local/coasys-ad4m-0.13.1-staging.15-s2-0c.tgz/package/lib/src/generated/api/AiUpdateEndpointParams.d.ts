import type { AiEndpointInput } from "./AiEndpointInput";
export type AiUpdateEndpointParams = {
    id: string;
    endpoint: AiEndpointInput;
};
