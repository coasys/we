/**
 * Why a property cannot be written.
 */
export type ReadOnlyReason = "classMarker" | "reverseRelation" | "computed" | "noSetter";
