/**
 * Remove an item from a collection of an instance (the membership link only).
 */
export type InstanceRemoveFromCollection = {
    className: string;
    baseUri: string;
    collection: string;
    /**
     * The item as a read of the instance lists it.
     */
    itemUri: string;
    /**
     * An open batch to stage the write into; see `InstanceCreate`'s `batchId`.
     */
    batchId?: string;
};
