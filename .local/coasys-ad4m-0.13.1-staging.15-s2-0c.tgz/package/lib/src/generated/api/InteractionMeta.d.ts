import type { InteractionParameter } from "./InteractionParameter";
export type InteractionMeta = {
    label: string;
    name: string;
    parameters: Array<InteractionParameter>;
};
