import type { LocalAiService } from "./LocalAiService";
/**
 * A service the plan leaves out, and why.
 */
export type LocalAiUnavailable = {
    service: LocalAiService;
    reason: string;
};
