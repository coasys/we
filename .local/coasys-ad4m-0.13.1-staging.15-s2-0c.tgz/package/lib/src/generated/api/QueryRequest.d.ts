/**
 * Unified query request (harmonised: engine + query in one).
 */
export type QueryRequest = {
    engine: string;
    query: string;
};
