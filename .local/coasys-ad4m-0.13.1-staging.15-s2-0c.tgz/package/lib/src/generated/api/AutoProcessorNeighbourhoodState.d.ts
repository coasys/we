import type { NeighbourhoodPhase } from "./NeighbourhoodPhase";
/**
 * One observation of an auto-processor pass by THIS executor. Small on
 * purpose: perspective + processor + claimant DID + batch key + phase.
 * Consumers merge these across ticks + across peers (via link-added on
 * `has_claim`) to render "who is currently processing what."
 */
export type AutoProcessorNeighbourhoodState = {
    /**
     * UUID of the perspective the pass runs on.
     */
    perspectiveUuid: string;
    /**
     * The processor's id (`AutoProcessorConfig::processor_id`).
     */
    processorId: string;
    /**
     * DID that claimed the batch — the executor's own DID for locally
     * initiated passes.
     */
    claimantDid: string;
    /**
     * Content hash of the batch (see [`super::claim::batch_key`]) — lets a
     * consumer merge `Claimed` and `Finished` events for the same batch
     * without duplicating rows.
     */
    batchKey: string;
    /**
     * Which lifecycle transition this event marks.
     */
    phase: NeighbourhoodPhase;
};
