import type { ModelInput } from "./ModelInput";
export type AiUpdateModelParams = {
    id: string;
    model: ModelInput;
};
