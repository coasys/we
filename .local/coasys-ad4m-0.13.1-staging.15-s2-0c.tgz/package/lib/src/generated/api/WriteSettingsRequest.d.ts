export type WriteSettingsRequest = {
    settings: string;
};
