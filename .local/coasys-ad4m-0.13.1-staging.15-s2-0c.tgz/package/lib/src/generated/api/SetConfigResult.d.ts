import type { ConfigRefusal } from "./ConfigRefusal";
/**
 * `runtime.setConfig` result. The keys not in `refused` are written.
 */
export type SetConfigResult = {
    restartPending: boolean;
    refused: Array<ConfigRefusal>;
};
