import type { ModelStatus } from "./ModelStatus";
import type { ModelType } from "./ModelType";
/**
 * A model as RPC results show it.
 */
export type Model = {
    id: string;
    name: string;
    modelType: ModelType;
    endpointId: string;
    /**
     * The id the endpoint knows the model by.
     */
    remoteModel: string;
    /**
     * Whether prompts with tools send them as tool definitions. Unset: yes on Anthropic
     * and Ollama endpoints, no on an OpenAI-shaped server (see [`Model::uses_native_tools`]).
     */
    nativeTools?: boolean | null;
    /**
     * Where the model stands by its endpoint's last health check.
     */
    status: ModelStatus;
};
