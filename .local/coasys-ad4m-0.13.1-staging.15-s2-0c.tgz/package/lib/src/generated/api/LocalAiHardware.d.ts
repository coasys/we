import type { LocalAiBackend } from "./LocalAiBackend";
import type { LocalAiCpu } from "./LocalAiCpu";
import type { LocalAiGpu } from "./LocalAiGpu";
/**
 * This device, as `ai.localHardware` answers.
 */
export type LocalAiHardware = {
    /**
     * `linux`, `macos` or `windows`.
     */
    os: string;
    /**
     * `x64` or `arm64` (the names the manifest's build keys use).
     */
    arch: string;
    cpu: LocalAiCpu;
    ramBytes: number;
    availableRamBytes: number;
    gpus: Array<LocalAiGpu>;
    /**
     * The backends a runtime build may use here, in no order.
     */
    backends: Array<LocalAiBackend>;
    /**
     * Memory the GPU backend may use: VRAM, an integrated GPU's VRAM and GTT, Apple's
     * working set. Unset without a usable GPU.
     */
    gpuBudgetBytes: number | null;
    /**
     * What the models may take together: min(GPU budget − 1 GiB, RAM − 4 GiB), or
     * RAM − 4 GiB without a GPU budget.
     */
    memoryBudgetBytes: number;
    /**
     * Free space where local AI stores its files.
     */
    diskFreeBytes: number | null;
    /**
     * The per-user directory of runtimes and models, shared by every agent.
     */
    storageDir: string;
    /**
     * The class `ai-wind-tunnel/hardware-classes.json` gives this device.
     */
    hardwareClass: string;
    /**
     * What detection could not read, and estimates.
     */
    notes: Array<string>;
};
