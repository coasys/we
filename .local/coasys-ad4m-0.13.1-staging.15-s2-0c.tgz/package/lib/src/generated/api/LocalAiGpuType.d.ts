export type LocalAiGpuType = "discrete" | "integrated" | "unified";
