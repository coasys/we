export type RuntimeUnytWalletHistoryParams = {
    page?: number;
    perPage?: number;
};
