export type BroadcastRequest = {
    payload: any;
    signed?: boolean;
    loopback?: boolean;
};
