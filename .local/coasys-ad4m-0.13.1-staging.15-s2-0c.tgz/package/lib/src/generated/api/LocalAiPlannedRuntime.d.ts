import type { LocalAiBackend } from "./LocalAiBackend";
import type { LocalAiProvider } from "./LocalAiProvider";
import type { LocalAiService } from "./LocalAiService";
export type LocalAiPlannedRuntime = {
    /**
     * The manifest's runtime id: `llama-server`, `nemo-speech`.
     */
    runtimeId: string;
    provider: LocalAiProvider;
    version: string;
    /**
     * The manifest's build key: `linux-x64-vulkan`.
     */
    build: string;
    backend: LocalAiBackend;
    /**
     * The archive and its extras.
     */
    sizeBytes: number;
    installed: boolean;
    services: Array<LocalAiService>;
};
