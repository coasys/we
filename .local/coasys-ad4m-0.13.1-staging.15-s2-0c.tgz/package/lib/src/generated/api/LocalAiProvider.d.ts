/**
 * The server program a runtime build provides.
 */
export type LocalAiProvider = "llama-server" | "nemo-speech";
