export type LanguageListParams = {
    filter?: string;
};
