export type RuntimeUnytSendHotParams = {
    recipient: string;
    amount: string;
};
