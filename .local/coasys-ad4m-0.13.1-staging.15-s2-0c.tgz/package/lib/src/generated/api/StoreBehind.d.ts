/**
 * The configured store answering a log behind this executor's cache (`identity.status`).
 */
export type StoreBehind = {
    /**
     * When the executor first saw it behind (unix seconds; in this run of the executor).
     */
    since: number;
    /**
     * The seq of the store's head at its last answer; `null` when it answered no log.
     */
    seq: number | null;
};
