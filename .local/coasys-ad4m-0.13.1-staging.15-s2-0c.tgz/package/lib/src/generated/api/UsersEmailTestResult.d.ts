/**
 * `get-code` answers the captured code (`null` when none); every other
 * action answers `true`.
 */
export type UsersEmailTestResult = boolean | string | null;
