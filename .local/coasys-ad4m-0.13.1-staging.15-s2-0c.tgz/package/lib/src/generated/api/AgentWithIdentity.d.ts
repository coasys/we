import type { DecoratedPerspective } from "./DecoratedPerspective";
/**
 * `agent.get`: the agent's profile, and the identity its device key speaks for (`did`
 * stays the device `did:key`).
 */
export type AgentWithIdentity = {
    /**
     * The `did:scid` this agent speaks for, or `null`.
     */
    identity: string | null;
    did: string;
    directMessageLanguage: string | null;
    perspective: DecoratedPerspective | null;
};
