export type PerspectiveFlowProposalParams = {
    uuid: string;
    proposalUri: string;
};
