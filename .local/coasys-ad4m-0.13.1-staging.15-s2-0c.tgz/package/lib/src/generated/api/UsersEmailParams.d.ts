export type UsersEmailParams = {
    email: string;
};
