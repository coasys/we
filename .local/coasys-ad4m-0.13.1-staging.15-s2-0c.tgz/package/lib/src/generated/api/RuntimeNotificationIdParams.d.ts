export type RuntimeNotificationIdParams = {
    id: string;
};
