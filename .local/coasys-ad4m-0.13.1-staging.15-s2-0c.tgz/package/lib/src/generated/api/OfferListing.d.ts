import type { OfferState } from "./OfferState";
import type { SignedOffer } from "./SignedOffer";
/**
 * One open or claimed offer of the identity.
 */
export type OfferListing = {
    offer: SignedOffer;
    state: OfferState;
};
