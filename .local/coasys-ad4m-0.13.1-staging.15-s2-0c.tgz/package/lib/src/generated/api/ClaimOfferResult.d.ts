import type { OfferKind } from "./OfferKind";
/**
 * `identity.claimOffer`: the claim is made; the holder confirms with the same match code.
 */
export type ClaimOfferResult = {
    did: string;
    offerId: string;
    /**
     * "R7K Q2M": the holder shows the same code.
     */
    matchCode: string;
    kind: OfferKind;
    expires: number;
};
