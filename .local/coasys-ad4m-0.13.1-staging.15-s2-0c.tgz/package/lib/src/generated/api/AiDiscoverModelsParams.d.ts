import type { EndpointKind } from "./EndpointKind";
/**
 * A saved endpoint by its id, or a server not saved yet by its kind, URL and key.
 */
export type AiDiscoverModelsParams = {
    endpointId: string;
} | {
    kind: EndpointKind;
    baseUrl: string;
    apiKey?: string;
};
