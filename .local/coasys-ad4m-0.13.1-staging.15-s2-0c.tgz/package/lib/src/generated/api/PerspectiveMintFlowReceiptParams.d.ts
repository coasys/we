export type PerspectiveMintFlowReceiptParams = {
    uuid: string;
    instanceUri: string;
};
