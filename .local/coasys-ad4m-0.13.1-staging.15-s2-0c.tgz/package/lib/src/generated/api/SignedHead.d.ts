/**
 * The store's signature over a log's head (`coasys:head`).
 */
export type SignedHead = {
    scid: string;
    seq: number;
    hash: string;
    time: number;
    /**
     * The store's `did:key`.
     */
    store: string;
    sig: string;
};
