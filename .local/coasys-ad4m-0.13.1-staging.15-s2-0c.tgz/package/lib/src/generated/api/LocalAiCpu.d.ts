export type LocalAiCpu = {
    brand: string;
    physicalCores: number | null;
    logicalCores: number;
    /**
     * avx, avx2, fma, f16c, avx512f; neon, dotprod, sve, i8mm.
     */
    features: Array<string>;
};
