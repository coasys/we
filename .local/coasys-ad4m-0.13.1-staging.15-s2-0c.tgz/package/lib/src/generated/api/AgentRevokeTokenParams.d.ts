export type AgentRevokeTokenParams = {
    token: string;
};
