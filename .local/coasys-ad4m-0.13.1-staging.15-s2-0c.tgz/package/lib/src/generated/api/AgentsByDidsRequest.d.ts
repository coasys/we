export type AgentsByDidsRequest = {
    dids: Array<string>;
};
