import type { LinkInput } from "./LinkInput";
export type PerspectiveAddLinksParams = {
    uuid: string;
    links: Array<LinkInput>;
    status?: string;
    batchId?: string;
};
