export type LanguageMetaInput = {
    description: string;
    name: string;
    possibleTemplateParams?: Array<string>;
    sourceCodeLink?: string;
};
