import type { AIPromptExamples } from "./AIPromptExamples";
export type AITask = {
    name: string;
    taskId: string;
    modelId: string;
    systemPrompt: string;
    promptExamples: Array<AIPromptExamples>;
    metaData: string | null;
    createdAt: string;
    updatedAt: string;
};
