/**
 * `identity.openOffer`.
 */
export type OfferOpened = {
    offerId: string;
};
