export type NeighbourhoodUuidParams = {
    uuid: string;
};
