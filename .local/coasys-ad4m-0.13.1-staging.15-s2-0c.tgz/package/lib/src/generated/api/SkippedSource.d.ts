/**
 * A source of a resolution the resolver did not read from.
 */
export type SkippedSource = {
    src: string;
    reason: string;
};
