import type { LinkInput } from "./LinkInput";
export type LinkUpdateInput = {
    oldLink: LinkInput;
    newLink: LinkInput;
};
