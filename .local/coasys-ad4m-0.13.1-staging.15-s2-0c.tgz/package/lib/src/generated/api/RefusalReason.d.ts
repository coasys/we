/**
 * Why `runtime.setConfig` did not write a key.
 */
export type RefusalReason = "local-only" | "pinned-by-config" | "invalid" | "unknown-key";
