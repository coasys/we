/**
 * An install's progress, as `ai-local-progress` events.
 */
export type LocalAiProgress = {
    /**
     * `plan`, `download`, `start`, `register`, `done` or `failed`.
     */
    phase: string;
    /**
     * The runtime id or model id being downloaded.
     */
    item: string | null;
    itemDoneBytes: number;
    itemTotalBytes: number;
    doneBytes: number;
    totalBytes: number;
    detail: string | null;
};
