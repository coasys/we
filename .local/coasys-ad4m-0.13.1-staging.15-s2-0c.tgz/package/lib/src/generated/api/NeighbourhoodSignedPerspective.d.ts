import type { LinkExpressionInput } from "./LinkExpressionInput";
/**
 * Wire shape of `crate::types::PerspectiveInput`, named apart from the
 * api `PerspectiveInput` so the two TypeScript files do not collide.
 */
export type NeighbourhoodSignedPerspective = {
    links: Array<LinkExpressionInput>;
};
