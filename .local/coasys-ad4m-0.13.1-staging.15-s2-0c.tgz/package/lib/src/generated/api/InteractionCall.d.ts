export type InteractionCall = {
    name: string;
    parametersStringified: string;
};
