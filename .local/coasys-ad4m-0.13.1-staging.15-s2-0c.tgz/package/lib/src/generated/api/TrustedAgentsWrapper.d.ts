/**
 * Wrapper: SDK sends `{ agents: [...] }` for trusted agent endpoints
 */
export type TrustedAgentsWrapper = {
    agents: Array<string>;
};
