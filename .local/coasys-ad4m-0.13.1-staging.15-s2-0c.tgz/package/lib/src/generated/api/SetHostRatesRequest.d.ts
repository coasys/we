import type { HostRate } from "./HostRate";
export type SetHostRatesRequest = {
    rates: Array<HostRate>;
};
