/**
 * What `register_shapes` did, by target class IRI (two classes may share a
 * name), each sorted.
 */
export type RegisterResult = {
    /**
     * Classes whose stored shape already was the one given: nothing written.
     */
    unchanged: Array<string>;
    /**
     * Classes written or rewritten.
     */
    written: Array<string>;
    /**
     * The shapes generation once the registry holds the new shapes. It
     * grows with every change to the installed shapes.
     */
    generation: number;
};
