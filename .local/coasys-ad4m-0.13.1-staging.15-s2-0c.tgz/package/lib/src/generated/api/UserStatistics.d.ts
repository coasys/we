import type { DateTime } from "./DateTime";
export type UserStatistics = {
    email: string;
    did: string;
    lastSeen: DateTime | null;
    perspectiveCount: number;
    remainingCredits: string;
    freeAccess: boolean;
    hotWalletAddress: string | null;
};
