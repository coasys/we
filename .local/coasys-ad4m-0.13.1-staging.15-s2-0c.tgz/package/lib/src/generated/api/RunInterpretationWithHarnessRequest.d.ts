import type { TranscriptTurn } from "./TranscriptTurn";
/**
 * Run harness-dispatched LLM interpretation over a transcript. Mirrors
 * [`RunInterpretationRequest`] but takes the tool-calling path — the LLM
 * sees a live `{Class}_query` / `{Class}_propose_create` /
 * `{Class}_propose_link_child` tool surface (design v3 §6) and drives the
 * extraction by tool calls rather than by emitting one big JSON blob.
 */
export type RunInterpretationWithHarnessRequest = {
    uuid: string;
    transcript: Array<TranscriptTurn>;
    /**
     * URI namespace new instance identities are minted under, e.g. `soa://ext/`.
     */
    basePrefix: string;
    /**
     * Local names of the subject classes to extract into (e.g. `["Task","Belief"]`).
     * `None`/empty selects all subject classes registered in the perspective.
     */
    classes?: Array<string>;
    /**
     * Upper bound on tool calls the harness will make in one pass. Reaching
     * the bound forces a final-answer step (no more tools). Must be > 0 —
     * zero would collapse the loop to the classic single-shot path and
     * should be routed there instead.
     */
    maxToolCalls: number;
    /**
     * Optional model override — same semantics as the auto-processor's
     * `modelOverride`. `None` uses the default LLM.
     */
    modelOverride?: string;
    /**
     * Optional parent-scope filter for existing-instance context (fed into
     * the pre-loop prompt). Same semantics as `RunInterpretationRequest`.
     */
    existingScope?: any;
    /**
     * Present: the pass emits `ToolCall` / `ToolResult` events on the
     * `auto-processor-event` topic carrying this value as both
     * `processor_id` and `batch_key`, so a subscribed UI can render the
     * harness loop live. Absent: the pass is silent (fast headless path).
     * Same wire-shape as `RunInterpretationRequest.observation_id`.
     */
    observationId?: string;
    /**
     * Enable per-tool-call `ToolCall` + `ToolResult` events on the
     * auto-processor topic. Dead-letter without `observation_id` (nothing
     * to key against); the server gates on both.
     */
    emitDebugEvents?: boolean;
};
