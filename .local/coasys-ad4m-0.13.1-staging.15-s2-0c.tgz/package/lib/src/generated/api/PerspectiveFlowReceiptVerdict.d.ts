import type { OutputRef } from "./OutputRef";
import type { PerspectiveReceiptOutcome } from "./PerspectiveReceiptOutcome";
/**
 * `verdict_wire`'s shape. The last three fields appear only when verified.
 */
export type PerspectiveFlowReceiptVerdict = {
    outcome: PerspectiveReceiptOutcome;
    detail: string;
    terminalState?: string;
    outputs?: Array<OutputRef>;
    voters?: Array<string>;
};
