/**
 * A bot key's scope.
 */
export type BotView = {
    can: Array<string>;
    expires: number;
};
