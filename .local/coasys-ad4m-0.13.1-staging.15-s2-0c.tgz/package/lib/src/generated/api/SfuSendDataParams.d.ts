export type SfuSendDataParams = {
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * The caller's session, as its join returned it.
     */
    participantId: string;
    channelLabel: string;
    /**
     * UTF-8 text, or base64 when `binary` is true.
     */
    data: string;
    binary?: boolean;
};
