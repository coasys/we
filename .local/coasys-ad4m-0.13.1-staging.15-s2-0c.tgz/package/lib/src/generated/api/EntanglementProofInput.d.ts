export type EntanglementProofInput = {
    deviceKey: string;
    deviceKeyType: string;
    deviceKeySignedByDid: string;
    didSignedByDeviceKey?: string;
};
