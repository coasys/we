import type { LocalAiBackend } from "./LocalAiBackend";
import type { LocalAiPlannedModel } from "./LocalAiPlannedModel";
import type { LocalAiPlannedRuntime } from "./LocalAiPlannedRuntime";
import type { LocalAiUnavailable } from "./LocalAiUnavailable";
/**
 * What `ai.localInstall` would do on this device.
 */
export type LocalAiPlan = {
    hardwareClass: string;
    runtimes: Array<LocalAiPlannedRuntime>;
    models: Array<LocalAiPlannedModel>;
    unavailable: Array<LocalAiUnavailable>;
    /**
     * What is not downloaded yet.
     */
    downloadBytes: number;
    /**
     * Everything the plan installs, downloaded or not.
     */
    totalBytes: number;
    /**
     * The planned models' memory, together.
     */
    memoryBytes: number;
    memoryBudgetBytes: number;
    diskFreeBytes: number | null;
    /**
     * The models fit the memory budget and the download fits the disk.
     */
    fits: boolean;
    /**
     * Why it does not fit, and what the plan stepped down or runs on the CPU.
     */
    reasons: Array<string>;
    /**
     * The recommendations' `generatedAt`.
     */
    recommendationsGeneratedAt: string;
    /**
     * The operator's device (`local_ai_device`); `null`: the best one detection found.
     */
    device: LocalAiBackend | null;
};
