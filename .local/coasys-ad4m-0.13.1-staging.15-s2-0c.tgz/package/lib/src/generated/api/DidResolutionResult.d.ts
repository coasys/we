import type { DidDocument } from "./DidDocument";
import type { DidDocumentMetadata } from "./DidDocumentMetadata";
import type { DidResolutionMetadata } from "./DidResolutionMetadata";
import type { DidVerificationMethod } from "./DidVerificationMethod";
/**
 * `identity.resolve`: a W3C DID Core resolution result. `didDocument` is the JSON-LD the
 * identity core writes (`ad4m_identity_core::did_document`); with a fragment (`#d1`) it is
 * `null` and `verificationMethod` holds that one method, its `id` made absolute
 * (`<did>#d1`). On an error both are `null` and `didResolutionMetadata.error` names it.
 */
export type DidResolutionResult = {
    didDocument: DidDocument | null;
    didDocumentMetadata: DidDocumentMetadata;
    didResolutionMetadata: DidResolutionMetadata;
    verificationMethod?: DidVerificationMethod;
};
