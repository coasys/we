import type { PerspectiveHandle } from "./PerspectiveHandle";
import type { PerspectiveState } from "./PerspectiveState";
export type PerspectiveStateFilter = {
    perspectiveUuid: string;
    state: PerspectiveState;
    perspective: PerspectiveHandle;
};
