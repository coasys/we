export type HostingInfoUser = {
    email: string;
    /**
     * `null` when the credits cannot be read.
     */
    credits: number | null;
    hotWalletAddress: string | null;
    freeAccess: boolean;
};
