import type { AiCapability } from "./AiCapability";
import type { EndpointHealth } from "./EndpointHealth";
import type { EndpointKind } from "./EndpointKind";
/**
 * An endpoint as RPC results show it.
 */
export type AiEndpoint = {
    id: string;
    name: string;
    kind: EndpointKind;
    baseUrl: string;
    hasApiKey: boolean;
    capabilities: Array<AiCapability>;
    maxNumCtx?: number | null;
    /**
     * How long a request to this endpoint may take, queueing included. Unset: 300 s for
     * chat `/v1` forwards, 600 s for chat the executor answers, 60 s for embeddings, 120 s
     * for speech. An OpenAI-protocol chat client uses this value for a stream too. A value
     * above 600 s is kept. A stream has no second timer in `within_endpoint_limits`.
     */
    requestTimeoutSecs?: number | null;
    /**
     * At most this many requests to this endpoint at once; the rest queue. Unset: no limit.
     */
    maxConcurrent?: number | null;
    /**
     * The executor's own local AI runs this server (`ai.localInstall`): its URL, key and
     * models follow the supervisor, `ai.updateEndpoint` and `ai.removeEndpoint` refuse it,
     * and its health is the supervisor's liveness check. `ai.localRemove` removes it.
     */
    managed: boolean;
    health: EndpointHealth;
};
