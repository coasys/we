import type { JsonValue } from "./serde_json/JsonValue";
/**
 * One pending overlay, flattened for the query surface / UIs.
 */
export type OverlayView = {
    /**
     * The base instance the overlay sits on.
     */
    base: string;
    /**
     * `"create"` | `"update"` — whether the LLM authored the whole instance or
     * only proposed changes to an existing one.
     */
    kind: string;
    /**
     * The `InterpretationRun` that last wrote it, if present.
     */
    run: string | null;
    /**
     * `(real predicate, staged value)` pairs — the model's proposed values a
     * human has not yet accepted.
     */
    inferred: Array<[string, JsonValue]>;
};
