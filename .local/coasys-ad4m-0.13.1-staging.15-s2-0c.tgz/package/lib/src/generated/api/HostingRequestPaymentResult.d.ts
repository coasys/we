export type HostingRequestPaymentResult = {
    success: boolean;
    amountHOT: string;
};
