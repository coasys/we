import type { ModelType } from "./ModelType";
export type SetDefaultModelRequest = {
    modelType: ModelType;
};
