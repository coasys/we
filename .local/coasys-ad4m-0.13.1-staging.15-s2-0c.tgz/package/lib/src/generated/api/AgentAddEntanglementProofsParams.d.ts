import type { EntanglementProofInput } from "./EntanglementProofInput";
/**
 * `{ proofs }`, plus `preflight: true` to sign the first proof's device key
 * instead of storing the proofs.
 */
export type AgentAddEntanglementProofsParams = {
    proofs: Array<EntanglementProofInput>;
    preflight?: boolean;
};
