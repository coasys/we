import type { CapabilityInput } from "./CapabilityInput";
export type AuthInfoInput = {
    appDesc: string;
    appDomain: string;
    appIconPath?: string;
    appName: string;
    appUrl?: string;
    capabilities?: Array<CapabilityInput>;
    userDid?: string;
};
