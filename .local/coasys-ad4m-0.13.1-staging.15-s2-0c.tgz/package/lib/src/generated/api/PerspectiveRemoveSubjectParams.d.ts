export type PerspectiveRemoveSubjectParams = {
    uuid: string;
    subjectClass: string;
    expressionAddress: string;
    batchId?: string;
};
