import type { Cardinality } from "./Cardinality";
import type { ValidationProblem } from "./ValidationProblem";
import type { JsonValue } from "./serde_json/JsonValue";
/**
 * One rejected property.
 */
export type ValidationError = {
    /**
     * The property as the class names it, or as the caller wrote it when the class has none.
     */
    property: string;
    problem: ValidationProblem;
    /**
     * The property's type: `string`, `boolean`, `integer`, `number`, `datetime`, `reference`,
     * or a custom datatype's local name. `None` for an unknown property.
     */
    expectedType: string | null;
    /**
     * `None` for an unknown property.
     */
    cardinality: Cardinality | null;
    /**
     * The property's `sh:in` values, in declared order, when it has a list.
     */
    allowedValues: Array<JsonValue> | null;
    /**
     * The value the caller sent, when there was one.
     */
    received: JsonValue | null;
    /**
     * For a collection item, its index in the array the caller sent.
     */
    item: number | null;
};
