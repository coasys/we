export type GenerateAgentRequest = {
    passphrase: string;
};
