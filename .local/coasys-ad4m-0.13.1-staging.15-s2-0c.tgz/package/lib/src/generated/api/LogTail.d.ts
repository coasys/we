/**
 * `runtime.logTail` result: the newest lines of this run's log file, oldest first.
 */
export type LogTail = {
    lines: Array<string>;
};
