import type { ForkRecord } from "./ForkRecord";
import type { SkippedSource } from "./SkippedSource";
/**
 * DID resolution metadata, with the executor's `coasys:` members.
 */
export type DidResolutionMetadata = {
    /**
     * `application/did+ld+json` on success.
     */
    contentType?: string;
    /**
     * The DID Core error: `invalidDid`, `invalidDidUrl`, `methodNotSupported`, `notFound`,
     * `representationNotSupported`, `internalError`.
     */
    error?: string;
    /**
     * Why, in words, with an error.
     */
    "coasys:message"?: string;
    /**
     * The host that answered the log (`host[:port][/path]`), or `cache`.
     */
    "coasys:source"?: string;
    /**
     * The log's head is one the cache accepted signed by a key of `identity.storeKeys`.
     */
    "coasys:headTrusted"?: boolean;
    /**
     * The first fork the cache recorded for the log; the document is from the log it held
     * first.
     */
    "coasys:fork"?: ForkRecord;
    /**
     * For a `did:key`: the key's id in its person's log (`d2`).
     */
    "coasys:keyId"?: string;
    /**
     * For a `did:key`: the key is valid at the head (a revoked key still resolves to its
     * person, with `false`).
     */
    "coasys:keyValid"?: boolean;
    /**
     * For a `did:key`: the key index named an identity whose log does not list the key.
     */
    "coasys:keyIndexMismatch"?: boolean;
    /**
     * Sources the resolver did not use, with why (refused address, unsupported scheme, a
     * failed fetch).
     */
    "coasys:skipped"?: Array<SkippedSource>;
};
