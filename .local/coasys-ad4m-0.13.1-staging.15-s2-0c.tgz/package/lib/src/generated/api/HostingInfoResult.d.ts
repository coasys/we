import type { HostingInfoUser } from "./HostingInfoUser";
import type { HostingVersionInfo } from "./HostingVersionInfo";
export type HostingInfoResult = {
    /**
     * `null` outside multi-user mode.
     */
    userInfo: HostingInfoUser | null;
    /**
     * `[token, rate]` pairs; `null` when the rates cannot be read.
     */
    rates: Array<[string, number]> | null;
    version: HostingVersionInfo;
};
