import type { Capability } from "./Capability";
/**
 * A conversation with the executor's AI: the `ai_sessions` row.
 */
export type AISession = {
    id: string;
    /**
     * The managed agent that owns the session; `null` for a session of the main agent.
     */
    ownerDid: string | null;
    title: string;
    /**
     * The model the session runs on; `null` = the node's default language model.
     */
    model: string | null;
    /**
     * The perspective the conversation is about: a hint for the model, not a limit. The
     * session's tools may act on every perspective the caller and the capabilities allow.
     */
    defaultPerspective: string | null;
    /**
     * The perspective holding the agent's WE template library (#1663).
     */
    libraryPerspective: string | null;
    /**
     * What the session's tools may do, as a caller holds them: `with.domain`,
     * `with.pointers` and `can`, e.g. read on perspective A, read+update on perspective B.
     * The harness checks every tool call against these intersected with the caller's own.
     */
    capabilities: Array<Capability>;
    createdAt: string;
    updatedAt: string;
};
