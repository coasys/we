/**
 * `sfu.callRestartIce`: the session whose ICE to restart.
 */
export type SfuRestartIceParams = {
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * The caller's session, as its join returned it. Any other id, even
     * another device of the same agent, is refused.
     */
    participantId: string;
};
