export type AIPromptExamplesInput = {
    input: string;
    output: string;
};
