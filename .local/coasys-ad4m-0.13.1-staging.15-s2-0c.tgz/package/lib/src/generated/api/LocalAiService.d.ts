/**
 * What a local runtime serves.
 */
export type LocalAiService = "llm" | "embeddings" | "stt" | "tts";
