import type { JsonValue } from "./serde_json/JsonValue";
export type HostingWalletResult = {
    /**
     * The Unyt zome's `get_ledger` output (open JSON); `null` on failure.
     */
    balance: JsonValue | null;
    pubkey: string | null;
};
