export type ModelState = "UNKNOWN" | "READY" | "MISSING" | "PULLING" | "ENDPOINT_DOWN";
