import type { AISessionMessageRole } from "./AISessionMessageRole";
import type { AITurnStatus } from "./AITurnStatus";
/**
 * One transcript entry: the `ai_messages` row.
 */
export type AISessionMessage = {
    id: string;
    sessionId: string;
    /**
     * The order the entries were written, per session.
     */
    seq: number;
    role: AISessionMessageRole;
    /**
     * The transcript entry: `{"text": ..}` for user and assistant turns;
     * `{"name", "arguments", "target"?, "writes", "result"? | "error"?}` for a
     * tool step. `writes` is the tool's declared intent
     * (`agent_session::tool_writes`), recorded before the call runs. It does
     * not say the call changed anything: a refused or failed write still has
     * `writes: true`.
     */
    content: unknown;
    /**
     * Set on the assistant's turns and on tool steps: `running` until it ends.
     */
    status: AITurnStatus | null;
    /**
     * Why a `failed`, `cancelled` or `interrupted` row ended.
     */
    error: string | null;
    createdAt: string;
};
