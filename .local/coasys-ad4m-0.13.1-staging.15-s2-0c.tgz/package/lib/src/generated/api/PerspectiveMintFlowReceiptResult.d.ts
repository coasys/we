import type { JsonValue } from "./serde_json/JsonValue";
export type PerspectiveMintFlowReceiptResult = {
    receiptUri: string;
    /**
     * The serialized `FlowReceipt`. The receipt tree carries no TS types,
     * so the wire keeps it opaque; pass it back to `verifyFlowReceipt`.
     */
    receipt: JsonValue;
};
