export type UsersVerifyEmailParams = {
    email: string;
    code: string;
    /**
     * Defaults to `signup`.
     */
    verificationType?: string;
    /**
     * Defaults to `ad4m`.
     */
    appName?: string;
};
