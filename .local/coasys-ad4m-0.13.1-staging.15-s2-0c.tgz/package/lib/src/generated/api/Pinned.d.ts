/**
 * Why a key's value in the file is not what runs: a flag or an environment variable of this
 * start overrides it.
 */
export type Pinned = "config";
