import type { TriggeredNotification } from "./TriggeredNotification";
/**
 * The `notification-triggered` event: the triggered notification plus the
 * perspective it fired in.
 */
export type NotificationTriggeredEvent = {
    perspectiveUuid: string;
    notification: TriggeredNotification;
};
