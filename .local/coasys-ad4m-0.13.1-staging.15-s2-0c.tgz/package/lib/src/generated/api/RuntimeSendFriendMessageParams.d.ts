import type { NeighbourhoodSignedPerspective } from "./NeighbourhoodSignedPerspective";
export type RuntimeSendFriendMessageParams = {
    did: string;
    /**
     * The perspective to sign as this agent.
     */
    message: NeighbourhoodSignedPerspective;
};
