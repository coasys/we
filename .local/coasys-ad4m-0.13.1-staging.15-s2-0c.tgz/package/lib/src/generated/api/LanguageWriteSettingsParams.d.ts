export type LanguageWriteSettingsParams = {
    address: string;
    settings: any;
};
