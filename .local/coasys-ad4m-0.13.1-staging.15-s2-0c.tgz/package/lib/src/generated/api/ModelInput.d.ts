import type { ModelType } from "./ModelType";
/**
 * A model to add, or the new settings of one (`ai.addModel`, `ai.updateModel`): an
 * upstream model on a registered endpoint.
 */
export type ModelInput = {
    name: string;
    modelType: ModelType;
    endpointId: string;
    /**
     * The id the endpoint knows the model by (`ai.discoverModels` lists them).
     */
    remoteModel: string;
    /**
     * Whether prompts with tools send them as tool definitions. Left out: yes on
     * Anthropic and Ollama endpoints, no on an OpenAI-shaped server.
     */
    nativeTools?: boolean;
};
