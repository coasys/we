export type UsersRevokeAllSessionsParams = {
    /**
     * The user whose sessions to revoke. A user may leave it out or name themselves; the
     * operator must name the user.
     */
    email?: string;
};
