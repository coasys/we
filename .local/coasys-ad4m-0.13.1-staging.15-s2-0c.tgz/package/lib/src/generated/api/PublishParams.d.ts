import type { JsonValue } from "./serde_json/JsonValue";
/**
 * `identity.publish` params. No vouching token or proof of work: the store has no brake yet
 * and admits a new log without one.
 */
export type PublishParams = {
    /**
     * Signed events that continue the log's head (or start a log), as JSON.
     */
    events: Array<JsonValue>;
};
