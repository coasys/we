import type { LocalAiService } from "./LocalAiService";
/**
 * What `ai.localInstall` asks for.
 */
export type LocalAiInstallParams = {
    /**
     * The services to set up, of those the plan offers. Left out: all of them.
     */
    services?: Array<LocalAiService> | null;
    /**
     * Start the runtimes and register them when the files are in. Left out: yes.
     */
    start?: boolean | null;
};
