/**
 * `perspective.flowFired`: for each of `instances`, in order, the proposals
 * the calling agent's pass has recorded as fired, sorted.
 */
export type PerspectiveFlowFiredParams = {
    uuid: string;
    instances: Array<string>;
};
