export type FriendSendMessageRequest = {
    message: any;
};
