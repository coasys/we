import type { SfuRoomParticipantInfo } from "./SfuRoomParticipantInfo";
/**
 * Snapshot of an SFU room, exposed over the WS RPC API.
 */
export type SfuRoomInfo = {
    neighbourhoodUrl: string;
    roomName: string;
    participantCount: number;
    participants: Array<SfuRoomParticipantInfo>;
    createdAtMs: number;
};
