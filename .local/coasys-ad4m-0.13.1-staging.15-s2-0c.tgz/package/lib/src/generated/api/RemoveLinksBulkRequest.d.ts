import type { LinkExpressionInput } from "./LinkExpressionInput";
export type RemoveLinksBulkRequest = {
    links: Array<LinkExpressionInput>;
    batchId?: string;
};
