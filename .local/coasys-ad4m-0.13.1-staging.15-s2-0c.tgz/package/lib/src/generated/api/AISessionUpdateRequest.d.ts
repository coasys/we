import type { Capability } from "./Capability";
/**
 * `ai.sessionUpdate`'s params: the session's id and the fields to change, flat.
 */
export type AISessionUpdateRequest = {
    /**
     * The session's id.
     */
    id: string;
    title: string | null;
    model: string | null | null;
    defaultPerspective: string | null | null;
    libraryPerspective: string | null | null;
    capabilities: Array<Capability> | null;
};
