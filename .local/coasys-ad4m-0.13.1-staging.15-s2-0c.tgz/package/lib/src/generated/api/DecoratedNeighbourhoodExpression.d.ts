import type { DecoratedExpressionProof } from "./DecoratedExpressionProof";
import type { Neighbourhood } from "./Neighbourhood";
export type DecoratedNeighbourhoodExpression = {
    author: string;
    data: Neighbourhood;
    proof: DecoratedExpressionProof;
    timestamp: string;
};
