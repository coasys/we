import type { LinkInput } from "./LinkInput";
export type AddLinkRequest = {
    link: LinkInput;
    status?: string;
    batchId?: string;
};
