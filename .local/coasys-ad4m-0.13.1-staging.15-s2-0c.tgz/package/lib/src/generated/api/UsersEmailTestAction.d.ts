export type UsersEmailTestAction = "send" | "enable" | "disable" | "get-code" | "clear" | "clear-codes" | "set-expiry";
