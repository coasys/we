import type { LinkMutations } from "./LinkMutations";
export type LinkMutationsRequest = {
    mutations: LinkMutations;
    status?: string;
};
