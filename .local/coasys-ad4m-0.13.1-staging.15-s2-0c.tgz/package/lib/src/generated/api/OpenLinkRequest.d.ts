export type OpenLinkRequest = {
    url: string;
};
