import type { LanguageMetaInput } from "./LanguageMetaInput";
export type PublishLanguageRequest = {
    languagePath: string;
    languageMeta: LanguageMetaInput;
};
