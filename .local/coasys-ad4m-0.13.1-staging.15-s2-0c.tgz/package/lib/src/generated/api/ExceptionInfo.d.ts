import type { ExceptionType } from "./ExceptionType";
export type ExceptionInfo = {
    addon: string | null;
    message: string;
    title: string;
    type: ExceptionType;
};
