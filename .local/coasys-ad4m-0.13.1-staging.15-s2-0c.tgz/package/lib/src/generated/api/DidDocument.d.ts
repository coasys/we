import type { DidVerificationMethod } from "./DidVerificationMethod";
/**
 * The JSON-LD of a `did:scid:coasys:1` DID document (the TypeScript contract of
 * `DidResolutionResult.didDocument`; the executor passes on the core's own JSON).
 */
export type DidDocument = {
    "@context": Array<string>;
    id: string;
    controller: string;
    verificationMethod: Array<DidVerificationMethod>;
    authentication: Array<string>;
    assertionMethod: Array<string>;
    keyAgreement: Array<string>;
    capabilityInvocation: Array<string>;
    alsoKnownAs?: Array<string>;
};
