/**
 * `sfu.callLeave`: the session to leave, as its join returned it.
 */
export type SfuCallLeaveParams = {
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * The `participantId` the join returned. Only the caller's own session
     * is left; any other id leaves nothing (`false`).
     */
    participantId: string;
};
