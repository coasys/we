/**
 * One session in an [`SfuRoomRoster`].
 */
export type SfuRosterParticipant = {
    agentDid: string;
    participantId: string;
};
