export type TrustedAgentsRequest = {
    agents: Array<string>;
};
