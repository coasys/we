export type PerspectiveSubscriptionParams = {
    uuid: string;
    subscriptionId: string;
};
