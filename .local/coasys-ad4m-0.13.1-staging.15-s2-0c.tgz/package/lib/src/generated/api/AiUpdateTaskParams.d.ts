import type { AITask } from "./AITask";
export type AiUpdateTaskParams = {
    task: AITask;
};
