export type PromptRequest = {
    taskId: string;
    prompt: string;
};
