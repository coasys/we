/**
 * Register a neighbourhood auto-processor on a perspective. See
 * `AutoProcessorConfig` for the semantics of each field.
 */
export type PerspectiveAddAutoProcessorParams = {
    uuid: string;
    processorId: string;
    /**
     * SPARQL `SELECT ?speaker ?text ?timestamp` over the source items.
     */
    sourceScopeQuery: string;
    basePrefix?: string;
    interpretationClasses: Array<string>;
    flows?: Array<string>;
    debounceMs: number;
    batchMin?: number;
    batchMax: number;
    maxWaitMs?: number;
    claimTtlMs: number;
    dedupStrategyJson?: string;
    sourceWindowMs?: number;
    existingScope?: any;
    mintScope?: any;
    maxToolCalls?: number;
    emitDebugEvents?: boolean;
};
