/**
 * Wire names stay snake_case, as the handlers read them.
 *
 * Exactly one of `class_name` and `class_names`: one class, or one query over
 * the union of several (#1238), whose rows carry `__subjectClass` and
 * `__subjectClasses`.
 */
export type PerspectiveModelQueryParams = {
    uuid: string;
    class_name?: string;
    class_names?: Array<string>;
    query_json: string;
};
