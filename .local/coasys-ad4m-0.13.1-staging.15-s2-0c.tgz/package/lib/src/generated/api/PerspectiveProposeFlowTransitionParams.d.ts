import type { OutputRef } from "./OutputRef";
export type PerspectiveProposeFlowTransitionParams = {
    uuid: string;
    instanceUri: string;
    toState: string;
    rationale?: string;
    outputs?: Array<OutputRef>;
};
