import type { ModelType } from "./ModelType";
export type AiGetDefaultModelParams = {
    modelType: ModelType;
};
