export type RequestBody = {
    did: string;
    /**
     * The `did:key` of the store the request is for; another store refuses it.
     */
    store: string;
    keyId: string;
    kelSeq: number;
    kelHash: string;
    method: string;
    path: string;
    bodyHash: string;
    nonce: string;
    expires: number;
};
