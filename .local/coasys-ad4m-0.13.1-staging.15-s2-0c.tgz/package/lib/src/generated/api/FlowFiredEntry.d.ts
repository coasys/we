/**
 * The proposals of one instance this agent has marked fired, as
 * `perspective.flowFired` returns them.
 */
export type FlowFiredEntry = {
    instance: string;
    /**
     * Sorted; empty when this agent has marked none.
     */
    fired: Array<string>;
};
