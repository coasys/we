/**
 * What an endpoint or one of its models can do.
 */
export type AiCapability = "chat" | "embeddings" | "transcription" | "speech";
