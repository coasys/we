export type RuntimeGrantNotificationParams = {
    id: string;
    granted: boolean;
};
