/**
 * Through an abstract class (#1435), dispatched to the record's own classes.
 */
export type UpdateSubjectRequest = {
    subjectClass: string;
    expressionAddress: string;
    /**
     * A JSON object: property name → value.
     */
    values: string;
    batchId?: string;
};
