export type NotificationInput = {
    description: string;
    appName: string;
    appUrl: string;
    appIconPath?: string;
    trigger: string;
    perspectiveIds: Array<string>;
    webhookUrl: string;
    /**
     * Sent as the bearer credential to `webhookUrl`. Results and events say only
     * whether one is set (`hasWebhookAuth`).
     */
    webhookAuth: string;
};
