import type { LocalAiBasis } from "./LocalAiBasis";
import type { LocalAiProvider } from "./LocalAiProvider";
import type { LocalAiService } from "./LocalAiService";
export type LocalAiPlannedModel = {
    service: LocalAiService;
    /**
     * The manifest's model id, also the id the runtime serves it by.
     */
    modelId: string;
    provider: LocalAiProvider;
    sizeBytes: number;
    memoryBytes: number;
    license: string;
    installed: boolean;
    /**
     * `measured`: the wind tunnel's recommendation. `default`: no class on the chain was
     * measured for this service, so the plan takes the manifest's smallest model.
     */
    basis: LocalAiBasis;
    /**
     * The measured class the recommendation comes from; for a default, this device's.
     */
    fromClass: string;
    /**
     * Empty for a default.
     */
    evidence: Array<string>;
    metrics: Record<string, unknown>;
    /**
     * The flags the server runs this model with: the measurement's, else the defaults.
     */
    serverFlags: Array<string>;
};
