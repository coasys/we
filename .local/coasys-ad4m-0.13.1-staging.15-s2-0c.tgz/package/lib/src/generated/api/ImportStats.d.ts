export type ImportStats = {
    total: number;
    imported: number;
    failed: number;
    omitted: number;
    errors: Array<string>;
};
