/**
 * `identity.claimOffer` params.
 */
export type ClaimOfferParams = {
    /**
     * The offer string (`coasys:offer:1:…`) or the offer link (`https://id.coasys.org/o#…`).
     */
    offer: string;
    /**
     * A name for this device the holder sees on the confirm card (at most 64 characters).
     */
    hint?: string;
};
