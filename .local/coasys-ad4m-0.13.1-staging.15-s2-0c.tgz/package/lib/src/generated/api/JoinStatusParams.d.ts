/**
 * `identity.joinStatus` params.
 */
export type JoinStatusParams = {
    offerId: string;
};
