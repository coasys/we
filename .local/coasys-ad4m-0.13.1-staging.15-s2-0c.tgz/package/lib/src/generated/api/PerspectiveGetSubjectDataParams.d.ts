export type PerspectiveGetSubjectDataParams = {
    uuid: string;
    subjectClass: string;
    expressionAddress: string;
};
