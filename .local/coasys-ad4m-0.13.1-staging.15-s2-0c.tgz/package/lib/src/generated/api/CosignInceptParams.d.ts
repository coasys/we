import type { JsonValue } from "./serde_json/JsonValue";
/**
 * `identity.cosignIncept` params.
 */
export type CosignInceptParams = {
    /**
     * An `incept` that lists this agent's device key, with the master's proof.
     */
    event: JsonValue;
};
