import type { NeighbourhoodPerspectivePayload } from "./NeighbourhoodPerspectivePayload";
export type NeighbourhoodBroadcastParams = {
    uuid: string;
    payload: NeighbourhoodPerspectivePayload;
    signed?: boolean;
    loopback?: boolean;
};
