/**
 * What an offer is for: `node` is an executor.
 */
export type OfferKind = "device" | "node" | "bot";
