/**
 * Wrapper: SDK sends `{ interactionCall: {...} }` for expression interact
 */
export type InteractionCallWrapper = {
    interactionCall: any;
};
