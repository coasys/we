export type PerspectiveInstanceAddToCollectionParams = {
    uuid: string;
    className: string;
    baseUri: string;
    collection: string;
    /**
     * The item, usually another instance's URI.
     */
    itemUri: string;
    /**
     * An open batch to stage the write into; see `InstanceCreate`'s `batchId`.
     */
    batchId?: string;
};
