/**
 * What a planned model is chosen by.
 */
export type LocalAiBasis = "measured" | "default";
