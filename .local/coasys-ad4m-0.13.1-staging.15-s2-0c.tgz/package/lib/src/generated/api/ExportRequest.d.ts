export type ExportRequest = {
    type: string;
    filePath: string;
    perspectiveUuid?: string;
};
