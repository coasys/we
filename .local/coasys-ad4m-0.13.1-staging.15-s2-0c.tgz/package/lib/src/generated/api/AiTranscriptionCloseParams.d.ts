export type AiTranscriptionCloseParams = {
    streamId: string;
};
