export type UpdatePerspectiveRequest = {
    name: string;
};
