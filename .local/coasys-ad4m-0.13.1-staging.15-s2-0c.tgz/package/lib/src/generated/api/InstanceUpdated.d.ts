export type InstanceUpdated = {
    className: string;
    baseUri: string;
    updatedProperties: Array<string>;
};
