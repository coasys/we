export type PerspectiveCommitBatchParams = {
    uuid: string;
    batchId: string;
};
