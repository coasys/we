/**
 * One ICE server entry as understood by browser `RTCConfiguration` —
 * mirrors the WebIDL shape so clients can pass it through unchanged.
 */
export type IceServer = {
    /**
     * One or more URLs (`stun:`, `turn:`, `turns:`).
     */
    urls: Array<string>;
    /**
     * TURN username, when applicable.
     */
    username?: string;
    /**
     * TURN long-term credential, when applicable.
     */
    credential?: string;
};
