import type { CollectionItems } from "./CollectionItems";
export type InstanceCreated = {
    /**
     * The class's canonical name.
     */
    className: string;
    /**
     * The new instance's URI (its id).
     */
    baseUri: string;
    propertiesSet: Array<string>;
    collectionsSet: Array<CollectionItems>;
    /**
     * The parent it was put under, when one was named.
     */
    parent: string | null;
};
