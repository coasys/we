export type ExpressionProof = {
    key: string;
    signature: string;
};
