/**
 * One output of a run: an instance, and the class it is an instance of.
 *
 * The class is part of the name because an output's content is what
 * `model_query` returns for that class's shape, and the same node read
 * through another class is other content. Serialised camelCase
 * (`{"className", "id"}`), the shape the TS client sends.
 */
export type OutputRef = {
    className: string;
    id: string;
};
