export type DecoratedExpressionProof = {
    key: string;
    signature: string;
    valid: boolean | null;
    invalid: boolean | null;
};
