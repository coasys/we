import type { LinkExpression } from "./LinkExpression";
export type PerspectiveAddLinkExpressionParams = {
    uuid: string;
    link: LinkExpression;
    status?: string;
    batchId?: string;
};
