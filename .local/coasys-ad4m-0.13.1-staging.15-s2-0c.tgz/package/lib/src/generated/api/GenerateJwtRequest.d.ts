export type GenerateJwtRequest = {
    rand: string;
    requestId: string;
};
