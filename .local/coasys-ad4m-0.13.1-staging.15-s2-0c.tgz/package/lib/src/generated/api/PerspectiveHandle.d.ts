import type { DecoratedNeighbourhoodExpression } from "./DecoratedNeighbourhoodExpression";
import type { PerspectiveState } from "./PerspectiveState";
export type PerspectiveHandle = {
    uuid: string;
    name: string | null;
    neighbourhood: DecoratedNeighbourhoodExpression | null;
    sharedUrl: string | null;
    state: PerspectiveState;
    owners: Array<string> | null;
};
