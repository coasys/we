import type { LinkExpressionInput } from "./LinkExpressionInput";
import type { LinkInput } from "./LinkInput";
export type PerspectiveUpdateLinkParams = {
    uuid: string;
    oldLink: LinkExpressionInput;
    newLink: LinkInput;
    batchId?: string;
};
