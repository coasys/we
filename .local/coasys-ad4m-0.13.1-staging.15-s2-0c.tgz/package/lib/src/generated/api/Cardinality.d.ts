/**
 * How many values a property takes: `min` 0 or 1, `max` 1 or none (a collection).
 */
export type Cardinality = {
    min: number;
    max: number | null;
};
