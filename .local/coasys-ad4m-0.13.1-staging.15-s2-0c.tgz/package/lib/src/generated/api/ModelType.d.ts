export type ModelType = "LLM" | "EMBEDDING" | "TRANSCRIPTION" | "SPEECH";
