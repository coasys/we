/**
 * Maps one outbound SDP m-line to the originating participant.
 */
export type TrackMapEntry = {
    /**
     * The SDP mid (media-line identifier) in the offer.
     */
    mid: string;
    /**
     * The session whose media this m-line carries: one agent on two
     * devices sends two.
     */
    participantId: string;
    /**
     * DID of the participant whose media this m-line carries.
     */
    agentDid: string;
    /**
     * `"audio"` or `"video"`.
     */
    mediaKind: string;
};
