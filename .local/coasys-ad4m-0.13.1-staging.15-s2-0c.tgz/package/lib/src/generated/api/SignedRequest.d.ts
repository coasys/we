import type { RequestBody } from "./RequestBody";
/**
 * A request signed by a key of the identity (`X-Coasys-Request`).
 */
export type SignedRequest = {
    req: RequestBody;
    sig: string;
};
