export type AddAgentInfosRequest = {
    agentInfos: Array<string>;
};
