import type { PerspectiveExpression } from "./PerspectiveExpression";
import type { PerspectiveHandle } from "./PerspectiveHandle";
export type NeighbourhoodSignalFilter = {
    perspectiveUuid: string;
    perspective: PerspectiveHandle;
    signal: PerspectiveExpression;
    recipient: string | null;
};
