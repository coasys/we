export type ExecuteCommandsRequest = {
    commands: string;
    expression: string;
    parameters?: string;
    batchId?: string;
};
