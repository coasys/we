import type { AgentMessage } from "./AgentMessage";
export type RunAgentRequest = {
    uuid: string;
    /**
     * The conversation so far, the person's request last.
     */
    messages: Array<AgentMessage>;
    /**
     * What the person is looking at, as a hint for the model (`{ "recordId": "…" }`).
     */
    context?: Record<string, unknown>;
    /**
     * Tools that write which the model may call — `instance_update`, `template_update`; only
     * tools that write inside the perspective (`agent_session::SESSION_WRITES`). None means a
     * session that only reads.
     */
    writeTools?: Array<string>;
    /**
     * A model id; the node's default language model when absent.
     */
    model?: string;
    /**
     * How many tool calls the model may make before it must answer. Default 20.
     */
    maxToolCalls?: number;
};
