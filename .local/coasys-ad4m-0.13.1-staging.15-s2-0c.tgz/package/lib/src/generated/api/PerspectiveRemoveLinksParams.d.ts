import type { LinkExpressionInput } from "./LinkExpressionInput";
export type PerspectiveRemoveLinksParams = {
    uuid: string;
    links: Array<LinkExpressionInput>;
    batchId?: string;
};
