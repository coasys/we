export type PerspectiveCreateSubjectParams = {
    uuid: string;
    subjectClass: string;
    expressionAddress: string;
    initialValues?: string;
    batchId?: string;
};
