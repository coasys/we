export type LinkStatus = "SHARED" | "LOCAL";
