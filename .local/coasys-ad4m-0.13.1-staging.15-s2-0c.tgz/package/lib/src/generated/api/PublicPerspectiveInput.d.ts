import type { LinkExpressionInput } from "./LinkExpressionInput";
export type PublicPerspectiveInput = {
    links: Array<LinkExpressionInput>;
};
