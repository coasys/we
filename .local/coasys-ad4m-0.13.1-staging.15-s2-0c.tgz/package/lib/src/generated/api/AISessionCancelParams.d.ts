export type AISessionCancelParams = {
    /**
     * The session whose turn ends.
     */
    sessionId: string;
};
