import type { DecoratedExpressionProof } from "./DecoratedExpressionProof";
import type { Icon } from "./Icon";
import type { LanguageRef } from "./LanguageRef";
export type ExpressionRendered = {
    author: string;
    data: string;
    icon: Icon;
    language: LanguageRef;
    proof: DecoratedExpressionProof;
    timestamp: string;
};
