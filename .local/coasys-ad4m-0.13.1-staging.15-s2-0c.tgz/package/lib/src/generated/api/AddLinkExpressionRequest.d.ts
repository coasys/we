import type { LinkExpression } from "./LinkExpression";
export type AddLinkExpressionRequest = {
    link: LinkExpression;
    status?: string;
    batchId?: string;
};
