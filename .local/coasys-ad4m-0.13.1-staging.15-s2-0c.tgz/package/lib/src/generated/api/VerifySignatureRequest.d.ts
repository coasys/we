export type VerifySignatureRequest = {
    did: string;
    data: string;
    signedData: string;
};
