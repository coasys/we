import type { Icon } from "./Icon";
export type LanguageHandle = {
    address: string;
    constructorIcon: Icon | null;
    icon: Icon | null;
    name: string;
    settings: string | null;
    settingsIcon: Icon | null;
};
