export type PerspectiveInstanceCreateParams = {
    uuid: string;
    /**
     * The subject class, as the perspective names it (matched case-insensitively).
     */
    className: string;
    /**
     * Values by property name: one JSON value per single-valued property (of the property's
     * type), an array of item URIs per collection. Required properties must be present.
     */
    properties?: Record<string, unknown>;
    /**
     * The new instance's URI. A random `ad4m://obj/…` one when absent; a bare string becomes a
     * literal URI.
     */
    baseUri?: string;
    /**
     * A node to put the new instance under, through the parent class's own `children` relation
     * when it has one, else `ad4m://has_child`.
     */
    parent?: string;
    /**
     * An open batch (`perspective.createBatch`) to stage the write into; it lands on the
     * batch's commit. Absent: the create commits on its own. On a non-validation error the
     * batch may hold a partial write — discard it (`perspective.discardBatch`), don't commit
     * it.
     */
    batchId?: string;
};
