import type { ConfigKeyInfo } from "./ConfigKeyInfo";
/**
 * `runtime.config` result.
 */
export type RuntimeConfig = {
    /**
     * The file's keys and values: what the next start reads. The file holds no secret (a
     * secret is named by a `*_file` path), and a secret pasted into it is left out.
     */
    values: Record<string, unknown>;
    /**
     * Every key `runtime.setConfig` knows, with its class.
     */
    keys: Array<ConfigKeyInfo>;
    /**
     * A write since this start waits for the next start.
     */
    restartPending: boolean;
    /**
     * The file the executor started with, `null` without `--config`.
     */
    file: string | null;
};
