export type AiTranscriptionOpenParams = {
    modelId: string;
};
