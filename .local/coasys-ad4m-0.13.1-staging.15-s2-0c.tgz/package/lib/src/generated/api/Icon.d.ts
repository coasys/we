export type Icon = {
    code: string | null;
};
