/**
 * One row of this agent's bookkeeping, as `perspective.flowStates` returns
 * it. An instance with no entry is one this agent has neither derived nor
 * minted here: a client must not guess its state.
 */
export type FlowStateEntry = {
    instance: string;
    /**
     * The state this agent's pass last derived. `None` for a row seeded at
     * mint and not derived yet: the instance stands at its flow's first
     * state, which only the flow definition names.
     */
    currentState: string | null;
    /**
     * RFC 3339 time of the pass that last wrote this state; `None` with it.
     */
    derivedAt: string | null;
};
