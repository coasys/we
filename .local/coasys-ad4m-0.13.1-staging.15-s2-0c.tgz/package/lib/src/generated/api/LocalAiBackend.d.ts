export type LocalAiBackend = "cpu" | "metal" | "vulkan" | "cuda" | "rocm";
