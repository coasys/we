export type SubscribeQueryRequest = {
    query: string;
    /**
     * Minted by the client, so it can end the subscription without the reply.
     */
    subscriptionId: string;
};
