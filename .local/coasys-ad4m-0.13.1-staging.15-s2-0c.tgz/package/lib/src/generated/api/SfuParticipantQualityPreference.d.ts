/**
 * One entry of `sfu.qualityPreferences`.
 */
export type SfuParticipantQualityPreference = {
    participantId: string;
    preference: string;
};
