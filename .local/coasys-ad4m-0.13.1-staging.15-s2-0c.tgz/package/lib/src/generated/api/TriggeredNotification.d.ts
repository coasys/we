import type { Notification } from "./Notification";
export type TriggeredNotification = {
    notification: Notification;
    perspectiveId: string;
    triggerMatch: string;
};
