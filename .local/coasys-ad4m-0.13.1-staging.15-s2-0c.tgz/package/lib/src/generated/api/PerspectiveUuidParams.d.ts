export type PerspectiveUuidParams = {
    uuid: string;
};
