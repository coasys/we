import type { ShapeAction } from "./ShapeAction";
import type { ShapeConformanceCondition } from "./ShapeConformanceCondition";
import type { JsonValue } from "./serde_json/JsonValue";
/**
 * SHACL Property Shape structure
 */
export type PropertyShapeJson = {
    path: string;
    name?: string;
    /**
     * Natural-language hint describing this property's meaning, injected into the
     * interpretation prompt / generated tool schema as semantic guidance for the LLM.
     * Emitted as an `ad4m://interpretation_hint` link on the property node.
     */
    interpretation_hint?: string;
    /**
     * Marks this property as the class's dedup identity (the "title-like"
     * interpretation key). Emitted as an `ad4m://identity` link on the
     * property node when `Some(true)`. No identity declared ⇒ no dedup.
     */
    identity?: boolean;
    /**
     * CRDT ordering strategy for a collection relation, from
     * `@HasMany({ ordering: { strategy } })`. Emitted as an `ad4m://ordering`
     * link on the property node, which is the only place
     * [`load_shape`](super::model_query::shape) reads it back from — so
     * dropping it here leaves the declaration inert: the setter writes no
     * ordering entries and hydration never reorders.
     */
    ordering?: string;
    datatype?: string;
    min_count?: number;
    max_count?: number;
    writable?: boolean;
    local?: boolean;
    /**
     * Sole selector of storage mode. `None` → deterministic typed
     * literal (fast POS-index path, the default). `Some("literal")` →
     * signed envelope on the built-in literal language. `Some(<addr>)`
     * → expression on that custom language. Stored as `ad4m://resolveLanguage`.
     */
    resolve_language?: string;
    node_kind?: string;
    collection?: boolean;
    /**
     * Setter action for single-valued properties
     */
    setter?: Array<ShapeAction>;
    /**
     * Adder action for collection properties
     */
    adder?: Array<ShapeAction>;
    /**
     * Remover action for collection properties
     */
    remover?: Array<ShapeAction>;
    /**
     * Pre-computed getter expression for reading this relation/property.
     * For relations with a target model, this encodes conformance filtering.
     */
    getter?: string;
    /**
     * Structured conformance conditions (DB-agnostic).
     */
    conformance_conditions?: Array<ShapeConformanceCondition>;
    /**
     * Target SHACL node shape URI (sh:class). When present, linked nodes
     * must conform to this shape, enabling typed construction.
     */
    class?: string;
    /**
     * Kind of relation this property describes. One of "hasMany", "hasOne",
     * "belongsToOne", "belongsToMany".  Drives direction (forward/reverse)
     * and scalar-vs-collection rendering.
     */
    relation_kind?: string;
    /**
     * The relation is read `polymorphic: true` unless a query says otherwise
     * (`ad4m://polymorphic`); the executor applies it at every include depth.
     */
    polymorphic?: boolean;
    /**
     * Bare target class name for a relation property — used by the executor
     * to look up the target shape through its in-memory cache.
     */
    target_class_name?: string;
    /**
     * Post-getter where-clause filter for relation properties.  Keys are
     * property names on the target class; values follow the where-clause DSL.
     */
    where_filter?: JsonValue;
    /**
     * Predicate IRI lookup for `where_filter` keys (property name → predicate).
     */
    where_predicates?: {
        [key in string]: string;
    };
    /**
     * Whether conformance/type filtering is enabled for this relation.
     * Omitted (defaulting to true) when not explicitly disabled.
     */
    filter?: boolean;
    /**
     * Fixed value constraint (sh:hasValue).  When combined with min_count >= 1
     * the property is interpreted as a `@Flag` — its presence + value mark
     * the instance as belonging to the class.
     */
    has_value?: string;
    /**
     * Transform expression (SHACL-AF Node Expression).
     * Serialized as JSON and stored as a `literal:string:` link.
     */
    transform?: JsonValue;
    /**
     * `sh:in` — allowed values with optional AD4M labels, stored as JSON.
     */
    in?: Array<JsonValue>;
    pattern?: string;
    min_inclusive?: number;
    max_inclusive?: number;
    /**
     * The name this property answers to when the class is read through an
     * abstract class (#1435), keyed by the abstract class's name:
     * `{ "TextContent": "text" }`. Emitted as one [`ALIAS_PREDICATE`] link.
     */
    alias?: {
        [key in string]: string;
    };
};
