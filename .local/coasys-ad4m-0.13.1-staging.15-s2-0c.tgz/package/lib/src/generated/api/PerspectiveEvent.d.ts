import type { PerspectiveHandle } from "./PerspectiveHandle";
/**
 * `perspective-added` / `perspective-updated`: one event to all of the perspective's owners.
 */
export type PerspectiveEvent = {
    perspectiveUuid: string;
    perspective: PerspectiveHandle;
};
