export type DisposeQueryRequest = {
    subscriptionId: string;
};
