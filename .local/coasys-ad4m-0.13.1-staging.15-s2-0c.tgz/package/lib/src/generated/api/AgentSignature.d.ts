export type AgentSignature = {
    publicKey: string;
    signature: string;
};
