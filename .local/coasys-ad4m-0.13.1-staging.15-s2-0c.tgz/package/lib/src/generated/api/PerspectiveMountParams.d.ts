export type PerspectiveMountParams = {
    uuid: string;
    languageAddress: string;
};
