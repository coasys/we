import type { DecoratedPerspective } from "./DecoratedPerspective";
export type Neighbourhood = {
    linkLanguage: string;
    meta: DecoratedPerspective;
};
