import type { CascadeStep } from "./CascadeStep";
import type { ValidationError } from "./ValidationError";
import type { WriteStep } from "./WriteStep";
/**
 * A refused or failed instance write. Serialized (camelCase, tagged by `kind`) as the data of
 * the RPC error; MCP writes its own text from it.
 */
export type InstanceError = {
    "kind": "unknownClass";
    className: string;
    registered: Array<string>;
} | {
    "kind": "ambiguousClass";
    className: string;
    candidates: Array<string>;
} | {
    "kind": "abstractClass";
    className: string;
} | {
    "kind": "invalidUri";
    field: string;
    value: string;
} | {
    "kind": "emptyProperties";
} | {
    "kind": "batchNotFound";
    batchId: string;
} | {
    "kind": "callsInBatch";
    className: string;
    batchId: string;
} | {
    "kind": "validation";
    className: string;
    errors: Array<ValidationError>;
} | {
    "kind": "notFound";
    className: string;
    baseUri: string;
} | {
    "kind": "alreadyExists";
    className: string;
    baseUri: string;
} | {
    "kind": "storedAsExpressions";
    className: string;
    collection: string;
    itemUri: string;
    language: string;
    members: Array<string>;
} | {
    "kind": "failed";
    className: string;
    step: WriteStep;
    error: string;
} | {
    "kind": "partiallyRemoved";
    className: string;
    baseUri: string;
    removed: number;
    step: CascadeStep;
    error: string;
};
