export type SfuNeighbourhoodParams = {
    neighbourhoodUrl: string;
};
