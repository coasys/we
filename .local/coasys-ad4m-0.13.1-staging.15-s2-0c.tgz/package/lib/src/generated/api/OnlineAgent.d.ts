import type { PerspectiveExpression } from "./PerspectiveExpression";
export type OnlineAgent = {
    did: string;
    /**
     * Empty when the agent has not set a status: the link language reports
     * such an agent with a `null` status.
     */
    status: PerspectiveExpression;
};
