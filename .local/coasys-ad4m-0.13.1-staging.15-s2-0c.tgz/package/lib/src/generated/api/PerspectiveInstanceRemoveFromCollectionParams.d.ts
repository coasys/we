export type PerspectiveInstanceRemoveFromCollectionParams = {
    uuid: string;
    className: string;
    baseUri: string;
    collection: string;
    /**
     * The item as a read of the instance lists it.
     */
    itemUri: string;
    /**
     * An open batch to stage the write into; see `InstanceCreate`'s `batchId`.
     */
    batchId?: string;
};
