/**
 * Runs the class's destructor; through an abstract class (#1435), that of
 * each of the record's classes it reads.
 */
export type RemoveSubjectRequest = {
    subjectClass: string;
    expressionAddress: string;
    batchId?: string;
};
