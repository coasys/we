export type AISessionSendParams = {
    /**
     * The session to send on.
     */
    sessionId: string;
    /**
     * What the person says.
     */
    text: string;
};
