export type SfuRoomParams = {
    neighbourhoodUrl: string;
    roomName: string;
};
