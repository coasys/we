export type PerspectiveUpdateSubjectParams = {
    uuid: string;
    subjectClass: string;
    expressionAddress: string;
    /**
     * A JSON object: property name → value.
     */
    values: string;
    batchId?: string;
};
