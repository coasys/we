/**
 * How a session ended.
 */
export type AgentReply = {
    /**
     * What the model said last: its answer to the person.
     */
    text: string;
};
