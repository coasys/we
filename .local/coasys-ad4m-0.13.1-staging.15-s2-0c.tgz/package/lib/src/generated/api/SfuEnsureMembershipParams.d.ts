export type SfuEnsureMembershipParams = {
    neighbourhoodUrl: string;
    did: string;
};
