import type { InteractionCall } from "./InteractionCall";
export type ExpressionInteractRequest = {
    url: string;
    interactionCall: InteractionCall;
};
