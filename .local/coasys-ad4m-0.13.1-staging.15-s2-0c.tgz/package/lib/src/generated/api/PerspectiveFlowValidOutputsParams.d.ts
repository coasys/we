export type PerspectiveFlowValidOutputsParams = {
    uuid: string;
    flow: string;
    /**
     * Terminal-state name to filter by.
     */
    state?: string;
};
