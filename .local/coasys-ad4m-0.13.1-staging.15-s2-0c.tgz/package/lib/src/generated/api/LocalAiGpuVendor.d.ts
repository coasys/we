export type LocalAiGpuVendor = "nvidia" | "amd" | "intel" | "apple" | "other";
