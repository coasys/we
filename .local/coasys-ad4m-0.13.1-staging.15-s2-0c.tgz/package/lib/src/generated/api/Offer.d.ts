import type { OfferKind } from "./OfferKind";
import type { JsonValue } from "./serde_json/JsonValue";
/**
 * An offer. Absent fields are left out: the signature covers the JCS form.
 */
export type Offer = {
    scid: string;
    offerId: string;
    kind: OfferKind;
    commit: string;
    expires: number;
    deviceKey?: string;
    bot?: JsonValue;
};
