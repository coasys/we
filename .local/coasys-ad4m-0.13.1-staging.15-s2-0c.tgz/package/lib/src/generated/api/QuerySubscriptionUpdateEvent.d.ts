import type { QuerySubscriptionUpdate } from "./QuerySubscriptionUpdate";
import type { QueryUpdatesLagged } from "./QueryUpdatesLagged";
/**
 * `query-subscription-update`: one change to a live query, delivered only
 * to the connection that opened it, or [`QueryUpdatesLagged`].
 */
export type QuerySubscriptionUpdateEvent = QuerySubscriptionUpdate | QueryUpdatesLagged;
