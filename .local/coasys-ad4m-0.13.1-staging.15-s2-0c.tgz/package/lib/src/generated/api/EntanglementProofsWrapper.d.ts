import type { EntanglementProofInput } from "./EntanglementProofInput";
/**
 * Wrapper: SDK sends `{ proofs: [...] }` for entanglement endpoints
 */
export type EntanglementProofsWrapper = {
    proofs: Array<EntanglementProofInput>;
};
