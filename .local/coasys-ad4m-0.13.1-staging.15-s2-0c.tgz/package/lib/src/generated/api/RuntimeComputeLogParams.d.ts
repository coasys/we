export type RuntimeComputeLogParams = {
    /**
     * Defaults to the caller's own email.
     */
    userEmail?: string;
    /**
     * ISO 8601; only entries after this timestamp.
     */
    since?: string;
    /**
     * Defaults to 100.
     */
    limit?: number;
};
