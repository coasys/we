export type GetSubjectDataRequest = {
    subjectClass: string;
    expressionAddress: string;
};
