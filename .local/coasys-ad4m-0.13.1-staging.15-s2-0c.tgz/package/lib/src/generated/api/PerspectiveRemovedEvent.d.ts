/**
 * `perspective-removed`: one event to all of the perspective's owners.
 */
export type PerspectiveRemovedEvent = {
    perspectiveUuid: string;
    uuid: string;
};
