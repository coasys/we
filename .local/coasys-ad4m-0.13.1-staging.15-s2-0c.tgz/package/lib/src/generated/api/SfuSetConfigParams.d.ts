import type { SfuConfig } from "./SfuConfig";
export type SfuSetConfigParams = {
    neighbourhoodUrl: string;
    config: SfuConfig;
};
