import type { ResourceInput } from "./ResourceInput";
export type CapabilityInput = {
    can: Array<string>;
    with: ResourceInput;
};
