export type UsersSetCreditsParams = {
    email: string;
    amount: number;
};
