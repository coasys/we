export type CreateSubjectRequest = {
    subjectClass: string;
    expressionAddress: string;
    initialValues?: string;
    batchId?: string;
};
