/**
 * What the holder sees of a claim; the secret is gone.
 */
export type ClaimView = {
    deviceKey: string;
    encKey: string;
    canKeepMaster: boolean;
    hint: string | null;
    coSig: string;
    claimedAt: number;
};
