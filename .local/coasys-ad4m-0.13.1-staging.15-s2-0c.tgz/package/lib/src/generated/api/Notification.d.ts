/**
 * A notification as RPC results and events show it: whether a webhook credential is
 * set, never the credential.
 */
export type Notification = {
    id: string;
    granted: boolean;
    description: string;
    appName: string;
    appUrl: string;
    appIconPath: string;
    trigger: string;
    perspectiveIds: Array<string>;
    webhookUrl: string;
    hasWebhookAuth: boolean;
    /**
     * The owner's DID: a managed user's, or the main agent's.
     */
    ownerDid: string;
};
