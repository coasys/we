import type { Offer } from "./Offer";
import type { SignedBy } from "./SignedBy";
/**
 * An offer signed by the identity's current master key (`coasys:offer`).
 */
export type SignedOffer = {
    offer: Offer;
    by: SignedBy;
    sig: string;
};
