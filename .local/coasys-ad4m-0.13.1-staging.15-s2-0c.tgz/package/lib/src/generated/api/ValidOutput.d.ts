import type { OutputRef } from "./OutputRef";
/**
 * One instance a verified receipt speaks for. What the "valid outputs of
 * flow F" query returns, and what the `producedByFlow` model-query filter
 * admits.
 */
export type ValidOutput = {
    /**
     * The instance, as `(className, id)` — the pair the quorum committed to.
     */
    output: OutputRef;
    /**
     * The instance's content **as the quorum committed to it**: the
     * `model_query` hydration at completion. A consumer that pays out on
     * the instance as it stands now compares this against a fresh read —
     * [`flow_valid_outputs`] already has.
     */
    content: string;
    /**
     * The terminal state the granting run settled into, re-derived by the
     * verifier (never read off the receipt on trust).
     */
    terminalState: string;
    /**
     * The content-derived URI of the receipt that proves it, for callers
     * that want to fetch or re-verify the artifact itself.
     */
    receiptUri: string;
};
