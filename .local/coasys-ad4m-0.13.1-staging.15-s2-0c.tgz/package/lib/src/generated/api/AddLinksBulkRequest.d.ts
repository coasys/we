import type { LinkInput } from "./LinkInput";
export type AddLinksBulkRequest = {
    links: Array<LinkInput>;
    status?: string;
    batchId?: string;
};
