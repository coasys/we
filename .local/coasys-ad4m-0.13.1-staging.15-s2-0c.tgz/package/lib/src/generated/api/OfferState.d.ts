import type { ClaimView } from "./ClaimView";
/**
 * An offer's state.
 */
export type OfferState = {
    "state": "open";
} | {
    "state": "claimed";
    claim: ClaimView;
} | {
    "state": "spent";
    seq: number;
} | {
    "state": "expired";
} | {
    "state": "cancelled";
} | {
    "state": "contested";
} | {
    "state": "superseded";
};
