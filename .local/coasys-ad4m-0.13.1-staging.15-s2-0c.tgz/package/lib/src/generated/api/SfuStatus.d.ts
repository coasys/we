/**
 * `sfu.status`: whether this executor can relay media to remote
 * participants.
 */
export type SfuStatus = {
    reachability: "public" | "nat" | "unknown";
    /**
     * True when the SFU accepts inbound connections from the internet.
     */
    isPublic: boolean;
    /**
     * The SFU server's bound UDP address (`ip:port`).
     */
    bindAddress: string;
    /**
     * The public address (`ip:port`) offered next to the bind address
     * behind NAT, when there is one.
     */
    advertisedAddress?: string;
    /**
     * Human-readable reachability detail.
     */
    detail: string;
};
