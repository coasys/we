import type { LinkInput } from "./LinkInput";
export type PerspectiveInput = {
    links: Array<LinkInput>;
};
