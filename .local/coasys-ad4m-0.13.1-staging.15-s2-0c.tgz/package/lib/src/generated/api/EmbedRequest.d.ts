export type EmbedRequest = {
    modelId: string;
    text: string;
};
