export type LanguageAddressParams = {
    address: string;
};
