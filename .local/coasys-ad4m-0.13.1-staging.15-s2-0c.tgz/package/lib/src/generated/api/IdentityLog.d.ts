import type { ForkRecord } from "./ForkRecord";
import type { SignedHead } from "./SignedHead";
import type { JsonValue } from "./serde_json/JsonValue";
/**
 * `identity.log`: a log as the cache holds it. Every event passed `fold` here.
 */
export type IdentityLog = {
    did: string;
    /**
     * The events from `from` on, in seq order, as JSON.
     */
    events: Array<JsonValue>;
    /**
     * The last head of the log the cache accepted from the agent language.
     */
    head: SignedHead | null;
    fork: ForkRecord | null;
};
