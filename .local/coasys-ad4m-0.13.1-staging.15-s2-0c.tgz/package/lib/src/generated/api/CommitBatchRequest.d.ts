export type CommitBatchRequest = {
    batchId: string;
};
