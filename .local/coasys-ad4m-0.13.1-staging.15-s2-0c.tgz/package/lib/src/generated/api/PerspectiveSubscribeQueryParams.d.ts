/**
 * `perspective.subscribeQuery`: the subscription id is the client's, so it can end the
 * subscription without the reply (after a timeout or an abort).
 */
export type PerspectiveSubscribeQueryParams = {
    uuid: string;
    query: string;
    subscriptionId: string;
};
