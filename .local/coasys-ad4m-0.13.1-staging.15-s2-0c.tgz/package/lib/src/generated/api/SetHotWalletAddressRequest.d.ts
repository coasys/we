export type SetHotWalletAddressRequest = {
    address: string;
};
