import type { AuthInfoInput } from "./AuthInfoInput";
export type RequestCapabilityRequest = {
    authInfo: AuthInfoInput;
    agent?: string;
};
