export type RequestPaymentRequest = {
    amountHOT: string;
};
