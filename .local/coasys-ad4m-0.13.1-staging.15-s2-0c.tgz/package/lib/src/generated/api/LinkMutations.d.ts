import type { LinkExpressionInput } from "./LinkExpressionInput";
import type { LinkInput } from "./LinkInput";
export type LinkMutations = {
    additions: Array<LinkInput>;
    removals: Array<LinkExpressionInput>;
};
