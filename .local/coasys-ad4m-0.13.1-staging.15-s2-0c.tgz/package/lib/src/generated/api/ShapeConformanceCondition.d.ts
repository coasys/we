/**
 * A single structured conformance condition for relation filtering.
 * DB-agnostic representation that can be translated to any query language.
 */
export type ShapeConformanceCondition = {
    /**
     * Type of check: "flag" (predicate + value) or "required" (predicate exists)
     */
    type: string;
    /**
     * The predicate URI to check on the target node
     */
    predicate: string;
    /**
     * For "flag" conditions: the expected value
     */
    value?: string;
};
