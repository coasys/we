export type SetUnytMembraneProofRequest = {
    /**
     * Base64-encoded membrane proof from the hosting joining service.
     */
    proof: string;
};
