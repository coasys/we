/**
 * `identity.joinStatus`: the offer's state for this executor's key. On `spent` the log lists
 * the key and the agent speaks for `did`.
 */
export type JoinStatus = {
    state: string;
    did: string | null;
    keyId: string | null;
    seq: number | null;
};
