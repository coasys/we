import type { DecoratedPerspective } from "./DecoratedPerspective";
export type Agent = {
    did: string;
    directMessageLanguage: string | null;
    perspective: DecoratedPerspective | null;
};
