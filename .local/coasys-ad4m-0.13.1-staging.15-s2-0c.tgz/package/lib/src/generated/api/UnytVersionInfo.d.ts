/**
 * The Unyt alliance DNA: installed and bundled versions, and why the last
 * install failed. `setUnytMembraneProof` installs in the background, so this
 * is where its outcome shows.
 */
export type UnytVersionInfo = {
    /**
     * Version of the installed DNA; `null` until an install succeeds.
     */
    installed: string | null;
    /**
     * Version of the DNA bundled with this executor.
     */
    bundled: string;
    /**
     * Error of the last install that failed; `null` after a success or a new proof.
     */
    installError: string | null;
};
