import type { ShapeJson } from "./ShapeJson";
/**
 * A registered class: its name, its shape, and the SHA-256 (hex) of the
 * shape's canonical JSON.
 */
export type ShapeSummary = {
    name: string;
    shape: ShapeJson;
    hash: string;
};
