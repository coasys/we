export type RuntimeFriendStatusParams = {
    did: string;
};
