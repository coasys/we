export type DiscardBatchRequest = {
    batchId: string;
};
