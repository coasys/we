export type AiIdParams = {
    id: string;
};
