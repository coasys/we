import type { LocalAiModelStatus } from "./LocalAiModelStatus";
import type { LocalAiRuntimeStatus } from "./LocalAiRuntimeStatus";
/**
 * `ai.localStatus`: what is set up here and how the runtimes run.
 */
export type LocalAiStatus = {
    /**
     * An install finished for this executor.
     */
    installed: boolean;
    installing: boolean;
    storageDir: string;
    /**
     * The installed runtimes start with the executor (`local_ai_autostart`, on unless set
     * off). Nothing is ever installed at start or on a request: only `ai.localInstall`.
     */
    autostart: boolean;
    runtimes: Array<LocalAiRuntimeStatus>;
    models: Array<LocalAiModelStatus>;
};
