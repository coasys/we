/**
 * DID document metadata: seqs as decimal strings (DID Core makes them strings). Empty on an
 * error.
 */
export type DidDocumentMetadata = {
    /**
     * The seq whose state the document shows.
     */
    versionId?: string;
    /**
     * The seq after it, when the log holds one.
     */
    nextVersionId?: string;
    /**
     * The log has ended (whatever the version).
     */
    deactivated?: boolean;
};
