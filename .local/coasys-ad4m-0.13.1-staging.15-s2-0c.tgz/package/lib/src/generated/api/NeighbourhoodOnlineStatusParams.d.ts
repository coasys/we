import type { NeighbourhoodPerspectivePayload } from "./NeighbourhoodPerspectivePayload";
export type NeighbourhoodOnlineStatusParams = {
    uuid: string;
    status: NeighbourhoodPerspectivePayload;
    signed?: boolean;
};
