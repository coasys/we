/**
 * What `ai.localRemove` asks for.
 */
export type LocalAiRemoveParams = {
    /**
     * Also delete the runtimes and models from the per-user store. Other agents of this
     * user share it. Left out: no, only this executor's setup goes.
     */
    deleteFiles?: boolean | null;
};
