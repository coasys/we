import type { AuthInfo } from "./AuthInfo";
export type Apps = {
    auth: AuthInfo;
    requestId: string;
    revoked: boolean | null;
    /**
     * Always empty: the executor does not keep app tokens, and an app receives its token
     * once, from `agent.generateJwt`. The field stays for clients that require it.
     */
    token: string;
};
