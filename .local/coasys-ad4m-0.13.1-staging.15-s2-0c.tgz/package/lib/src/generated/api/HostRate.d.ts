/**
 * Price in HOT the host charges for one metered operation.
 */
export type HostRate = {
    description: string;
    priceInHOT: number;
};
