/**
 * What a remove's link cascade was doing when the store failed.
 */
export type CascadeStep = {
    "step": "list";
    uri: string;
} | {
    "step": "remove";
    source: string;
    predicate: string | null;
    target: string;
};
