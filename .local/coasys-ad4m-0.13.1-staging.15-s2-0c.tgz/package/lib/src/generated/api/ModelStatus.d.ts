import type { ModelState } from "./ModelState";
/**
 * Where an upstream model stands.
 */
export type ModelStatus = {
    state: ModelState;
    /**
     * 0..100, only while `PULLING`.
     */
    progress?: number | null;
    detail?: string | null;
};
