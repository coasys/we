import type { KeyClass } from "./KeyClass";
import type { Pinned } from "./Pinned";
/**
 * One key `runtime.config` lists.
 */
export type ConfigKeyInfo = {
    key: string;
    class: KeyClass;
    pinned?: Pinned;
};
