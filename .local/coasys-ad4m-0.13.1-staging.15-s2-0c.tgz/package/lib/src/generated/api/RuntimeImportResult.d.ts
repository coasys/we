import type { ImportResult } from "./ImportResult";
import type { RuntimeImportPerspectiveResult } from "./RuntimeImportPerspectiveResult";
/**
 * `type: "db"` yields import stats; `type: "perspective"` echoes the file's snapshot.
 */
export type RuntimeImportResult = ImportResult | RuntimeImportPerspectiveResult;
