/**
 * The part of the caller's app info that login-code requests read.
 */
export type UsersAppInfo = {
    appName?: string;
};
