import type { LinkExpressionInput } from "./LinkExpressionInput";
export type PerspectiveRemoveLinkParams = {
    uuid: string;
    link: LinkExpressionInput;
    batchId?: string;
};
