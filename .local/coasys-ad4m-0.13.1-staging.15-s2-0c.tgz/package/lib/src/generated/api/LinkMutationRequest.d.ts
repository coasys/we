import type { LinkInput } from "./LinkInput";
import type { LinkUpdateInput } from "./LinkUpdateInput";
/**
 * Unified link mutation request (harmonised endpoint).
 */
export type LinkMutationRequest = {
    additions?: Array<LinkInput>;
    removals?: Array<LinkInput>;
    updates?: Array<LinkUpdateInput>;
    status?: string;
    batchId?: string;
};
