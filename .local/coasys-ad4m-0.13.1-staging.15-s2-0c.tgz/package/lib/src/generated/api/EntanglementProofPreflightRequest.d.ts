export type EntanglementProofPreflightRequest = {
    deviceKey: string;
    deviceKeyType: string;
};
