export type UsersLoginParams = {
    email: string;
    password: string;
    /**
     * Defaults to `ad4m`.
     */
    appName?: string;
};
