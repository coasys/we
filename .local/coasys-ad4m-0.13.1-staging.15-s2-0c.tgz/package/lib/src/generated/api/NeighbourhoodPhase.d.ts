/**
 * Coarse-grained pass phase for the observability stream. Distinct from
 * `AutoProcessorStep` — that has 10 fine-grained steps for the pass owner;
 * this has just the two transitions a neighbour cares about.
 */
export type NeighbourhoodPhase = "claimed" | "finished" | "abandoned";
