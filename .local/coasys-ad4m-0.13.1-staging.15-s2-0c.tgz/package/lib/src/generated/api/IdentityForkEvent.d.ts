/**
 * `identity-fork`: the cache found two different valid events at one seq of a log. It kept its
 * history and appended nothing. A store that answers a shorter log raises none.
 */
export type IdentityForkEvent = {
    did: string;
    seq: number;
    ours: string;
    theirs: string;
};
