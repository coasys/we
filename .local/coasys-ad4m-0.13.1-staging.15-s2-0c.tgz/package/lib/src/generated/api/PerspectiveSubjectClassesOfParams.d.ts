export type PerspectiveSubjectClassesOfParams = {
    uuid: string;
    uris?: Array<string>;
};
