import type { LinkInput } from "./LinkInput";
export type PerspectiveAddLinkParams = {
    uuid: string;
    link: LinkInput;
    status?: string;
    batchId?: string;
};
