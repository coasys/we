export type SetFreeHostingEnabledRequest = {
    enabled: boolean;
};
