/**
 * The items a create put into one collection.
 */
export type CollectionItems = {
    collection: string;
    items: Array<string>;
};
