/**
 * Reply to `perspective.resyncSubscription`: the subscription's current
 * revision and the result it describes.
 */
export type PerspectiveResynced = {
    revision: number;
    result: any;
};
