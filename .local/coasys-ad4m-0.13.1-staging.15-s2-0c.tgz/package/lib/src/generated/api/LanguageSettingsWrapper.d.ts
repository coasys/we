/**
 * Wrapper: SDK sends `{ settings: ... }` for language settings
 */
export type LanguageSettingsWrapper = {
    settings: any;
};
