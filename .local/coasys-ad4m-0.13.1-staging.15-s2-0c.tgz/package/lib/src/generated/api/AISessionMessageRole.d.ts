/**
 * Who wrote an `ai_messages` row.
 */
export type AISessionMessageRole = "user" | "assistant" | "tool";
