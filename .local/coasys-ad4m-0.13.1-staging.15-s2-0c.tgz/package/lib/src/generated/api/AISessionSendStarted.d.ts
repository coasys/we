/**
 * `ai.sessionSend`'s answer: the ids of the person's message and of the `running` assistant
 * row the detached task writes.
 */
export type AISessionSendStarted = {
    messageId: string;
    replyId: string;
};
