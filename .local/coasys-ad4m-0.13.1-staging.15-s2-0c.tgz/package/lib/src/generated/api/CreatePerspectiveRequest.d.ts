export type CreatePerspectiveRequest = {
    name: string;
};
