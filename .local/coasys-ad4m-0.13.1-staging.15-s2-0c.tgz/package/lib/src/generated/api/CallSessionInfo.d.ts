/**
 * Result of a `call_join` — SDP answer + optional cascade redirect +
 * stream mapping for the joining peer.
 */
export type CallSessionInfo = {
    roomName: string;
    neighbourhoodUrl: string;
    participantId: string;
    sdpAnswer: string;
    /**
     * When set, the join was not served here: the caller should join this
     * DID's SFU node instead (cascade load redirect). Only a `callJoin` with
     * `acceptRedirect` gets one.
     */
    redirectTo?: string;
    /**
     * Roster of existing participants at join time, format:
     * `"participantId:did"`.
     * For track-to-DID attribution, use the `track_mapping` field on
     * each renegotiation offer — the SDP mids are assigned there.
     */
    streamMapping: Array<string>;
};
