export type ExpressionUrlRequest = {
    url: string;
};
