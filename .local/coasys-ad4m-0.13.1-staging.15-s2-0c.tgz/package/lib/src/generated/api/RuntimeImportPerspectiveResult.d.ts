export type RuntimeImportPerspectiveResult = {
    success: boolean;
    snapshot: any;
};
