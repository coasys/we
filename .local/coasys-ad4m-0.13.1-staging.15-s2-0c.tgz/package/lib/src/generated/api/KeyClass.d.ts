/**
 * Who may write a key.
 */
export type KeyClass = "restart" | "machine";
