import type { RefusalReason } from "./RefusalReason";
export type ConfigRefusal = {
    key: string;
    reason: RefusalReason;
    detail?: string;
};
