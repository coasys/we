/**
 * `perspective.flowStates`: the calling agent's recorded state of each flow
 * instance (#1424). Instances it has not derived yet are absent.
 */
export type PerspectiveFlowStatesParams = {
    uuid: string;
    /**
     * Narrow to these instance URIs; all of the agent's instances if absent.
     */
    instances?: Array<string>;
};
