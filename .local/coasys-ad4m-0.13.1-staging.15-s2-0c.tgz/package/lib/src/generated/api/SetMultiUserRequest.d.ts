export type SetMultiUserRequest = {
    enabled: boolean;
};
