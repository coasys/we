import type { AITaskInput } from "./AITaskInput";
export type AiAddTaskParams = {
    task: AITaskInput;
};
