export type LockAgentRequest = {
    passphrase: string;
};
