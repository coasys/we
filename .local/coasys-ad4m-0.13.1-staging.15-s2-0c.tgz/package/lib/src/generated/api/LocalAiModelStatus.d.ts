import type { LocalAiService } from "./LocalAiService";
export type LocalAiModelStatus = {
    service: LocalAiService;
    modelId: string;
    /**
     * The executor's model row (`ai.models`), once registered.
     */
    model: string | null;
};
