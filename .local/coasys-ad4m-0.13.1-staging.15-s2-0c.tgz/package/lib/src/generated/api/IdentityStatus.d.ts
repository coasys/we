import type { ForkRecord } from "./ForkRecord";
import type { SignedHead } from "./SignedHead";
import type { StoreBehind } from "./StoreBehind";
import type { StoreInfo } from "./StoreInfo";
/**
 * `identity.status`: what this agent's device key speaks for.
 */
export type IdentityStatus = {
    /**
     * The `did:scid` this agent speaks for, or `null` (a device-only identity).
     */
    did: string | null;
    /**
     * The agent's device key, a multikey (`z6Mk…`): its `did:key` without the prefix.
     */
    deviceKey: string;
    /**
     * The X25519 key `did_key` derives from the device key (`z6LS…`), the `enc` an `incept`
     * or `add` lists for it.
     */
    deviceEnc: string;
    /**
     * The device key's id in the log (`d1`), once the log lists it.
     */
    keyId: string | null;
    /**
     * The seq of the event that revoked the device key, if one did.
     */
    revoked: number | null;
    /**
     * The last head of the log the cache accepted.
     */
    head: SignedHead | null;
    /**
     * The first fork the cache recorded for the log.
     */
    fork: ForkRecord | null;
    /**
     * Set while the configured store answers the log behind the cache (a store restored from
     * a backup, or not caught up): the cached log answers meanwhile. `null` once it catches up.
     */
    storeBehind: StoreBehind | null;
    /**
     * The identity store this executor uses (the config's, else its network seed's), and
     * whether it trusts a key for it; `null` when it has none (a network without a store).
     */
    store: StoreInfo | null;
};
