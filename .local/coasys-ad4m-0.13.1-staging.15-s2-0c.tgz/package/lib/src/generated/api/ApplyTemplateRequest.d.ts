export type ApplyTemplateRequest = {
    sourceLanguageHash: string;
    templateData: string;
};
