/**
 * `identity.resetLog` params.
 */
export type ResetLogParams = {
    /**
     * The `did:scid:coasys:1:…` whose cached log, accepted head and forks this executor drops.
     */
    did: string;
};
