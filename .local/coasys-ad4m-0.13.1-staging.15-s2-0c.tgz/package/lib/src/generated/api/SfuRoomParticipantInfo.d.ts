/**
 * One participant of an [`SfuRoomInfo`]. The SDK names it
 * `SfuRoomParticipantInfo`: its `SfuParticipantInfo` carries a live
 * `MediaStream`.
 */
export type SfuRoomParticipantInfo = {
    /**
     * The session: an agent in the call from two devices is two participants.
     */
    participantId: string;
    agentDid: string;
    hasAudio: boolean;
    hasVideo: boolean;
    isActiveSpeaker: boolean;
};
