export type AgentByDidParams = {
    did: string;
};
