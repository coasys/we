export type AgentRemoveAppParams = {
    id: string;
};
