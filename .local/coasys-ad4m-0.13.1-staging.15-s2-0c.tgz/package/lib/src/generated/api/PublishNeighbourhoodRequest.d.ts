import type { Perspective } from "./Perspective";
export type PublishNeighbourhoodRequest = {
    perspectiveUuid: string;
    linkLanguage: string;
    meta: Perspective;
};
