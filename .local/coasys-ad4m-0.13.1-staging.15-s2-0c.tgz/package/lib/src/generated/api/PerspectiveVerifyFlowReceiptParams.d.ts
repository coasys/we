import type { JsonValue } from "./serde_json/JsonValue";
export type PerspectiveVerifyFlowReceiptParams = {
    uuid: string;
    /**
     * A `FlowReceipt` as `perspective.mintFlowReceipt` returned it. The
     * receipt tree carries no TS types, so the wire keeps it opaque.
     */
    receipt: JsonValue;
};
