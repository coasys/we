/**
 * A model on an Ollama endpoint, by the id Ollama knows it by.
 */
export type AiUpstreamModelParams = {
    endpointId: string;
    remoteModel: string;
};
