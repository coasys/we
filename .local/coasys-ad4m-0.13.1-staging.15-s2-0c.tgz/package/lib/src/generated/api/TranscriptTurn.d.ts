/**
 * One conversation turn fed to the extractor.
 */
export type TranscriptTurn = {
    speaker: string;
    text: string;
};
