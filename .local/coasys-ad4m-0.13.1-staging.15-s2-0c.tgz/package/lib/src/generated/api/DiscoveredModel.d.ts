import type { AiCapability } from "./AiCapability";
/**
 * One model an endpoint lists.
 */
export type DiscoveredModel = {
    id: string;
    /**
     * What the endpoint says the model does, or a guess from its id where it says nothing.
     */
    capabilities: Array<AiCapability>;
    contextLength?: number | null;
};
