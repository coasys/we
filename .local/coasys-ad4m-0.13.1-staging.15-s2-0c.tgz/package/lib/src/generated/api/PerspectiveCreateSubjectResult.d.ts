/**
 * The URL a `call` constructor minted for the new instance (`Url`);
 * `true` when the class's constructor wrote links (`Created`). A mounted
 * class's constructor calls into its language, which names the record it
 * made (design §3.3).
 */
export type PerspectiveCreateSubjectResult = boolean | string;
