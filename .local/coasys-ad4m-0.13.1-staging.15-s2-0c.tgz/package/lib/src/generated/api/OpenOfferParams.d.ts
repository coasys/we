import type { SignedOffer } from "./SignedOffer";
/**
 * `identity.openOffer` params.
 */
export type OpenOfferParams = {
    signedOffer: SignedOffer;
};
