/**
 * `runtime.logTail` params.
 */
export type LogTailParams = {
    /**
     * How many of the newest lines; at most 2000 are returned.
     */
    lines: number;
};
