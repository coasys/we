/**
 * `coasys:bot`: what a bot key may do, until when.
 */
export type DidBotScope = {
    can: Array<string>;
    expires: number;
};
