import type { DecoratedLinkExpression } from "./DecoratedLinkExpression";
export type DecoratedPerspective = {
    links: Array<DecoratedLinkExpression>;
};
