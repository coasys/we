export type SignMessageRequest = {
    message: string;
};
