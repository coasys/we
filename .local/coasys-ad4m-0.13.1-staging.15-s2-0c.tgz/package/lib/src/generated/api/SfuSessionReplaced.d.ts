/**
 * A later join from the same device (another tab) replaced one of this
 * agent's call sessions: the executor has dropped it. Delivered to the
 * agent (`targetDid`); the session whose participant id it names stops and
 * does not rejoin.
 */
export type SfuSessionReplaced = {
    targetDid: string;
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * The replaced session.
     */
    participantId: string;
};
