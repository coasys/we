import type { IceServer } from "./IceServer";
/**
 * A neighbourhood's call configuration. Only `mode` and
 * `maxMeshParticipants` are stored in the neighbourhood (see
 * `sfu::config_store`); `sfu.getConfig` fills the node fields from the
 * executor, and `sfu.setConfig` refuses them and `iceServers`.
 */
export type SfuConfig = {
    /**
     * `"mesh"` | `"designated"` | `"gateway"` | `"cascaded"`
     */
    mode: "mesh" | "designated" | "gateway" | "cascaded";
    /**
     * Not stored, and `sfu.setConfig` refuses it: a client always joins
     * its own executor's SFU.
     */
    designatedPeer?: string;
    /**
     * Fallback mode when SFU is unavailable.
     */
    fallback: "mesh" | "designated" | "gateway" | "cascaded";
    /**
     * Maximum participants before mesh is degraded.
     */
    maxMeshParticipants: number;
    /**
     * This node's cascade peers (`--sfu-cascade-peers`), as
     * `sfu.getConfig` reports them. Not stored in the neighbourhood.
     */
    sfuPeers?: Array<string>;
    /**
     * This node's capacity in a cascade (`--sfu-max-participants-per-node`),
     * as `sfu.getConfig` reports it. Not stored in the neighbourhood.
     */
    maxParticipantsPerNode?: number;
    /**
     * The cascade node that takes redirected joins first
     * (`--sfu-preferred-node`); overflow spills to other nodes only when
     * it reaches capacity. Useful when a powerful hosted multi-user node
     * serves most participants and lighter personal executors act as
     * fallbacks. As `sfu.getConfig` reports it; not stored in the
     * neighbourhood.
     */
    preferredSfuDid?: string;
    /**
     * ICE servers (STUN + TURN) for the SFU path, when an app passes this
     * config to `createSession`. Never stored in the neighbourhood, where
     * every member would sync every credential: `sfu.setConfig` refuses
     * it and `sfu.getConfig` leaves it empty.
     */
    iceServers?: Array<IceServer>;
};
