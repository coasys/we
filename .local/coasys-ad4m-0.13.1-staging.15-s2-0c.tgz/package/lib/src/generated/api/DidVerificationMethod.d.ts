import type { DidBotScope } from "./DidBotScope";
/**
 * A verification method of a [`DidDocument`].
 */
export type DidVerificationMethod = {
    /**
     * `#d1` in a document; `<did>#d1` when dereferenced alone.
     */
    id: string;
    type: string;
    controller: string;
    publicKeyMultibase: string;
    /**
     * A bot key's scope at the document's seq.
     */
    "coasys:bot"?: DidBotScope;
};
