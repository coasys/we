import type { SignedRequest } from "./SignedRequest";
/**
 * `identity.offers` params: a list request signed by the current master key.
 */
export type OffersParams = {
    request: SignedRequest;
    /**
     * Seconds to wait for a change (0–8).
     */
    wait?: number;
};
