/**
 * `identity.log` params.
 */
export type LogParams = {
    /**
     * A `did:scid:coasys:1:…`.
     */
    did: string;
    /**
     * The first seq to return (default 0).
     */
    from?: number;
    /**
     * Refresh from the agent language before answering.
     */
    fresh?: boolean;
};
