/**
 * Grant/revoke a notification (partial update for grant status only)
 */
export type NotificationGrantRequest = {
    granted: boolean;
};
