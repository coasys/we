import type { Agent } from "./Agent";
/**
 * `agent-updated`: `{ agent }`.
 */
export type AgentUpdatedEvent = {
    agent: Agent;
};
