import type { JsonValue } from "./serde_json/JsonValue";
export type AgentStatus = {
    did: string | null;
    didDocument: JsonValue | null;
    error: string | null;
    isInitialized: boolean;
    isUnlocked: boolean;
    /**
     * The `did:scid` the agent's device key speaks for, or `null`. `did` stays the device
     * `did:key`, so links and profiles keep the author they had.
     */
    identity: string | null;
};
