/**
 * Set properties of an instance; the others stay as they are. A collection with
 * a declared setter takes the full member list it should have — `[]` clears
 * it; any other collection is refused (`collectionNotSettable`).
 */
export type InstanceUpdate = {
    className: string;
    baseUri: string;
    /**
     * Values by property name, at least one: one JSON value per single-valued
     * property, an array of member URIs per collection that declares a setter.
     */
    properties: Record<string, unknown>;
    /**
     * An open batch to stage the write into; see `InstanceCreate`'s `batchId`.
     * A write whose lifecycle actions include `call`s cannot batch (the calls
     * cannot be rolled back): with `batchId` it is refused (`callsInBatch`)
     * before anything is called or written.
     */
    batchId?: string;
};
