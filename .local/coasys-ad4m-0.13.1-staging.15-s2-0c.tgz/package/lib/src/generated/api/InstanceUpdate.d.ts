/**
 * Set single-valued properties of an instance; the others stay as they are.
 */
export type InstanceUpdate = {
    className: string;
    baseUri: string;
    /**
     * Values by property name, at least one; single-valued properties only.
     */
    properties: Record<string, unknown>;
    /**
     * An open batch to stage the write into; see `InstanceCreate`'s `batchId`.
     */
    batchId?: string;
};
