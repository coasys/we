export type PerspectiveQueryParams = {
    uuid: string;
    query: string;
};
