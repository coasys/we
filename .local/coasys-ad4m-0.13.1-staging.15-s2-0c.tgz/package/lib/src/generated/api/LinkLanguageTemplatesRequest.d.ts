export type LinkLanguageTemplatesRequest = {
    addresses: Array<string>;
};
