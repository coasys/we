import type { TrackMapEntry } from "./TrackMapEntry";
/**
 * Server-pushed SDP offer delivered to one specific participant when
 * the SFU needs them to renegotiate — typically because a new peer
 * joined the same room and the relay now has additional outbound
 * tracks to forward.  The client applies this as a remote offer,
 * generates an answer, and posts the answer via
 * `sfu.callAnswerServerOffer`.
 */
export type SfuCallRenegotiationOffer = {
    /**
     * DID of the participant this offer is addressed to.  Used by the
     * events_ws fanout to filter per-user.
     */
    targetDid: string;
    /**
     * The session the offer is for. Every session of `target_did` gets
     * it; only this one applies it.
     */
    participantId: string;
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * JSON-encoded `RTCSessionDescriptionInit` for the new offer.
     */
    sdpOffer: string;
    /**
     * Mid-to-DID attribution for newly added outbound m-lines in this
     * offer.  The client uses these to correlate incoming tracks to
     * participant DIDs (arrival order alone cannot guarantee this —
     * HashMap iteration order on the server makes both stream_mapping
     * and m-line ordering non-deterministic).
     */
    trackMapping?: Array<TrackMapEntry>;
};
