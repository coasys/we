export type LocalAiPhase = "starting" | "running" | "restarting" | "stopped" | "failed";
