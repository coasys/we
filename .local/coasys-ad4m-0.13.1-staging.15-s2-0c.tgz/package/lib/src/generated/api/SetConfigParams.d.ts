/**
 * `runtime.setConfig` params: keys to write, keys to remove (each then takes its default).
 */
export type SetConfigParams = {
    set?: Record<string, unknown>;
    unset?: Array<string>;
};
