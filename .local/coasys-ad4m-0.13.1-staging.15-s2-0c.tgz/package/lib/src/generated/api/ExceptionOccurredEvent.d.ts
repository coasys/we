import type { ExceptionInfo } from "./ExceptionInfo";
/**
 * `exception-occurred`: `{ exception }`.
 */
export type ExceptionOccurredEvent = {
    exception: ExceptionInfo;
};
