import type { ModelType } from "./ModelType";
export type AiSetDefaultModelParams = {
    id: string;
    modelType: ModelType;
};
