/**
 * AD4M Action - represents a link operation (e.g., addLink, removeLink, setSingleTarget)
 */
export type ShapeAction = {
    action: string;
    source: string;
    predicate: string;
    target: string;
    local?: boolean;
};
