import type { PropertyShapeJson } from "./PropertyShapeJson";
import type { ShapeAction } from "./ShapeAction";
/**
 * A class's shape: the JSON `perspective.registerShapes` takes and
 * `perspective.shapes` answers (`SHACLShape.toJSON()` in the SDK).
 */
export type ShapeJson = {
    /**
     * The shape's own URI (`SHACLShape.nodeShapeUri` in the SDK). Defaults
     * to `{namespace}{ClassName}Shape`.
     */
    node_shape_uri?: string;
    target_class: string;
    properties: Array<PropertyShapeJson>;
    /**
     * Natural-language hint describing what this class represents, used to steer
     * LLM interpretation (generic "English hint → model instance" mechanism).
     * Emitted as an `ad4m://interpretation_hint` link.
     */
    interpretation_hint?: string;
    /**
     * Constructor actions for creating instances
     */
    constructor_actions?: Array<ShapeAction>;
    /**
     * Destructor actions for removing instances
     */
    destructor_actions?: Array<ShapeAction>;
    /**
     * Parent shape URIs (model inheritance). Emitted as one `sh://node`
     * link per parent on the shape node.
     */
    parent_shapes?: Array<string>;
    /**
     * An abstract class (#1435): queried as the union of every concrete
     * class that has its property names, never created, never chosen when a
     * record is classified. Emitted as one [`ABSTRACT_PREDICATE`] link on
     * the shape node. See `model_query::abstract_classes`.
     */
    abstract?: boolean;
};
