export type PerspectiveInstanceRemoveParams = {
    uuid: string;
    className: string;
    baseUri: string;
    /**
     * An open batch to stage the write into; see `InstanceCreate`'s `batchId`.
     */
    batchId?: string;
};
