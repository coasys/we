/**
 * What an endpoint is, for discovery and health. The chat wire protocol is
 * [`EndpointKind::protocol`]: llama-server, vLLM, speaches and OpenAI speak the same one
 * and differ only in how they list models.
 */
export type EndpointKind = "OLLAMA" | "LLAMA_SERVER" | "VLLM" | "OPEN_AI" | "ANTHROPIC" | "OPEN_AI_AUDIO" | "OPEN_AI_COMPATIBLE";
