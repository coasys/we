export type LanguageMeta = {
    address: string;
    author: string;
    description: string | null;
    name: string;
    possibleTemplateParams: Array<string> | null;
    sourceCodeLink: string | null;
    templateAppliedParams: string | null;
    templateSourceLanguageAddress: string | null;
    templated: boolean | null;
};
