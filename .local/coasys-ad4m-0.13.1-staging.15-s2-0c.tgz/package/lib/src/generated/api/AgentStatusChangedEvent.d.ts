import type { AgentStatus } from "./AgentStatus";
/**
 * `agent-status-changed`: `{ agent }`.
 */
export type AgentStatusChangedEvent = {
    agent: AgentStatus;
};
