/**
 * `names` restricts the reply to those classes, each named by its name
 * (every class of that name) or its target class IRI; unknown ones are left
 * out.
 */
export type PerspectiveShapesParams = {
    uuid: string;
    names?: Array<string>;
};
