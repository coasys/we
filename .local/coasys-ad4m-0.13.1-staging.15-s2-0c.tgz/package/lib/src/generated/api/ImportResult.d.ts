import type { ImportStats } from "./ImportStats";
export type ImportResult = {
    perspectives: ImportStats;
    links: ImportStats;
    expressions: ImportStats;
    perspectiveDiffs: ImportStats;
    notifications: ImportStats;
    aiEndpoints: ImportStats;
    models: ImportStats;
    defaultModels: ImportStats;
    tasks: ImportStats;
    friends: ImportStats;
    trustedAgents: ImportStats;
    knownLinkLanguages: ImportStats;
    users: ImportStats;
};
