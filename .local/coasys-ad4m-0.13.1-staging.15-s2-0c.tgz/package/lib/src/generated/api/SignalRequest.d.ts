export type SignalRequest = {
    remoteAgentDid: string;
    payload: any;
    signed?: boolean;
};
