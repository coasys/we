/**
 * Data channel message relayed through the SFU, published on the
 * `sfu-data` event to the room's members.
 */
export type SfuDataMessage = {
    /**
     * DID of the participant who sent the data.
     */
    senderDid: string;
    /**
     * The session that sent it. A message reaches the sender's agent when
     * it is in the call on another device too; the sending session itself
     * drops it by this id.
     */
    senderParticipantId: string;
    neighbourhoodUrl: string;
    roomName: string;
    /**
     * Label of the data channel.
     */
    channelLabel: string;
    /**
     * True when the payload is binary (base64-encoded in `data`).
     */
    binary: boolean;
    /**
     * The payload — UTF-8 text or base64-encoded binary.
     */
    data: string;
};
