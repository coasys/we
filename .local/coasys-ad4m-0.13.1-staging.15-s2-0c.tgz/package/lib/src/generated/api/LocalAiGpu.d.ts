import type { LocalAiGpuType } from "./LocalAiGpuType";
import type { LocalAiGpuVendor } from "./LocalAiGpuVendor";
export type LocalAiGpu = {
    vendor: LocalAiGpuVendor;
    type: LocalAiGpuType;
    name: string;
    /**
     * Dedicated memory (an integrated GPU's carve-out).
     */
    vramBytes: number | null;
    /**
     * System memory the GPU may map besides (amdgpu's GTT), or Vulkan's device-local heap
     * of an integrated GPU.
     */
    sharedBytes: number | null;
    driver: string | null;
    /**
     * The highest CUDA version the NVIDIA driver supports, e.g. `13.0`.
     */
    cudaVersion: string | null;
    /**
     * `nvml`, `vulkan`, `sysfs` or `sysctl`.
     */
    source: string;
};
