export type CreateExpressionRequest = {
    content: string;
    languageAddress: string;
};
