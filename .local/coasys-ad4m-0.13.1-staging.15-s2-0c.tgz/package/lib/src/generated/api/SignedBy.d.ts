/**
 * The log position of the key that signed.
 */
export type SignedBy = {
    keyId: string;
    kelSeq: number;
    kelHash: string;
};
