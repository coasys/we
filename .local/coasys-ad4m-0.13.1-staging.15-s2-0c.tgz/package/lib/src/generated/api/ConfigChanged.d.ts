/**
 * `config-changed`: keys written to the config file. No values: the operator reads them with
 * `runtime.config`.
 */
export type ConfigChanged = {
    keys: Array<string>;
    restartPending: boolean;
};
