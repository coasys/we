/**
 * The socket dropped updates, maybe for any of its live queries: every
 * live query on it must resync.
 */
export type QueryUpdatesLagged = {
    lagged: true;
};
