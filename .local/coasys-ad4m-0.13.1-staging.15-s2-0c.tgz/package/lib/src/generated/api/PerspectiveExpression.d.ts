import type { DecoratedExpressionProof } from "./DecoratedExpressionProof";
import type { DecoratedPerspective } from "./DecoratedPerspective";
export type PerspectiveExpression = {
    author: string;
    data: DecoratedPerspective;
    proof: DecoratedExpressionProof;
    timestamp: string;
};
