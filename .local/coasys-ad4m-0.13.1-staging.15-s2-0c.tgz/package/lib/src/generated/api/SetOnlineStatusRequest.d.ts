export type SetOnlineStatusRequest = {
    status: any;
    signed?: boolean;
};
