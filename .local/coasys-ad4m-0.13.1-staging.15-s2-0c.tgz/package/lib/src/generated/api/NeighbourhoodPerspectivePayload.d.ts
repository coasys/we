import type { NeighbourhoodSignedPerspective } from "./NeighbourhoodSignedPerspective";
import type { PerspectiveUnsignedInput } from "./PerspectiveUnsignedInput";
/**
 * A perspective to sign and send: signed links when `signed` is true or
 * absent, bare links when `signed` is false.
 */
export type NeighbourhoodPerspectivePayload = NeighbourhoodSignedPerspective | PerspectiveUnsignedInput;
