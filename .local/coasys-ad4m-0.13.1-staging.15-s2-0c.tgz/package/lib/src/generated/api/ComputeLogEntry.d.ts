export type ComputeLogEntry = {
    id: number;
    userEmail: string;
    timestamp: string;
    operation: string;
    summary: string | null;
    cost: number;
    creditsAfter: number;
};
