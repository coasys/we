import type { AiCapability } from "./AiCapability";
import type { EndpointKind } from "./EndpointKind";
/**
 * A server found on a loopback port by `ai.detectEndpoints`. Nothing is saved.
 */
export type DetectedEndpoint = {
    kind: EndpointKind;
    baseUrl: string;
    capabilities: Array<AiCapability>;
    servedModels: Array<string>;
};
