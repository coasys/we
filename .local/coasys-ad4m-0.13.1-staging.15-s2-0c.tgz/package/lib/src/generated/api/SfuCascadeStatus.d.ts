import type { SfuCascadePipe } from "./SfuCascadePipe";
/**
 * `sfu.cascadeStatus`: the SFU↔SFU pipes that are fully established.
 */
export type SfuCascadeStatus = {
    establishedCount: number;
    pipes: Array<SfuCascadePipe>;
};
