import type { ShapeJson } from "./ShapeJson";
/**
 * The shapes to register, each as the class of its target class.
 */
export type PerspectiveRegisterShapesParams = {
    uuid: string;
    shapes: Array<ShapeJson>;
};
