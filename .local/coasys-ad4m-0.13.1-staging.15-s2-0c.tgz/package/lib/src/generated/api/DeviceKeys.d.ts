/**
 * An executor's device keys from its one wallet key: the `did:key` it signs with, and the
 * X25519 multikey (`z6LS…`) a sender seals to. `identity.rekey` answers the new ones;
 * `identity.custodyStatus` the current ones.
 */
export type DeviceKeys = {
    sign: string;
    enc: string;
};
