export type PerspectiveQueryLinksParams = {
    uuid: string;
    source?: string;
    predicate?: string;
    target?: string;
    /**
     * RFC 3339 timestamp; an unparsable value is ignored.
     */
    fromDate?: string;
    /**
     * RFC 3339 timestamp; an unparsable value is ignored.
     */
    untilDate?: string;
    limit?: number;
};
