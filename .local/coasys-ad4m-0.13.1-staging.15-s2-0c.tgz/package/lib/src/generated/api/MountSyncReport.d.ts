/**
 * What a mount sync reports back: how many links the expansion added to
 * and removed from the perspective's store (one link per changed property
 * value — a title edit is `{added: 1, removed: 1}`).
 */
export type MountSyncReport = {
    added: number;
    removed: number;
};
