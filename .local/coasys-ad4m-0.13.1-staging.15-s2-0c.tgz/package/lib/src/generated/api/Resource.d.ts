export type Resource = {
    domain: string;
    pointers: Array<string>;
};
