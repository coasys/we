import type { UsersAppInfo } from "./UsersAppInfo";
export type UsersRequestVerificationParams = {
    email: string;
    appInfo?: UsersAppInfo;
};
