import type { DecoratedLinkExpression } from "./DecoratedLinkExpression";
/**
 * Links a mutation or batch commit added and removed. `updates` stays empty.
 */
export type PerspectiveLinkDiff = {
    additions: Array<DecoratedLinkExpression>;
    removals: Array<DecoratedLinkExpression>;
    updates: Array<DecoratedLinkExpression>;
};
