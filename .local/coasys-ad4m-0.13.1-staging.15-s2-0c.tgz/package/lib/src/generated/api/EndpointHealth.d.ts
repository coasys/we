import type { EndpointState } from "./EndpointState";
/**
 * The last health check of an endpoint.
 */
export type EndpointHealth = {
    state: EndpointState;
    /**
     * Unix milliseconds.
     */
    checkedAt?: number;
    /**
     * The upstream's reason, with the endpoint's key scrubbed out.
     */
    detail?: string | null;
    /**
     * The model ids the last check listed.
     */
    servedModels: Array<string>;
};
