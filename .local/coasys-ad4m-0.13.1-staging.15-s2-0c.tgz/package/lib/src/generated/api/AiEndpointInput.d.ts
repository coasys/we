import type { AiCapability } from "./AiCapability";
import type { EndpointKind } from "./EndpointKind";
/**
 * An endpoint to add, or the new settings of one (`ai.addEndpoint`, `ai.updateEndpoint`).
 */
export type AiEndpointInput = {
    name: string;
    kind: EndpointKind;
    baseUrl: string;
    /**
     * The provider key. Left out on add: no key. Left out on update: the stored key stays,
     * and the update is refused if `baseUrl` changes too, because a key goes only to the
     * endpoint it was set for. Empty: no key. Never serialised back out.
     */
    apiKey?: string;
    /**
     * Left out: probed from the models the endpoint lists.
     */
    capabilities?: Array<AiCapability>;
    maxNumCtx?: number;
    /**
     * How long one `/v1` request to the endpoint may take, queueing included. Left out:
     * the route's default.
     */
    requestTimeoutSecs?: number;
    /**
     * At most this many requests to the endpoint at once, at least 1. Left out: no limit.
     */
    maxConcurrent?: number;
};
