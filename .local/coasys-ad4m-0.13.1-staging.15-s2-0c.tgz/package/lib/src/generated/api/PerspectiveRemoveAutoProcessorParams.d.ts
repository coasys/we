export type PerspectiveRemoveAutoProcessorParams = {
    uuid: string;
    processorId: string;
};
