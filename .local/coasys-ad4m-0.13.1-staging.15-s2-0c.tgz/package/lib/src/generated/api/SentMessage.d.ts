import type { PerspectiveExpression } from "./PerspectiveExpression";
export type SentMessage = {
    message: PerspectiveExpression;
    recipient: string;
};
