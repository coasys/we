/**
 * `property` scopes the resolution to one predicate; omit it for the whole base.
 */
export type PerspectiveResolveInterpretationParams = {
    uuid: string;
    base: string;
    property?: string;
};
