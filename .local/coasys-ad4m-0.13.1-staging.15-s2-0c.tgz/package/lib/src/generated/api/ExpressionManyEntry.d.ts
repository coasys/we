import type { ExpressionLookupError } from "./ExpressionLookupError";
import type { ExpressionRendered } from "./ExpressionRendered";
/**
 * One `expression.getMany` entry (`null` when `expression.get` returns `null`).
 */
export type ExpressionManyEntry = ExpressionLookupError | ExpressionRendered;
