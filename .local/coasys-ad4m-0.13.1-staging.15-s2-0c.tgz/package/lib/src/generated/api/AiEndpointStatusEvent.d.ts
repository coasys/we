import type { AiCapability } from "./AiCapability";
import type { EndpointHealth } from "./EndpointHealth";
/**
 * The `ai-endpoint-status` event: an endpoint's health or capabilities changed.
 */
export type AiEndpointStatusEvent = {
    endpointId: string;
    health: EndpointHealth;
    capabilities: Array<AiCapability>;
};
