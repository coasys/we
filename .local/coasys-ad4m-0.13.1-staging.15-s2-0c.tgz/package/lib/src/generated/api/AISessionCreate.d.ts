import type { Capability } from "./Capability";
/**
 * What `ai.sessionCreate` takes.
 */
export type AISessionCreate = {
    title: string | null;
    model: string | null;
    /**
     * The perspective the conversation is about, as a hint for the model. Not a limit.
     */
    defaultPerspective: string | null;
    /**
     * The perspective holding the agent's WE template library.
     */
    libraryPerspective: string | null;
    /**
     * What the session's tools may do. Absent: everything the caller holds.
     */
    capabilities: Array<Capability> | null;
};
