import type { TranscriptTurn } from "./TranscriptTurn";
/**
 * Run generic LLM interpretation over a transcript into the perspective's own
 * SHACL subject classes. Shapes are resolved server-side from the
 * perspective's registered classes, so callers pass only the transcript.
 */
export type RunInterpretationRequest = {
    uuid: string;
    transcript: Array<TranscriptTurn>;
    /**
     * URI namespace new instance identities are minted under, e.g. `soa://ext/`.
     */
    basePrefix: string;
    /**
     * Local names of the subject classes to extract into (e.g. `["Task","Belief"]`).
     * `None`/empty selects all subject classes registered in the perspective.
     */
    classes?: Array<string>;
    /**
     * Optional parent-scope filter for the dedup lookup: when set, only
     * existing instances of the target classes that live under this scope
     * are candidates for upsert. `None` = whole-perspective dedup set (the
     * pre-scope default). Same semantics as `AutoProcessorConfig.existingScope`.
     */
    existingScope?: any;
    /**
     * Optional parent-scope target for newly minted instances: when set,
     * every base URI the pass CREATES is additionally linked as a child of
     * `mintScope.id` via the scope's predicate. Upserts of pre-existing
     * instances are NOT linked (would multi-parent unrelated graph state).
     * Must be the `Raw` variant of `Scope` (id + predicate). Same semantics
     * as `AutoProcessorConfig.mintScope`.
     */
    mintScope?: any;
    /**
     * Opt into live observability for this one-shot pass, under an id the
     * **caller** chooses.
     *
     * A watch pass is identified by its `batch_key` — a hash of the source
     * items the watcher gathered. A one-shot pass has neither: the caller
     * supplies the transcript directly, so there are no source item ids to
     * hash and no claim to key off. Rather than invent a server-side id the
     * caller would then have to correlate by guesswork (the pass is one
     * blocking RPC, so there is no earlier response to carry it), the caller
     * names the pass and gets its own id back on every event.
     *
     * Present: the pass emits `RunningInterpretation` → `Processed` on the
     * `auto-processor-event` topic, plus `Claimed` → `Finished`/`Abandoned`
     * on the neighbourhood topic, all carrying this value as both
     * `processor_id` and `batch_key`. Absent: the pass is silent, exactly as
     * before — no existing caller changes behaviour.
     */
    observationId?: string;
    /**
     * Emit `LlmRequestSent` / `LlmResponseReceived` (carrying the raw prompt
     * and response) for this pass. Ignored without `observation_id` — there
     * would be nothing to correlate the payloads to. Same switch, same
     * reasons, as `AutoProcessorConfig.emit_debug_events`.
     */
    emitDebugEvents?: boolean;
};
