import type { LinkMutations } from "./LinkMutations";
export type PerspectiveLinkMutationsParams = {
    uuid: string;
    mutations: LinkMutations;
    status?: string;
};
