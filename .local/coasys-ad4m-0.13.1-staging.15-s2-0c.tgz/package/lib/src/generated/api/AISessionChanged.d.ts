import type { AISession } from "./AISession";
import type { AISessionMessage } from "./AISessionMessage";
/**
 * The `ai-session-changed` event: pushed to the session's owner on a new message, a
 * status change and each tool step.
 */
export type AISessionChanged = {
    sessionId: string;
    /**
     * `created`, `updated`, `deleted` or `message`.
     */
    kind: string;
    /**
     * The session row, for `created` and `updated`.
     */
    session: AISession | null;
    /**
     * The message row, for `message`.
     */
    message: AISessionMessage | null;
};
