export type PerspectiveReceiptOutcome = "verified" | "rejected" | "undecidable";
