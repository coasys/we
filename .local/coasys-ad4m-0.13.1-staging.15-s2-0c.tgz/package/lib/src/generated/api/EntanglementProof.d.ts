export type EntanglementProof = {
    deviceKey: string;
    deviceKeySignedByDid: string;
    deviceKeyType: string;
    did: string;
    didSignedByDeviceKey: string | null;
    didSigningKeyId: string;
};
