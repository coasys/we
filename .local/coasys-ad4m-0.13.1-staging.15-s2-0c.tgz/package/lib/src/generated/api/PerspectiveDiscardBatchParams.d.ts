export type PerspectiveDiscardBatchParams = {
    uuid: string;
    batchId: string;
};
