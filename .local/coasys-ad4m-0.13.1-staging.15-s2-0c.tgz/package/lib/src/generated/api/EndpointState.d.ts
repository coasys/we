export type EndpointState = "UNKNOWN" | "REACHABLE" | "UNAUTHORIZED" | "UNREACHABLE";
