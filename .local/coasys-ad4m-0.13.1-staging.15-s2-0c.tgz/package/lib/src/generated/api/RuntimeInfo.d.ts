export type RuntimeInfo = {
    ad4mExecutorVersion: string;
    /**
     * The commit the executor was built from, or nothing when the build could not tell (no git
     * checkout). Every build between two releases reports one version; this names the build.
     */
    ad4mExecutorCommit: string | null;
    isInitialized: boolean;
    isUnlocked: boolean;
};
