import type { PersistentCache } from "./PersistentCache";
/** What a {@link KeyedCache} writes to its persistent store. */
export interface StoredEntry<V> {
    value: V;
    ts: number;
}
export interface KeyedCacheOptions<V> {
    /**
     * Reads many keys in one call: one entry per key, in order, `null` when
     * not found, an `Error` when that key's read failed (it rejects that key's
     * readers only).
     */
    loadMany(keys: string[]): Promise<Array<V | null | Error>>;
    /**
     * Reads one key (`null` when not found; rejects when the read failed).
     * When set, a miss of {@link KeyedCache.get} is read alone with it, so it
     * waits for no other key; only {@link KeyedCache.getMany} uses `loadMany`.
     */
    load?(key: string): Promise<V | null>;
    /** Most keys per `loadMany` call. Default: no limit. */
    maxBatch?: number;
    /** Second tier, read on a memory miss (IndexedDB in browsers). */
    persistent?: PersistentCache<StoredEntry<V>>;
    /** How long a value stays fresh in memory, per key. Default: until evicted. */
    maxAgeMs?(key: string): number;
    /** How long a stored value stays fresh. Default: forever. */
    persistentMaxAgeMs?(): number;
    /** Memory limits; the oldest values go first. Default: none. */
    limits?(): {
        entries: number;
        bytes: number;
    };
}
/**
 * Keyed read cache shared by profile and expression lookups. Concurrent reads
 * of one key share one request; misses of one tick go out in one `loadMany`
 * call, except a `get()` miss when the options have `load`. A `null` (not
 * found) is returned but not kept.
 */
export declare class KeyedCache<V> {
    #private;
    constructor(opts: KeyedCacheOptions<V>);
    get(key: string): Promise<V | null>;
    getMany(keys: string[]): Promise<Array<V | null>>;
    /** Stores a value known to be current; a read in flight for the key is not kept. */
    set(key: string, value: V): void;
    /** Forgets a key in memory and in the persistent store. */
    delete(key: string): void;
    /** Forgets every key in memory, and in the persistent store when `persistent` is set. */
    clear(persistent?: boolean): void;
}
