/**
 * PersistentCache — two-tier persistent key-value cache abstraction.
 *
 * Provides an IndexedDB-backed implementation for browsers and a no-op
 * NullCache fallback for Node.js / environments without IndexedDB.
 *
 * Design goals:
 * - Lazy open: IDB connection is deferred until first access
 * - Fire-and-forget writes: put() resolves immediately (best-effort persistence)
 * - Graceful degradation: all IDB errors resolve (never reject), so callers
 *   never need try/catch around cache operations
 * - Tree-shakeable: import only what you need
 */
export interface PersistentCache<T = unknown> {
    get(key: string): Promise<T | undefined>;
    put(key: string, value: T): Promise<void>;
    delete(key: string): Promise<void>;
    clear(): Promise<void>;
}
export declare class IDBCache<T = unknown> implements PersistentCache<T> {
    #private;
    constructor(dbName: string, storeName: string);
    get(key: string): Promise<T | undefined>;
    put(key: string, value: T): Promise<void>;
    delete(key: string): Promise<void>;
    clear(): Promise<void>;
}
export declare class NullCache<T = unknown> implements PersistentCache<T> {
    get(_key: string): Promise<T | undefined>;
    put(_key: string, _value: T): Promise<void>;
    delete(_key: string): Promise<void>;
    clear(): Promise<void>;
}
/**
 * Create a PersistentCache backed by IndexedDB (browser) or NullCache (Node.js).
 *
 * @param dbName    - IndexedDB database name
 * @param storeName - IndexedDB object store name
 */
export declare function createPersistentCache<T = unknown>(dbName: string, storeName: string): PersistentCache<T>;
