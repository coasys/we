import { ApiClient } from "../apiClient";
import type { ClaimOfferResult } from "../generated/api/ClaimOfferResult";
import type { DeviceKeys } from "../generated/api/DeviceKeys";
import type { DeviceView } from "../generated/api/DeviceView";
import type { DidResolutionResult } from "../generated/api/DidResolutionResult";
import type { IdentityLog } from "../generated/api/IdentityLog";
import type { IdentityStatus } from "../generated/api/IdentityStatus";
import type { JoinStatus } from "../generated/api/JoinStatus";
import type { OfferListing } from "../generated/api/OfferListing";
import type { OfferOpened } from "../generated/api/OfferOpened";
import type { SignedHead } from "../generated/api/SignedHead";
import type { SignedOffer } from "../generated/api/SignedOffer";
import type { SignedRequest } from "../generated/api/SignedRequest";
/**
 * The executor's `did:scid:coasys:1` calls.
 *
 * The executor holds device keys only. Master keys and the 12 words stay with the app
 * (`ad4m-identity-client`), which signs the events and offers these calls pass on.
 * `agent.status()` and `agent.me()` carry `identity`, the `did:scid` the agent speaks for.
 */
export declare class IdentityClient {
    #private;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    /**
     * This agent's identity, device key, `enc` key and the cached head. `storeBehind` is set
     * (`{ since, seq }`) while the configured store answers the log behind the executor's cache,
     * and `null` once it catches up. `store` is the identity store this executor uses
     * (`{ url, trusted }`: its config's, else its network's) and whether it trusts a key for it;
     * `null` when its network has no store, so identities cannot be created or linked there.
     */
    status(): Promise<IdentityStatus>;
    /** A log through the executor's cache; `fresh` refreshes it from the store first. */
    log(did: string, from?: number, fresh?: boolean): Promise<IdentityLog>;
    /**
     * Resolves a `did:scid:coasys:1` DID URL (`?src=`, `?versionId=`, `#d1`) or a bare device
     * `did:key` to a W3C DID Core resolution result. The executor answers from its key-log
     * cache unless `fresh`, or the cache lacks the log or the asked version. A refusal comes
     * back as `didResolutionMetadata.error` (`invalidDid`, `invalidDidUrl`, `notFound`, …), not
     * as a thrown error. With a fragment, `didDocument` is null and `verificationMethod` holds
     * that method. For a `did:key`, `didResolutionMetadata["coasys:keyId"]` and
     * `["coasys:keyValid"]` say which key of the person's log it is and whether it is valid.
     */
    resolve(didUrl: string, options?: {
        fresh?: boolean;
        accept?: string;
    }): Promise<DidResolutionResult>;
    /**
     * Drops this executor's cached copy of `did`'s log (its events, accepted head and recorded
     * forks); the next read refreshes from the configured store and takes the store's branch.
     * The way out of an `identity-fork`. The operator (admin credential) only.
     */
    resetLog(did: string): Promise<boolean>;
    /**
     * Adds this agent's device-key proof to an `incept` that lists its key. For the main
     * agent the admin credential only; a user's session for its own agent.
     */
    cosignIncept(event: unknown): Promise<unknown>;
    /**
     * Appends signed events through the agent language. For the main agent the admin
     * credential only; a user's session for its own agent.
     */
    publish(events: unknown[]): Promise<SignedHead>;
    openOffer(signedOffer: SignedOffer): Promise<OfferOpened>;
    /** The identity's open and claimed offers, for a request signed by its current master key. */
    offers(request: SignedRequest, wait?: number): Promise<OfferListing[]>;
    /** Claims an offer link for this executor (the operator only). */
    claimOffer(offer: string, hint?: string): Promise<ClaimOfferResult>;
    joinStatus(offerId: string): Promise<JoinStatus>;
    /** The identity's device keys, from its log. */
    devices(): Promise<DeviceView[]>;
    /**
     * A new main wallet key for this executor, so a revoked executor can link again. The old
     * key stays for history. Only the operator on the executor's machine (the admin credential
     * on a loopback listener). A caller without the admin credential gets 403 "Admin credential
     * required"; the admin credential on a network listener gets 403 `local-only`.
     */
    rekey(): Promise<DeviceKeys>;
    /**
     * The custody channel: the main agent's device keys (public keys only), the keys a master
     * key sent to this computer is sealed to. Only the admin credential on a loopback listener
     * of an executor started with `--custody-channel`; any other caller gets 403.
     */
    custodyStatus(): Promise<DeviceKeys>;
}
