import { Ad4mModel } from "../model/Ad4mModel";
/**
 * The built-in abstract class `TextContent { text }` (#1446): text a view or
 * an LLM can read — a message, a note, a block of a document. `text` may
 * contain HTML or Markdown.
 *
 * Querying it reads every class that has a `text` property, or a property
 * aliased to `text`:
 *
 * ```typescript
 * @Model({ name: "Message", implements: [TextContent] })
 * class Message extends Ad4mModel {
 *   @Property({ through: "flux://body", alias: { TextContent: "text" } })
 *   body: string = "";
 * }
 *
 * const everything = await TextContent.findAll(perspective, { parent: { id: channel } });
 * ```
 *
 * Built in: the executor declares it (mirrors
 * `rust-executor/src/perspectives/hardwired_sdna/text_content.json`) and
 * reads it by its URI, `ad4m://TextContent`, so a perspective never stores it
 * and an app class named `TextContent` does not replace it. `register()` on
 * it writes nothing.
 *
 * The waker's mention subscription (`get_mention_waker_config`) reads it for
 * the agent's names in the text. Mention links it reads through
 * {@link Mentioning}, with text or without.
 */
export declare class TextContent extends Ad4mModel {
    /** The URI the executor reads it by. */
    static readonly builtinUri = "ad4m://TextContent";
    /** The text. May contain HTML or Markdown. */
    text: string;
}
