/**
 * TypeScript @Model classes mirroring the Rust-side hardwired SDNA for the
 * flow runtime. Apps can import these to query the perspective graph for
 * pending flow-transition proposals without knowing the raw link predicates.
 *
 * Do not register them: the classes are hard-wired in the executor, which
 * registers each before writing its first instance and reads one not
 * registered yet as empty.
 *
 * Querying:
 *   const pending = await FlowTransitionProposal.findAll(perspective);
 *
 * Slice 5/7 of the flow-implementation arc (design doc §4.2). The Rust engine
 * mints these as of #987 — see `flow_classes.rs` (`mint_proposal`, URIs at
 * `ad4m://flow/proposal/{id}`) — and reads them back in
 * `flow_instance/atom.rs`. A UI mints or joins them through
 * `FlowInstance.proposeTransition`. This class is the client-side mirror:
 *   - clients build UI over proposals without knowing the raw link predicates;
 *   - the SDNA-parity test locks TS/Rust drift against
 *     `rust-executor/src/perspectives/hardwired_sdna/flow_transition_proposal.json`.
 */
import { Ad4mModel } from "../model/Ad4mModel";
/**
 * The engine's proposer rule (`self_authored_proposer`: a `proposer` link
 * signed by the DID it names) as a getter. Must match the `proposer` getter in
 * `hardwired_sdna/flow_transition_proposal.json` byte for byte, as
 * `ACCEPTED_BY_GETTER` must.
 */
export declare const PROPOSER_GETTER = "SELECT ?target WHERE { ?source <ad4m://flow/proposer> ?target . FILTER EXISTS { ?_claim <http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies> <<( ?source <ad4m://flow/proposer> ?target )>> ; <ad4m://ontology/author> ?_author ; <ad4m://ontology/proofValid> ?_valid . FILTER(STR(?_author) = STR(?target) && STR(?_valid) = \"true\") } }";
/**
 * The engine's vote rule (`signed_by`: the link's author is the DID it names,
 * and its signature verified) as a getter over the link's reifier. Must match
 * the `acceptedBy` getter in `hardwired_sdna/flow_transition_proposal.json`
 * byte for byte: whichever side registers the class first decides the stored
 * shape.
 */
export declare const ACCEPTED_BY_GETTER = "SELECT ?target WHERE { ?source <ad4m://acceptedBy> ?target . FILTER EXISTS { ?_vote <http://www.w3.org/1999/02/22-rdf-syntax-ns#reifies> <<( ?source <ad4m://acceptedBy> ?target )>> ; <ad4m://ontology/author> ?_author ; <ad4m://ontology/proofValid> ?_valid . FILTER(STR(?_author) = STR(?target) && STR(?_valid) = \"true\") } }";
export declare class FlowTransitionProposal extends Ad4mModel {
    /**
     * URI of the running `FlowInstance` this proposal targets. First-declared
     * property so `buildSHACL` derives the shape namespace from its `through`
     * prefix — `ad4m://flow/instance` → `ad4m://` → target_class
     * `ad4m://FlowTransitionProposal`. Also the identity predicate: the
     * discriminator `findAll` uses to isolate proposal nodes.
     */
    flowInstance: string;
    /** Name of the state the flow instance is currently in. */
    fromState: string;
    /** Name of the state the proposal wants to transition to. */
    toState: string;
    /**
     * DID of the agent that issued the proposal, read the way the engine reads
     * it: only from a `proposer` link signed by the DID it names. Any member
     * can write a `proposer` link naming someone else, and an unchecked read
     * would show that DID instead (and drop the real proposer from the voters).
     */
    proposer: string;
    /**
     * URIs of instances offered as evidence that `toState.requires` is now
     * satisfied. Multiple links, one per cited instance; ordering is not
     * significant.
     */
    evidence: string[];
    /**
     * JSON blob: `{ [uri]: sha256_hex }` — one entry per evidence URI, hashing
     * the canonicalized graph-visible properties (sorted by property URI,
     * multi-values sorted lexicographically) at proposal time. Downstream
     * verifiers use it to detect edits to cited instances after the proposal
     * was written. Stored as an opaque string because SHACL properties carry
     * no rich-object type; the engine parses it back into a map.
     */
    evidenceHashes: string;
    /**
     * The instances the proposer names as the run's outputs. Written only on
     * a proposal into a terminal state; one link per output, ordering not
     * significant. Each entry is the canonical JSON text of a
     * `{ className, id }` pair (`FlowOutputRef`); `JSON.parse` it to read one.
     */
    outputs: string[];
    /**
     * SHA-256 (hex) over the named outputs' content (each instance as
     * `model_query` returns it through its class), signed by the proposer
     * next to the evidence seal. Co-signers load the outputs and recompute it
     * before voting, and a flow receipt's output preimages must hash to it.
     * Empty on a proposal into a non-terminal state.
     */
    outputsHash: string;
    /**
     * The proposer's uniqueness salt for this proposal's content-addressed
     * URI (`ad4m://flow/proposal/<hash>`; the hash covers the instance, the
     * edge, the seal, the outputs commitment, the proposer DID and this
     * nonce). The engine writes a UUID. A proposal without one — or whose URI
     * does not match its own signed fields — is not engine-visible:
     * co-signatures name the URI, so the URI must commit to what they sign
     * (#1108).
     */
    nonce: string;
    /**
     * URI of the `InterpretationRun` node that produced this proposal, when
     * the proposal came from an LLM extraction pass. Absent when a human
     * clicked "propose" in the UI or an external tool wrote the proposal
     * directly.
     */
    runUri?: string;
    /**
     * Free-form human-readable justification. Optional — the LLM includes it
     * when it wants to explain *why* the cited evidence satisfies the state's
     * `requires`; the UI shows it to reviewers.
     */
    rationale?: string;
    /**
     * DIDs that accepted this proposal, as the consensus engine counts them:
     * an `ad4m://acceptedBy` link counts only when it is signed by the DID it
     * names, since anyone can write one naming someone else, and each DID once.
     * The proposer's vote is implicit and the proposer may also accept, so the
     * voters are the *set* `{ proposer } ∪ acceptedBy`, not its sum.
     * Read-only: vote with `acceptProposal`, withdraw with `rejectProposal`.
     */
    acceptedBy: string[];
}
export declare class FlowInstanceRecord extends Ad4mModel {
    /**
     * URI of the `SHACLFlow` this instance runs — the flow's canonical
     * identity, collision-free across social-DNA modules from different
     * communities (bare names WILL collide once shared flows are adopted
     * cross-team — James PR #929 R5). Sourced from `SHACLFlow.flowUri`
     * (which is `${namespace}${name}Flow`, e.g. `coasys://DeliveryFlow`).
     *
     * First-declared property so `buildSHACL` derives the shape namespace
     * from its `through` prefix — `ad4m://flow/flow_uri` → `ad4m://` →
     * target_class `ad4m://FlowInstance`. Also the discriminator predicate
     * `findAll` uses to isolate instance nodes.
     *
     * The human-readable flow name is still available on the paired
     * `SHACLFlow` (via `perspective.getFlow(record.flowUri.split('/').pop()!.replace(/Flow$/,''))`,
     * or more commonly via the `FlowInstance` wrapper's `flowName` getter).
     */
    flowUri: string;
    /**
     * URI of the subject expression this flow runs on.
     * Named `subject` (not `baseExpression`) because `Ad4mModel` reserves
     * `baseExpression` as a synthetic hydration field always set to the
     * instance's own URI — a subclass property with that name is shadowed
     * on read.
     */
    subject: string;
}
