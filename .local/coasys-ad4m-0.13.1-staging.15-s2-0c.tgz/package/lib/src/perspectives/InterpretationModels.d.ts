/**
 * TypeScript @Model classes mirroring the Rust-side SDNA for the generic
 * interpretation subsystem.  Apps can import these to query the perspective
 * graph for interpretation history and pending overlay proposals without
 * knowing the raw link predicates.
 *
 * Do not register them: the classes are hard-wired in the executor, which
 * registers each before writing its first instance and reads one not
 * registered yet as empty. An app registering its copy would compete with
 * the executor's revision.
 *
 * Querying:
 *   const pending = await InterpretationOverlay.findAll(perspective);
 *   const runs    = await InterpretationRun.findAll(perspective);
 *   const configs = await AutoProcessorConfig.findAll(perspective);
 */
import { Ad4mModel } from "../model/Ad4mModel";
export declare class AutoProcessorConfig extends Ad4mModel {
    /** Unique processor id — the dedup key for auto-processor instances. */
    processorId: string;
    /** SPARQL SELECT that gathers source items each pass. */
    sourceScopeQuery: string;
    /** URI prefix for minted instances; omit for the per-processor default. */
    basePrefix?: string;
    /** Class URIs (SHACL targetClass) to materialise each pass. */
    interpretationClasses: string[];
    /** Flow URIs (`{namespace}{name}Flow`) this processor runs flow features on; empty = off. */
    flows: string[];
    /** Quiet-window (ms) after the last new item before a pass runs. */
    debounceMs: string;
    /** Minimum batch size before a pass runs (default 1). */
    batchMin?: string;
    /** Maximum items per pass. */
    batchMax: string;
    /** Safety flush (ms) for a sub-`batchMin` batch; absent = wait indefinitely. */
    maxWaitMs?: string;
    /** How long a won claim is authoritative before peers may re-claim (ms). */
    claimTtlMs: string;
    /** How far back (ms) each pass looks; absent = unbounded. */
    sourceWindowMs?: string;
    /** Serialised `DedupStrategy` JSON (absent = NormalizedString). */
    dedupStrategy?: string;
    /**
     * Serialised `Scope` JSON (absent = whole-perspective dedup set).
     * Constrains the existing-instance lookup to the subtree rooted at
     * `Scope.id` linked via `Scope.predicate` — the SoA-tree "existing items
     * live under THIS project node" pattern. Stored as an opaque JSON blob
     * because SHACL properties carry no rich-object type-check; the Rust
     * watcher parses it back into `Scope`.
     */
    existingScope?: string;
    /**
     * Serialised `Scope` JSON (absent = mint sites are unlinked). When set,
     * every freshly created base URI gets an additional `Scope.id
     * --Scope.predicate--> new-uri` link written into the perspective, so
     * mints become first-class children of the target scope. Must be the
     * `Raw` form of `Scope`; `Model` scopes carry no linking predicate.
     */
    mintScope?: string;
    /**
     * Tool-call budget for the interpretation-pass harness. Absent (or `"0"`)
     * = the original single-shot LLM path — one prompt, one parse, no tools.
     * `"N"` (positive integer) = engage the tool-calling harness and let the
     * LLM issue up to N tool calls per pass (query/list/get/propose_create/
     * propose_link_child) before being forced to answer. Stored as a decimal
     * string because SHACL properties carry no numeric type; the Rust
     * watcher parses it back to `u32`.
     */
    maxToolCalls?: string;
    /**
     * Enable full debug observability: persists the raw LLM prompt + response
     * on the pass's `InterpretationRun` AND emits `LlmRequestSent` /
     * `LlmResponseReceived` mid-pass events. `"true"` / `"false"` string.
     */
    emitDebugEvents?: string;
}
export declare class InterpretationRun extends Ad4mModel {
    /** UUID for this run — the dedup key across run nodes. */
    runId: string;
    /** LLM model id used for this run. */
    model?: string;
    /** SHA-256 hex of the system prompt + few-shots at the time of the run. */
    promptVersion?: string;
    /** RFC3339 timestamp when the run completed. */
    ranAt?: string;
    /** URI of the AutoProcessorConfig node that triggered this run. */
    processor?: string;
    /**
     * Source item IDs consumed by this pass.
     * Stored as multiple links with the same predicate; the processed-turn
     * cursor uses these to avoid re-interpreting a turn. Values are plain
     * strings (turn hex), so the property opts into `sh:datatype`-gated
     * literal decoding on hydration.
     */
    sources: string[];
    /** Raw LLM prompt this pass fed the model. Present only when the pass's
     *  AutoProcessor had `emitDebugEvents: true`. Absent by default. */
    debugPrompt?: string;
    /** Raw LLM response this pass received. Same rules as `debugPrompt`. */
    debugResponse?: string;
}
export declare class InterpretationOverlay extends Ad4mModel {
    /**
     * Whether the LLM authored the whole instance (`"create"`) or proposed
     * changes to an existing one (`"update"`).  This is the discriminator link
     * that makes a node identifiable as an overlay.
     */
    kind: string;
    /** URI of the InterpretationRun that last wrote this overlay, if present. */
    run?: string;
}
