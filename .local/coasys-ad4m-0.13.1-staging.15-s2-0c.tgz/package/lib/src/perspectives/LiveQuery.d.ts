import type { PerspectiveClient } from "./PerspectiveClient";
/** Reply to `perspective.subscribeQuery` / `perspective.modelSubscribe`. */
export interface Subscribed {
    subscriptionId: string;
    result: any;
    revision: number;
}
/**
 * A `query-subscription-update` event: the change from the previous revision.
 * Model results carry `ids` (the new order), `upsert` (new or changed
 * instances) and, when the query set `count: true`, `totalCount`; query results carry `added` / `removed` rows;
 * a result that could not be diffed comes whole as `result`.
 */
export interface QueryUpdate {
    subscriptionId: string;
    revision: number;
    ids?: string[];
    upsert?: any[];
    totalCount?: number;
    added?: any[];
    removed?: any[];
    result?: any;
}
/** The executor dropped updates, maybe for any live query on this socket:
 *  every live query resyncs. */
export interface QueryLagged {
    lagged: true;
}
/** What a live query tells its owner about re-opening its subscription after a
 *  reconnect or a failed resync: `reopening` after each failed attempt, with
 *  the delay before the next one, and `open` once a re-open succeeds after
 *  one failed. Until then the query is not live, even though its last result
 *  is still readable. */
export type LiveQueryStatus = {
    state: 'reopening';
    error: unknown;
    retryInMs: number;
} | {
    state: 'open';
};
/** Delay before the first retry of a failed re-open; it doubles per failure. */
export declare const REOPEN_BASE_DELAY_MS = 1000;
/** Longest delay between two re-open attempts. */
export declare const REOPEN_MAX_DELAY_MS = 60000;
/** The delay before re-open attempt `failures + 1`: between half and all of
 *  `REOPEN_BASE_DELAY_MS * 2^(failures - 1)`, capped at
 *  `REOPEN_MAX_DELAY_MS`. The random half spreads the clients of a restarted
 *  executor apart. */
export declare function reopenDelay(failures: number, random?: () => number): number;
/** Apply one update to the last result. Query rows are a multiset: added rows are appended.
 *  Throws when the update names an instance that neither the last result nor
 *  the update holds: the last result was wrong, and the caller must resync. */
export declare function applyUpdate(result: any, update: QueryUpdate): any;
/**
 * One live query on the executor. Holds the last result, applies each update
 * to it, calls `resyncSubscription` when a revision is missing, and opens a
 * new subscription after a reconnect (the executor ends a socket's
 * subscriptions when it closes). A re-open that fails (the executor is
 * still loading the perspective after a restart) is retried with backoff
 * until it succeeds or the query is disposed; `onStatus` listeners hear
 * about it (#1595). `onResult` gets every result after the first; `start()`
 * returns the first.
 */
export declare class LiveQuery {
    #private;
    /** `open` subscribes on the executor; aborting its signal cancels the call. */
    constructor(client: PerspectiveClient, uuid: string, open: (signal: AbortSignal) => Promise<Subscribed>, onResult: (result: any) => void);
    get id(): string | undefined;
    get result(): any;
    /** Whether a re-open failed and the query is waiting to retry it. */
    get reopening(): boolean;
    /** Call `listener` on each failed re-open and when a re-open succeeds
     *  after one failed. Returns a remover. */
    onStatus(listener: (status: LiveQueryStatus) => void): () => void;
    /** Open the subscription (again) and return its initial result. A start
     *  that a newer one overtakes resolves with the newer one's result. */
    start(): Promise<any>;
    /** End the subscription. With `cancelOpening`, a subscribe call still in
     *  flight is cancelled too, so the executor stops computing a first result
     *  nobody waits for (#1595); the pending `start()` then rejects instead of
     *  resolving with that result. */
    dispose(options?: {
        cancelOpening?: boolean;
    }): void;
}
