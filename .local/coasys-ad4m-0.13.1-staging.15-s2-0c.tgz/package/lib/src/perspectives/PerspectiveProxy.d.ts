import { PerspectiveClient } from "./PerspectiveClient";
import type { EventMap, ScopedEventName } from "../generated/api/Events";
import type { FlowFiredEntry } from "../generated/api/FlowFiredEntry";
import type { FlowFireOutcome, FlowMintedReceipt, FlowOutputRef, FlowProposeResult, FlowReceiptVerdict, FlowStateEntry, FlowValidOutput } from "./FlowInstance";
import { CallOptions } from "../apiClient";
import { Link, LinkExpression, LinkExpressionInput, LinkExpressionMutations, LinkMutations } from "../links/Links";
import { LinkQuery } from "./LinkQuery";
import { PerspectiveHandle, PerspectiveState } from './PerspectiveHandle';
import { Perspective } from "./Perspective";
import { ExpressionRendered } from "../expression/Expression";
import { NeighbourhoodProxy } from "../neighbourhood/NeighbourhoodProxy";
import { NeighbourhoodExpression } from "../neighbourhood/Neighbourhood";
import { AIClient } from "../ai/AIClient";
import { AllInstancesResult } from "../model/types";
import { LiveQueryStatus, Subscribed } from "./LiveQuery";
import type { TranscriptTurn } from "../generated/api";
import type { MountSyncReport } from "../generated/api/MountSyncReport";
import type { AgentMessage } from "../generated/api/AgentMessage";
import type { AgentReply } from "../generated/api/AgentReply";
import type { JsonValue } from "../generated/api/serde_json/JsonValue";
import type { RegisterResult } from "../generated/api/RegisterResult";
import type { CollectionItemAdded, CollectionItemRemoved, InstanceAddToCollection, InstanceCreate, InstanceCreated, InstanceRemove, InstanceRemoveFromCollection, InstanceRemoved, InstanceUpdate, InstanceUpdated } from "../generated/api";
import { SHACLShape } from "../shacl/SHACLShape";
import { SHACLFlow } from "../shacl/SHACLFlow";
import type { AddAutoProcessorConfig, InterpretationOverlayInfo, RawScope, RunInterpretationObserveOptions } from "./AutoProcessor";
type QueryCallback = (result: AllInstancesResult) => void;
/** A class registered in a perspective, as {@link PerspectiveProxy.shapes} reads it. */
export interface RegisteredShape {
    /** The class name: the local name of its target class. */
    name: string;
    shape: SHACLShape;
    /** SHA-256 (hex) of the shape's canonical JSON. */
    hash: string;
}
/** A live SPARQL or model query with its latest result.
 *
 * `subscribe()` opens the query and resolves once the first result is in;
 * `onResult()` callbacks then get every later result. The executor sends
 * only changes; `LiveQuery` applies them, recovers from a missed update and
 * re-opens the query after a reconnect. Call `dispose()` when done.
 *
 * ```typescript
 * const subscription = await perspective.subscribeQuery("SELECT ?s WHERE { ?s ?p ?o }");
 * const remove = subscription.onResult(result => console.log(result));
 * subscription.dispose();
 * ```
 */
export declare class QuerySubscriptionProxy {
    #private;
    /** With `className`, `query` is a model query (JSON) over that class or
     *  union of classes, opened with `modelSubscribe`; results are
     *  `{ instances, totalCount }`. Without it, `query` is SPARQL. */
    constructor(uuid: string, query: string, client: PerspectiveClient, className?: string | string[]);
    /** Open the query; resolves with the first result delivered. */
    subscribe(): Promise<void>;
    /** The executor's id for this subscription. */
    get id(): string;
    /** Resolves once the first result has arrived. */
    get initialized(): Promise<boolean>;
    /** The latest result. */
    get result(): AllInstancesResult;
    /** Call `callback` with every later result. Returns a remover. */
    onResult(callback: QueryCallback): () => void;
    /** Whether the query lost its subscription (a reconnect, a failed
     *  resync), could not open it again yet and is retrying: `result` is then
     *  not live. */
    get reopening(): boolean;
    /** Call `listener` on each failed re-open of the subscription and when a
     *  re-open succeeds after one failed (see {@link LiveQueryStatus}).
     *  Returns a remover. */
    onStatus(listener: (status: LiveQueryStatus) => void): () => void;
    /** End the subscription on the executor and drop all callbacks. With
     *  `cancelOpening`, a `subscribe()` still waiting on the executor is
     *  cancelled too, and rejects. */
    dispose(options?: {
        cancelOpening?: boolean;
    }): void;
}
/** Link status argument. The executor accepts either case and returns links
 *  with the upper-case form (`LinkExpression.status`). */
export type LinkStatus = "shared" | "local" | "SHARED" | "LOCAL";
interface Parameter {
    name: string;
    value: string;
}
/**
 * PerspectiveProxy provides a high-level interface for working with AD4M Perspectives - agent-centric semantic graphs
 * that store and organize links between expressions.
 *
 * A Perspective is fundamentally a collection of links (subject-predicate-object triples) that represent an agent's view
 * of their digital world. Through PerspectiveProxy, you can:
 * - Add, remove, and query links
 * - Work with Social DNA (subject classes and flows)
 * - Subscribe to real-time updates
 * - Share perspectives as Neighbourhoods
 * - Execute Prolog queries for complex graph patterns
 *
 *
 * @example
 * ```typescript
 * // Create and work with links
 * const perspective = await ad4m.perspective.add("My Space");
 * await perspective.add({
 *   source: "did:key:alice",
 *   predicate: "knows",
 *   target: "did:key:bob"
 * });
 *
 * // Query links
 * const friends = await perspective.get({
 *   source: "did:key:alice",
 *   predicate: "knows"
 * });
 *
 * // Use Social DNA
 * await Todo.register(perspective);
 * const todo = await perspective.createSubject("Todo", "expression://123");
 *
 * // Subscribe to changes
 * perspective.on("link-added", ({ link }) => {
 *   console.log("New link added:", link);
 * });
 * ```
 */
export declare class PerspectiveProxy {
    #private;
    /** Unique identifier of this perspective */
    uuid: string;
    /** Human-readable name of this perspective */
    name: string;
    /** If this perspective is shared as a Neighbourhood, this is its URL */
    sharedUrl: string | null;
    /** If this perspective is shared, this contains the Neighbourhood metadata */
    neighbourhood: NeighbourhoodExpression | null;
    /** Current sync state if this perspective is shared */
    state: PerspectiveState | null;
    /** List of owners of this perspective */
    owners?: string[];
    /** @internal Exposed for ModelQueryBuilder subscription management */
    get client(): PerspectiveClient;
    /**
     * Creates a new PerspectiveProxy instance.
     * Note: Don't create this directly, use ad4m.perspective.add() instead.
     */
    constructor(handle: PerspectiveHandle, ad4m: PerspectiveClient);
    /** Update the proxy's internal handle and public fields in-place.
     *  Keeps the same object reference so all holders see the update. */
    updateHandle(handle: PerspectiveHandle): void;
    /**
     * Executes a set of actions on an expression with optional parameters.
     * Used internally by Social DNA flows and subject class operations.
     *
     * Actions are specified as an array of commands that modify links in the perspective.
     * Each action is an object with the following format:
     * ```typescript
     * {
     *   action: "addLink" | "removeLink" | "setSingleTarget" | "collectionSetter",
     *   source: string,    // Usually "this" to reference the current expression
     *   predicate: string, // The predicate URI
     *   target: string     // The target value or "value" for parameters
     * }
     * ```
     *
     * Available commands:
     * - `addLink`: Creates a new link
     * - `removeLink`: Removes an existing link
     * - `setSingleTarget`: Removes all existing links with the same source/predicate and adds a new one
     * - `collectionSetter`: Special command for setting relation properties
     *
     * When used with parameters, the special value "value" in the target field will be
     * replaced with the actual parameter value.
     *
     * @example
     * ```typescript
     * // Add a state link and remove an old one
     * await perspective.executeAction([
     *   {
     *     action: "addLink",
     *     source: "this",
     *     predicate: "todo://state",
     *     target: "todo://doing"
     *   },
     *   {
     *     action: "removeLink",
     *     source: "this",
     *     predicate: "todo://state",
     *     target: "todo://ready"
     *   }
     * ], "expression://123");
     *
     * // Set a property using a parameter
     * await perspective.executeAction([
     *   {
     *     action: "setSingleTarget",
     *     source: "this",
     *     predicate: "todo://title",
     *     target: "value"
     *   }
     * ], "expression://123", [
     *   { name: "title", value: "New Title" }
     * ]);
     * ```
     *
     * @param actions - Array of action objects to execute
     * @param expression - Target expression address (replaces "this" in actions)
     * @param parameters - Optional parameters that replace "value" in actions
     * @param batchId - Optional batch ID to group this operation with others
     */
    executeAction(actions: any, expression: any, parameters: Parameter[], batchId?: string): Promise<boolean>;
    /**
     * Retrieves links from the perspective that match the given query.
     *
     * @param query - Query parameters to filter links
     * @returns Array of matching LinkExpressions
     *
     * @example
     * ```typescript
     * // Get all links where Alice knows someone
     * const links = await perspective.get({
     *   source: "did:key:alice",
     *   predicate: "knows"
     * });
     *
     * // Get all comments on a post
     * const comments = await perspective.get({
     *   source: "post://123",
     *   predicate: "comment"
     * });
     * ```
     */
    get(query: LinkQuery, options?: CallOptions): Promise<LinkExpression[]>;
    /**
     * Runs generic LLM interpretation over a conversation transcript, turning it
     * into typed instances of this perspective's own SHACL subject classes
     * (steered by each class's `@InterpretationHint`). The target shapes are
     * resolved automatically from the perspective's registered classes, so you
     * pass only the transcript. New instances are written as links into this
     * perspective; the returned placements list each instance's base URI and
     * the links written for it.
     *
     * @param transcript ordered `{ speaker, text }` turns
     * @param basePrefix URI namespace for new instance identities, e.g. `soa://ext/`
     * @param classes local names of the subject classes to extract into; omit for all
     * @param options scopes, progress reporting, and `signal` / `timeoutMs`
     *   (default {@link LONG_TIMEOUT_MS})
     */
    runInterpretation(transcript: TranscriptTurn[], basePrefix: string, classes?: string[], options?: CallOptions & {
        existingScope?: RawScope;
        mintScope?: RawScope;
        /** Report progress while the pass runs — see {@link RunInterpretationObserveOptions}. */
        observe?: RunInterpretationObserveOptions;
    }): Promise<string[]>;
    /**
     * Harness-dispatched interpretation pass over this perspective (design v3
     * §6 — the tool-calling counterpart to {@link runInterpretation}). The LLM
     * sees a live per-class tool surface (`{Class}_query`, `{Class}_get`,
     * `{Class}_propose_create`, `{Class}_propose_link_child`, …) and drives
     * the extraction via tool calls; buffered proposals drain through the
     * same overlay gate the single-shot path uses.
     *
     * @param transcript ordered `{ speaker, text }` turns
     * @param basePrefix URI namespace new instance identities are minted under
     * @param maxToolCalls upper bound on tool calls the harness will make in
     *   one pass (must be > 0 — use {@link runInterpretation} for the
     *   classic single-shot path)
     * @param classes local names of the subject classes to extract into; omit for all
     * @param modelOverride optional model override; omit for the default LLM
     * @param options `signal` / `timeoutMs` (default {@link LONG_TIMEOUT_MS})
     */
    runInterpretationWithHarness(transcript: TranscriptTurn[], basePrefix: string, maxToolCalls: number, classes?: string[], modelOverride?: string, observationId?: string, emitDebugEvents?: boolean, options?: CallOptions): Promise<string[]>;
    /**
     * Ask a model something about this perspective, or ask it to change something, with the
     * executor's own tools — including the tools apps install for their records. It reads freely;
     * it writes only with the tools named in `settings.writeTools`, as you. Answers with the
     * model's final reply.
     *
     * @param messages the conversation so far, the person's request last
     * @param settings `context` (what the person is looking at), `writeTools`, `model`, `maxToolCalls`
     * @param options `signal` / `timeoutMs` (default {@link LONG_TIMEOUT_MS})
     */
    runAgent(messages: AgentMessage[], settings?: Parameters<PerspectiveClient['runAgent']>[2], options?: CallOptions): Promise<AgentReply>;
    /**
     * Register a neighbourhood auto-processor on this perspective. The executor
     * then runs interpretation automatically over new source items (like Flux
     * per channel), coordinating which peer processes each batch. Returns the
     * processor id. Subscribe to progress via `on('auto-processor-event')`.
     */
    addAutoProcessor(config: AddAutoProcessorConfig): Promise<string>;
    /**
     * Stop an auto-processor by deleting its config.
     *
     * The registration is data — the watch loop reads the processor set back out of the
     * perspective's graph on every tick — so deleting the config is what stops it, and there is
     * nothing else to unregister. The config is `Shared`, so this stops the processor for the
     * neighbourhood rather than only for this peer.
     *
     * Resolves `true` when there was a processor to remove and `false` when there was not; a
     * processor another peer has already removed is not an error.
     *
     * The processor's `InterpretationRun` nodes stay: they are the record of what it did and the
     * processed-turn cursor, so a processor later registered under the same id resumes where this
     * one left off rather than re-reading every turn.
     */
    removeAutoProcessor(processorId: string): Promise<boolean>;
    /**
     * Pending interpretation overlays on this perspective — LLM suggestions the
     * §4 divergence gate staged rather than applied, awaiting human accept/reject.
     *
     * Concurrent callers share one in-flight RPC. Nothing is kept after it
     * settles, so every call made after that fetches from the executor again.
     * {@link acceptInterpretation} and {@link rejectInterpretation} detach the
     * in-flight RPC, so a read issued after they resolve never joins a read
     * that started before the write.
     * Each caller gets its own copy of the array.
     */
    interpretationOverlays(): Promise<InterpretationOverlayInfo[]>;
    /**
     * Accept an interpretation overlay's suggestion(s): the LLM's staged value
     * becomes the real, human-owned value and the overlay is deleted. Pass
     * `property` to accept a single predicate; omit it for the whole base.
     */
    acceptInterpretation(base: string, property?: string): Promise<boolean>;
    /**
     * Reject an interpretation overlay's suggestion(s). Omit `property` to reject
     * the whole base — a rejected `create` deletes the suggested instance, a
     * rejected `update` drops the overlay and keeps the real value.
     */
    rejectInterpretation(base: string, property?: string): Promise<boolean>;
    /**
     * `outputs` names the instances a run produces, as `{ className, id }`
     * pairs, for a transition into a terminal state. The proposal signs a
     * hash over their content, and a receipt for the run can only speak for
     * exactly these instances, as they stood at completion. Naming outputs
     * for a non-terminal state is refused.
     */
    proposeFlowTransition(instanceUri: string, toState: string, rationale?: string, outputs?: FlowOutputRef[]): Promise<FlowProposeResult>;
    acceptFlowProposal(proposalUri: string): Promise<FlowFireOutcome[]>;
    /** Withdraw our own links from a proposal; resolves to how many went. */
    rejectFlowProposal(proposalUri: string): Promise<number>;
    /**
     * Re-decide a flow receipt under this perspective's own flow catalogue.
     * The verdict is three-way — see {@link FlowReceiptVerdict}: branch on
     * `outcome`, never on a boolean you derive from it.
     */
    verifyFlowReceipt(receipt: JsonValue): Promise<FlowReceiptVerdict>;
    /**
     * Which instances are, as they stand, valid outputs of `flow`?
     *
     * Backed by receipt verification executor-side (see
     * {@link FlowValidOutput}); an instance without a verifying receipt, or
     * edited since its run completed, is not listed. The same predicate is
     * available as a model-query filter:
     * `where: { producedByFlow: { flow, state? } }`.
     *
     * Rejects — never resolves to `[]` — when the flow is not on this
     * perspective, or when it carries more receipt candidates than the
     * executor's per-flow budget (256): "could not read every receipt" is not
     * "no valid outputs". The filter rejects the same way.
     */
    flowValidOutputs(flow: string, state?: string): Promise<FlowValidOutput[]>;
    /**
     * The state each flow instance is in, as **this agent's** executor last
     * derived it — one entry per instance it has derived, optionally narrowed
     * to `instances`. An instance missing from the answer has not been
     * derived here yet; it stands at its flow's first state.
     *
     * The state is not stored on the graph: the engine derives it from the
     * signed proposals and keeps what it derived per agent, outside the
     * perspective. So no other agent — a co-owner on the same executor included —
     * can read or write your entries, and a link query never sees them.
     * `FlowInstance.findAll` / `start` call this for you.
     */
    flowStates(instances?: string[]): Promise<FlowStateEntry[]>;
    /**
     * For each of `instances`, in order, the proposals whose votes settled an
     * edge, as this agent's executor recorded them — the flow's history,
     * sorted by URI (`fired: []` when none). One call covers up to 200
     * instances (the executor refuses more with a 400); split a longer list
     * into batches of 200.
     * Replaces the `resolvedAs` property proposals used to carry.
     */
    flowFired(instances: string[]): Promise<FlowFiredEntry[]>;
    /**
     * Called whenever a flow instance on this perspective changes state on
     * this agent's executor, or an edge settles: `{ instance, from, to,
     * firedProposals, caughtUp }`. Only this agent's sockets receive it.
     *
     * When the executor first derives an instance that already has history
     * (it synced in, or the executor was upgraded) it is called once with
     * `caughtUp: true`, `from: null` and no `firedProposals`: the settles
     * before that are history, but `to` is the state to show for a run that
     * read as not derived (`FlowInstance.currentStateName === undefined`).
     *
     * Returns a function that removes the handler; {@link dispose} removes
     * it too.
     */
    onFlowStateChanged(handler: (event: EventMap["flow-state-changed"]) => void): () => void;
    /** Mint and store the receipt for a completed flow run. */
    mintFlowReceipt(instanceUri: string): Promise<FlowMintedReceipt>;
    /**
     * Executes a Prolog query against the perspective's knowledge base.
     * This is a powerful way to find complex patterns in the graph.
     *
     * @param query - Prolog query string
     * @returns Query results or false if no results
     *
     * @example
     * ```typescript
     * // Find friends of friends
     * const results = await perspective.infer(`
     *   triple(A, "knows", B),
     *   triple(B, "knows", C),
     *   A \= C
     * `);
     *
     * // Find all active todos
     * const todos = await perspective.infer(`
     *   instance(Todo, "Todo"),
     *   property_getter("Todo", Todo, "state", "active")
     * `);
     * ```
     */
    infer(query: string, options?: CallOptions): Promise<any>;
    /**
     * Executes a SPARQL query against the perspective's link cache.
     * This allows powerful SQL-like queries on the link data stored in SPARQL.
     *
     * **Security Note:** Only read-only queries (SELECT, RETURN, etc.) are permitted.
     * Mutating operations (DELETE, UPDATE, INSERT, CREATE, DROP, DEFINE, etc.) are
     * blocked for security reasons. Use the perspective's add/remove methods to modify links.
     *
     * **Cancellation:** Pass `{ signal }` from an `AbortController` to abort
     * an in-flight query.  The executor receives `request.cancel` over the
     * WebSocket and short-circuits the JSON reply.  Caveat: Oxigraph itself
     * cannot be interrupted mid-evaluation, so an already-running scan will
     * keep its blocking thread busy until it completes; what's saved is the
     * serialise + network + client-deserialise tax on the result.  Aborted
     * calls reject with `DOMException('Aborted', 'AbortError')` — match
     * `fetch()` for handling. A call with `options` makes its own RPC.
     *
     * **Sharing:** concurrent identical calls without `options` share one RPC;
     * each caller gets its own result object. Nothing is cached once the
     * call settles: use a live query for repeated reads of the same data.
     *
     * @param query - SPARQL query string (read-only operations only)
     * @param options - Optional call options (e.g. AbortSignal for cancellation)
     * @returns Query results as parsed JSON
     */
    querySparql<T = any>(query: string, options?: CallOptions): Promise<T>;
    /**
     * Execute a model query — the executor-side replacement for SPARQL query building + JS hydration.
     *
     * The executor resolves the model's shape from the perspective's SHACL
     * triples (written by `registerShapes`).  Callers no longer ship shape
     * metadata with the query; the perspective is the source of truth.
     *
     * @param className - The model class name (e.g. "Recipe"), or several: one
     *   query over their union, whose rows carry `__subjectClass` and
     *   `__subjectClasses` (#1238)
     * @param queryJson - Structured query as JSON string
     * @returns Object with `instances` array, and `totalCount` when the query sets `count: true`
     */
    modelQuery(className: string | string[], queryJson: string, options?: CallOptions): Promise<{
        instances: any[];
        totalCount?: number;
    }>;
    /** Resolve each URI to the names of every subject class it is an instance of.
     *
     * The counterpart of {@link isSubjectInstance}, which asks the same question
     * one class at a time. Without this, finding the class of an arbitrary URI
     * meant looping over every registered class — a round trip each — and doing
     * it again for every URI.
     *
     * Class membership in AD4M is structural — a URI belongs to a class when it
     * carries that class's flags and required properties — so membership is **not
     * exclusive**: an instance conforms to its parent classes, and to any
     * unrelated class whose required set happens to be a subset of what it
     * carries. Every match is returned.
     *
     * The list is ordered **most specific first**, meaning by the number of
     * triples the class requires — a subclass requires everything its parent does
     * and more — with ties broken alphabetically so that every peer answers
     * identically. A caller that can only act on one class should take
     * `classes[0]`, but that head is only a heuristic: it is arbitrary between two
     * unrelated classes requiring the same number of triples, which is exactly
     * the case the full list exists to expose.
     *
     * A URI is **absent from the result** when no *registered* class matched it.
     * That covers two situations, and nothing here separates them: the URI may
     * not be a subject instance at all, or it may be an instance of a class this
     * perspective has not registered. Absence is used rather than an empty list
     * because an empty list would claim the stronger thing — that the URI belongs
     * to no class — which this cannot know.
     *
     * @param uris The expression URIs to classify.
     */
    subjectClassesOf(uris: string[]): Promise<Record<string, string[]>>;
    /**
     * Mount a language into this perspective: the executor installs the
     * language's `mountShapes()`, reads `mountSnapshot()`, and keeps the
     * records in step as local links — model queries, SPARQL and
     * subscriptions then see them like any other instances.
     */
    mount(languageAddress: string): Promise<boolean>;
    /** Drop a mount: every record link it expanded, plus the mount link itself. */
    unmount(languageAddress: string): Promise<boolean>;
    /**
     * Re-read the mounted language's snapshot and apply the diff.
     * Returns how many links the sync added and removed.
     */
    syncMount(languageAddress: string): Promise<MountSyncReport>;
    /** The addresses of every language this perspective has mounted. */
    mounts(): Promise<string[]>;
    /**
     * Evaluate property getters for a batch of instances in a single RPC call.
     * Returns a map of `{ instanceId: { prop: value, ... } }`.
     *
     * Use this instead of `Ad4mModel.evaluateGetters()` for lazy-loading
     * getter-backed properties on visible items (e.g. `replyingTo` on messages).
     *
     * @param className - The model class name (e.g. "Message")
     * @param instanceIds - Array of instance base expression URIs
     * @param propertyNames - Optional subset of property names to evaluate
     * @returns Map of instance ID → evaluated property values
     */
    evaluateGetters(className: string, instanceIds: string[], propertyNames?: string[]): Promise<Record<string, Record<string, any>>>;
    /**
     * Open a live model query on the executor. Later changes arrive as
     * updates; `LiveQuery` (or `ModelQueryBuilder.subscribe()`) applies them.
     * The subscription ends with `disposeQuerySubscription()` or when the
     * socket closes.
     *
     * @param className - The model class name, or several (same as modelQuery)
     * @param queryJson - JSON-serialized query parameters (same as modelQuery)
     * @returns `subscriptionId`, initial `result` and `revision` (0)
     */
    modelSubscribe(className: string | string[], queryJson: string): Promise<Subscribed>;
    /**
     * Adds a new link to the perspective.
     *
     * @param link - The link to add
     * @param status - Whether the link should be shared in a Neighbourhood
     * @param batchId - Optional batch ID to group this operation with others
     * @returns The created LinkExpression
     *
     * @example
     * ```typescript
     * // Add a simple relationship
     * await perspective.add({
     *   source: "did:key:alice",
     *   predicate: "follows",
     *   target: "did:key:bob"
     * });
     *
     * // Add a local-only link
     * await perspective.add({
     *   source: "note://123",
     *   predicate: "tag",
     *   target: "private"
     * }, "local");
     * ```
     */
    add(link: Link, status?: LinkStatus, batchId?: string): Promise<LinkExpression>;
    /**
     * Adds multiple links to the perspective in a single operation.
     * More efficient than adding links one by one.
     *
     * @param links - Array of links to add
     * @param status - Whether the links should be shared
     * @param batchId - Optional batch ID to group this operation with others
     * @returns Array of created LinkExpressions
     */
    addLinks(links: Link[], status?: LinkStatus, batchId?: string): Promise<LinkExpression[]>;
    /**
     * Removes multiple links from the perspective.
     *
     * @param links - Array of links to remove
     * @param batchId - Optional batch ID to group this operation with others
     * @returns Array of removed LinkExpressions
     */
    removeLinks(links: LinkExpressionInput[], batchId?: string): Promise<LinkExpression[]>;
    /**
     * Applies a set of link mutations (adds and removes) in a single operation.
     * Useful for atomic updates to the perspective.
     *
     * @param mutations - Object containing links to add and remove
     * @param status - Whether new links should be shared
     * @returns Object containing results of the mutations
     */
    linkMutations(mutations: LinkMutations, status?: LinkStatus): Promise<LinkExpressionMutations>;
    /**
 * Adds a pre-signed LinkExpression to the perspective.
 *
 * The executor checks the signature against `link.author` and stores the
 * verdict as `proof.valid`. If the same link (author, source, predicate,
 * target and timestamp) is already stored with a signature that verifies,
 * its stored proof is kept. The expression passed here is still returned
 * and, when Shared, committed to the neighbourhood as given.
 *
 * @param link - The signed LinkExpression to add
 * @param status - Whether the link should be shared
 * @param batchId - Optional batch ID to group this operation with others
 * @returns The added LinkExpression
 */
    addLinkExpression(link: LinkExpression, status?: LinkStatus, batchId?: string): Promise<LinkExpression>;
    /**
 * Updates an existing link with new data.
 *
 * @param oldLink - The existing link to update
 * @param newLink - The new link data
 * @param batchId - Optional batch ID to group this operation with others
 */
    update(oldLink: LinkExpressionInput, newLink: Link, batchId?: string): Promise<LinkExpression>;
    /**
     * Removes a link from the perspective.
     *
     * Accepts either a full `LinkExpressionInput` (as returned by `add`) or a bare
     * `Link` (source/predicate/target only).  When a bare Link is passed the method
     * resolves it to the first stored `LinkExpression` whose source, predicate, and
     * target match, then removes that expression.  A bare Link without a predicate
     * (or with the constructor's `""` stand-in) matches only stored links that
     * themselves have no predicate.  If no match is found an error is thrown
     * naming the link so the caller knows what was expected.
     *
     * @param link - The link to remove (LinkExpressionInput or bare Link)
     * @param batchId - Optional batch ID to group this operation with others
     */
    remove(link: LinkExpressionInput | Link, batchId?: string): Promise<boolean>;
    /** Creates a new batch for grouping operations */
    createBatch(): Promise<string>;
    /** Commits a batch of operations */
    commitBatch(batchId: string): Promise<LinkExpressionMutations>;
    /**
     * Drops an open batch without committing it — the recovery for a failed batched call:
     * a failed call does not roll back the calls before it and may have staged part of its
     * own work, so discard rather than commit to keep the successful calls. Resolves `true`
     * when the batch was open and is now dropped.
     */
    discardBatch(batchId: string): Promise<boolean>;
    /**
     * Retrieves and renders an Expression referenced in this perspective.
     *
     * @param expressionURI - URI of the Expression to retrieve
     * @returns The rendered Expression
     */
    getExpression(expressionURI: string): Promise<ExpressionRendered>;
    /**
     * Creates a new Expression in the specified Language.
     *
     * @param content - Content for the new Expression
     * @param languageAddress - Address of the Language to use
     * @returns URI of the created Expression
     */
    createExpression(content: any, languageAddress: string): Promise<string>;
    /**
     * Call `handler` with every `type` event about this perspective, until the
     * returned function or {@link dispose} releases it.
     *
     * @example
     * ```typescript
     * perspective.on("link-added", ({ link }) => console.log("New link:", link));
     * perspective.on("link-updated", ({ oldLink, newLink }) => console.log(oldLink, "->", newLink));
     * perspective.on("sync-state-change", ({ state }) => console.log("Sync state:", state));
     * ```
     */
    on<K extends ScopedEventName>(type: K, handler: (event: EventMap[K]) => void): () => void;
    /** Removes every handler this proxy registered. Other proxies for the same
     *  perspective keep theirs. */
    dispose(): void;
    /**
     * Creates a snapshot of the current perspective state.
     * Useful for backup or sharing.
     *
     * @returns Perspective object containing all links
     */
    snapshot(): Promise<Perspective>;
    /**
     * Loads a perspective snapshot, replacing current content.
     *
     * @param snapshot - Perspective snapshot to load
     */
    loadSnapshot(snapshot: Perspective): Promise<void>;
    /**
     * Gets a single target value matching a query.
     * Useful when you expect only one result.
     *
     * @param query - Query to find the target
     * @returns Target value or void if not found
     *
     * @example
     * ```typescript
     * // Get a user's name
     * const name = await perspective.getSingleTarget({
     *   source: "did:key:alice",
     *   predicate: "name"
     * });
     * ```
     */
    getSingleTarget(query: LinkQuery): Promise<string | void>;
    /**
     * Sets a single target value, removing any existing targets.
     *
     * @param link - Link defining the new target
     * @param status - Whether the link should be shared
     *
     * @example
     * ```typescript
     * // Set a user's status
     * await perspective.setSingleTarget({
     *   source: "did:key:alice",
     *   predicate: "status",
     *   target: "online"
     * });
     * ```
     */
    setSingleTarget(link: Link, status?: LinkStatus): Promise<void>;
    /** Returns all the Social DNA flows defined in this perspective */
    sdnaFlows(): Promise<string[]>;
    /**
     * Returns all Social DNA flows that can be started from the given expression.
     *
     * Post-`flowable` retirement: a flow is a candidate iff its `inputTypes`
     * declaration is compatible with the expression. Matching rules:
     * - Empty `inputTypes` or one containing the `"any"` wildcard → always
     *   matches (same behaviour as the legacy `flowable === "any"` case).
     * - Otherwise, at least one of the expression's registered subject-class
     *   URIs (resolved via {@link subjectClassesOf}) must appear in
     *   `inputTypes`. This is the concrete-type match the design doc's §5
     *   spawn engine calls for; without it, a flow declaring
     *   `inputTypes: ["Task"]` was previously *never* returned by
     *   `availableFlows("some-task-uri")` — the entire point of typed
     *   flows was silently unreachable (James PR #929 J#3).
     *
     * The expression is classified against the perspective's registered
     * classes only. An expression whose class is not registered on this
     * perspective matches no typed flow (absence, not falsehood — same
     * discipline as {@link subjectClassesOf}); typed flows requiring
     * unknown classes are still returned to their untyped-caller peers.
     */
    availableFlows(exprAddr: string): Promise<string[]>;
    /**
     * Register model classes in this perspective, each as the class of its
     * target class IRI, in one call:
     *
     * ```typescript
     * await perspective.registerShapes([Recipe.generateSHACL().shape]);
     * ```
     *
     * A class whose stored shape already is the given one is left alone
     * (`unchanged`): registering on every start writes nothing. The others
     * are rewritten in one diff (`written`), which keeps links other apps
     * put on the class. Both lists name classes by target class IRI.
     * Answers once the executor reads the new shapes.
     *
     * Rejects, writing nothing, when two shapes name one class or share a
     * shape URI, or when another class holds a shape URI given here.
     */
    registerShapes(shapes: SHACLShape[]): Promise<RegisterResult>;
    /**
     * The classes registered in this perspective, sorted by name (only those
     * named in `names` when given): each with its shape and the SHA-256 of
     * the shape's canonical JSON, which changes exactly when the shape does.
     */
    shapes(names?: string[]): Promise<RegisteredShape[]>;
    /**
     * **Recommended way to add Flow definitions.**
     *
     * Store a SHACL Flow (state machine) in this Perspective using the type-safe `SHACLFlow` class.
     * The flow is serialized as RDF triples (links) for native AD4M storage and querying.
     *
     * @param name - Flow name (e.g., 'TODO', 'Approval')
     * @param flow - SHACLFlow instance defining the state machine
     *
     * @example
     * ```typescript
     * import { SHACLFlow } from '@coasys/ad4m';
     *
     * const deliveryFlow = new SHACLFlow('Delivery', 'delivery://');
     * deliveryFlow.inputTypes = ['Task'];
     * deliveryFlow.interpretationHint =
     *   'Advance a Task through delivery: Identified → Scoped → InProgress → Review → Done.';
     *
     * deliveryFlow.addState({ name: 'Identified', value: 0 });
     * deliveryFlow.addState({ name: 'Scoped',     value: 1 });
     * deliveryFlow.addState({ name: 'InProgress', value: 2 });
     * deliveryFlow.addState({ name: 'Review',     value: 3 });
     * deliveryFlow.addState({ name: 'Done',       value: 4 });
     *
     * deliveryFlow.addTransition({ actionName: 'Scope',  fromState: 'Identified', toState: 'Scoped',     actions: [] });
     * deliveryFlow.addTransition({ actionName: 'Start',  fromState: 'Scoped',     toState: 'InProgress', actions: [] });
     * deliveryFlow.addTransition({ actionName: 'Submit', fromState: 'InProgress', toState: 'Review',     actions: [] });
     * deliveryFlow.addTransition({ actionName: 'Accept', fromState: 'Review',     toState: 'Done',       actions: [] });
     *
     * // Optional: n distinct DIDs must co-sign a proposal before it fires.
     * deliveryFlow.consensusRule = { n: 2 };
     *
     * await perspective.addFlow('Delivery', deliveryFlow);
     * ```
     *
     * Rejects, storing nothing, when a `consensusRule` carries a key the
     * executor does not know or a key written twice (#1144): the error names
     * the state and the key.
     */
    addFlow(name: string, flow: SHACLFlow): Promise<void>;
    /**
     * Retrieve a Flow definition by name from this Perspective
     *
     * @param name - Flow name to retrieve
     * @returns The SHACLFlow or null if not found
     */
    getFlow(name: string): Promise<SHACLFlow | null>;
    /**
     * Creates a new subject instance of the given subject class
     *
     * @param subjectClass Either a string with the name of the subject class, or an object
     * with the properties of the subject class.
     * @param exprAddr The address of the expression to be turned into a subject instance
     * @param initialValues Optional initial values for properties. If provided, these will be
     * merged with constructor actions for better performance. A collection property accepts
     * an array value and stores one entry per element; scalar properties store arrays/objects
     * as a single JSON value.
     * @param batchId Optional batch ID for grouping operations. If provided, returns the expression address
     * instead of the subject proxy since the subject won't exist until the batch is committed.
     * @returns A proxy object for the created subject, or just the expression address if in batch mode
     */
    createSubject<T, B extends string | undefined = undefined>(subjectClass: T, exprAddr: string, initialValues?: Record<string, any>, batchId?: B): Promise<B extends undefined ? T : string>;
    /** Sets properties of an existing instance in the executor. Through an
     *  abstract class (#1435), each value is written by every class of the
     *  record that the abstract class reads, under its own name. */
    updateSubject(className: string, exprAddr: string, values: Record<string, any>, batchId?: string): Promise<void>;
    /**
     * Creates an instance of a subject class, validated by the executor against the class's
     * SHACL shape before anything is written (each property's type, which are required, which
     * take a single value, `sh:in`): the same check as the MCP `instance_create` tool. A refused
     * write rejects with an `RpcError` whose `data` is an `InstanceError` (status 422 and
     * `kind: 'validation'` for a shape violation, with one `ValidationError` per property) and
     * stages nothing. With `batchId` a non-validation failure can leave part of the write
     * staged in the batch — discard it ({@link discardBatch}), don't commit it to keep
     * earlier calls. An instance created in the same batch is not found — existence reads
     * committed state only — so a create followed by an update, remove or
     * `instanceAddToCollection` of the new instance in one batch fails `notFound`; put a new
     * instance's initial collection items on the create itself.
     *
     * @example
     * const { baseUri } = await perspective.instanceCreate({ className: "Task", properties: { title: "Write" } });
     */
    instanceCreate(body: InstanceCreate): Promise<InstanceCreated>;
    /** Sets single-valued properties of an instance, validated; the others stay. See {@link instanceCreate}. */
    instanceUpdate(body: InstanceUpdate): Promise<InstanceUpdated>;
    /** Removes an instance and every link to and from it. See {@link instanceCreate}. */
    instanceRemove(body: InstanceRemove): Promise<InstanceRemoved>;
    /** Adds an item to a collection of an instance, validated. See {@link instanceCreate}. */
    instanceAddToCollection(body: InstanceAddToCollection): Promise<CollectionItemAdded>;
    /** Removes an item from a collection of an instance. See {@link instanceCreate}. */
    instanceRemoveFromCollection(body: InstanceRemoveFromCollection): Promise<CollectionItemRemoved>;
    getSubjectData<T>(subjectClass: T, exprAddr: string): Promise<T>;
    /** Removes a subject instance by running its (SDNA defined) destructor,
     * which means removing links around the given expression address
     *
     * @param subjectClass Either a string with the name of the subject class, or an object
     * with the properties of the subject class. In the latter case, the first subject class
     * that matches the given properties will be used.
     * @param exprAddr The address of the expression to be turned into a subject instance
     * @param batchId Optional batch ID for grouping operations. If provided, the removal will be part of the batch
     * and won't be executed until the batch is committed.
     */
    removeSubject<T>(subjectClass: T, exprAddr: string, batchId?: string): Promise<void>;
    /** Checks if the given expression is a subject instance of the given subject class
     * @param expression The expression to be checked
     * @param subjectClass Either a string with the name of the subject class, or an object
     * with the properties of the subject class. In the latter case, the first subject class
     * that matches the given properties will be used.
    */
    isSubjectInstance<T>(expression: string, subjectClass: T): Promise<boolean>;
    /** Returns all subject instances of the given subject class.
     *  @param subjectClass The name of the subject class, a `@Model` class (its
     * instances come back loaded), or an object with the properties of the
     * subject class (the first registered class that has them is used).
     */
    getAllSubjectInstances<T>(subjectClass: T): Promise<T[]>;
    /**
     * Find a subject class by matching an object's properties/relations against the registered shapes.
     * @returns The matching class name, or null if no match found.
     */
    private findClassByProperties;
    getNeighbourhoodProxy(): NeighbourhoodProxy;
    /**
     * Returns a proxy object for working with AI capabilities.
     *
     * @returns AIClient instance
     *
     * @example
     * ```typescript
     * // Use AI to analyze perspective content
     * const summary = await perspective.ai.summarize();
     *
     * // Generate new content
     * const suggestion = await perspective.ai.suggest("next action");
     * ```
     */
    get ai(): AIClient;
    /** Live SPARQL query: resolves once the first result is in.
     *  Call `dispose()` on the returned proxy when done. The executor
     *  refuses a Prolog query (400): Prolog live queries are not supported. */
    subscribeQuery(query: string): Promise<QuerySubscriptionProxy>;
}
export {};
