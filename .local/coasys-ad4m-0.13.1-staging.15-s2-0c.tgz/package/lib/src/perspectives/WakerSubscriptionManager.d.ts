/**
 * WakerSubscriptionManager — manages live query subscriptions for the waker.
 *
 * This is the single implementation: it is exported from `@coasys/ad4m` and
 * used by the integration tests, and the OpenClaw AD4M plugin re-exports this
 * module (`plugins/ad4m/wakerSubscriptionManager.ts`) rather than carrying its
 * own copy. Any behaviour change belongs here.
 */
export interface WakerSubscription {
    id: string;
    type: "mention" | "channel-messages";
    perspective: string;
    channel: string;
    /** SPARQL, or with `className` a model query (JSON) over that class. */
    query: string;
    /**
     * The class `query` reads, as a model query. A mention subscription has the
     * built-in `ad4m://TextContent`, from the executor's `get_mention_waker_config`;
     * a children subscription the built-in `ad4m://Container`, from
     * `generate_waker_query` (#1446). Without it `query` is SPARQL.
     */
    className?: string;
    /**
     * A mention subscription's terms (profile names and the DID), from
     * `get_mention_waker_config`. The text query matches by substring, so a
     * record found through its text wakes only when the text holds one of
     * these as a whole word ({@link holdsAWholeWordTerm}).
     */
    terms?: string[];
    /**
     * A mention subscription's agent DID, from `get_mention_waker_config`. A
     * record whose `mentions` links it, in a verified link another agent wrote,
     * wakes whatever its text says ({@link mentionOf}).
     */
    did?: string;
    /**
     * A mention subscription's second query, a model query (JSON) over
     * `mentionClass`, from `get_mention_waker_config`: every record whose
     * `mentions` relation links the agent's DID, with text or without (a WE
     * post's root). It runs beside `query` under the same id, so a record both
     * find wakes once, through the query that reports it first.
     */
    mentionQuery?: string;
    /** The class `mentionQuery` reads: the built-in `ad4m://Mentioning`. */
    mentionClass?: string;
    /**
     * Set by the manager, not the caller: whether a mention subscription's text
     * query has taken its opening result, which the manager records as history.
     * It persists with the subscription. Until it is set, the text query's
     * opening result is history even after a restart: the persisted seen set
     * may hold the mention query's records only (the subscription listened
     * without its text query, #1735), so the text query's old matches would all
     * wake at once. A subscription saved without it (an older version) starts
     * that way too.
     */
    textHistoryRead?: boolean;
    neighbourhood?: string;
}
/**
 * How much of a record's text the word check reads. Dropping markup costs time
 * quadratic in a run of unclosed `<script>`, `<style>` or `<!--` openers, so a
 * very long text could hold the event loop for seconds, and a row that holds
 * no term is checked again on every result while it is in the window. A term
 * past this many characters does not wake.
 */
export declare const MENTION_TEXT_LIMIT = 16384;
/**
 * Whether `text` holds one of `terms` as a whole word, case-insensitively:
 * "Data" is in "hi Data!", "@data" and "Data's turn", not in "metadata" or
 * "database". A term is matched literally (regex characters, quotes) and must
 * not touch a letter, mark, digit or underscore on either side, so a name
 * that starts or ends with punctuation still matches. Same rule as #1459's
 * SPARQL `(?:^|\W)term(?:\W|$)`.
 *
 * The rule runs on the visible text only: in HTML, tags and attributes are
 * dropped and entities decoded first. A mention's target attribute
 * (`href`, `data-id`, `data-did`) matches an exact, case-sensitive DID term, which
 * is how a mention by DID is found when the DID is not in the visible text.
 *
 * The mention query's `contains` matches substrings (model query has no word
 * match); this is the check that keeps "data" from waking on "metadata" when
 * a record is found through its text alone ({@link mentionOf}).
 *
 * It reads the first {@link MENTION_TEXT_LIMIT} characters only.
 */
export declare function holdsAWholeWordTerm(text: string, terms: string[]): boolean;
/** Per-message parent resolution result for mention subscriptions. */
export interface MentionMessage {
    /** The mentioned record's id. */
    address: string;
    /**
     * Every container holding it (channels, threads, calls, blocks): whatever
     * links it with `ad4m://has_child`, and every instance of a class whose
     * `children` relation links it. A record can sit in several.
     */
    parents: string[];
    /**
     * Everything above the parents, nearest first: their parents, theirs, and so on up to the
     * manager's `ancestorDepth`. Each address once, however many paths reach it. Empty when the
     * parents have none, or the walk could not be made.
     */
    ancestors: string[];
    /**
     * The DID that signed the link of the path that woke the agent (`via`): the mention link to
     * its DID, or the text link whose own text names it. Only that link is theirs; the record's
     * other links may be someone else's.
     */
    author?: string;
    /** That link's timestamp, ISO 8601. */
    timestamp?: string;
    /**
     * Whether that link's signature verified for `author`. A mention is only taken from a link
     * that verified, so a wake's mention is `true`.
     */
    verified: boolean;
    /**
     * The query that reported the record first: `"mentions"`, a mention link to the agent's DID
     * (Mentioning's `mentions`); `"text"`, its name or DID as a whole word in the text (a mention
     * link may also exist). A text match is the agent's name used as a word, which need not
     * address it ("the data shows" for an agent named Data).
     */
    via?: "mentions" | "text";
}
/** What {@link mentionOf} finds about a mention: how it was made, and the provenance of its link. */
type MentionProvenance = Pick<MentionMessage, "author" | "timestamp" | "verified" | "via">;
/**
 * Whether a row of one of the mention subscription's two model queries mentions the
 * subscription's agent, and the provenance of the link it does so in; `null` when it does not.
 *
 * - A row of the query over Mentioning: a verified link to the agent's DID that another agent
 *   wrote, in the row's `__links.mentions`. It wakes whatever the record's text says, or
 *   whether it has any: WE's chip label may run into the next word ("@Datai have…"), and a WE
 *   post's mention sits on its root, which has no text. Its provenance is that link's (the
 *   newest such).
 * - A row of the query over TextContent: the query matched a substring, so the text must hold
 *   a term as a whole word ({@link holdsAWholeWordTerm}), and so must the text of a verified
 *   link another agent wrote, in `__links.text`. Its provenance is that link's (the newest
 *   such). The row's `text` is the newest text link's, whoever wrote it, so it does not say
 *   whose words they are.
 *
 * `via` says which it was. A record both queries find wakes once, through the query that
 * reports it first ({@link WakerSubscriptionManager}).
 */
export declare function mentionOf(row: any, sub: Pick<WakerSubscription, "did" | "terms">): MentionProvenance | null;
export interface WakerLogger {
    info(msg: string): void;
    warn(msg: string): void;
    error(msg: string): void;
    debug(msg: string): void;
}
export interface WakerSubscriptionManagerOptions {
    /** PerspectiveClient from Ad4mClient (provides subscribeQuery etc.) */
    perspectiveClient: any;
    /** Logger instance */
    logger: WakerLogger;
    /** Debounce interval in ms before firing the wake callback (default 2000) */
    debounceMs?: number;
    /**
     * How many levels above a mentioned item's parents to report as `ancestors` (default 3).
     * Each level is one batched query, so the walk is bounded by this depth and by
     * what the levels hold. 0 reports parents only.
     */
    ancestorDepth?: number;
    /**
     * Called when a subscription fires (after debounce). For mention subs, `mentions` holds every
     * mention not yet delivered, with its parent info. Resolve `false` (or reject) when the wake did
     * not reach the agent: those mentions stay out of the persisted seen set and are offered again
     * after `retryWakeMs`, so a wake lost to a restarting gateway is not lost for good.
     */
    onWake: (sub: WakerSubscription, result: any, mentions?: MentionMessage[]) => void | boolean | Promise<void | boolean>;
    /** Called when the active subscription list changes (for persistence). */
    onPersist?: (subscriptions: WakerSubscription[], seenMessages: Record<string, string[]>) => void;
    /** Previously persisted seen message IDs per subscription. Seeds seenMessages on resubscribe to avoid duplicate wakes. */
    previousSeenMessages?: Record<string, string[]>;
    /** Optional: provide QuerySubscriptionProxy class directly (avoids require("@coasys/ad4m") at runtime). */
    QuerySubscriptionProxy?: any;
    /** How long to wait before re-attempting a subscription the executor rejected
     *  (default 30000). 0 disables re-attempts. Each re-attempt round that still
     *  leaves something pending doubles the wait, up to `maxRetryPendingMs`. */
    retryPendingMs?: number;
    /** Longest wait between two re-attempt rounds (default 300000). */
    maxRetryPendingMs?: number;
    /**
     * How long the executor gets to answer the subscribe handshake before the
     * attempt is abandoned and queued for re-attempt (default 15000). 0 removes
     * the bound. Covers both `proxy.subscribe()` and `proxy.initialized`: when
     * the executor accepts the socket but never answers, neither settles, and
     * without a deadline the subscription ended up neither active nor pending,
     * so the re-attempt cycle never saw it (#1016). Each query of a mention
     * subscription gets its own: one whose mention query opens listens through
     * it, and re-attempts a text query that did not open on its own (#1735),
     * with this budget doubled per failed re-attempt, up to `maxRetryPendingMs`.
     */
    subscribeTimeoutMs?: number;
    /** First delay before offering an undelivered mention wake again (default 5000); doubles per
     *  failed attempt, up to 60000. */
    retryWakeMs?: number;
}
/**
 * Add a short cause hint to known subscription failures.
 * The executor needs its main key to register a live query; on a restarted
 * executor whose wallet was never unlocked this surfaces as a bare 403.
 */
export declare function hintFor(msg: string): string;
export declare class WakerSubscriptionManager {
    private perspectiveClient;
    private logger;
    private debounceMs;
    private ancestorDepth;
    private onWake;
    private onPersist?;
    private QuerySubscriptionProxyCtor;
    private previousSeenMessages;
    private retryPendingMs;
    private subscribeTimeoutMs;
    private retryWakeMs;
    /** Per subscription its proxies: one, or a mention subscription's text and mention queries. */
    private proxies;
    private activeSubscriptions;
    /** Subscriptions the executor rejected, waiting to be re-attempted. */
    private pendingSubscriptions;
    private retryTimer;
    private maxRetryPendingMs;
    /** Re-attempt rounds in a row that left something pending, for the backoff. */
    private retryRounds;
    /**
     * Subscriptions that were active until one of their live queries lost its
     * executor subscription (a reconnect, a failed resync) and failed to open it
     * again, with the proxies still re-opening. The query retries on its own,
     * with backoff, so the manager does not subscribe them again; it reports
     * them as pending instead of active until every proxy is open again, and
     * keeps persisting them so a restart restores them (#1595).
     */
    private reopening;
    /**
     * Mention subscriptions listening through their mention query only, because
     * their text query failed to open (#1735: a TextContent `contains` scan over a
     * large neighbourhood can take longer than the handshake budget). The text
     * query alone is re-attempted: `timer` is the wait before the next attempt,
     * `proxy` the attempt in flight. `release()` cancels both.
     */
    private textRetries;
    /**
     * Cancellation tokens for in-flight `subscribe()` calls.
     *
     * `subscribe()` awaits `proxy.subscribe()` and `proxy.initialized`; a
     * `dispose()` / `disposeAll()` landing during either await used to leave a
     * live subscription behind, because nothing stopped the resumed call from
     * registering the proxy in `proxies` / `activeSubscriptions` afterwards.
     * `epoch` is bumped by `disposeAll()` (which cannot enumerate in-flight
     * ids), `generations` per id by `dispose()` and by each new `subscribe()`.
     */
    private epoch;
    private generations;
    private debounceTimers;
    /** Per-subscription set of already-processed message addresses (for mention subs)
     *  or serialized result hash (for channel-messages subs). */
    private seenMessages;
    /**
     * Per mention subscription: the addresses whose wake was delivered, or that were history when
     * the subscription opened. This, not `seenMessages`, is what gets persisted: an address joins
     * `seenMessages` as soon as it is read, while its parents are still resolving and before any
     * wake, so a restart in between must not take it as done.
     */
    private delivered;
    /**
     * Per mention subscription: mentions read but whose wake has not been delivered yet, keyed by
     * address. They accumulate across a debounce window, so one wake names all of them.
     */
    private undelivered;
    /** Failed wake attempts in a row per subscription, for the retry backoff. */
    private wakeFailures;
    constructor(options: WakerSubscriptionManagerOptions);
    /** A token identifying this attempt at subscribing `id`. */
    private beginAttempt;
    /** Whether this attempt has been superseded by a dispose or a newer one. */
    private isStale;
    /**
     * Create a live subscription: SPARQL, or a model query when `sub.className` is set.
     * If a subscription with the same id already exists, it is disposed first.
     */
    subscribe(sub: WakerSubscription): Promise<void>;
    /**
     * A proxy of `sub` failed to re-open its live query, or re-opened it after
     * failing. `sub` counts as active again once none of its proxies is still
     * re-opening. `proxies` tells a status of a replaced subscription apart.
     */
    private onReopenStatus;
    /** The wait before the next re-attempt round: `retryPendingMs` doubled per
     *  round in a row that left something pending, capped at
     *  `maxRetryPendingMs`, and between half and all of that, so wakers of a
     *  restarted executor do not all retry at once. */
    private nextRetryDelay;
    /** The longest the next re-attempt round waits. */
    private retryCeiling;
    /** Arm the re-attempt timer if pending subscriptions are waiting. */
    private scheduleRetry;
    /**
     * Re-attempt every subscription the executor rejected.
     * Each attempt that fails puts itself back into the pending set and re-arms
     * the timer, so an agent that asked to be subscribed ends up enrolled once
     * the executor can accept the query.
     */
    retryPending(): Promise<void>;
    /** Subscriptions that are not listening and are being re-attempted: the
     *  ones the executor rejected, and active ones whose live query is
     *  re-opening after a reconnect. */
    getPending(): WakerSubscription[];
    /**
     * Dispose a single subscription.
     * @param persist — if false, skip calling onPersist (used during batch cleanup).
     */
    dispose(id: string, persist?: boolean): void;
    /** Drop everything held for `id`, as `dispose()` does, but leave the
     *  re-attempt backoff as it is. */
    private release;
    /** (Re)start the timer that offers `sub`'s undelivered mentions to `onWake` after `delayMs`. */
    private scheduleMentionWake;
    /**
     * Offer every undelivered mention of `sub` in one wake. On delivery they join the persisted
     * seen set; on failure they stay undelivered and are offered again with backoff.
     */
    private deliverMentions;
    /** Dispose all active subscriptions and drop anything still pending. */
    disposeAll(): void;
    /** Get all active subscriptions. */
    getActive(): WakerSubscription[];
    /** Check if a subscription exists. */
    has(id: string): boolean;
    /**
     * Everything holding any of `addresses`, in one model query: a `Container`
     * step in (#1446). The executor follows `ad4m://has_child` on any node and
     * each class's own `children` relation on its instances, so the waker
     * looks up no predicate. Failures count as none.
     */
    private parentsOf;
    /**
     * The chain above an item's parents, nearest first, up to `ancestorDepth` levels: one
     * transitive `Container` walk in from the parents, bounded by `maxDepth`. The executor walks
     * containment as a graph, so each address comes once however many paths reach it, and a
     * cycle ends. The item and its parents are never reported as ancestors.
     */
    private ancestorsOf;
    /** The ids of the `Container` rows `parent` scopes to, in the executor's order. */
    private containers;
    private persist;
}
export {};
