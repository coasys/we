import { Link } from "../links/Links";
export declare class LinkQuery {
    source?: string;
    target?: string;
    predicate?: string;
    fromDate?: Date;
    untilDate?: Date;
    limit?: number;
    constructor(obj: object);
    isMatch(l: Link): boolean;
}
