import { ApiClient, CallOptions, EventFilter } from '../apiClient';
import type { EventMap, EventName } from '../generated/api/Events';
import { ExpressionRendered } from "../expression/Expression";
import { ExpressionClient } from "../expression/ExpressionClient";
import { Link, LinkExpressionInput, LinkExpression, LinkMutations, LinkExpressionMutations } from "../links/Links";
import { NeighbourhoodClient } from "../neighbourhood/NeighbourhoodClient";
import { NeighbourhoodProxy } from "../neighbourhood/NeighbourhoodProxy";
import { LinkQuery } from "./LinkQuery";
import { Perspective } from "./Perspective";
import { LinkStatus, PerspectiveProxy } from './PerspectiveProxy';
import { AIClient } from "../ai/AIClient";
import type { QueryLagged, QueryUpdate, Subscribed } from "./LiveQuery";
import type { TranscriptTurn } from "../generated/api";
import type { AgentMessage } from "../generated/api/AgentMessage";
import type { AgentReply } from "../generated/api/AgentReply";
import type { PerspectiveCreateSubjectResult } from "../generated/api/PerspectiveCreateSubjectResult";
import type { MountSyncReport } from "../generated/api/MountSyncReport";
import type { JsonValue } from "../generated/api/serde_json/JsonValue";
import type { FlowFiredEntry } from "../generated/api/FlowFiredEntry";
import type { CollectionItemAdded, CollectionItemRemoved, InstanceAddToCollection, InstanceCreate, InstanceCreated, InstanceRemove, InstanceRemoveFromCollection, InstanceRemoved, InstanceUpdate, InstanceUpdated, RegisterResult, ShapeJson, ShapeSummary } from "../generated/api";
import type { AddAutoProcessorConfig, InterpretationOverlayInfo, RawScope, RunInterpretationObserveOptions } from "./AutoProcessor";
import type { FlowFireOutcome, FlowMintedReceipt, FlowOutputRef, FlowProposeResult, FlowReceiptVerdict, FlowStateEntry, FlowValidOutput } from "./FlowInstance";
export declare class PerspectiveClient {
    #private;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    setExpressionClient(client: ExpressionClient): void;
    setNeighbourhoodClient(client: NeighbourhoodClient): void;
    setAIClient(client: AIClient): void;
    get aiClient(): AIClient;
    all(): Promise<PerspectiveProxy[]>;
    byUUID(uuid: string): Promise<PerspectiveProxy | null>;
    snapshotByUUID(uuid: string): Promise<Perspective | null>;
    publishSnapshotByUUID(uuid: string): Promise<string | null>;
    queryLinks(uuid: string, query: LinkQuery, options?: CallOptions): Promise<LinkExpression[]>;
    queryProlog(uuid: string, query: string, options?: CallOptions): Promise<unknown>;
    /**
     * Concurrent identical calls (same perspective and query, no `options`)
     * share one RPC. Each caller parses its own copy of the reply, and a call
     * made after the shared one settled makes a new RPC. So does a call made
     * after a write through this client settled: the shared RPC may have been
     * answered before the write (see `#wrote`).
     */
    querySparql<T = any>(uuid: string, query: string, options?: CallOptions): Promise<T>;
    /** Open a live SPARQL query. Updates arrive through {@link onQueryUpdate}. */
    /** `options.signal` cancels the call, and the executor stops computing the first result. */
    subscribeQuery(uuid: string, query: string, options?: CallOptions): Promise<Subscribed>;
    /** Every `query-subscription-update` event on this client's socket. */
    onQueryUpdate(cb: (update: QueryUpdate | QueryLagged) => void): () => void;
    /** The current result and revision of a live query, after a revision gap. */
    resyncSubscription(uuid: string, subscriptionId: string): Promise<{
        revision: number;
        result: any;
    }>;
    /** Ends the subscription on the executor. The caller releases its local listener
     *  with the function {@link onQueryUpdate} returned. */
    disposeQuerySubscription(uuid: string, subscriptionId: string): Promise<boolean>;
    /** `className` may name several classes: one query over their union (#1238). */
    modelQuery(uuid: string, className: string | string[], queryJson: string, options?: CallOptions): Promise<any>;
    subjectClassesOf(uuid: string, uris: string[]): Promise<Record<string, string[]>>;
    mount(uuid: string, languageAddress: string): Promise<boolean>;
    unmount(uuid: string, languageAddress: string): Promise<boolean>;
    syncMount(uuid: string, languageAddress: string): Promise<MountSyncReport>;
    mounts(uuid: string): Promise<string[]>;
    evaluateGetters(uuid: string, className: string, instanceIds: string[], propertyNames?: string[]): Promise<Record<string, Record<string, any>>>;
    /** Open a live model query over one class or several. Updates arrive through {@link onQueryUpdate}. */
    /** `options.signal` cancels the call, and the executor stops computing the first result. */
    modelSubscribe(uuid: string, className: string | string[], queryJson: string, options?: CallOptions): Promise<Subscribed>;
    add(name: string): Promise<PerspectiveProxy>;
    update(uuid: string, name: string): Promise<PerspectiveProxy>;
    remove(uuid: string): Promise<{
        perspectiveRemove: boolean;
    }>;
    addLink(uuid: string, link: Link, status?: LinkStatus, batchId?: string): Promise<LinkExpression>;
    addLinks(uuid: string, links: Link[], status?: LinkStatus, batchId?: string): Promise<LinkExpression[]>;
    removeLinks(uuid: string, links: LinkExpressionInput[], batchId?: string): Promise<LinkExpression[]>;
    linkMutations(uuid: string, mutations: LinkMutations, status?: LinkStatus): Promise<LinkExpressionMutations>;
    /**
     * Run generic LLM interpretation over a transcript into this perspective's own
     * SHACL subject classes. The target shapes are resolved server-side from the
     * perspective's registered subject classes, so you pass only the transcript.
     * Returns the freshly minted instances (their base URIs + the links written).
     *
     * The server-side call prompts an LLM (up to `INTERPRETATION_MAX_ATTEMPTS`
     * retries on parse failure), so it can legitimately take minutes on slower
     * or CPU-only models, so it defaults to {@link LONG_TIMEOUT_MS}.
     *
     * `existingScope` and `mintScope` match the AutoProcessor semantics:
     * `existingScope` constrains the dedup lookup to instances under a
     * subtree; `mintScope` links every FRESHLY-created base as a child of
     * `mintScope.id` via its predicate (upserts of pre-existing instances
     * are NOT re-parented — same rule as the watcher).
     */
    runInterpretation(uuid: string, transcript: TranscriptTurn[], basePrefix: string, classes?: string[], existingScope?: RawScope, mintScope?: RawScope, observe?: RunInterpretationObserveOptions, options?: CallOptions): Promise<string[]>;
    /**
     * Tool-calling counterpart to {@link runInterpretation}. The LLM sees a
     * live per-class tool surface (`{Class}_query`, `{Class}_propose_create`,
     * `{Class}_propose_link_child`, …) and drives the extraction via tool
     * calls; buffered proposals drain through the same overlay gate the
     * single-shot path uses.
     *
     * `maxToolCalls` bounds the loop and MUST be > 0 — zero would collapse
     * the harness to a no-op final-answer step; use {@link runInterpretation}
     * for the classic single-shot path.
     *
     * Defaults to {@link LONG_TIMEOUT_MS}, like the single-shot path.
     */
    runInterpretationWithHarness(uuid: string, transcript: TranscriptTurn[], basePrefix: string, maxToolCalls: number, classes?: string[], modelOverride?: string, existingScope?: RawScope, observationId?: string, emitDebugEvents?: boolean, options?: CallOptions): Promise<string[]>;
    /**
     * A conversation with a model in this perspective, using the executor's own tools: the tools
     * that read this perspective, and only the writing tools named in `writeTools`. Every tool a
     * session offers acts on this perspective alone, so tools about other perspectives, the agent
     * or the node (listing or publishing perspectives, the profile) are not available. Runs as the
     * caller, with the caller's capabilities, and answers with the model's final reply.
     *
     * Defaults to {@link LONG_TIMEOUT_MS}: an agent may read documentation and make many tool
     * calls before it answers.
     */
    runAgent(uuid: string, messages: AgentMessage[], settings?: {
        /** What the person is looking at, as a hint for the model (`{ recordId }`). */
        context?: Record<string, unknown>;
        /** Tools that write which the model may call. Absent: the session only reads. */
        writeTools?: string[];
        /** A model id; the node's default language model when absent. */
        model?: string;
        /** How many tool calls before the model must answer. Default 20. */
        maxToolCalls?: number;
    }, options?: CallOptions): Promise<AgentReply>;
    /**
     * Register a neighbourhood auto-processor on this perspective. The executor's
     * watch loop then runs interpretation automatically over new source items
     * (like Flux per channel), coordinating which peer processes each batch via
     * the shared-graph ProcessingClaim, and emits step signals on the events
     * WebSocket (subscribe with `on('auto-processor-event', …, { perspective })`).
     * Returns the processor id.
     */
    addAutoProcessor(uuid: string, config: AddAutoProcessorConfig): Promise<string>;
    /** Delete an auto-processor's config. `false` when there was none to delete. */
    removeAutoProcessor(uuid: string, processorId: string): Promise<boolean>;
    /** Pending interpretation overlays (LLM suggestions awaiting human accept/reject). */
    interpretationOverlays(uuid: string): Promise<InterpretationOverlayInfo[]>;
    /** Accept an overlay's suggestion(s): the LLM value becomes the real value and
     *  the overlay is deleted. Omit `property` to accept the whole base. */
    acceptInterpretation(uuid: string, base: string, property?: string): Promise<boolean>;
    /** Reject an overlay's suggestion(s). Omit `property` to reject the whole base
     *  (a rejected `create` deletes the suggested instance). */
    rejectInterpretation(uuid: string, base: string, property?: string): Promise<boolean>;
    proposeFlowTransition(uuid: string, instanceUri: string, toState: string, rationale?: string, outputs?: FlowOutputRef[]): Promise<FlowProposeResult>;
    acceptFlowProposal(uuid: string, proposalUri: string): Promise<FlowFireOutcome[]>;
    /**
     * Withdraw this agent's own links from a proposal. Resolves to how many
     * were retracted — one for a withdrawn vote, more when retracting a
     * proposal this agent opened.
     */
    rejectFlowProposal(uuid: string, proposalUri: string): Promise<number>;
    /** Re-decide a flow receipt under this perspective's own flow catalogue. */
    verifyFlowReceipt(uuid: string, receipt: JsonValue): Promise<FlowReceiptVerdict>;
    /** The instances that are, as they stand, valid outputs of `flow`
     *  (optionally: of runs settled into terminal state `state`). */
    flowValidOutputs(uuid: string, flow: string, state?: string): Promise<FlowValidOutput[]>;
    /** The calling agent's recorded state of each flow instance it has
     *  derived, optionally narrowed to `instances`. */
    flowStates(uuid: string, instances?: string[]): Promise<FlowStateEntry[]>;
    /** For each of `instances`, in order, the proposals the calling agent's
     *  replica recorded as fired, sorted. One call covers up to 200
     *  instances (more is refused with a 400); split a longer list into
     *  batches of 200. */
    flowFired(uuid: string, instances: string[]): Promise<FlowFiredEntry[]>;
    /** Mint and store the receipt for a completed flow run. Fails while the
     *  run has not settled into a terminal state, and when an output's
     *  content no longer matches what the quorum committed to. */
    mintFlowReceipt(uuid: string, instanceUri: string): Promise<FlowMintedReceipt>;
    addLinkExpression(uuid: string, link: LinkExpression, status?: LinkStatus, batchId?: string): Promise<LinkExpression>;
    updateLink(uuid: string, oldLink: LinkExpressionInput, newLink: Link, batchId?: string): Promise<LinkExpression>;
    removeLink(uuid: string, link: LinkExpressionInput, batchId?: string): Promise<boolean>;
    /**
     * Register model classes, each as the class of its target class IRI. A
     * class whose stored shape already is the given one is left alone; the
     * others are rewritten in one diff. Answers once the executor reads the
     * new shapes.
     */
    registerShapes(uuid: string, shapes: ShapeJson[]): Promise<RegisterResult>;
    /** The registered classes (only those in `names` when given), sorted by name. */
    shapes(uuid: string, names?: string[]): Promise<ShapeSummary[]>;
    executeCommands(uuid: string, commands: string, expression: string, parameters: string, batchId?: string): Promise<boolean>;
    /** The URL a `call` constructor minted (string), or `true` for a link constructor. */
    createSubject(uuid: string, subjectClass: string, expressionAddress: string, initialValues?: string, batchId?: string): Promise<PerspectiveCreateSubjectResult>;
    /** Through an abstract class (#1435), the executor writes to the record's own classes. */
    updateSubject(uuid: string, subjectClass: string, expressionAddress: string, values: string, batchId?: string): Promise<boolean>;
    removeSubject(uuid: string, subjectClass: string, expressionAddress: string, batchId?: string): Promise<boolean>;
    /**
     * Validated writes (`perspective.instance*`): the executor checks each against the class's
     * SHACL shape — each property's type, which are required, which take a single value, `sh:in`
     * — before writing anything. A refused write rejects with an `RpcError` whose `data` is an
     * `InstanceError` and stages nothing for that call; a shape violation is status 422 with
     * `data.kind === 'validation'` and `data.errors` naming each property.
     *
     * With `batchId` the write is staged into that open batch and lands on its commit; the
     * link reads a write does (collection membership, the remove cascade) see the batch's own
     * staged work, but an instance created in the same batch is not found — instance existence
     * reads committed state only, so a create followed by an update, remove or
     * `instanceAddToCollection` of the new instance in one batch fails `notFound`; put a new
     * instance's initial collection items on the create itself. A failure that is not a
     * refusal — a store error mid-write, `failed` / `partiallyRemoved` — can leave part of the
     * write staged in the batch: discard it ({@link discardBatch}) instead of committing
     * it to keep the calls that succeeded.
     */
    instanceCreate(uuid: string, body: InstanceCreate): Promise<InstanceCreated>;
    /** Sets the given single-valued properties; the others stay. See {@link instanceCreate}. */
    instanceUpdate(uuid: string, body: InstanceUpdate): Promise<InstanceUpdated>;
    /** Removes the instance and every link to and from it. See {@link instanceCreate}. */
    instanceRemove(uuid: string, body: InstanceRemove): Promise<InstanceRemoved>;
    /** Adds an item to a collection (a no-op when it is a member). See {@link instanceCreate}. */
    instanceAddToCollection(uuid: string, body: InstanceAddToCollection): Promise<CollectionItemAdded>;
    /** Removes an item's membership link from a collection. See {@link instanceCreate}. */
    instanceRemoveFromCollection(uuid: string, body: InstanceRemoveFromCollection): Promise<CollectionItemRemoved>;
    getSubjectData(uuid: string, subjectClass: string, expressionAddress: string): Promise<string>;
    getExpression(expressionURI: string): Promise<ExpressionRendered>;
    createExpression(content: unknown, languageAddress: string): Promise<string>;
    /** The client's event bus; see {@link ApiClient.on}. */
    on<K extends EventName>(type: K, handler: (event: EventMap[K]) => void, filter?: EventFilter): () => void;
    getNeighbourhoodProxy(uuid: string): NeighbourhoodProxy;
    createBatch(uuid: string): Promise<string>;
    commitBatch(uuid: string, batchId: string): Promise<LinkExpressionMutations>;
    /**
     * Drops an open batch without committing it — the recovery for a failed batched call:
     * a failed call does not roll back the calls before it and may have staged part of its
     * own work, so discard rather than commit to keep the successful calls. Resolves `true`
     * when the batch was open and is now dropped.
     */
    discardBatch(uuid: string, batchId: string): Promise<boolean>;
    /** Register a callback that fires after a successful WebSocket reconnect.
     *  Passes through to ApiClient.onReconnect(). Returns an unsubscribe function. */
    onReconnect(callback: () => void): () => void;
}
