import { NeighbourhoodExpression } from "../neighbourhood/Neighbourhood";
import type { PerspectiveHandle as WirePerspectiveHandle } from "../generated/api/PerspectiveHandle";
import type { DecoratedNeighbourhoodExpression } from "../generated/api/DecoratedNeighbourhoodExpression";
export declare const PerspectiveState: {
    readonly Private: "PRIVATE";
    readonly NeighboudhoodCreationInitiated: "NEIGHBOURHOOD_CREATION_INITIATED";
    readonly NeighbourhoodJoinInitiated: "NEIGHBOURHOOD_JOIN_INITIATED";
    readonly LinkLanguageFailedToInstall: "LINK_LANGUAGE_FAILED_TO_INSTALL";
    readonly LinkLanguageInstalledButNotSynced: "LINK_LANGUAGE_INSTALLED_BUT_NOT_SYNCED";
    readonly Synced: "SYNCED";
};
export type PerspectiveState = typeof PerspectiveState[keyof typeof PerspectiveState];
export declare class PerspectiveHandle {
    uuid: string;
    name: string;
    state: PerspectiveState;
    sharedUrl?: string;
    neighbourhood?: NeighbourhoodExpression;
    owners?: string[];
    constructor(uuid?: string, name?: string, state?: PerspectiveState);
    /** Build a PerspectiveHandle from the executor's wire shape. */
    static fromWire(wire: WirePerspectiveHandle): PerspectiveHandle;
}
/** Build a NeighbourhoodExpression, with a `Perspective` as its meta, from the wire shape. */
export declare function neighbourhoodExpressionFromWire(wire: DecoratedNeighbourhoodExpression): NeighbourhoodExpression;
