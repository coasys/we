/**
 * SPARQL binding helpers — typed shapes and parsers for `querySparql<T>()`.
 *
 * AD4M stores non-string property values as URL-encoded `Literal` payloads
 * (see {@link Literal}). When raw SPARQL queries pull these values out of the
 * RDF store the bindings are still in encoded form; consumers must decode
 * before use. The helpers here centralise that decode step so each call site
 * can pick the variant matching its declared binding type.
 *
 * @example
 * ```ts
 * interface MessageBinding {
 *   id: string;
 *   timestamp: string;  // raw literal — decode with parseLitNumber
 *   body?: string;      // raw literal — decode with parseLit
 * }
 * const rows = await perspective.querySparql<MessageBinding[]>(query);
 * const ts = parseLitNumber(rows[0].timestamp);   // number
 * const body = rows[0].body ? parseLit(rows[0].body) : '';
 * ```
 */
/** Common AD4M link binding — matches the `?source/?predicate/?target/?author/?timestamp` pattern. */
export interface LinkBinding {
    source: string;
    predicate: string;
    target: string;
    author?: string;
    timestamp?: string;
}
/** COUNT(?x) result binding — SPARQL returns counts as string literals. */
export interface CountBinding {
    count: string;
}
/** Sum a SPARQL COUNT(?x) result down to a plain number (returns 0 on empty). */
export declare function parseSparqlCount(result: CountBinding[] | undefined | null): number;
/**
 * Decode a `Literal`-encoded SPARQL binding back to a plain string.
 *
 * Returns `''` for `undefined`/empty input. Falls through to the raw value
 * if decoding fails — bindings against properties resolved through a custom
 * language are already raw URIs and should pass through unchanged.
 *
 * Signed-envelope literals
 * ------------------------
 * Properties declared with `resolveLanguage: 'literal'` are written through
 * the built-in `literal` language, which wraps the value in a signed
 * expression envelope (`{ author, timestamp, data, proof }`) and encodes
 * the whole envelope as a `literal:json:` URL — see
 * `rust-executor/src/languages/mod.rs::expression_create` (literal branch).
 * On read, `parseLit` unwraps `.data` from that envelope so callers get the
 * original scalar value instead of the envelope JSON.
 *
 * The Channel V refactor moved most scalar properties to deterministic
 * typed XSD literals which no longer round-trip through this envelope — for
 * those properties the SPARQL binding is already the lexical form and this
 * helper decodes to the primitive.  Signed-envelope literals still exist
 * for any property that opts back into `resolveLanguage: 'literal'` (e.g.
 * per-message provenance for chat bodies), which is why the `.data` unwrap
 * is preserved here.
 *
 * Non-envelope JSON objects (`literal:json:` payloads that are not signed
 * envelopes) are JSON-stringified for display.
 */
export declare function parseLit(val: string | undefined | null): string;
/** Decode a `Literal`-encoded binding to a number. Returns 0 on empty/invalid input. */
export declare function parseLitNumber(val: string | undefined | null): number;
/** Decode a `Literal`-encoded binding to a boolean. Returns false on empty input. */
export declare function parseLitBoolean(val: string | undefined | null): boolean;
