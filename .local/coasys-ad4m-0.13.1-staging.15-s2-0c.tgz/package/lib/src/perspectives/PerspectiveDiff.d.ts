import { LinkExpression } from "../links/Links";
export declare class PerspectiveDiff {
    additions: LinkExpression[];
    removals: LinkExpression[];
}
declare const PerspectiveDiffExpression_base: abstract new (author?: string, timestamp?: string, data?: PerspectiveDiff, proof?: import("../expression/Expression").ExpressionProof) => import("../expression/Expression").ExpressionShape<PerspectiveDiff, import("../expression/Expression").ExpressionProof>;
export declare class PerspectiveDiffExpression extends PerspectiveDiffExpression_base {
}
export {};
