import { Link, LinkExpression, LinkExpressionInput, LinkInput } from "../links/Links";
import { LinkQuery } from "./LinkQuery";
import type { DecoratedPerspective } from "../generated/api/DecoratedPerspective";
import type { Perspective as WirePerspective } from "../generated/api/Perspective";
import type { PerspectiveExpression as WirePerspectiveExpression } from "../generated/api/PerspectiveExpression";
/** A Perspective represents subjective meaning, encoded through
* associations between expressions, a.k.a. Links, that is a graph
* over the objective Expressions of any subset of Languages.
*
* This type represents the clean onotological concept of a Perspective.
* An instance of this class can be regarded as an immutable snapshot of
* a mutable perspective.
*
* The types PerspectiveProxy and PerspectiveHandle are used when dealing
* with an instantiated mutable perspective as is done through most of
* the AD4M API.
*/
export declare class Perspective {
    /** The content of the perspective, a list/graph of links */
    links: LinkExpression[];
    constructor(links?: LinkExpression[]);
    /** Build a Perspective (with its query helpers) from the executor's wire shape. */
    static fromWire(wire: DecoratedPerspective | null): Perspective;
    static toWire(perspective: Perspective): WirePerspective;
    /** Convenience function for filtering links just like with PerspectiveProxy */
    get(query: LinkQuery): LinkExpression[];
    /** Convenience function to get the target of the first link that matches the given query
     * This makes sense when the query is expected to return only one link
     * and the target of that link is what you are looking for.
     */
    getSingleTarget(query: LinkQuery): string | void;
}
export declare class PerspectiveInput {
    links: LinkExpressionInput[];
}
export declare class PerspectiveUnsignedInput {
    links: LinkInput[];
    constructor(links?: LinkInput[]);
    static fromLink(link: Link): PerspectiveUnsignedInput;
}
declare const PerspectiveExpression_base: abstract new (author?: string, timestamp?: string, data?: Perspective, proof?: import("../expression/Expression").ExpressionProof) => import("../expression/Expression").ExpressionShape<Perspective, import("../expression/Expression").ExpressionProof>;
export declare class PerspectiveExpression extends PerspectiveExpression_base {
    static fromWire(wire: WirePerspectiveExpression): PerspectiveExpression;
}
export {};
