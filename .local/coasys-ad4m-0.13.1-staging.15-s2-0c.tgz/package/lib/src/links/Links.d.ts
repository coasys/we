import type { DecoratedLinkExpression } from "../generated/api/DecoratedLinkExpression";
import type { LinkExpression as WireLinkExpression } from "../generated/api/LinkExpression";
import type { LinkExpressionInput as WireLinkExpressionInput } from "../generated/api/LinkExpressionInput";
import type { LinkMutations as WireLinkMutations } from "../generated/api/LinkMutations";
import type { LinkStatus as WireLinkStatus } from "../generated/api/LinkStatus";
import type { PerspectiveLinkDiff } from "../generated/api/PerspectiveLinkDiff";
export declare class Link {
    source: string;
    target: string;
    predicate?: string;
    constructor(obj: any);
}
export declare class LinkMutations {
    additions: LinkInput[];
    removals: LinkExpressionInput[];
}
export declare class LinkExpressionMutations {
    additions: LinkExpression[];
    removals: LinkExpression[];
    constructor(additions: LinkExpression[], removals: LinkExpression[]);
    static fromWire(diff: PerspectiveLinkDiff): LinkExpressionMutations;
}
export declare class LinkInput {
    source: string;
    target: string;
    predicate?: string;
}
declare const LinkExpression_base: abstract new (author?: string, timestamp?: string, data?: Link, proof?: import("../expression/Expression").ExpressionProof) => import("../expression/Expression").ExpressionShape<Link, import("../expression/Expression").ExpressionProof>;
export declare class LinkExpression extends LinkExpression_base {
    hash(): number;
    status?: WireLinkStatus;
    /** Build a LinkExpression (with `hash()`) from the executor's wire shape. */
    static fromWire(wire: WireLinkExpression | DecoratedLinkExpression): LinkExpression;
}
declare const LinkExpressionInput_base: abstract new () => import("../expression/Expression").ExpressionShape<LinkInput, import("../expression/Expression").ExpressionProofInput>;
export declare class LinkExpressionInput extends LinkExpressionInput_base {
    hash: () => number;
    status?: WireLinkStatus;
}
export declare function linkExpressionToWire(link: LinkExpression): WireLinkExpression;
export declare function linkExpressionInputToWire(link: LinkExpressionInput): WireLinkExpressionInput;
export declare function linkMutationsToWire(mutations: LinkMutations): WireLinkMutations;
export declare function linkEqual(l1: LinkExpression, l2: LinkExpression): boolean;
export declare function isLink(l: any): boolean;
export declare class LinkExpressionUpdated {
    oldLink: LinkExpression;
    newLink: LinkExpression;
    constructor(oldLink: LinkExpression, newLink: LinkExpression);
}
export {};
