/**
 * Peer-to-peer WebRTC mesh transport for the AD4M SDK Session interface.
 *
 * Ported from WE Framework's call module (`mesh.ts` and `protocol.ts`), which
 * stays wire-compatible with it: a WE mesh peer and an SDK mesh peer in the
 * same call negotiate with each other.
 *
 * ## Mesh, not SFU
 *
 * Every participant connects to every other, so N participants means N−1
 * connections each and each peer uploads its video N−1 times. That caps at
 * roughly four to six peers before upstream bandwidth becomes the limit. The
 * SFU path (`SfuManager`) handles larger rooms; this path needs no server.
 *
 * ## Membership comes from the roster; this class only negotiates
 *
 * {@link MeshManager.setRoster} receives whoever presence says is in the call.
 * Connections are reconciled against it: appear → connect, disappear → tear
 * down. There is no join or leave message, because a peer that crashes never
 * sends one.
 *
 * ## Perfect negotiation
 *
 * Both peers see each other join at slightly different moments and both fire
 * `negotiationneeded`, so offers collide. Each pair has a **polite** peer and
 * an **impolite** one, decided by comparing DIDs, which needs no agreement
 * round-trip. On collision the impolite peer ignores the incoming offer and
 * the polite peer rolls back its own.
 *
 * ## The signalling channel is not reliable
 *
 * Perfect negotiation assumes a reliable ordered channel. Telepresence is
 * neither: the executor confirms it took a message and nothing confirms a peer
 * received it, sends are dispatched concurrently, and the first broadcast on a
 * freshly joined neighbourhood has been measured at eighteen seconds. Against
 * that, a lost offer deadlocks a pair, a candidate overtaking its description
 * gets discarded, and concurrent handling corrupts the state machine. Four
 * mechanisms fix that:
 *
 * 1. **Per-peer serialisation.** Signalling for one peer runs one message at a
 *    time ({@link MeshManager.enqueue}).
 * 2. **Candidate buffering.** Candidates arriving before a remote description
 *    wait for one.
 * 3. **A recovery ladder.** ICE restart → resend the description → rebuild the
 *    pair, escalating, on a sweep ({@link MeshManager.tick}).
 * 4. **A `reset` message**, so a rebuild is agreed rather than unilateral.
 *
 * ## Which connection a message is about
 *
 * A pair has many connections over its life — a rebuild, a reset, a peer that
 * reloads — and the two sides routinely disagree for a moment about which one
 * is current. Applied to the wrong connection, a description is refused by the
 * browser ("The order of m-lines in subsequent offer doesn't match order from
 * previous offer/answer"). So every connection names itself
 * ({@link PeerSlot.generation}) and every message says which connection sent it
 * and which it is for ({@link CallGenerations}). See {@link MeshManager.placeOf}.
 *
 * ## Who repairs
 *
 * Recovery uses the same tie-break as offers: the impolite peer acts first.
 * The polite peer runs the same ladder on a doubled deadline, which covers the
 * case where the impolite side has no slot for the pair at all.
 *
 * ## Signalling via telepresence
 *
 * SDP and ICE travel through the neighbourhood's telepresence channel
 * (`sendBroadcastU` / `addSignalHandler`). See {@link createTelepresenceChannel}.
 */
import type { PerspectiveExpression, PerspectiveUnsignedInput } from "../perspectives/Perspective";
import type { SfuDataMessage } from "./SfuTypes";
/**
 * Checked on receipt; a mismatch is dropped. New message kinds and the
 * generation fields were added without a bump: an old peer ignores a kind it
 * does not know and never reads the generations, so old and new peers still
 * converge. A bump would make them drop every message from each other.
 */
export declare const CALL_PROTOCOL_VERSION = 1;
/**
 * Which of the sender's connections a message comes from, and which of the
 * receiver's it is for. Both are optional; a message without them is read as
 * it was before generations existed.
 */
export interface CallGenerations {
    /** The sender's connection, an id it chose when it made the connection. */
    gen?: string;
    /** The receiver's connection as the sender last heard it named. */
    peerGen?: string;
}
export type CallBody = 
/**
 * `offer` numbers the offers of one connection: an offer carries its own,
 * an answer the one it answers. An answer to an offer this side has since
 * replaced is refused by the browser, so it is dropped instead. Optional:
 * a peer predating it sends none, and its answers apply as before.
 */
{
    kind: "description";
    description: RTCSessionDescriptionInit;
    offer?: number;
} | {
    kind: "ice";
    candidate: RTCIceCandidateInit;
}
/** Throw this pair's connection away and build a new one. */
 | {
    kind: "reset";
}
/** Application data, relayed over signalling because the mesh has no server. SDK-only. */
 | {
    kind: "data";
    label: string;
    data: string;
    binary: boolean;
}
/**
 * The sender is still in the call: sent to all on a timer by the session
 * (`MeshManager.beat`), reported as the `beat` event. Not persisted. An SDK
 * from before it parses it to nothing and drops it without a word.
 */
 | {
    kind: "beat";
};
export interface CallEnvelope extends CallGenerations {
    v: number;
    call: string;
}
export type CallMessage = CallEnvelope & CallBody;
/**
 * Narrow an untrusted payload off the transport.
 *
 * Everything arriving here was published by another agent, so it gets
 * shape-checked before use. The sender id comes from the transport rather
 * than the payload — a self-reported `from` would lack authentication.
 */
export declare function parseCallMessage(payload: unknown): CallMessage | null;
/** Structurally an ephemeral channel, restated so this module carries
 *  no import-time dependency on any particular transport. */
export interface SignallingChannel {
    publish(payload: unknown, to?: {
        agentId?: string;
    }): void;
    onMessage(cb: (from: string, payload: unknown) => void): () => void;
    /**
     * One result per publish, uncorrelated with the message. Optional: a
     * transport that cannot tell what became of a send must not pretend.
     * Where present, the mesh uses it to tell "the message was lost" from
     * "the message has not gone yet" — see {@link MeshManager.outstanding}.
     */
    onPublishResult?(cb: (result: {
        ok: boolean;
        ms: number;
    }) => void): () => void;
    /**
     * Settles once messages published from now on reach `onMessage`.
     * Optional: a transport that delivers from the moment `onMessage`
     * returns has nothing to wait for. A peer told about this one before it
     * listens would offer into the void until a repair resends.
     */
    listening?(): Promise<void>;
}
/** Minimal telepresence surface the channel bridge needs. */
export interface TelepresenceProxy {
    sendBroadcastU(status: PerspectiveUnsignedInput): Promise<boolean>;
    addSignalHandler(handler: (payload: PerspectiveExpression) => void): Promise<void>;
    removeSignalHandler(handler: (payload: PerspectiveExpression) => void): void;
}
/**
 * A mesh peer: one agent on one device. An agent calling from two devices is
 * two peers, each with its own connection to everyone else, so neither device's
 * media or teardown can stand in for the other's.
 */
export declare function meshPeerId(did: string, device: string): string;
/** The agent a mesh peer id belongs to. */
export declare function agentOfMeshPeer(peerId: string): string;
/**
 * Bridge NeighbourhoodProxy telepresence to the SignallingChannel
 * the mesh consumes, as the peer `selfDid` on `selfDevice`.
 *
 * ## Peers are devices
 *
 * The sender a message reports is a {@link meshPeerId}: the link's author,
 * which the executor verified, and the device the author's payload names. A
 * device is only the author's own claim, so it can tell this agent's devices
 * apart but never speak for another agent. Only this device's own echo is
 * dropped: a broadcast from another device of this agent — the executor hands
 * one to every client of the agent — is a peer like any other.
 *
 * ## Why unicast runs emulated over broadcast
 *
 * AD4M exposes real directed send (`sendSignalU`), but it remains
 * broken in current executor builds. This adapter addresses over
 * broadcast: the recipient DID goes in the link's `target` and
 * receivers drop anything not addressed to them. That provides
 * **addressing, not privacy** — every peer still receives the payload.
 */
export declare function createTelepresenceChannel(proxy: TelepresenceProxy, selfDid: string, selfDevice: string): SignallingChannel;
export type MeshEvent = "participant-joined" | "participant-left"
/** A participant's stream object or the liveness of its tracks changed:
 *  a rebuilt connection, or a remote track muted or unmuted. */
 | "participant-updated" | "stream-added" | "stream-removed"
/** `(did, RTCPeerConnectionState)` */
 | "peer-state"
/** `(did, { rung, attempts })` — a repair was attempted on this pair. */
 | "peer-recovery"
/** `(did)` — a peer of this call beat ({@link MeshManager.beat}), listed in the roster or not. */
 | "beat" | "error";
export type MeshEventCallback = (...args: any[]) => void;
/** Which rung of the recovery ladder an attempt was on. */
export type RecoveryRung = "ice-restart" | "resend" | "rebuild";
export interface MeshParticipant {
    did: string;
    stream: MediaStream;
    hasAudio: boolean;
    hasVideo: boolean;
    isActiveSpeaker: boolean;
}
export interface MeshManagerOptions {
    channel: SignallingChannel;
    callId: string;
    selfId: string;
    /** NAT traversal. Defaults to {@link DEFAULT_ICE_SERVERS} — public STUN, no TURN. */
    iceServers?: RTCIceServer[];
    /** Injected so tests can supply a fake. Receives the configuration the mesh decided on. */
    createPeerConnection?: (configuration: RTCConfiguration) => RTCPeerConnection;
    /** Injectable clock, so the recovery ladder is testable without waiting out real deadlines. */
    now?: () => number;
    /** How often the mesh looks at its own connections. `0` disables the timer;
     *  {@link MeshManager.tick} still works, which is how tests drive it. */
    sweepMs?: number;
    /** Called after a network change (see `ApiClient.onNetworkChange`): every
     *  pair restarts ICE then, rather than waiting for each to notice. */
    onNetworkChange?: (callback: () => void) => () => void;
    /** Called when a pair goes disconnected: checks the socket the signals
     *  go over now (see `ApiClient.checkConnection`). A dead one is redialled
     *  and `onNetworkChange` restarts every pair. */
    checkConnection?: () => void;
}
/** Public STUN, and no TURN. Two servers, because ICE queries them in parallel. */
export declare const DEFAULT_ICE_SERVERS: RTCIceServer[];
/**
 * How long a pair may sit unconnected before the impolite side intervenes.
 * Only has to outlast a healthy negotiation: a send still in flight defers
 * repair on its own (see {@link MeshManager.outstanding}).
 */
export declare const HANDSHAKE_GRACE_MS = 10000;
/** How long each rung of the ladder is given before escalating to the next. */
export declare const RECOVERY_INTERVAL_MS = 8000;
/**
 * How long `disconnected` is tolerated before an ICE restart. Shorter than the
 * others: `disconnected` often recovers by itself within a second or two.
 */
export declare const DISCONNECT_GRACE_MS = 5000;
/**
 * How many times a pair is repaired before the mesh stops and lets `failed`
 * stand. A pair that failed a full ladder four times needs TURN or a network,
 * and neither is fixed by a fifth attempt. Reset by a successful connection.
 */
export declare const MAX_RECOVERY_ATTEMPTS = 4;
/** How often the mesh looks at its own connections, when not driven by hand. */
export declare const SWEEP_INTERVAL_MS = 2000;
/**
 * The shortest gap between two repairs, whatever asks for them. A settled send
 * calls `tick` and a repair publishes, so without a floor the two chase each
 * other through every pair in the call. Below {@link SWEEP_INTERVAL_MS} so the
 * ordinary cadence is never throttled.
 */
export declare const REPAIR_SPACING_MS = 1500;
export declare class MeshManager {
    private channel;
    private callId;
    private selfId;
    private configuration;
    private createPeerConnection;
    private now;
    private sweepMs;
    private sweep;
    private callbacks;
    private slots;
    private states;
    private outbound;
    /** One stream for all outbound tracks, so a peer receives mic and camera grouped. */
    private outboundStream;
    private closed;
    private channelUnsubscribe;
    private unwatchPublish;
    private pending;
    /** The peer connections each peer has replaced. Kept past a slot, so a late message cannot revive one. */
    private retired;
    private dataListeners;
    /**
     * Sends published and not yet reported on. With an unreliable transport,
     * "the peer never answered" and "the message has not left yet" look the
     * same, and repairing the second piles sends onto a stalled executor. Stays
     * zero on a transport without `onPublishResult`.
     */
    private outstanding;
    /** When a sweep last repaired something — see {@link REPAIR_SPACING_MS}. */
    private lastRepairAt;
    /**
     * Repairs of a connected pair's unanswered renegotiation, per peer, kept
     * across rebuilds. A slot's `attempts` resets when its connection connects,
     * which a rebuilt pair does before it renegotiates again — so a peer that
     * never answers a renegotiation would be resent to and rebuilt forever.
     * Cleared only when a renegotiation is answered.
     */
    private renegotiationRepairs;
    private onNetworkChange;
    private unwatchNetwork;
    private checkConnection;
    constructor(options: MeshManagerOptions);
    on(event: MeshEvent, callback: MeshEventCallback): void;
    off(event: MeshEvent, callback?: MeshEventCallback): void;
    private emit;
    private fail;
    private participant;
    join(localStream: MediaStream): Promise<void>;
    leave(): Promise<void>;
    destroy(): Promise<void>;
    /**
     * Reconcile connections against who presence says belongs in the
     * call. Excludes this agent.
     */
    setRoster(peerIds: string[]): void;
    getParticipants(): MeshParticipant[];
    peerStates(): Map<string, RTCPeerConnectionState>;
    /**
     * Throw one pair's connection away and negotiate it again, telling the
     * peer to do the same. The manual rung of the ladder: reachable from either
     * side regardless of politeness, and it resets the automatic budget.
     */
    reconnect(peerId: string): void;
    /**
     * How this pair's media reaches the other end — `host` on a LAN, `srflx`
     * through NAT, `relay` through TURN — or `null` when nothing is connected.
     * Separates "this pair needs TURN" from "the handshake never finished".
     */
    transportOf(peerId: string): Promise<string | null>;
    /**
     * Replace the outbound track of a given kind on every peer connection.
     * Uses `RTCRtpSender.replaceTrack` on the sections declared up front, so
     * muting, unmuting and camera↔screen swaps never renegotiate. Pass `null`
     * to stop sending that kind.
     */
    replaceTrack(kind: "audio" | "video", track: MediaStreamTrack | null): Promise<void>;
    /**
     * Send data to all other participants via the signalling channel.
     * The mesh has no server-side relay — data rides the same
     * telepresence broadcast the SDP/ICE messages use.
     */
    sendData(label: string, data: string, binary?: boolean): void;
    /**
     * Tell every peer of the call that this one is still in it. Through
     * {@link publish}, so a beat's publish result is counted like any other
     * send. Nothing once the mesh has left.
     */
    beat(): void;
    subscribeDataChannel(callback: (msg: SfuDataMessage) => void): () => void;
    private handleData;
    /** Every publish goes through here, so {@link outstanding} counts exactly the reported ones. */
    private publish;
    /**
     * Addressed twice, on purpose: `to` on the publish lets a transport with
     * native unicast send to one peer, and `to` in the payload makes a
     * fanout-only transport filter on receipt.
     */
    private send;
    /** Which connections a message from this slot is between. */
    private stamp;
    private sendFrom;
    /** Send the connection's local description, numbered as {@link CallBody} describes. */
    private sendDescription;
    private retire;
    private connect;
    /** Close one pair's connection, without telling anyone it happened. */
    private disconnect;
    /** The peer left the call. */
    private removePeer;
    /**
     * Signalling that arrived before the roster caught up, kept until it does.
     *
     * A peer who denied the microphone has no outbound tracks, so it never
     * fires `negotiationneeded` again after its offer is dropped. It joined and
     * connected to nobody. Bounded on both axes, because this buffers messages
     * from agents the roster has not vouched for. Overflow drops the oldest.
     */
    private hold;
    /** Replay what this peer sent while we were still learning it belongs here. */
    private release;
    /** Put one message on this peer's queue. The chain never rejects — `handle` reports its own failures. */
    private enqueue;
    /**
     * Where a message stands against the connection this side holds for its sender.
     *
     * - `current` — from the peer connection this one talks to, or the first to
     *   name itself, or it names nothing (a peer predating generations).
     * - `stale` — for a connection of this side's that was replaced, or from
     *   one of the peer's that was. Nothing it says applies.
     * - `newer` — from a peer connection this side has not met: the peer has started over.
     */
    private placeOf;
    private handle;
    private flushCandidates;
    /**
     * Throw this pair away and start again. Attempts carry over to the new
     * slot, or a pair that rebuilds every time would never reach
     * {@link MAX_RECOVERY_ATTEMPTS}.
     */
    private rebuild;
    /**
     * One pair, one repair, on whichever rung its state calls for, cheapest first:
     *
     * 1. **ICE restart.** Keeps the connection and DTLS session; only
     *    re-gathers the transport. For `failed` and a `disconnected` that did
     *    not come back.
     * 2. **Resend the description.** For a handshake that never completed,
     *    which on this transport means a message was dropped — either half.
     * 3. **Rebuild.** When there is nothing to resend, or the rungs above were tried.
     */
    private repair;
    /**
     * The network changed: every pair's path is likely gone, though ICE has
     * noticed on none yet. Each negotiated pair takes the ladder's first rung
     * now, all at once — an ICE restart is one offer per pair, and waiting
     * for each to time out costs seconds of silence. Pairs still negotiating
     * have nothing to restart; the sweep keeps looking after them.
     *
     * It skips the sweep's guards (`outstanding`, one pair per sweep) on
     * purpose. They stop the sweep reading a slow send as a lost one and
     * escalating every pair at once. Here nothing is judged lost, and the
     * rung is the first one: one offer per pair, each to a different peer.
     * A restart offer that is lost falls to the sweep, guards and all.
     */
    private restartAll;
    /** Whether this pair has been given long enough, and whether it is this side's turn to act. */
    private dueForRepair;
    /**
     * Look at every connection and repair what is stuck. Driven by an internal
     * timer; public because tests drive it by hand.
     */
    tick(): void;
}
