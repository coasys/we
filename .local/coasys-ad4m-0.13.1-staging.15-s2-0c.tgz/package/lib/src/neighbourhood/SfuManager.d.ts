/**
 * SFU (Selective Forwarding Unit) client manager.
 *
 * Framework-agnostic WebRTC client for the AD4M executor's embedded
 * SFU.  Handles topology resolution, SDP negotiation, server-pushed
 * renegotiation, simulcast quality preferences, and reconnecting after
 * a failed connection.
 *
 * The client reaches one SFU: its own executor's. Multi-node calls work
 * through cascade pipes between executors, so the client never follows
 * a redirect or a rebalance to another node — it has no way to reach one.
 *
 * One session per device: a join names this device (`deviceId`), and the
 * executor gives it a participant id that every later call about the
 * session names. The same agent on another device is another participant;
 * a later join from this device — another tab — replaces this session, and
 * the manager stops (`replaced`) rather than taking the call back. Each
 * user join sends a random session key that the rebuilds of that call send
 * again; the executor refuses (409) a key another tab's join replaced, so a
 * tab that missed its `sfu-session-replaced` notice stops all the same.
 *
 * Applications (Flux, WE, or any other) wrap this class with their
 * own reactive store and UI layer.  The manager itself only touches
 * Web APIs (RTCPeerConnection, MediaStream) and the AD4M
 * neighbourhood RPC surface.
 */
import { NeighbourhoodProxy } from "./NeighbourhoodProxy";
import type { CallSessionInfo, SfuCallRenegotiationOffer, SfuConfig, SfuDataMessage, SfuQualityPreference, SfuRoomRoster, SfuSessionReplaced } from "./SfuTypes";
/** Minimal interface for the neighbourhood client methods the SFU
 *  manager calls.  NeighbourhoodClient satisfies this directly —
 *  pass the client through without an adapter. */
export interface SfuNeighbourhoodApi {
    sfuCallJoin(neighbourhoodUrl: string, roomName: string, sdpOffer: string, deviceId: string, sessionKey: string): Promise<CallSessionInfo>;
    sfuCallLeave(neighbourhoodUrl: string, roomName: string, participantId: string): Promise<boolean>;
    sfuCallSetQualityPreference(neighbourhoodUrl: string, roomName: string, participantId: string, preference: SfuQualityPreference): Promise<boolean>;
    sfuCallAnswerServerOffer(neighbourhoodUrl: string, roomName: string, participantId: string, sdpAnswer: string): Promise<boolean>;
    subscribeSfuCallRenegotiationOffer(targetDid: string, callback: (event: SfuCallRenegotiationOffer) => void): () => void;
    /** Ask the SFU to restart ICE on the session `participantId`; the offer
     *  arrives through `subscribeSfuCallRenegotiationOffer`. */
    sfuCallRestartIce(neighbourhoodUrl: string, roomName: string, participantId: string): Promise<boolean>;
    /** Called after a network change, once calls reach the executor again. */
    onNetworkChange(callback: () => void): () => void;
    /** Check the executor socket now; one found dead is redialled and
     *  `onNetworkChange` fires. Called when ICE goes disconnected, since a
     *  network switch the platform announced nothing for leaves that socket
     *  OPEN and dead, and the restart would go out on it. */
    checkConnection(): void;
    sfuAddIceCandidate(neighbourhoodUrl: string, roomName: string, participantId: string, candidate: string): Promise<boolean>;
    sfuSendData(neighbourhoodUrl: string, roomName: string, participantId: string, channelLabel: string, data: string, binary?: boolean): Promise<boolean>;
    subscribeSfuDataChannel(callback: (message: SfuDataMessage) => void): () => void;
    subscribeSfuRoomRoster(callback: (roster: SfuRoomRoster) => void): () => void;
    subscribeSfuSessionReplaced(callback: (event: SfuSessionReplaced) => void): () => void;
}
export type SfuTopology = "sfu" | "mesh" | "cascaded";
export interface SfuCallState {
    topology: SfuTopology;
    roomId: string;
    participantId: string | null;
    sfuPeerDid: string | null;
    participants: Map<string, SfuParticipantState>;
    localStream: MediaStream | null;
    peerConnection: RTCPeerConnection | null;
}
/** One session in the call: an agent on two devices is two participants. */
export interface SfuParticipantState {
    participantId: string;
    did: string;
    stream: MediaStream;
    hasAudio: boolean;
    hasVideo: boolean;
    isActiveSpeaker: boolean;
}
export type SfuEvent = "topology-changed" | "participant-joined" | "participant-left" | "active-speaker" | "stream-added" | "stream-removed"
/** `(SfuSessionReplaced)` — a later join from this device took the call over; this manager stopped. */
 | "replaced" | "error";
export type SfuEventCallback = (...args: any[]) => void;
/** ICE server configuration for SFU peer connections. */
export interface SfuIceConfig {
    /** Used as given, before `sfuConfig.iceServers`. */
    servers?: RTCIceServer[];
}
/**
 * This device's id for SFU calls, unless the app gives one. In a browser it
 * is kept in `localStorage`, which every tab of one profile shares, so the
 * tabs of one browser are one device; outside a browser (Node), the process
 * is the device.
 */
export declare function defaultDeviceId(): string;
/**
 * Determine the optimal call topology from the SFU config and the
 * current participant count.  Returns the topology, the DID of the
 * SFU peer to connect to (if any), and the full config.
 */
export declare function resolveTopology(neighbourhood: NeighbourhoodProxy, neighbourhoodUrl: string, participantCount: number): Promise<{
    topology: SfuTopology;
    sfuPeer: string | null;
    config: SfuConfig;
}>;
export declare class SfuManager {
    private neighbourhood;
    private neighbourhoodUrl;
    private roomId;
    private agentDid;
    /** The device this manager calls from: a later join from it replaces this session. */
    private deviceId;
    /** This call session's key: a rebuild joins with it again, a user's join
     *  makes a new one. The executor refuses a key a later join from this
     *  device replaced, so a tab that missed its notice cannot take the call back. */
    private sessionKey;
    private state;
    private callbacks;
    private iceServers;
    /** Reconnects since ICE last reached connected — not since a join: a
     *  join can succeed while the media path never comes up. */
    private reconnectAttempts;
    private static readonly MAX_RECONNECTS;
    /** How long one rebuild keeps retrying a join the executor cannot take yet. */
    private static readonly REJOIN_WINDOW_MS;
    /** The executor's wait before the first resend of an unanswered offer.
     *  `OFFER_RETRY_BASE` in `rust-executor/src/sfu/server.rs`. */
    private static readonly OFFER_RESEND_BASE_MS;
    /** How long ICE has to come back after that resend arrives. */
    private static readonly RESTART_AFTER_RESEND_MS;
    /** How long an ICE restart has to bring the connection back before a rebuild.
     *  The window stays open through the first resend, then the previous 5 s
     *  for ICE. A restart that connects clears the timer at once. */
    private static readonly RESTART_TIMEOUT_MS;
    /** A rebuild is running: a second failure signal joins it rather than starting another. */
    private reconnecting;
    /** Bumped by `leave()`, so a reconnect in flight stops before rejoining. */
    private generation;
    /** Which participant (session and agent) each received media section carries, from the server's mappings. */
    private midToParticipant;
    /** Participant ids the roster removed and has not listed since. */
    private departed;
    /** The sender of each kind of local media: declared at join, so a later camera or screen needs no renegotiation. */
    private senders;
    /** Tracks `replaceTrack` set since the user's join, for a rebuilt connection to send. */
    private replacedTracks;
    /** The last quality preference set, for a rebuilt connection to restore. */
    private qualityPreference;
    /** Server offers waiting to be applied, in arrival order, one at a time. */
    private offerQueue;
    /** The last server offer answered. The executor sends an unanswered
     *  restart offer again when asked twice; one that was answered meanwhile
     *  must not be answered again, or that answer lands on its next offer. */
    private answeredOffer;
    private renegotiationUnsubscribe;
    private rosterUnsubscribe;
    /** For the manager's call, not one join: a reconnect between its leave and its join still hears a notice. */
    private replacedUnsubscribe;
    /** Participant ids of this call a notice can still name: the current one, and any whose leave found it gone. */
    private heldIds;
    /** Settles when the latest join has its participant id, or failed. */
    private joinSettled;
    private dataChannelUnsubscribe;
    /** An ICE restart is in flight until this fires: ICE going disconnected
     *  again joins it, a network change replaces it. */
    private restartTimer;
    private networkUnsubscribe;
    /** Running while the room's roster leaves this session out: see `noticeRoster`. */
    private unlistedTimer;
    /** How long the roster may leave this session out before the call is rebuilt. */
    private static readonly UNLISTED_GRACE_MS;
    constructor(neighbourhood: SfuNeighbourhoodApi, roomId: string, agentDid: string, neighbourhoodUrl?: string, iceConfig?: SfuIceConfig, sfuConfig?: SfuConfig, 
    /** This device; unset, `defaultDeviceId()`. Apps outside a browser profile (Electron, tests) pass their own. */
    deviceId?: string);
    /**
     * Rebuild the call after its connection failed: leave, then join again
     * on this executor. Leaving first frees the old session's slot at once;
     * the join would replace it anyway, as it comes from this device.
     * Another tab's join can still replace the old session before the leave
     * lands: that notice stops the rebuild wherever it is, and a session its
     * join already got is left. A tab that missed the notice learns it from
     * the rejoin: the executor refuses the replaced session key (409), and
     * the manager stops as the notice would have stopped it, without retrying.
     *
     * Two budgets. A rebuild whose join works but whose connection fails
     * again counts once against `MAX_RECONNECTS`, reset when ICE connects.
     * Within one rebuild, a join that fails because the executor cannot be
     * reached — a restart, an outage — is retried with backoff for up to
     * `REJOIN_WINDOW_MS`, so the call comes back on its own once it can.
     */
    private reconnect;
    /**
     * Repair the connection in place: the SFU offers new ICE credentials
     * (`sfuCallRestartIce`), the offer is answered like any server offer,
     * and the browser gathers candidates on whatever network it has now.
     * DTLS, tracks and the room slot stay. If the connection is not back
     * within `RESTART_TIMEOUT_MS`, the call is rebuilt. One restart at a
     * time: a call while one is in flight does nothing.
     *
     * The restart names this manager's session, the participant id its
     * current join returned: the executor restarts that session only, never
     * another device's of the same agent. A manager with no session — its
     * join not back yet, between a rebuild's leave and join, left, or
     * replaced by another tab — sends nothing.
     */
    private restartIce;
    private endRestart;
    on(event: SfuEvent, callback: SfuEventCallback): void;
    off(event: SfuEvent, callback?: SfuEventCallback): void;
    private emit;
    /** Join the SFU call with simulcast support. */
    join(localStream: MediaStream): Promise<void>;
    /** Drop the server-event subscriptions of the current join. */
    private releaseServerEvents;
    private clearUnlistedTimer;
    /**
     * The room's roster no longer lists this session (its participant id)
     * while `pc` is the call's: the server has dropped this session, and ICE
     * may not say so. In E6 (CI job 53158) one of six sessions never started
     * a rebuild after a 20 s outage the server had dropped it for. The check
     * is per session, not per agent: another device of this agent keeps the
     * DID listed. Rebuild once the roster has left this session out for
     * `UNLISTED_GRACE_MS`; a roster that lists it again in that time
     * cancels, since one published just before this join landed can arrive
     * after it. A manager with no session (between leave and join, or
     * stopped because a later tab replaced it) starts no rebuild: `stop`
     * clears the timer and drops `pc`, so a replaced session never rejoins
     * and never takes the call back from the newer tab.
     */
    private noticeRoster;
    /**
     * Leave this manager's session on the executor, if it has one, and forget
     * it. Only the participant id a join returned is ever left: a manager
     * that never joined, or whose join was refused, sends nothing, so it can
     * never end a session another tab of this agent is in.
     */
    private leaveSession;
    /** Undo a join that failed part way: its subscriptions and its connection. */
    private abandon;
    /**
     * Subscribe to the server's events for this join: renegotiation offers
     * and the room roster. `join` calls this before `sfuCallJoin`: the
     * executor sends a socket only the events it watches, and a call
     * carries the pending watch ahead of itself, so no event the join
     * causes is lost. Offers wait for `joined` and then apply one at a
     * time, in arrival order; one that arrives for a connection already
     * replaced is dropped.
     */
    private subscribeServerEvents;
    /** Apply one server offer to `pc` and answer it, unless `pc` is no longer the call's. */
    private applyServerOffer;
    /**
     * Make the participants match `sessions`, the room's roster: everyone new
     * joins, and — when `complete`, as the roster event is — everyone
     * missing leaves. The join's own roster can lag the room, so it only adds.
     * This session is never a participant; this agent's other devices are.
     */
    private applyRoster;
    /** The participant for session `participantId` of `did`, joining them to the call if they are new. */
    private ensureParticipant;
    /**
     * A later join from this device replaced a session of this call: the
     * executor has already dropped it. Stop as `leave` does, but never
     * rejoin — the other tab has the call now — and say so with `replaced`.
     * A session this manager got since (a reconnect's) is left.
     */
    private stopReplaced;
    /** End this manager's call locally: no reconnect in flight continues, nothing is sent. */
    private stop;
    private refreshKinds;
    /** End the call: locally, and on the executor if this manager joined. */
    leave(): Promise<void>;
    /** Forget the call's participants, telling listeners each one left. */
    private resetParticipants;
    setQualityPreference(preference: SfuQualityPreference): Promise<void>;
    getState(): Readonly<SfuCallState>;
    getParticipants(): SfuParticipantState[];
    /**
     * Replace the outbound track of a given kind on the SFU peer connection.
     *
     * Both kinds were declared at join, so this is always
     * `RTCRtpSender.replaceTrack` — no renegotiation. Pass `null` to stop
     * sending that kind.
     */
    replaceTrack(kind: "audio" | "video", track: MediaStreamTrack | null): Promise<void>;
    /**
     * Send data to all other participants in the room via the SFU.
     * Text payloads pass as-is; binary payloads should arrive
     * base64-encoded with `binary: true`.
     */
    sendData(channelLabel: string, data: string, binary?: boolean): Promise<void>;
    /**
     * Subscribe to data channel messages from other participants — this
     * agent's other devices included, this session's own messages not.
     * Returns an unsubscribe function.  Only one subscription per
     * manager instance — a second call replaces the first.
     */
    subscribeDataChannel(callback: (message: SfuDataMessage) => void): () => void;
    destroy(): Promise<void>;
}
