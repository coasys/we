import { Perspective } from "../perspectives/Perspective";
export declare class Neighbourhood {
    linkLanguage: string;
    meta: Perspective;
    constructor(linkLanguage: string, meta: Perspective);
}
declare const NeighbourhoodExpression_base: abstract new (author?: string, timestamp?: string, data?: Neighbourhood, proof?: import("../expression/Expression").ExpressionProof) => import("../expression/Expression").ExpressionShape<Neighbourhood, import("../expression/Expression").ExpressionProof>;
export declare class NeighbourhoodExpression extends NeighbourhoodExpression_base {
}
export {};
