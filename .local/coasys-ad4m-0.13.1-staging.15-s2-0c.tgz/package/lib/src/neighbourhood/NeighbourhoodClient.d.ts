import { ApiClient, CallOptions } from '../apiClient';
import { Address } from "../Address";
import { DID } from "../DID";
import { OnlineAgent, TelepresenceSignalCallback } from "../language/Language";
import { Perspective, PerspectiveExpression, PerspectiveUnsignedInput } from "../perspectives/Perspective";
import { PerspectiveHandle } from "../perspectives/PerspectiveHandle";
import type { CallSessionInfo, SfuCallRenegotiationOffer, SfuCascadeStatus, SfuConfig, SfuDataMessage, SfuMigrateEvent, SfuParticipantQualityPreference, SfuQualityPreference, SfuRoomInfo, SfuRoomRoster, SfuSessionReplaced, SfuStatus } from "./SfuTypes";
export declare class NeighbourhoodClient {
    #private;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    publishFromPerspective(perspectiveUUID: string, linkLanguage: Address, meta: Perspective, options?: CallOptions): Promise<string>;
    joinFromUrl(url: string, options?: CallOptions): Promise<PerspectiveHandle>;
    otherAgents(perspectiveUUID: string): Promise<DID[]>;
    hasTelepresenceAdapter(perspectiveUUID: string): Promise<boolean>;
    onlineAgents(perspectiveUUID: string): Promise<OnlineAgent[]>;
    /** The caller's own online status, as it last set it on this executor, or `null`. */
    ownOnlineStatus(perspectiveUUID: string): Promise<PerspectiveExpression | null>;
    setOnlineStatus(perspectiveUUID: string, status: Perspective): Promise<boolean>;
    setOnlineStatusU(perspectiveUUID: string, status: PerspectiveUnsignedInput): Promise<boolean>;
    sendSignal(perspectiveUUID: string, remoteAgentDid: string, payload: Perspective): Promise<boolean>;
    sendSignalU(perspectiveUUID: string, remoteAgentDid: string, payload: PerspectiveUnsignedInput): Promise<boolean>;
    sendBroadcast(perspectiveUUID: string, payload: Perspective, loopback?: boolean): Promise<boolean>;
    sendBroadcastU(perspectiveUUID: string, payload: PerspectiveUnsignedInput, loopback?: boolean): Promise<boolean>;
    dispatchSignal(perspectiveUUID: string, signal: PerspectiveExpression): void;
    subscribeToSignals(perspectiveUUID: string): Promise<void>;
    addSignalHandler(perspectiveUUID: string, handler: TelepresenceSignalCallback): Promise<void>;
    removeSignalHandler(perspectiveUUID: string, handler: TelepresenceSignalCallback): void;
    sfuStartRoom(neighbourhoodUrl: string, roomName: string): Promise<SfuRoomInfo>;
    sfuStopRoom(neighbourhoodUrl: string, roomName: string): Promise<boolean>;
    sfuListRooms(): Promise<SfuRoomInfo[]>;
    /**
     * Join a call from `deviceId`. The executor replaces this agent's session
     * from the same device (another tab) and keeps those from other devices.
     * The result's `participantId` names the session in every later call.
     * `sessionKey` is the caller's random key for the session: a rebuild
     * sends it again; a key a later join from this device replaced is
     * refused with `RpcError` status 409, and that session must stop.
     */
    sfuCallJoin(neighbourhoodUrl: string, roomName: string, sdpOffer: string, deviceId: string, sessionKey: string): Promise<CallSessionInfo>;
    /** Leave the session `participantId`; `false` when it is not this agent's or is gone already. */
    sfuCallLeave(neighbourhoodUrl: string, roomName: string, participantId: string): Promise<boolean>;
    sfuCallSetQualityPreference(neighbourhoodUrl: string, roomName: string, participantId: string, preference: SfuQualityPreference): Promise<boolean>;
    sfuCallAnswerServerOffer(neighbourhoodUrl: string, roomName: string, participantId: string, sdpAnswer: string): Promise<boolean>;
    /** Ask the SFU to restart ICE on the session `participantId` (this
     *  agent's, as its join returned it; any other is refused). The offer
     *  arrives as an `sfu-call-renegotiation-offer` event for that session;
     *  answer it with {@link sfuCallAnswerServerOffer}. */
    sfuCallRestartIce(neighbourhoodUrl: string, roomName: string, participantId: string): Promise<boolean>;
    /** Fires after a network change, once the client's socket is back on
     *  the new network. See {@link ApiClient.onNetworkChange}. */
    onNetworkChange(callback: () => void): () => void;
    /** Check the client's socket now: one that says nothing within a
     *  deadline is treated as a network change. See {@link ApiClient.checkConnection}. */
    checkConnection(): void;
    sfuGetConfig(neighbourhoodUrl: string): Promise<SfuConfig>;
    sfuSetConfig(neighbourhoodUrl: string, config: SfuConfig): Promise<boolean>;
    sfuPeerForNeighbourhood(neighbourhoodUrl: string): Promise<string | null>;
    sfuPeersForNeighbourhood(neighbourhoodUrl: string): Promise<string[]>;
    /**
     * Add a remote ICE candidate to an existing SFU call.  Enables
     * trickle ICE: the client sends its SDP offer immediately after
     * `setLocalDescription` and then calls this method for each
     * candidate as it arrives, rather than waiting for gathering to
     * complete (which can take up to 8 seconds on restrictive
     * networks).
     */
    sfuAddIceCandidate(neighbourhoodUrl: string, roomName: string, participantId: string, candidate: string): Promise<boolean>;
    /**
     * Send data through the SFU to all other participants in the room.
     * The server relays it to their matching data channel and
     * publishes it as an `sfu-data` event.
     */
    sfuSendData(neighbourhoodUrl: string, roomName: string, participantId: string, channelLabel: string, data: string, binary?: boolean): Promise<boolean>;
    /**
     * Subscribe to SFU data channel messages.  Returns an unsubscribe
     * function.  Messages arrive for every participant in the room;
     * filter by `senderDid` or `senderParticipantId` if needed. One sent by
     * a session of this agent arrives here when the agent is in the call on
     * another device too: it carries the sending session's participant id.
     */
    subscribeSfuDataChannel(callback: (message: SfuDataMessage) => void): () => void;
    /** Subscribe to the rosters of the call rooms this agent is in: who is in each, by session, whenever that changes. */
    subscribeSfuRoomRoster(callback: (roster: SfuRoomRoster) => void): () => void;
    /**
     * Subscribe to the executor's notice that a session of this agent was
     * replaced: a later join from the same device took its call over. The
     * notice names the replaced session's participant id; the session that
     * holds it stops and does not rejoin.
     */
    subscribeSfuSessionReplaced(callback: (event: SfuSessionReplaced) => void): () => void;
    /**
     * Subscribe to server-pushed SFU SDP renegotiation offers.  The
     * server publishes an `sfu-call-renegotiation-offer` event every
     * time the relay's outbound track set changes for `targetDid`.
     * Callers apply the offer to their `RTCPeerConnection`, generate an
     * answer, and post it via `sfuCallAnswerServerOffer`.
     *
     * The executor already sends each socket only its own DID's offers;
     * this subscription additionally filters on `targetDid` for safety.
     * An agent in the call on two devices gets the offers of both: each
     * names the session it is for (`participantId`).
     * Returns an unsubscribe function.
     */
    subscribeSfuCallRenegotiationOffer(targetDid: string, callback: (payload: SfuCallRenegotiationOffer) => void): () => void;
    /**
     * Subscribe to cascade rebalance migration events for `targetDid`.
     * The server publishes an `sfu-migrate` event when the cascade
     * rebalancer decides a participant should move to a less-loaded
     * node.  Returns an unsubscribe function.
     */
    subscribeSfuMigrateEvent(targetDid: string, callback: (payload: SfuMigrateEvent) => void): () => void;
    /**
     * Whether every member of the neighbourhood is hosted on this
     * executor — the members its SFU can serve. A call's "auto" topology
     * uses the SFU only then: anyone else could not join the same room.
     *
     * @param perspectiveId  The neighbourhood's perspective handle UUID.
     */
    sfuServesAllMembers(perspectiveId: string): Promise<boolean>;
    /** The calling agent's own DID — the user's, for a user token. */
    callerDid(): Promise<string | null>;
    /**
     * Read-only: SFU service status including public reachability.
     * Returns whether this executor can relay media to remote
     * participants (public), sits behind NAT (nat), or could not
     * determine its reachability (unknown).
     */
    sfuStatus(): Promise<SfuStatus>;
    /**
     * Read-only: how many SFU↔SFU pipe transports are fully established,
     * plus the list of pipes.  Useful for diagnostics and wind-tunnel
     * assertions.
     */
    sfuCascadeStatus(): Promise<SfuCascadeStatus>;
    /**
     * Read-only: per-participant quality preferences the SFU event loop
     * currently holds.  Returns `[{participantId, preference}, ...]`.
     */
    sfuQualityPreferences(): Promise<SfuParticipantQualityPreference[]>;
    /**
     * Register a DID as a neighbourhood member on this executor.
     * In production the neighbourhood join flow handles this
     * automatically; this RPC exists for test harnesses and bridge
     * deployments.
     */
    sfuEnsureMembership(neighbourhoodUrl: string, did: string): Promise<boolean>;
}
