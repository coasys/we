import { SfuNeighbourhoodApi } from "./SfuManager";
import { type SignallingChannel } from "./MeshManager";
import type { OnlineAgent } from "../language/Language";
import type { SfuConfig, SfuDataMessage, SfuQualityPreference, SfuParticipantInfo, SfuStatus, IceServer } from "./SfuTypes";
export type SessionTopology = "mesh" | "sfu" | "auto";
export type SessionState = "idle" | "joining" | "active" | "leaving" | "closed";
export type SessionEvent = "topology-changed" | "participant-joined" | "participant-left" | "active-speaker" | "stream-added" | "stream-removed"
/** `(participant)` — a participant's stream object or track liveness changed. Mesh only. */
 | "participant-updated"
/** `(did, RTCPeerConnectionState)` — one pair's connection state. Mesh only. */
 | "peer-state"
/** `(did, { rung, attempts })` — the mesh attempted a repair on this pair. */
 | "peer-recovery" | "state-changed"
/**
 * `(SfuSessionReplaced)` — the call was joined again from this device (another tab), and
 * that join took it over: this session's call has ended, and it is idle again.
 */
 | "replaced" | "error";
export type SessionEventCallback = (...args: any[]) => void;
/** Unified WebRTC media session wrapping both mesh and SFU topologies. */
export interface Session {
    /**
     * Connect to the room with local media. Resolves when the session becomes active, or
     * idle if another tab on this device replaced the call while it joined (`replaced`).
     */
    join(localStream: MediaStream): Promise<void>;
    /** Disconnect from the room. The session returns to idle and can rejoin. */
    leave(): Promise<void>;
    /** Current participants in the room (excluding this session; this agent's other devices included). */
    readonly participants: ReadonlyArray<SfuParticipantInfo>;
    /** Subscribe to incoming remote media tracks. Returns an unsubscribe function. */
    onTrack(cb: (stream: MediaStream, track: MediaStreamTrack) => void): () => void;
    /**
     * Replace the outbound track of a given kind on all peer connections.
     *
     * Uses `RTCRtpSender.replaceTrack` — no renegotiation, so camera↔screen
     * swaps and mute/unmute are instant and atomic across all peers.
     * Pass `null` to stop sending that kind without tearing down the transceiver.
     */
    replaceTrack(kind: "audio" | "video", track: MediaStreamTrack | null): Promise<void>;
    /** Set the preferred simulcast quality layer. */
    setQualityPreference(pref: SfuQualityPreference): Promise<void>;
    /** Send data to all other participants via the SFU relay. */
    sendData(label: string, data: string, binary?: boolean): Promise<void>;
    /** Subscribe to data channel messages from other participants. Returns an unsubscribe function. */
    onData(cb: (message: SfuDataMessage) => void): () => void;
    /** Current lifecycle state. */
    getState(): SessionState;
    /** Subscribe to session events. */
    on(event: SessionEvent, cb: SessionEventCallback): void;
    /** Unsubscribe from session events. Omit cb to remove all listeners for the event. */
    off(event: SessionEvent, cb?: SessionEventCallback): void;
    /** Each mesh peer's connection state. Empty on the SFU path, which has one connection. */
    peerStates(): Map<string, RTCPeerConnectionState>;
    /** Rebuild one mesh peer's connection, telling the peer to do the same. No-op on the SFU path. */
    reconnect(did: string): void;
    /** How a mesh peer's media travels — `host`, `srflx` or `relay` — or `null`. */
    transportOf(did: string): Promise<string | null>;
    /** Release all resources. Calls leave() if still active. */
    destroy(): Promise<void>;
}
export interface SessionCreateOptions {
    topology?: SessionTopology;
    neighbourhoodUrl?: string;
    /** The neighbourhood's call config. With `topology: "auto"`, its mode decides: any SFU mode
     *  runs through the SFU, `mesh` stays peer-to-peer. Passing one is the app's statement that
     *  every member reaches the same SFU. */
    sfuConfig?: SfuConfig;
    /** NAT traversal for both paths, each server as given. Takes precedence over `sfuConfig.iceServers`. */
    iceServers?: IceServer[];
    /**
     * The device this session calls from: a join from the same device replaces this agent's
     * earlier session (another tab); another device joins beside it, as a participant of its own.
     * Unset, the browser profile's id (`localStorage`), or one per process outside a browser.
     */
    deviceId?: string;
}
interface SessionImplConfig {
    api: SfuNeighbourhoodApi;
    roomId: string;
    agentDid: string;
    neighbourhoodUrl: string;
    topology: SessionTopology;
    sfuConfig?: SfuConfig;
    iceServers?: IceServer[];
    /** See `SessionCreateOptions.deviceId`. */
    deviceId?: string;
    /** Signalling channel for mesh topology — required when topology resolves to mesh. It must
     *  speak as this session's peer, {@link meshPeerId} of `agentDid` and the device. */
    channel?: SignallingChannel;
    /** Publish call-presence via telepresence.  The session broadcasts
     *  membership so other agents' roster polls can discover it. */
    setOnlineStatus?: (status: {
        links: StatusLink[];
    }) => Promise<boolean>;
    /** This agent's current online status. The session adds its presence
     *  link and marker to it at join and takes them out again at leave,
     *  leaving the app's own links and the presence of this agent's other
     *  live devices — which the mesh roster reads from here too. A device of
     *  this agent that stopped beating is taken out once, by the poll that
     *  finds it stale. */
    ownOnlineStatus?: () => Promise<{
        data?: {
            links?: {
                data?: Partial<StatusLink>;
            }[];
        };
    } | null>;
    /** Poll for agents currently online in the neighbourhood.  The
     *  session reconciles the result against its mesh connections. */
    onlineAgents?: () => Promise<OnlineAgent[]>;
    /** Local executor's SFU status. "auto" needs `isPublic`: clients
     *  that are not on the executor's machine must reach its SFU. */
    localSfuStatus?: SfuStatus;
    /** Whether every member of the neighbourhood is hosted on the local
     *  executor, so all of them reach its SFU. "auto" picks the SFU only
     *  when this resolves true. */
    sfuServesAllMembers?: () => Promise<boolean>;
}
type StatusLink = {
    source: string;
    predicate?: string;
    target: string;
};
export declare function createSession(config: SessionImplConfig): Session;
export {};
