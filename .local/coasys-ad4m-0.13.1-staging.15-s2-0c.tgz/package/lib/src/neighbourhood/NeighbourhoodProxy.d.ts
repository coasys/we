import { DID } from "../DID";
import { OnlineAgent } from "../language/Language";
import { Perspective, PerspectiveExpression, PerspectiveUnsignedInput } from "../perspectives/Perspective";
import { NeighbourhoodClient } from "./NeighbourhoodClient";
import type { CallSessionInfo, SfuCallRenegotiationOffer, SfuCascadeStatus, SfuConfig, SfuDataMessage, SfuMigrateEvent, SfuParticipantQualityPreference, SfuQualityPreference, SfuRoomInfo, SfuSessionReplaced } from "./SfuTypes";
import { type Session, type SessionCreateOptions } from "./Session";
export declare class NeighbourhoodProxy {
    #private;
    constructor(client: NeighbourhoodClient, pID: string, agentDid?: string);
    /** List DIDs of agents who have joined this neighbourhood. */
    otherAgents(): Promise<DID[]>;
    /** Check whether the neighbourhood's link language supports telepresence. */
    hasTelepresenceAdapter(): Promise<boolean>;
    /** List agents currently online in this neighbourhood. */
    onlineAgents(): Promise<OnlineAgent[]>;
    /** This agent's own online status, as it last set it on this executor, or `null`. */
    ownOnlineStatus(): Promise<PerspectiveExpression | null>;
    /** Set this agent's online status with a signed perspective payload. */
    setOnlineStatus(status: Perspective): Promise<boolean>;
    /** Set this agent's online status with an unsigned perspective payload. */
    setOnlineStatusU(status: PerspectiveUnsignedInput): Promise<boolean>;
    /** Send a signed signal to a specific remote agent via the link language. */
    sendSignal(remoteAgentDid: string, payload: Perspective): Promise<boolean>;
    /** Send an unsigned signal to a specific remote agent via the link language. */
    sendSignalU(remoteAgentDid: string, payload: PerspectiveUnsignedInput): Promise<boolean>;
    /**
     * Broadcast a signed signal to all agents in the neighbourhood. The
     * sender's own agent gets it too (its other clients hear it), so a handler
     * that must not act on its own messages drops them by author or device;
     * `loopback` adds a second copy for the sender's executor.
     */
    sendBroadcast(payload: Perspective, loopback?: boolean): Promise<boolean>;
    /** Broadcast an unsigned signal to all agents in the neighbourhood; delivered as {@link sendBroadcast}. */
    sendBroadcastU(payload: PerspectiveUnsignedInput, loopback?: boolean): Promise<boolean>;
    /** Register a handler for incoming telepresence signals. */
    addSignalHandler(handler: (payload: PerspectiveExpression) => void): Promise<void>;
    /** Remove a previously registered signal handler. */
    removeSignalHandler(handler: (payload: PerspectiveExpression) => void): void;
    /** Active sessions in this neighbourhood. Destroyed sessions remove themselves. */
    get sessions(): ReadonlyArray<Session>;
    /**
     * Create a WebRTC media session.  Call `session.join(localStream)` to connect.
     *
     * Fetches the local executor's SFU status (cached after the first
     * call): with `topology: "auto"`, a session uses the SFU only when it
     * is public and hosts every member of the neighbourhood.
     */
    createSession(roomName: string, options?: SessionCreateOptions): Promise<Session>;
    sfuConfig(neighbourhoodUrl: string): Promise<SfuConfig>;
    setSfuConfig(neighbourhoodUrl: string, config: SfuConfig): Promise<boolean>;
    sfuPeer(neighbourhoodUrl: string): Promise<string | null>;
    sfuPeers(neighbourhoodUrl: string): Promise<string[]>;
    sfuStartRoom(neighbourhoodUrl: string, roomName: string): Promise<SfuRoomInfo>;
    sfuStopRoom(neighbourhoodUrl: string, roomName: string): Promise<boolean>;
    sfuListRooms(): Promise<SfuRoomInfo[]>;
    /** Join from `deviceId`: a join from the same device replaces this agent's session there. */
    callJoin(neighbourhoodUrl: string, roomName: string, sdpOffer: string, deviceId: string, sessionKey: string): Promise<CallSessionInfo>;
    /** Leave the session `participantId` (the join's). */
    callLeave(neighbourhoodUrl: string, roomName: string, participantId: string): Promise<boolean>;
    callSetQualityPreference(neighbourhoodUrl: string, roomName: string, participantId: string, preference: SfuQualityPreference): Promise<boolean>;
    callAnswerServerOffer(neighbourhoodUrl: string, roomName: string, participantId: string, sdpAnswer: string): Promise<boolean>;
    /**
     * Subscribe to the executor's notices that a session of this agent was
     * replaced by a later join from the same device. Returns an unsubscribe
     * function.
     */
    subscribeSessionReplaced(callback: (event: SfuSessionReplaced) => void): () => void;
    /**
     * Subscribe to server-pushed renegotiation offers for `targetDid`.
     * Returns an unsubscribe function.  See
     * `NeighbourhoodClient.subscribeSfuCallRenegotiationOffer` for the
     * underlying mechanism.
     */
    subscribeCallRenegotiationOffer(targetDid: string, callback: (payload: SfuCallRenegotiationOffer) => void): () => void;
    /**
     * Subscribe to cascade rebalance migration events for `targetDid`.
     * Returns an unsubscribe function.
     */
    subscribeMigrateEvent(targetDid: string, callback: (event: SfuMigrateEvent) => void): () => void;
    addIceCandidate(neighbourhoodUrl: string, roomName: string, participantId: string, candidate: string): Promise<boolean>;
    sendData(neighbourhoodUrl: string, roomName: string, participantId: string, channelLabel: string, data: string, binary?: boolean): Promise<boolean>;
    subscribeDataChannel(callback: (message: SfuDataMessage) => void): () => void;
    sfuCascadeStatus(): Promise<SfuCascadeStatus>;
    sfuQualityPreferences(): Promise<SfuParticipantQualityPreference[]>;
    sfuEnsureMembership(neighbourhoodUrl: string, did: string): Promise<boolean>;
}
