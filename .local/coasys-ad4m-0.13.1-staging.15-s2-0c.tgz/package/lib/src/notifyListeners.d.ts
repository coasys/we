/** Call `callback`. A throw, or a rejected promise from an async callback, is logged, not raised. */
export declare function callSafely<A extends unknown[]>(callback: (...args: A) => unknown, label: string, ...args: A): void;
