import type { ModelType } from "../generated/api/ModelType";
/** A model onboarding offers to set up, by the id its server knows it by. */
export interface RecommendedModel {
    modelType: ModelType;
    /** Ollama's name for it: `ai.pullModel` fetches it onto an Ollama endpoint. */
    ollama?: string;
    /** The id an OpenAI-shaped audio server (speaches) knows it by. */
    openAiAudio?: string;
    /** One line for the person choosing. */
    description: string;
}
/**
 * The models onboarding recommends, the one place they are named: a 4-8B instruct model
 * that calls tools, an embedding model, and a transcription model. Any model the servers
 * serve works; these are the defaults a fresh setup offers.
 */
export declare const AI_RECOMMENDED_MODELS: readonly RecommendedModel[];
/** Where to get a model server when none runs on this machine. */
export declare const AI_SERVER_INSTALL_LINKS: {
    readonly ollama: "https://ollama.com/download";
    readonly speaches: "https://speaches.ai/installation/";
};
