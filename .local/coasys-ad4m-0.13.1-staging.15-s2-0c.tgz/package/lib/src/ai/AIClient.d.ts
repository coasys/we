import { ApiClient, CallOptions } from '../apiClient';
import { AITask } from "./Tasks";
import type { AiDiscoverModelsParams, AiEndpoint, AiEndpointInput, DetectedEndpoint, DiscoveredModel, LocalAiHardware, LocalAiInstallParams, LocalAiPlan, LocalAiProgress, LocalAiStatus, Model, ModelInput, ModelStatus, ModelType } from "./AITypes";
import type { AISession } from "../generated/api/AISession";
import type { AISessionChanged } from "../generated/api/AISessionChanged";
import type { AISessionMessage } from "../generated/api/AISessionMessage";
import type { AISessionSendStarted } from "../generated/api/AISessionSendStarted";
import type { Capability } from "../generated/api/Capability";
/** The fields a session's create and update take. A field left out keeps its value on an
 *  update (and takes the default on a create); a nullable one is cleared with `null`. */
export interface AISessionInput {
    title?: string;
    model?: string | null;
    defaultPerspective?: string | null;
    libraryPerspective?: string | null;
    capabilities?: Capability[];
}
/** How long `localInstall` waits by default: a first install downloads gigabytes. */
export declare const LOCAL_INSTALL_TIMEOUT_MS: number;
export declare class AIClient {
    #private;
    constructor(baseUrl: string, token?: string, sharedApiClient?: ApiClient);
    /** Every model, each on its endpoint, with where it stands by the endpoint's last check. */
    getModels(): Promise<Model[]>;
    /**
     * The models a server lists, with their capabilities: a saved endpoint by
     * `{ endpointId }`, or a server not saved yet by `{ kind, baseUrl, apiKey? }`.
     *
     * Rejects when the server is unreachable or the key is refused, which makes this the
     * credential check too: without it a bad key surfaces later as a failed completion
     * carrying an error from a different layer.
     */
    discoverModels(params: AiDiscoverModelsParams): Promise<DiscoveredModel[]>;
    /**
     * The upstream model servers this executor uses, with their health. Operator only:
     * a managed user's session is refused. Keys never come back: `hasApiKey` says
     * whether one is set.
     */
    endpoints(): Promise<AiEndpoint[]>;
    /**
     * Register an upstream server. The executor lists its models once first: the answer
     * carries the endpoint's health, and its capabilities when `capabilities` is left out.
     * It saves an endpoint that does not answer yet.
     */
    addEndpoint(endpoint: AiEndpointInput): Promise<AiEndpoint>;
    /**
     * Replace an endpoint's settings. Without `apiKey` the stored key stays, and the update
     * is refused if `baseUrl` changes too. The models on the endpoint follow it.
     */
    updateEndpoint(id: string, endpoint: AiEndpointInput): Promise<AiEndpoint>;
    /** Remove an endpoint. Refused while models run on it, unless `cascade` removes them too. */
    removeEndpoint(id: string, cascade?: boolean): Promise<boolean>;
    /** Model servers running on the executor's machine (loopback ports). Nothing is saved. */
    detectEndpoints(): Promise<DetectedEndpoint[]>;
    /**
     * Pull a model onto an Ollama endpoint. Resolves when the pull is done; progress
     * arrives as `model-status` events.
     */
    pullModel(endpointId: string, remoteModel: string, options?: CallOptions): Promise<boolean>;
    /** Delete a model from an Ollama endpoint. Refused while a model uses it. */
    deleteUpstreamModel(endpointId: string, remoteModel: string): Promise<boolean>;
    /**
     * The executor's device: OS, CPU, RAM, GPUs, the backends a runtime can use, the memory
     * budget the models must fit, and the hardware class. Not for managed users.
     */
    localHardware(): Promise<LocalAiHardware>;
    /**
     * What `localInstall` would set up on this device: the runtime builds and models per
     * service, the download size, and whether it fits (with the reasons when not).
     */
    localPlan(): Promise<LocalAiPlan>;
    /**
     * Download the plan's runtimes and models into the per-user store (resumable, sha256
     * checked), start them and register them as managed endpoints, models and defaults.
     * Resolves when it is done, which takes minutes the first time; `onProgress` gets the
     * `ai-local-progress` events meanwhile. Operator only (the admin credential).
     */
    localInstall(params?: LocalAiInstallParams, onProgress?: (progress: LocalAiProgress) => void, options?: CallOptions): Promise<LocalAiStatus>;
    /** What local AI has installed for this executor and how its runtimes run. */
    localStatus(): Promise<LocalAiStatus>;
    /** Start the installed runtimes (they also start with the executor). Operator only. */
    localStart(options?: CallOptions): Promise<LocalAiStatus>;
    /** Stop the runtimes; their endpoints and models stay, down. Operator only. */
    localStop(): Promise<LocalAiStatus>;
    /**
     * Stop the runtimes and remove their endpoints and models. `deleteFiles` also deletes
     * the downloaded runtimes and models, which other agents of this user may share.
     * Operator only.
     */
    localRemove(deleteFiles?: boolean): Promise<boolean>;
    /**
     * Register an upstream model on an endpoint, by the id the endpoint knows it by. Refused
     * when the endpoint does not exist or cannot serve the type (embeddings on Anthropic).
     * Answers the new model's id.
     */
    addModel(model: ModelInput, options?: CallOptions): Promise<string>;
    updateModel(modelId: string, model: ModelInput): Promise<boolean>;
    removeModel(modelId: string): Promise<boolean>;
    setDefaultModel(modelType: ModelType, modelId: string): Promise<boolean>;
    getDefaultModel(modelType: ModelType): Promise<Model | null>;
    tasks(): Promise<AITask[]>;
    addTask(name: string, modelId: string, systemPrompt: string, promptExamples: {
        input: string;
        output: string;
    }[], metaData?: string): Promise<AITask>;
    removeTask(taskId: string): Promise<boolean>;
    updateTask(taskId: string, task: AITask): Promise<AITask>;
    /** Where a model stands by its endpoint's last health check (`READY`, `MISSING`, ...). */
    modelStatus(modelId: string): Promise<ModelStatus>;
    prompt(taskId: string, prompt: string, options?: CallOptions): Promise<string>;
    embed(modelId: string, text: string, options?: CallOptions): Promise<Array<number>>;
    /**
     * Open a transcription stream on a TRANSCRIPTION model. Feed it one utterance at a time
     * (the caller decides where speech starts and ends; the executor drops an utterance its
     * speech gate does not take as speech); each utterance's text arrives at
     * `streamCallback`, in the order fed.
     */
    openTranscriptionStream(modelId: string, streamCallback: (text: string) => void): Promise<string>;
    closeTranscriptionStream(streamId: string): Promise<void>;
    /**
     * Feed an audio utterance (16 kHz mono) to one or more transcription streams.
     * Sends raw binary Float32Array as application/octet-stream. On a model served by an
     * endpoint this resolves once the utterance is transcribed, and rejects when the upstream
     * failed (nothing is published then).
     * NOTE: This method still uses HTTP fetch because binary audio data
     * cannot be efficiently sent over the JSON-based WebSocket RPC protocol.
     * Transcription results are delivered via the WS event channel.
     *
     * Rejects if any stream did not take the audio. When only some failed, the message names them
     * and the others were fed, so retry only the failed ids.
     */
    feedTranscriptionStream(streamIds: string | string[], audio: Float32Array | number[]): Promise<void>;
    /** Creates a session. `capabilities` absent: everything the caller holds. */
    sessionCreate(input?: AISessionInput): Promise<AISession>;
    sessionList(): Promise<AISession[]>;
    session(id: string): Promise<AISession>;
    /** A field left out keeps its value; a nullable one (`model`, `defaultPerspective`,
     *  `libraryPerspective`) is cleared with `null`. Capabilities can only be narrowed
     *  to what the caller holds. */
    sessionUpdate(id: string, update: AISessionInput): Promise<AISession>;
    sessionDelete(id: string): Promise<boolean>;
    /** Stores the user's message and starts the turn as a detached task; returns the ids
     *  of the message and of the `running` reply. Follow it with {@link onSessionChanged}. */
    sendMessage(sessionId: string, text: string): Promise<AISessionSendStarted>;
    cancelTurn(sessionId: string): Promise<boolean>;
    /** The transcript, newest entries last. `before` pages older than a `seq`. */
    sessionMessages(sessionId: string, options?: {
        limit?: number;
        before?: number;
    }): Promise<AISessionMessage[]>;
    /** `handler` gets every change to a session the caller owns: a new message, a status
     *  change, each tool step. Returns the unsubscribe function. */
    onSessionChanged(handler: (event: AISessionChanged) => void): () => void;
}
