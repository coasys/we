export declare class AIPromptExamplesInput {
    input: string;
    output: string;
    constructor(input: string, output: string);
}
export declare class AIPromptExamples {
    input: string;
    output: string;
    constructor(input: string, output: string);
}
export declare class AITaskInput {
    name: string;
    modelId: string;
    systemPrompt: string;
    promptExamples: AIPromptExamplesInput[];
    metaData: string;
    constructor(name: string, model_id: string, system_prompt: string, prompt_examples: AIPromptExamplesInput[], metaData?: string);
}
export declare class AITask {
    name: string;
    modelId: string;
    taskId: string;
    systemPrompt: string;
    promptExamples: AIPromptExamples[];
    metaData?: string;
    createdAt: string;
    updatedAt: string;
    constructor(name: string, model_id: string, task_id: string, system_prompt: string, prompt_examples: AIPromptExamples[], metaData?: string, created_at?: string, updated_at?: string);
}
