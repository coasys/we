import { AgentClient } from './agent/AgentClient';
import { LanguageClient } from './language/LanguageClient';
import { NeighbourhoodClient } from './neighbourhood/NeighbourhoodClient';
import { PerspectiveClient } from './perspectives/PerspectiveClient';
import { RuntimeClient } from './runtime/RuntimeClient';
import { ExpressionClient } from './expression/ExpressionClient';
import { AIClient } from './ai/AIClient';
import { IdentityClient } from './identity/IdentityClient';
import { EventFilter } from './apiClient';
import type { EventMap, EventName } from './generated/api/Events';
/**
 * Client for the Ad4m interface wrapping WebSocket RPC calls
 * for convenient use in user facing code.
 *
 * Aggregates the six sub-clients:
 * AgentClient, ExpressionClient, LanguageClient,
 * NeighbourhoodClient, PerspectiveClient and RuntimeClient
 * for the respective functionality.
 *
 * {@link Ad4mClient.on} receives executor events from the moment of registration.
 */
export declare class Ad4mClient {
    #private;
    constructor(baseUrl: string, token?: string, options?: {
        webSocketImpl?: new (url: string) => WebSocket;
        fetchImpl?: typeof fetch;
    });
    get agent(): AgentClient;
    get expression(): ExpressionClient;
    get languages(): LanguageClient;
    get neighbourhood(): NeighbourhoodClient;
    get perspective(): PerspectiveClient;
    get runtime(): RuntimeClient;
    get ai(): AIClient;
    /** The executor's identity calls (`did:scid:coasys:1`). */
    get identity(): IdentityClient;
    /**
     * Call `handler` with every `type` event, or only those about
     * `filter.perspective`. The payload is typed by the executor's event
     * table (`generated/api/Events.ts`). Returns a function that removes the
     * handler.
     */
    on<K extends EventName>(type: K, handler: (event: EventMap[K]) => void, filter?: EventFilter): () => void;
    /**
     * Call `callback` once when the executor refuses this client's token
     * (expired, revoked, or no session). Every call then fails with a 401
     * `RpcError` and the client stops reconnecting: log in again and build a
     * new client. Returns a function that removes the callback.
     */
    onAuthFailed(callback: (reason: string) => void): () => void;
    /**
     * Reconnect now if the connection to the executor dropped and the client is
     * waiting out its backoff: for a host that knows the executor is back (it
     * restarted it, or the device woke). A no-op while connected or connecting.
     */
    reconnectNow(): void;
    /** Close all event connections and clear in-memory caches */
    close(): void;
}
