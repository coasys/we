import { Link } from "../links/Links";
import type { NodeExpression } from "./NodeExpression";
import type { ShapeJson } from "../generated/api/ShapeJson";
/**
 * AD4M Action - represents a link operation
 */
export interface AD4MAction {
    action: string;
    source: string;
    predicate: string;
    target: string;
    local?: boolean;
}
/**
 * A single structured conformance condition for relation filtering.
 * DB-agnostic representation that can be translated to any query language.
 */
export interface ConformanceCondition {
    /** Type of check: 'flag' (predicate + value) or 'required' (predicate exists) */
    type: 'flag' | 'required';
    /** The predicate URI to check on the target node */
    predicate: string;
    /** For 'flag' conditions: the expected value */
    value?: string;
}
/**
 * SHACL Property Shape
 * Represents constraints on a single property path
 */
export interface SHACLPropertyShape {
    /** Property name (e.g., "name", "ingredients") - used for generating named URIs */
    name?: string;
    /** The property path (predicate URI) */
    path: string;
    /** Expected datatype (e.g., xsd:string, xsd:integer) */
    datatype?: string;
    /**
     * CRDT ordering strategy for this collection ("linkedList"), when it has one.
     *
     * Declared in the shape rather than passed per query so the executor applies
     * it to every writer — the ORM, MCP agents, raw WS-RPC callers, another app
     * on the same neighbourhood.
     */
    ordering?: string;
    /** Node kind constraint (IRI, Literal, BlankNode) */
    nodeKind?: 'IRI' | 'Literal' | 'BlankNode';
    /** Minimum cardinality (required if >= 1) */
    minCount?: number;
    /** Maximum cardinality (single-valued if 1, omit for collections) */
    maxCount?: number;
    /** Regex pattern for string validation */
    pattern?: string;
    /** Minimum value (inclusive) for numeric properties */
    minInclusive?: number;
    /** Maximum value (inclusive) for numeric properties */
    maxInclusive?: number;
    /** Fixed value constraint (for Flag properties) */
    hasValue?: string;
    /** AD4M-specific: Local-only property */
    local?: boolean;
    /** AD4M-specific: Writable property */
    writable?: boolean;
    /** AD4M-specific: sole selector of storage mode:
     *   - unset               → deterministic typed literal (fast POS-index
     *                            path, the default for a plain `@Property()`).
     *   - `"literal"`         → signed envelope on the built-in literal
     *                            language (per-value provenance, e.g. Flux
     *                            message bodies).
     *   - `<custom address>`  → `expression_create` on that custom language. */
    resolveLanguage?: string;
    /** AD4M-specific: Setter action for this property */
    setter?: AD4MAction[];
    /** AD4M-specific: Adder action for collection properties */
    adder?: AD4MAction[];
    /** AD4M-specific: Remover action for collection properties */
    remover?: AD4MAction[];
    /** AD4M-specific: Pre-computed SPARQL getter expression for reading this relation/property.
     *  For relations with a target model, this encodes conformance filtering
     *  so that Rust/MCP can execute the exact same query as the JS runtime. */
    getter?: string;
    /** AD4M-specific: Structured conformance conditions (DB-agnostic).
     *  Each condition describes a check on the target node (flag match or required property). */
    conformanceConditions?: ConformanceCondition[];
    /** sh:class — the target SHACL node shape URI that linked nodes must conform to.
     *  Set automatically when a relation has a `target` model. Enables typed construction
     *  on the Rust/MCP side by referencing the full target shape. */
    class?: string;
    /** sh:in — allowed values for this property (enum constraint).
     *  Each entry has a `value` (the RDF term) and an optional `label` (human-readable name).
     *  Standard SHACL `sh:in` only defines values; labels are an AD4M extension. */
    in?: Array<{
        value: string;
        label?: string;
    }>;
    /** AD4M-specific: multi-valued property (`ad4m://CollectionShape`).
     *  `toJSON()` defaults it to true for `hasMany` and `belongsToMany`. */
    collection?: boolean;
    /** AD4M-specific: kind of relation this property describes.
     *  Drives direction (forward/reverse), scalar-vs-collection rendering,
     *  and default max-count. */
    relationKind?: 'hasMany' | 'hasOne' | 'belongsToOne' | 'belongsToMany';
    /** AD4M-specific: the relation is read `polymorphic: true` unless the query
     *  says otherwise (`ad4m://polymorphic`). Carried in the shape so the executor
     *  applies it at every include depth, below a polymorphic include too. */
    polymorphic?: boolean;
    /** AD4M-specific: target class name (local-name) for a relation property.
     *  Complements `class` (the SHACL node-shape URI) by providing the bare
     *  model class name used by the executor to look up the target shape
     *  through the perspective's shape cache. */
    targetClassName?: string;
    /** AD4M-specific: post-getter where-clause filter for a relation property. */
    whereFilter?: any;
    /** AD4M-specific: predicate-IRI lookup map for `whereFilter` keys
     *  (property name → predicate URI on the target class). */
    wherePredicates?: Record<string, string>;
    /** AD4M-specific: whether conformance/type filtering is enabled for this
     *  relation.  `false` opts out of DB-level type filtering while keeping
     *  hydration via `include`. */
    filter?: boolean;
    /** AD4M-specific: Transform expression (SHACL-AF Node Expression).
     *  Applied to a property's resolved value in the Rust model query engine —
     *  for values resolved through a `resolveLanguage` (`"literal"` for a signed
     *  envelope, or a custom language) and for any property that declares a
     *  transform. */
    transform?: NodeExpression;
    /** AD4M-specific: Natural-language hint that steers the generic LLM
     *  extractor when producing typed instances from a transcript.  Emitted
     *  as an `ad4m://interpretation_hint` link on the property shape node and
     *  surfaced on `ShapeProperty.interpretation_hint` by the Rust model query. */
    interpretationHint?: string;
    /** AD4M-specific: marks this property as the class's identity (dedup key)
     *  for the generic LLM interpreter. Emitted as an `ad4m://identity` link
     *  (`literal:string:true`) and read back on `ShapeProperty.identity`. */
    identity?: boolean;
    /** AD4M-specific: the name this property answers to when its class is read
     *  through an abstract class, keyed by the abstract class's name:
     *  `{ TextContent: "text" }`. Emitted as one `ad4m://alias` link
     *  (`literal:string:` + the URL-encoded JSON map). */
    alias?: Record<string, string>;
}
/**
 * SHACL Node Shape
 * Defines constraints for instances of a class
 */
export declare class SHACLShape {
    /** URI of this shape (e.g., recipe:RecipeShape) */
    nodeShapeUri: string;
    /** Target class this shape applies to (e.g., recipe:Recipe) */
    targetClass?: string;
    /** Property constraints */
    properties: SHACLPropertyShape[];
    /** AD4M-specific: Constructor actions for creating instances */
    constructor_actions?: AD4MAction[];
    /** AD4M-specific: Destructor actions for removing instances */
    destructor_actions?: AD4MAction[];
    /** Parent shape URIs for model inheritance (sh:node references) */
    parentShapes: string[];
    /** AD4M-specific: Natural-language hint that steers the generic LLM
     *  extractor when producing instances of this class.  Emitted as an
     *  `ad4m://interpretation_hint` link on the shape node itself and surfaced
     *  on `ModelShape.interpretation_hint` by the Rust model query. */
    interpretationHint?: string;
    /** AD4M-specific: an abstract class. Querying it reads every concrete class
     *  that has its property names; it is never created. Emitted as one
     *  `ad4m://abstract` link on the shape node. */
    isAbstract?: boolean;
    /**
     * Create a new SHACL Shape
     * @param targetClassOrShapeUri - If one argument: the target class (shape URI auto-derived as {class}Shape)
     *                                If two arguments: first is shape URI, second is target class
     * @param targetClass - Optional target class when first arg is shape URI
     */
    constructor(targetClassOrShapeUri: string, targetClass?: string);
    /**
     * Add a parent shape reference (sh:node) for model inheritance.
     * When a @Model class extends another @Model, the child shape
     * references the parent shape so SHACL validators can walk the
     * class hierarchy.
     */
    addParentShape(parentShapeUri: string): void;
    /**
     * Add a property constraint to this shape
     */
    addProperty(prop: SHACLPropertyShape): void;
    /**
     * Set constructor actions for this shape
     */
    setConstructorActions(actions: AD4MAction[]): void;
    /**
     * Set destructor actions for this shape
     */
    setDestructorActions(actions: AD4MAction[]): void;
    /**
     * Serialize shape to Turtle (RDF) format
     */
    toTurtle(): string;
    /**
     * Serialize shape to AD4M Links (RDF triples)
     * Stores the shape as a graph of links in a Perspective
     */
    toLinks(): Link[];
    /**
     * Reconstruct shape from AD4M Links
     */
    static fromLinks(links: Link[], shapeUri: string): SHACLShape;
    /**
     * The shape as `perspective.registerShapes` takes it and
     * `perspective.shapes` answers it: every field, so
     * `SHACLShape.fromJSON(shape.toJSON())` is the same shape.
     */
    toJSON(): ShapeJson;
    /**
     * Create a shape from a JSON object (inverse of toJSON)
     */
    static fromJSON(json: ShapeJson): SHACLShape;
}
