/**
 * Builder functions for SHACL-AF Node Expressions.
 *
 * These functions construct JSON-serializable expression trees for property transforms.
 * All builders return frozen objects to prevent accidental mutation.
 */
import type { NodeExpression } from './NodeExpression';
/**
 * Identity expression: pass the focus node through unchanged.
 */
export declare function focus(): NodeExpression;
/**
 * Literal constant expression.
 */
export declare function literal(value: string | number | boolean): NodeExpression;
/**
 * Path expression: navigate to a property on the resolved object.
 * The predicate can be a full IRI (e.g., "file_storage://data_base64")
 * or a simple property name. The Rust evaluator will strip the namespace.
 */
export declare function path(predicate: string): NodeExpression;
/**
 * Existence check: returns true if the inner expression is non-null and non-empty.
 */
export declare function exists(expr: NodeExpression): NodeExpression;
/**
 * Conditional expression with optional else branch.
 * Returns a chainable builder that supports `.then()` and `.else()`.
 */
export declare function ifExpr(cond: NodeExpression): {
    then: (thenExpr: NodeExpression) => {
        else: (elseExpr?: NodeExpression) => Readonly<{
            readonly else: NodeExpression;
            readonly type: "if";
            readonly cond: NodeExpression;
            readonly then: NodeExpression;
        }>;
        toExpression: () => Readonly<{
            readonly type: "if";
            readonly cond: NodeExpression;
            readonly then: NodeExpression;
        }>;
    };
};
/**
 * String concatenation: joins evaluated arguments as strings.
 * Null/undefined arguments are skipped.
 */
export declare function concat(...args: NodeExpression[]): NodeExpression;
/**
 * Coalesce: returns the first non-null evaluated argument.
 */
export declare function coalesce(...args: NodeExpression[]): NodeExpression;
/**
 * Function call: invoke a named transform function by IRI.
 * Primarily used for built-in functions like "ad4m://fn/defaultFileDecode".
 */
export declare function fn(iri: string, args?: NodeExpression[]): NodeExpression;
