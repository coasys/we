import { Link } from "../links/Links";
import { AD4MAction } from "./SHACLShape";
export { AD4MAction };
/**
 * Link pattern for state detection
 * Used to check if an expression is in a particular state
 */
export interface LinkPattern {
    /** Optional source pattern (if omitted, uses the expression address) */
    source?: string;
    /** Required predicate to match */
    predicate: string;
    /** Required target value to match */
    target: string;
}
/**
 * Per-property condition for a `ModelQuery`. String / number / boolean
 * shorthands compile to an equality match; the object forms are the full
 * shape a `ModelQuery` engine consumer will evaluate against a class
 * instance's decoded property value.
 *
 * Only the shorthand + `equals` / `in` / `exists` / `matches` operators are
 * declared in v1 (see design doc §4.1). More operators can land as
 * additional variants without a schema break.
 */
export type PropertyCondition = string | number | boolean | {
    equals: unknown;
} | {
    in: unknown[];
} | {
    exists: true;
} | {
    matches: string;
};
/**
 * A model-level query — the shape a flow's `requires` guard evaluates
 * against the perspective's current class-instance graph. Deliberately
 * higher-level than raw links so guards talk about subject classes, not
 * the underlying triples.
 *
 * See design doc §3 principle 2 ("Guards talk about models, not raw graph")
 * and §4.1 for the full field spec. Template variables allowed inside
 * `where` string values: `$flow.base`, `$flow.uri` (alias:
 * `$flow.instance`), `$did` — the engine substitutes at evaluation time.
 */
export interface ModelQuery {
    /** Subject-class URI to search for. */
    className: string;
    /**
     * Per-property conditions (all must match — AND semantics inside one
     * ModelQuery, same as AND semantics across an array of ModelQueries).
     */
    where?: {
        [prop: string]: PropertyCondition | string;
    };
    /**
     * Cardinality constraint on matching instances. Default `{ min: 1 }` —
     * at least one match required to satisfy the guard.
     */
    count?: {
        min?: number;
        max?: number;
    };
    /**
     * Scope the query to instances linked from a flow anchor. The anchor
     * (base subject or flow instance URI) is the **source** of the link and
     * the matched item is the **target**: `linkedTo: "base"` finds items
     * where the base subject links TO them via the default predicate
     * `ad4m://has_child`.
     *
     * `"base"` / `"flow"` use `ad4m://has_child`; the object form
     * `{ via, to }` names a custom predicate (e.g.
     * `{ via: "ns://about", to: "flow" }`).
     *
     * For the reverse direction (matched instance → anchor), use
     * `where: { about: "$flow.base" }` instead — `linkedTo` cannot
     * express that direction.
     */
    linkedTo?: "flow" | "base" | {
        via: string;
        to: "flow" | "base";
    };
    /**
     * When this query is used as a `ConsensusRule.fromRole`, names the
     * property on the matched instance that carries a DID. Design doc §7.2
     * Shape 1 (instance-carries-DID): engine runs the query, then extracts
     * `didProperty` from each result to build the eligible-DID set.
     *
     * Shape 2 (instance-is-per-DID, using `$did` templating in `where`)
     * omits `didProperty` — the engine iterates candidate DIDs and treats
     * a non-empty result set as "this DID matches."
     *
     * Ignored when the query is used as a state guard (`requires`) or
     * background `context`.
     */
    didProperty?: string;
    /**
     * OR-compose a role expression across multiple ModelQueries. Semantics:
     * a DID counts if it appears in the result of ANY branch (design §7.3
     * multi-role hybrid example — "either reviewer OR admin"). Branches
     * can carry their own `didProperty` / `where`, but NOT `linkedTo`
     * (which must be on the outer query — `linkedTo` on a branch is
     * rejected at translation time).
     *
     * Every branch must use the same `className` as the outer query and
     * cannot declare its own `count` — the outer query's class and
     * cardinality apply to the combined result set.
     *
     * A ModelQuery with a non-empty `or` array acts as a composition node;
     * its own `className` / `where` etc. still count as an additional
     * branch (union with the array). Empty or unset = no composition.
     *
     * Intentionally scoped to `or` for v1 — `and` / `not` fall out of the
     * same mechanism and can land later without a schema break (design
     * §7.4). Ignored when the query is used as a state guard or context.
     */
    or?: ModelQuery[];
    /**
     * When this query is used as a `ConsensusRule.fromRole`, require each
     * matched instance to be a valid output of a completed run of another
     * flow, and date the grant from that run's quorum instead of from an
     * assignment link.
     *
     * The same name and the same check as the model-query filter
     * `where: { producedByFlow }`: a receipt filed under `flow`'s index must
     * verify against this replica's own flow definitions, be for `flow`, have
     * settled into `state`, and name this instance (as this query's
     * `className`) among its outputs. Each replica checks this against its
     * own graph; the read-set carries only the resulting grant date.
     *
     * Two things to know before configuring one:
     * - An instance no verified receipt produced is simply not a member.
     *   There is no fallback to the assignment link — if there were, writing
     *   that link would grant the role and this gate would be decorative.
     * - **A granted role is not un-granted by undoing the flow.** Retracting
     *   a settling vote moves the live flow back; the receipt keeps
     *   verifying. The only un-grant is a new signed
     *   `ad4m://flow/role_grant_revoked` tombstone on the instance, from an
     *   author this query's own `where.author` accepts — so a query with no
     *   author condition can be revoked by anyone, and one naming an author
     *   who is not around cannot be revoked at all.
     *
     * Ignored when the query is used as a state guard (`requires`) or
     * background `context`.
     */
    producedByFlow?: ProducedByFlow;
}
/**
 * The granting-flow reference on a `fromRole` query's `producedByFlow`.
 *
 * The same shape as the model-query filter's `{ flow, state? }`, except
 * that `state` is required here: without it, a run that settled into a
 * flow's `rejected` state would grant what its `approved` state was meant
 * to.
 */
export interface ProducedByFlow {
    /** The granting flow's URI — `{namespace}{name}Flow`. */
    flow: string;
    /** The state that run must have settled into. */
    state: string;
}
/**
 * Consensus rule for a flow-state transition (or a top-level zero-state
 * flow's completion). Distinct DID counting with optional role
 * restriction.
 *
 * Design doc §7:
 * - `{ n: 1 }` — any agent's proposal advances (default).
 * - `{ n: 2 }` — two distinct agents must agree.
 * - `{ n, fromRole }` — only agents matching the role query count.
 *
 * `fromRole` reuses `ModelQuery` (design §7.2) so role definitions live
 * entirely in the ontology — communities can invent roles like
 * "Reviewer" / "Guardian" without any code change.
 */
export interface ConsensusRule {
    /** Required count of distinct qualifying DIDs. */
    n: number;
    /**
     * Optional role restriction. When set, only DIDs returned by the role
     * query are counted. Two evaluation shapes (design §7.2):
     *   Shape 1 — `didProperty` present: run once, extract DIDs from matches.
     *   Shape 2 — `$did` templated in `where`: run per candidate.
     *
     * The executor refuses a rule with a key it does not know, anywhere in
     * the rule (a misspelt `fromRole`, or `grantedByFlow` inside it), and a
     * key written twice. `addFlow` rejects such a definition before storing
     * it, with an error naming the state and the key. A definition that
     * arrived by sync is refused when read: the edge fires for nobody and the
     * executor log names the key. It does not drop the key and read a wider
     * gate.
     */
    fromRole?: ModelQuery;
}
/**
 * Flow State definition
 * Represents a single state in the flow state machine
 */
export interface FlowState {
    /** State name (e.g., "ready", "doing", "done") */
    name: string;
    /** Numeric state value for ordering (e.g., 0, 0.5, 1) */
    value: number;
    /**
     * Natural-language description of what puts a flow instance IN this state.
     * Used by AI-driven state suggestion (`suggestFlowState`) — the same
     * pattern subject classes use for `interpretationHint`. When set, the LLM
     * reads it alongside conversation content to suggest transitions.
     *
     * Example (Deliberation Flow, "Tension" state):
     *   "Participants have voiced opposing views or objections — there is a
     *   clear disagreement or unresolved conflict on the table."
     */
    interpretationHint?: string;
    /**
     * Model-level guard: the state is satisfied when every ModelQuery in
     * the array returns at least one match on committed graph state
     * (overlays do NOT count as evidence — design §3 principle 5).
     *
     * Array semantics: AND — every entry must match. Empty / unset =
     * no model-level guard.
     *
     * Design doc §4.1: "an array of queries, ALL must match; each query's
     * matches become evidence."
     */
    requires?: ModelQuery[];
    /**
     * Optional English hint for a targeted LLM confirmation before the
     * engine declares the state entered. Distinct from
     * `interpretationHint`, which frames the state semantically for the
     * up-front extraction pass — `semanticCheck` is the "am I still
     * confident?" pass the engine runs after `requires` matches, for
     * states where structural presence isn't enough (e.g. tension
     * resolution).
     *
     * Design doc §5 covers the LLM confirmation pass shape. Unset = no
     * confirmation, `requires` matches directly imply state entered.
     */
    semanticCheck?: string;
    /**
     * Per-state consensus rule override. When present, transitions INTO
     * this state require the specified number of distinct qualifying DIDs
     * (see `ConsensusRule`). Overrides the flow-level `consensusRule` if
     * both are set; when neither is set, the runtime engine's default of
     * `{ n: 1 }` applies (any single agent's action fires the transition).
     *
     * Design doc §4.1 (v3) — per-state override enables mixed-consensus
     * flows where e.g. "Perspective" states need only one voice but the
     * "Resolution" state requires a quorum.
     */
    consensusRule?: ConsensusRule;
}
/**
 * Flow Transition definition
 * Represents a transition between two states
 */
export interface FlowTransition {
    /** Name of this action (shown to users, e.g., "Start", "Finish") */
    actionName: string;
    /** State to transition from */
    fromState: string;
    /** State to transition to */
    toState: string;
    /** Actions to execute for this transition */
    actions: AD4MAction[];
}
/**
 * SHACL Flow - represents a state machine for AD4M expressions
 *
 * Flows define:
 * - Which expressions can enter the flow (via `inputTypes`)
 * - What states exist and their per-state guards (via `requires`)
 * - How to transition between states (via transitions + consensus rules)
 *
 * A running instance's state is not stored on the graph: the executor
 * derives it from the signed transition proposals and keeps what it derived
 * per agent, outside the perspective (#1424). Read it through the
 * `FlowInstance` wrapper ({@link FlowInstance.start} /
 * {@link FlowInstance.findAll}, `currentStateName`) or
 * `PerspectiveProxy.flowStates`, and follow it with
 * `PerspectiveProxy.onFlowStateChanged` — see design doc §4.3/§5.
 *
 * @example
 * ```typescript
 * const todoFlow = new SHACLFlow('todo://TODO', 'todo://');
 *
 * // Any expression can become a TODO
 * todoFlow.inputTypes = ['any'];
 *
 * todoFlow.addState({ name: 'ready', value: 0 });
 * todoFlow.addState({ name: 'doing', value: 0.5 });
 * todoFlow.addState({ name: 'done',  value: 1 });
 *
 * todoFlow.addTransition({
 *   actionName: 'Start',
 *   fromState: 'ready',
 *   toState: 'doing',
 *   actions: [],
 * });
 *
 * // Register on the perspective and mint an instance on a subject.
 * await perspective.addFlow('TODO', todoFlow);
 * const instance = await FlowInstance.start(perspective, 'TODO', 'expr://123');
 * ```
 */
export declare class SHACLFlow {
    /**
     * Every predicate {@link toLinks} writes from the flow's own URI. The
     * flow's URI also carries links the definition does not own (a receipt
     * index, for one), so replacing a definition removes only these from it.
     * Keep in step with `toLinks`.
     */
    static readonly FLOW_LEVEL_PREDICATES: readonly string[];
    /**
     * Every predicate {@link toLinks} writes from a state's or a transition's
     * URI, plus the retired `ad4m://stateCheck`, so a re-add still clears it
     * from an older definition. These URIs can carry links the definition does
     * not own too (an app's label on a state, for one), so replacing a
     * definition removes only these from them. Keep in step with `toLinks`.
     */
    static readonly STATE_AND_TRANSITION_PREDICATES: readonly string[];
    /** Flow name (e.g., "TODO") */
    name: string;
    /** Namespace for generated URIs */
    namespace: string;
    /**
     * Top-level natural-language description of what the flow is about — used
     * by AI-driven state suggestion (`suggestFlowState`) to frame the state
     * hints. Optional; states' own `interpretationHint`s are what actually
     * discriminate. Example (Deliberation Flow):
     *   "Tracks a group deliberation from an initial proposal to a shared
     *   understanding — through voicing perspectives, surfacing tension, and
     *   finding overlap."
     */
    interpretationHint?: string;
    /**
     * Subject-class URIs the flow accepts as its base expression.
     *
     * Design doc §4.1: a flow's *typed input*. When an
     * expression whose class matches any URI in this array enters scope,
     * the flow-spawn engine considers it a candidate base. Superseded
     * the older link-level `flowable: LinkPattern` primitive — model-level
     * matching by subject class instead of link matching. Empty array =
     * flow declares no typed input. The `"any"` sentinel is accepted as
     * a wildcard for tests and legacy flows.
     */
    inputTypes: string[];
    /**
     * Subject-class URIs the flow must produce (linked to the base) for a
     * run to count as complete.
     *
     * Design doc §4.1: a flow's *typed output*. Two jobs:
     * (a) documentation for stateful flows — records what a completed run
     * leaves in the graph; (b) **terminal condition** for zero-state flows —
     * a flow with no `FlowState`s completes when at least one instance of
     * each `outputTypes` entry exists in scope and is linked to the base,
     * and `consensusRule` fires. This is what makes "Like" a first-class
     * flow with no state machine.
     */
    outputTypes: string[];
    /**
     * Optional English hint for AI-driven flow-spawn: when should the
     * interpretation engine mint a new instance of this flow (as opposed
     * to advancing an existing one)?
     *
     * Design doc §4.1: analogous to `interpretationHint` on subject
     * classes — steers the LLM's up-front extraction pass. Distinct from
     * `interpretationHint` on the flow, which describes what the flow *is*.
     * Example (Delivery Flow): "Spawn when someone commits to a concrete,
     * actionable task."
     */
    creationHint?: string;
    /**
     * Optional background queries pulled into the LLM prompt as CONTEXT
     * (not evidence).
     *
     * Design doc §4.1: engine evaluates each `ModelQuery` and threads
     * matches into the prompt so the LLM can reason with them, but
     * matches do NOT count toward `requires` guards on states. Same
     * `ModelQuery[]` shape and template-variable rules as `FlowState.requires`.
     * Empty / unset = no context queries.
     */
    context?: ModelQuery[];
    /**
     * Flow-level consensus rule. Two roles:
     *  - **Default for state transitions** — when a `FlowState` doesn't
     *    declare its own `consensusRule`, transitions into it fall back
     *    to this rule.
     *  - **Zero-state flow completion** — for actions-as-flows (a flow
     *    with no `FlowState`s), this is the rule the engine checks the
     *    moment `outputTypes` are satisfied. E.g. a Like flow declares
     *    `{ n: 1 }` and completes on the first author.
     *
     * Design doc §4.1: terminal condition for stateless flows.
     * Unset = engine default of `{ n: 1 }` applies at both layers.
     */
    consensusRule?: ConsensusRule;
    /**
     * States in this flow.
     *
     * **Ordering convention (James PR #929 R9):** the array is stored sorted
     * ascending by `value`, ties broken by state name ascending (code-point
     * order), NaN values last. `states[0]` is the initial state — the one
     * {@link FlowInstance.start} mints a fresh instance into. A flow author
     * who wants a specific state as the entry point must give it the lowest
     * `value` in the set; two states sharing the lowest value start in the
     * one whose name sorts first (#1202). `fromLinks` enforces this sort, so
     * link-order on the graph never dictates the initial state.
     */
    private _states;
    /** Transitions between states */
    private _transitions;
    /**
     * Create a new SHACL Flow
     * @param name - Flow name (e.g., "TODO")
     * @param namespace - Namespace for URIs (e.g., "todo://")
     */
    constructor(name: string, namespace: string);
    /** Get all states */
    get states(): FlowState[];
    /** Get all transitions */
    get transitions(): FlowTransition[];
    /**
     * Add a state to the flow
     * @param state - State definition
     */
    addState(state: FlowState): void;
    /**
     * Add a transition to the flow
     * @param transition - Transition definition
     */
    addTransition(transition: FlowTransition): void;
    /**
     * Get the flow shape URI
     */
    get flowUri(): string;
    /**
     * Get a state URI
     */
    stateUri(stateName: string): string;
    /**
     * Get a transition URI: `{namespace}{name}.transition/{from}/{to}/{action}`.
     * Each part is RFC 3986-encoded, so the URI is unique per transition. The
     * executor's flow writer (`parse_flow_to_links`) builds the same URI.
     */
    transitionUri(fromState: string, toState: string, actionName: string): string;
    /**
     * Serialize the flow to AD4M links
     * These links can be stored in a perspective and queried via SPARQL
     *
     * @returns Array of Link objects representing the flow
     */
    toLinks(): Link[];
    /**
     * Reconstruct a SHACLFlow from links
     *
     * @param links - Array of links containing the flow definition
     * @param flowUri - The URI of the flow to reconstruct
     * @returns Reconstructed SHACLFlow
     */
    static fromLinks(links: Link[], flowUri: string): SHACLFlow;
    /**
     * Convert to JSON representation
     */
    toJSON(): object;
    /**
     * Create from JSON representation
     */
    static fromJSON(json: any): SHACLFlow;
}
