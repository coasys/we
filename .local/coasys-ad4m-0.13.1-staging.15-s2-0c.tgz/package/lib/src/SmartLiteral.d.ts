import { PerspectiveProxy } from "./perspectives/PerspectiveProxy";
export declare const SMART_LITERAL_CONTENT_PREDICATE = "smart_literal://content";
export declare class SmartLiteral {
    #private;
    constructor(perspective: PerspectiveProxy, base: string);
    get base(): string;
    static create(perspective: PerspectiveProxy, literal: any): Promise<SmartLiteral>;
    static isSmartLiteralBase(perspective: PerspectiveProxy, base: string): Promise<boolean>;
    static getAllSmartLiterals(perspective: PerspectiveProxy): Promise<SmartLiteral[]>;
    get(): Promise<any>;
    set(content: any): Promise<void>;
}
