export declare const typeDefsString = "";
